import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// Types
export type UserRole = 'patient' | 'doctor' | 'admin';
export type ServiceType = 'telehealth' | 'emergency';
export type AppointmentStatus = 'pending' | 'doctor_assigned' | 'in_progress' | 'completed' | 'cancelled';
export type PlanStatus = 'active' | 'inactive' | 'expired';

export interface User {
  id: string;
  uuid?: string;
  email: string;
  name: string;
  firstName?: string;
  lastName?: string;
  role: UserRole;
  avatar?: string;
  phone?: string;
  city?: string;
  dateOfBirth?: string;
  gender?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  specialization?: string; // For doctors
  isActive?: boolean;
}

export interface Plan {
  id: string;
  name: string;
  price: number;
  validityDays: number;
  services: ServiceType[];
  description: string;
  features: string[];
  isActive: boolean;
}

export interface UserPlan {
  id: string;
  planId: string;
  userId: string;
  startDate: string;
  endDate: string;
  status: PlanStatus;
}

export interface Appointment {
  id: string;
  patientId: string;
  doctorId?: string;
  planId: string;
  serviceType: ServiceType;
  status: AppointmentStatus;
  city: string;
  dateTime: string;
  patientDetails: {
    age: number;
    gender: string;
    emergencyContact: string;
  };
  prescription?: Prescription;
  createdAt: string;
  videoCallStarted?: boolean;
}

export interface Prescription {
  id: string;
  appointmentId: string;
  diagnosis: string;
  medicines: {
    name: string;
    dosage: string;
    duration: string;
    frequency?: string;
    foodInstructions?: string;
  }[];
  generalAdvice?: string;
  restrictions?: string;
  notes: string;
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
}

// No mock domain data; all domain entities should come from backend APIs.

// Cities for dropdown
export const cities = [
  'New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix',
  'Philadelphia', 'San Antonio', 'San Diego', 'Dallas', 'Miami',
  'London', 'Paris', 'Tokyo', 'Sydney', 'Dubai'
];

// Store Interface
interface AppState {
  // Auth
  currentUser: User | null;
  isAuthenticated: boolean;
  
  // Data
  users: User[];
  plans: Plan[];
  userPlans: UserPlan[];
  appointments: Appointment[];
  notifications: Notification[];
  
  // Actions
  login: (email: string, password: string, role: UserRole) => boolean;
  register: (user: Omit<User, 'id'>, password: string) => boolean;
  logout: () => void;
  switchRole: (role: UserRole) => void;
  setUser: (user: User) => void;
  
  // Plan actions
  purchasePlan: (planId: string) => void;
  createPlan: (plan: Omit<Plan, 'id'>) => void;
  updatePlan: (planId: string, updates: Partial<Plan>) => void;
  
  // Appointment actions
  createAppointment: (appointment: Omit<Appointment, 'id' | 'createdAt'>) => void;
  assignDoctor: (appointmentId: string, doctorId: string) => void;
  updateAppointmentStatus: (appointmentId: string, status: AppointmentStatus) => void;
  startVideoCall: (appointmentId: string) => void;
  addPrescription: (appointmentId: string, prescription: Omit<Prescription, 'id' | 'appointmentId' | 'createdAt'>) => void;
  
  // Doctor actions
  addDoctor: (doctor: Omit<User, 'id' | 'role'>) => void;
  updateDoctor: (doctorId: string, updates: Partial<User>) => void;
  
  // Notification actions
  addNotification: (notification: Omit<Notification, 'id' | 'createdAt'>) => void;
  markNotificationRead: (notificationId: string) => void;
  
  // Getters
  getCurrentUserPlan: () => (UserPlan & { plan: Plan }) | null;
  getPatientAppointments: () => Appointment[];
  getDoctorAppointments: () => Appointment[];
  getUserNotifications: () => Notification[];
}

const generateId = () => Math.random().toString(36).substr(2, 9);

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      currentUser: null,
      isAuthenticated: false,
      users: [],
      plans: [],
      userPlans: [],
      appointments: [],
      notifications: [],

      // Legacy demo auth functions (no longer used in production).
      // Real authentication is handled via backend JWT + authApi.
      login: () => false,
      register: () => false,

      logout: () => {
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
        set({ currentUser: null, isAuthenticated: false });
      },

      setUser: (user: User) => set({ currentUser: user, isAuthenticated: true }),

      switchRole: () => {},

      purchasePlan: (planId) => {
        const { currentUser, userPlans, plans } = get();
        if (!currentUser) return;
        
        const plan = plans.find(p => p.id === planId);
        if (!plan) return;
        
        const startDate = new Date();
        const endDate = new Date();
        endDate.setDate(endDate.getDate() + plan.validityDays);
        
        const newUserPlan: UserPlan = {
          id: generateId(),
          planId,
          userId: currentUser.id,
          startDate: startDate.toISOString(),
          endDate: endDate.toISOString(),
          status: 'active',
        };
        
        set({ userPlans: [...userPlans, newUserPlan] });
      },

      createPlan: (planData) => {
        const newPlan: Plan = { ...planData, id: generateId() };
        set({ plans: [...get().plans, newPlan] });
      },

      updatePlan: (planId, updates) => {
        set({
          plans: get().plans.map(p => p.id === planId ? { ...p, ...updates } : p),
        });
      },

      createAppointment: (appointmentData) => {
        const newAppointment: Appointment = {
          ...appointmentData,
          id: generateId(),
          createdAt: new Date().toISOString(),
        };
        set({ appointments: [...get().appointments, newAppointment] });
      },

      assignDoctor: (appointmentId, doctorId) => {
        set({
          appointments: get().appointments.map(a =>
            a.id === appointmentId
              ? { ...a, doctorId, status: 'doctor_assigned' as AppointmentStatus }
              : a
          ),
        });
      },

      updateAppointmentStatus: (appointmentId, status) => {
        set({
          appointments: get().appointments.map(a =>
            a.id === appointmentId ? { ...a, status } : a
          ),
        });
      },

      startVideoCall: (appointmentId) => {
        set({
          appointments: get().appointments.map(a =>
            a.id === appointmentId
              ? { ...a, videoCallStarted: true, status: 'in_progress' as AppointmentStatus }
              : a
          ),
        });
      },

      addPrescription: (appointmentId, prescriptionData) => {
        const prescription: Prescription = {
          ...prescriptionData,
          id: generateId(),
          appointmentId,
          createdAt: new Date().toISOString(),
        };
        set({
          appointments: get().appointments.map(a =>
            a.id === appointmentId
              ? { ...a, prescription, status: 'completed' as AppointmentStatus }
              : a
          ),
        });
      },

      addDoctor: (doctorData) => {
        const newDoctor: User = { ...doctorData, id: generateId(), role: 'doctor', isActive: true };
        set({ users: [...get().users, newDoctor] });
      },

      updateDoctor: (doctorId, updates) => {
        set({
          users: get().users.map(u => u.id === doctorId ? { ...u, ...updates } : u),
        });
      },

      addNotification: (notificationData) => {
        const notification: Notification = {
          ...notificationData,
          id: generateId(),
          createdAt: new Date().toISOString(),
        };
        set({ notifications: [...get().notifications, notification] });
      },

      markNotificationRead: (notificationId) => {
        set({
          notifications: get().notifications.map(n =>
            n.id === notificationId ? { ...n, read: true } : n
          ),
        });
      },

      getCurrentUserPlan: () => {
        const { currentUser, userPlans, plans } = get();
        if (!currentUser) return null;
        
        const userPlan = userPlans.find(
          up => up.userId === currentUser.id && up.status === 'active'
        );
        if (!userPlan) return null;
        
        const plan = plans.find(p => p.id === userPlan.planId);
        if (!plan) return null;
        
        return { ...userPlan, plan };
      },

      getPatientAppointments: () => {
        const { currentUser, appointments } = get();
        if (!currentUser) return [];
        return appointments.filter(a => a.patientId === currentUser.id);
      },

      getDoctorAppointments: () => {
        const { currentUser, appointments } = get();
        if (!currentUser) return [];
        return appointments.filter(a => a.doctorId === currentUser.id);
      },

      getUserNotifications: () => {
        const { currentUser, notifications } = get();
        if (!currentUser) return [];
        return notifications.filter(n => n.userId === currentUser.id);
      },
    }),
    {
      name: 'navala-health-store',
    }
  )
);
