import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Bell, Mail, Loader2 } from 'lucide-react';
import { notificationSettingsApi, type NotificationSettingsData } from '@/services/api';
import { toast } from 'sonner';

export function NotificationSettingsCard() {
  const [settings, setSettings] = useState<NotificationSettingsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    try {
      setLoading(true);
      const res = await notificationSettingsApi.get();
      if (res.success && res.data) setSettings(res.data);
      else setSettings(defaultSettings());
    } catch {
      setSettings(defaultSettings());
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  function defaultSettings(): NotificationSettingsData {
    return {
      emailAppointments: true,
      emailReminders: true,
      emailPromo: false,
      inAppEnabled: true,
    };
  }

  const update = async (key: keyof NotificationSettingsData, value: boolean) => {
    if (!settings) return;
    const next = { ...settings, [key]: value };
    setSettings(next);
    setSaving(true);
    try {
      const res = await notificationSettingsApi.update({ [key]: value });
      if (res.success) {
        if (res.data) setSettings(res.data);
        toast.success('Notification settings saved');
      } else toast.error(res.message || 'Failed to save');
    } catch (e) {
      setSettings(settings);
      toast.error('Failed to save notification settings');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <Card className="shadow-card border-0">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Bell className="h-5 w-5 text-accent" />
            Notification settings
          </CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  const s = settings ?? defaultSettings();

  return (
    <Card className="shadow-card border-0">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Bell className="h-5 w-5 text-accent" />
          Notification settings
        </CardTitle>
        <CardDescription>
          Choose how you want to receive notifications. These are stored in your account and apply across devices.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between gap-4">
          <div className="space-y-0.5">
            <Label htmlFor="email-appointments" className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-muted-foreground" />
              Appointment emails
            </Label>
            <p className="text-xs text-muted-foreground">Confirmations and updates for appointments</p>
          </div>
          <Switch
            id="email-appointments"
            checked={s.emailAppointments}
            onCheckedChange={(v) => update('emailAppointments', v)}
            disabled={saving}
          />
        </div>
        <div className="flex items-center justify-between gap-4">
          <div className="space-y-0.5">
            <Label htmlFor="email-reminders" className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-muted-foreground" />
              Reminder emails
            </Label>
            <p className="text-xs text-muted-foreground">Medication and appointment reminders by email</p>
          </div>
          <Switch
            id="email-reminders"
            checked={s.emailReminders}
            onCheckedChange={(v) => update('emailReminders', v)}
            disabled={saving}
          />
        </div>
        <div className="flex items-center justify-between gap-4">
          <div className="space-y-0.5">
            <Label htmlFor="email-promo" className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-muted-foreground" />
              Promotional emails
            </Label>
            <p className="text-xs text-muted-foreground">Offers and health tips (optional)</p>
          </div>
          <Switch
            id="email-promo"
            checked={s.emailPromo}
            onCheckedChange={(v) => update('emailPromo', v)}
            disabled={saving}
          />
        </div>
        <div className="flex items-center justify-between gap-4">
          <div className="space-y-0.5">
            <Label htmlFor="in-app" className="flex items-center gap-2">
              <Bell className="h-4 w-4 text-muted-foreground" />
              In-app notifications
            </Label>
            <p className="text-xs text-muted-foreground">Bell icon alerts when you are logged in</p>
          </div>
          <Switch
            id="in-app"
            checked={s.inAppEnabled}
            onCheckedChange={(v) => update('inAppEnabled', v)}
            disabled={saving}
          />
        </div>
      </CardContent>
    </Card>
  );
}
