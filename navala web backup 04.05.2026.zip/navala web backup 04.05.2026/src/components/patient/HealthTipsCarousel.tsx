import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Sparkles, 
  ChevronLeft, 
  ChevronRight,
  Droplets,
  Moon,
  Salad,
  Plane,
  Shield,
  Pill,
} from 'lucide-react';

interface HealthTip {
  id: string;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  color: string;
}

const healthTips: HealthTip[] = [
  {
    id: '1',
    icon: Droplets,
    title: 'Stay Hydrated',
    description: 'Drink at least 8 oz of water for every hour in the air to prevent fatigue and jet lag during flights.',
    color: 'bg-accent/10 text-accent',
  },
  {
    id: '2',
    icon: Moon,
    title: 'Adjust Your Sleep',
    description: 'Start adjusting your sleep schedule 2-3 days before traveling to a new time zone.',
    color: 'bg-primary/10 text-primary',
  },
  {
    id: '3',
    icon: Salad,
    title: 'Eat Light While Traveling',
    description: 'Choose light, nutritious meals while traveling to avoid digestive issues and maintain energy levels.',
    color: 'bg-success/10 text-success',
  },
  {
    id: '4',
    icon: Plane,
    title: 'Move During Long Flights',
    description: 'Walk around and stretch every 2 hours on long flights to prevent deep vein thrombosis (DVT).',
    color: 'bg-warning/10 text-warning',
  },
  {
    id: '5',
    icon: Shield,
    title: 'Check Vaccinations',
    description: 'Verify required vaccinations for your destination country at least 6 weeks before travel.',
    color: 'bg-destructive/10 text-destructive',
  },
  {
    id: '6',
    icon: Pill,
    title: 'Pack Essential Medications',
    description: 'Always carry essential medications in your hand luggage with copies of prescriptions.',
    color: 'bg-accent/10 text-accent',
  },
];

export function HealthTipsCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % healthTips.length);
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + healthTips.length) % healthTips.length);
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % healthTips.length);
  };

  const currentTip = healthTips[currentIndex];

  return (
    <Card className="rounded-xl border border-border/60 bg-card shadow-sm overflow-hidden bg-gradient-to-r from-accent/5 via-transparent to-primary/5">
      <CardContent className="p-5">
        <div className="flex items-start gap-4">
          <div className={`h-12 w-12 rounded-xl flex items-center justify-center shrink-0 border border-border/40 ${currentTip.color.split(' ')[0]}`}>
            <currentTip.icon className={`h-6 w-6 ${currentTip.color.split(' ')[1]}`} strokeWidth={2} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="h-4 w-4 text-accent" strokeWidth={2} />
              <span className="text-xs font-medium text-accent uppercase tracking-wide">Travel Health Tip</span>
            </div>
            <h3 className="font-semibold text-foreground mb-1">{currentTip.title}</h3>
            <p className="text-sm text-muted-foreground">{currentTip.description}</p>
          </div>
          <div className="flex items-center gap-0.5 shrink-0">
            <Button variant="ghost" size="icon" className="h-9 w-9 rounded-lg" onClick={goToPrevious} title="Previous tip">
              <ChevronLeft className="h-5 w-5" strokeWidth={2} />
            </Button>
            <Button variant="ghost" size="icon" className="h-9 w-9 rounded-lg" onClick={goToNext} title="Next tip">
              <ChevronRight className="h-5 w-5" strokeWidth={2} />
            </Button>
          </div>
        </div>
        {/* Dots + arrows hint */}
        <div className="flex justify-center items-center gap-2 mt-4">
          <div className="flex justify-center gap-1.5">
            {healthTips.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`h-1.5 rounded-full transition-all ${
                  index === currentIndex
                    ? 'w-6 bg-primary'
                    : 'w-1.5 bg-muted-foreground/30 hover:bg-muted-foreground/50'
                }`}
                aria-label={`Tip ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
