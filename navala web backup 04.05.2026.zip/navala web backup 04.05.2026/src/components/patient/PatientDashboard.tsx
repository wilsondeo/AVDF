import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { PlanCard } from '@/components/patient/PlanCard';
import { HealthVitalsCard } from '@/components/patient/HealthVitalsCard';
import { HealthTipsCarousel } from '@/components/patient/HealthTipsCarousel';
import { MedicationReminder } from '@/components/patient/MedicationReminder';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Link, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Calendar,
  FileText,
  CreditCard,
  Clock,
  ArrowRight,
  User,
  Stethoscope,
  Activity,
  Loader2,
  Globe2,
  PlusCircle,
  AlertCircle,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { planApi, paymentApi, patientVitalsApi, patientMedicationsApi, familyMembersApi, type Plan } from '@/services/api';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { PLAN_BENEFITS_AVAILABLE } from '@/config/patientPlan';

const getNavigation = (hasActivePlan: boolean) => [
  { name: 'Dashboard', href: '/patient', icon: LayoutDashboard },
  { name: 'My Appointments', href: '/patient/appointments', icon: Calendar, disabled: !hasActivePlan },
  { name: 'Prescriptions', href: '/patient/prescriptions', icon: FileText, disabled: !hasActivePlan },
  { name: 'My Plan', href: '/patient/plans', icon: CreditCard },
  { name: 'New Plans', href: '/patient/new-plans', icon: CreditCard },
];

/** Score a single vital 0–100 based on normal ranges */
function scoreVital(
  key: 'heartRate' | 'bloodPressureSystolic' | 'bloodPressureDiastolic' | 'temperature' | 'oxygenLevel',
  value: number | null
): number | null {
  if (value == null) return null;
  switch (key) {
    case 'heartRate':
      if (value >= 60 && value <= 100) return 100;
      if (value >= 50 && value < 60) return 80;
      if (value > 100 && value <= 110) return 80;
      return Math.max(0, 60 - Math.abs(value - 80));
    case 'bloodPressureSystolic':
      if (value <= 120) return 100;
      if (value <= 140) return 70;
      return 50;
    case 'bloodPressureDiastolic':
      if (value <= 80) return 100;
      if (value <= 90) return 70;
      return 50;
    case 'temperature':
      if (value >= 97 && value <= 99) return 100;
      if (value >= 96 && value < 97) return 80;
      if (value > 99 && value <= 100) return 80;
      return 50;
    case 'oxygenLevel':
      if (value >= 95 && value <= 100) return 100;
      if (value >= 90 && value < 95) return 70;
      return 50;
    default:
      return null;
  }
}

/** Compute overall health score 0–100 from latest vitals and today's medication adherence */
function computeHealthScore(
  vitals: { heartRate?: number | null; bloodPressureSystolic?: number | null; bloodPressureDiastolic?: number | null; temperature?: number | null; oxygenLevel?: number | null } | null,
  medications: { taken: boolean }[]
): number | null {
  const vitalsScores: number[] = [];
  if (vitals) {
    if (vitals.heartRate != null) {
      const s = scoreVital('heartRate', vitals.heartRate);
      if (s != null) vitalsScores.push(s);
    }
    if (vitals.bloodPressureSystolic != null) {
      const s = scoreVital('bloodPressureSystolic', vitals.bloodPressureSystolic);
      if (s != null) vitalsScores.push(s);
    }
    if (vitals.bloodPressureDiastolic != null) {
      const s = scoreVital('bloodPressureDiastolic', vitals.bloodPressureDiastolic);
      if (s != null) vitalsScores.push(s);
    }
    if (vitals.temperature != null) {
      const s = scoreVital('temperature', vitals.temperature);
      if (s != null) vitalsScores.push(s);
    }
    if (vitals.oxygenLevel != null) {
      const s = scoreVital('oxygenLevel', vitals.oxygenLevel);
      if (s != null) vitalsScores.push(s);
    }
  }
  const vitalsScore = vitalsScores.length ? vitalsScores.reduce((a, b) => a + b, 0) / vitalsScores.length : null;
  const medTotal = medications.length;
  const medTaken = medications.filter((m) => m.taken).length;
  const medicationScore = medTotal > 0 ? (medTaken / medTotal) * 100 : null;

  if (vitalsScore != null && medicationScore != null) {
    return Math.round(0.6 * vitalsScore + 0.4 * medicationScore);
  }
  if (vitalsScore != null) return Math.round(vitalsScore);
  if (medicationScore != null) return Math.round(medicationScore);
  return null;
}

export default function PatientDashboard() {
  const { currentUser, getPatientAppointments } = useAppStore();
  const [currentPlan, setCurrentPlan] = useState<any>(null);
  const appointments = getPatientAppointments();
  const [availablePlans, setAvailablePlans] = useState<Plan[]>([]);
  const [loadingPlans, setLoadingPlans] = useState(false);
  const [loadingActivePlan, setLoadingActivePlan] = useState(true);
  const [healthScore, setHealthScore] = useState<number | null>(null);
  const [showFamilyUpgradeDialog, setShowFamilyUpgradeDialog] = useState(false);
  const navigate = useNavigate();

  /** Plan window: June 9 – July 20. Only appointments in this window show as "upcoming". */
  const getPlanWindowForYear = (year: number) => ({
    start: new Date(year, 5, 9),
    end: new Date(year, 6, 20),
  });
  const isInPlanWindow = (dateTime: string | Date) => {
    const d = new Date(dateTime);
    const { start, end } = getPlanWindowForYear(d.getFullYear());
    return d >= start && d <= end;
  };

  const upcomingAppointments = appointments.filter(
    (a) =>
      a.status !== 'completed' &&
      a.status !== 'cancelled' &&
      isInPlanWindow(a.dateTime)
  );

  const isHighestPlan =
    !!currentPlan &&
    availablePlans.length > 0 &&
    (() => {
      const currentPrice =
        typeof currentPlan.plan?.price === 'string'
          ? parseFloat(currentPlan.plan.price)
          : (currentPlan.plan?.price ?? 0);
      const maxPrice = Math.max(
        ...availablePlans.map((p) =>
          typeof p.price === 'string' ? parseFloat(p.price) : (p.price ?? 0)
        )
      );
      return currentPrice >= maxPrice;
    })();

  // Load available plans (even without purchase)
  useEffect(() => {
    loadAvailablePlans();
    loadActivePlan();
  }, []);

  const refreshHealthScore = async () => {
    try {
      const [vitalsRes, medsRes] = await Promise.all([
        patientVitalsApi.getList(1),
        patientMedicationsApi.getList(),
      ]);
      const latestVitals = vitalsRes.success && vitalsRes.data?.length ? vitalsRes.data[0] : null;
      const meds = medsRes.success && medsRes.data ? medsRes.data : [];
      setHealthScore(computeHealthScore(latestVitals ?? null, meds));
    } catch {
      setHealthScore(null);
    }
  };

  // Load vitals + medications and compute health score (on mount and when window regains focus)
  useEffect(() => {
    refreshHealthScore();
    const onFocus = () => refreshHealthScore();
    window.addEventListener('focus', onFocus);
    return () => window.removeEventListener('focus', onFocus);
  }, []);

  const loadActivePlan = async () => {
    try {
      setLoadingActivePlan(true);
      const res = await paymentApi.getActiveUserPlan();
      const active = res.success ? res.data?.activePlan : null;
      if (active && (active as any).plan) {
        setCurrentPlan({
          endDate: (active as any).endDate,
          plan: (active as any).plan,
        });
      } else {
        setCurrentPlan(null);
      }
    } finally {
      setLoadingActivePlan(false);
    }
  };

  const loadAvailablePlans = async () => {
    try {
      setLoadingPlans(true);
      const response = await planApi.getActivePlans();
      if (response.success && response.data) {
        // Normalize plans
        const normalizedPlans = response.data.plans.map(plan => ({
          ...plan,
          services: Array.isArray(plan.services) 
            ? plan.services 
            : (typeof plan.services === 'string' ? JSON.parse(plan.services) : []),
          features: Array.isArray(plan.features)
            ? plan.features
            : (typeof plan.features === 'string' ? JSON.parse(plan.features) : []),
          price: typeof plan.price === 'string' ? parseFloat(plan.price) : (plan.price || 0),
        }));
        setAvailablePlans(normalizedPlans);
      }
    } catch (error) {
      console.error('Failed to load plans:', error);
    } finally {
      setLoadingPlans(false);
    }
  };

  const handleAddFamilyMember = () => {
    if (!currentPlan || !currentPlan.plan) {
      setShowFamilyUpgradeDialog(true);
      return;
    }
    
    const maxPersons = currentPlan.plan.maxPersons || 1;
    if (maxPersons <= 1) {
      setShowFamilyUpgradeDialog(true);
      return;
    }
    
    navigate('/patient/profile');
  };

  // While loading active plan, show a spinner to avoid flicker
  if (loadingActivePlan) {
    return (
      <DashboardLayout navigation={getNavigation(false)} title="Patient Dashboard">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  // If no plan, show a simple plan purchase prompt (no extra static marketing)
  if (!currentPlan) {
    return (
      <DashboardLayout navigation={getNavigation(false)} title="Patient Dashboard">
        <div className="max-w-3xl mx-auto space-y-6 py-10">
          <Card className="shadow-card border-0">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">No Active Plan</CardTitle>
              <CardDescription>
                You need an active plan to book appointments.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center pb-8">
              <Link to="/patient/plans">
                <Button variant="hero" size="lg">
                  <CreditCard className="h-5 w-5 mr-2" />
                  View Plans
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout navigation={getNavigation(true)} title="Patient Dashboard">
      <div className="space-y-8 animate-fade-in">
        {/* Compact welcome strip */}
        <div className="rounded-xl border border-border/60 bg-card px-4 py-3 md:px-5 md:py-3.5 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-xl font-bold text-foreground">
                Welcome {currentUser?.name?.split(' ')[0]} 
              </h1>
              <Badge variant="success" className="font-medium rounded-md bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
                {currentPlan?.plan?.name}
              </Badge>
              <span className="text-xs text-muted-foreground">
                {`Your plan runs from ${PLAN_BENEFITS_AVAILABLE.dateRange}.`}
              </span>
            </div>
            <div className="flex items-center gap-2 sm:ml-auto">
              <Link to="/patient/profile">
                <Button variant="outline" size="sm" className="rounded-lg h-9">
                  <User className="h-4 w-4 mr-1.5" strokeWidth={2} />
                  Profile
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Travel health banner - Redesigned */}
        <div className="relative overflow-hidden rounded-2xl border border-primary/10 bg-gradient-to-br from-primary/5 via-background to-accent/5 shadow-md">
          <div className="absolute top-0 right-0 w-1/3 h-full opacity-10 pointer-events-none">
            <Globe2 className="w-full h-full text-primary -mr-20 -mt-10 rotate-12" />
          </div>
          <div className="flex flex-col md:flex-row items-center gap-6 p-6 md:p-8">
            <div className="flex-1 space-y-4 text-center md:text-left z-10">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-bold uppercase tracking-wider">
                <ShieldCheck className="h-3.5 w-3.5" />
                Your Medical Home Abroad
              </div>
              <h2 className="text-2xl md:text-3xl font-extrabold text-foreground leading-tight">
                Navala Travel Health is your <span className="text-primary italic">medical home</span> while you travel.
              </h2>
              <p className="text-sm md:text-base text-muted-foreground max-w-xl leading-relaxed">
                Wherever you are between June 9th and July 20th, you can book telehealth or in‑city
                care through Navala—without worrying about navigating the U.S. healthcare system
                alone.
              </p>
              <div className="flex flex-wrap justify-center md:justify-start gap-3 pt-2">
                <Link to="/patient/book">
                  <Button className="rounded-xl bg-primary text-primary-foreground shadow-lg hover:shadow-primary/20 hover:scale-105 transition-all font-bold px-6">
                    <Calendar className="h-4 w-4 mr-2" />
                    Book Appointment
                  </Button>
                </Link>
                <Link to="/patient/plans">
                  <Button variant="outline" className="rounded-xl border-primary/20 hover:bg-primary/5 font-bold px-6">
                    <CreditCard className="h-4 w-4 mr-2" />
                    View My Plan
                  </Button>
                </Link>
              </div>
            </div>
            <div className="w-full md:w-72 lg:w-80 shrink-0">
              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-primary to-accent rounded-2xl blur opacity-25 group-hover:opacity-40 transition duration-1000 group-hover:duration-200"></div>
                <div className="relative h-48 md:h-56 rounded-2xl overflow-hidden shadow-2xl border-4 border-white dark:border-slate-900">
                  <img 
                    src="https://cdn.sanity.io/images/0vv8moc6/physpractice/3737684e4ae1cf09758575266c82e352c4065bd7-364x243.jpg" 
                    alt="Travel Health"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Action Cards - New Section */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          <Link to="/patient/plans" className="group">
            <div className="h-full p-4 rounded-2xl border border-border/60 bg-card hover:border-primary/40 hover:shadow-lg hover:shadow-primary/5 transition-all flex flex-col items-center text-center gap-3">
              <div className="h-12 w-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center group-hover:scale-110 transition-transform">
                <CreditCard className="h-6 w-6" />
              </div>
              <span className="text-sm font-bold text-foreground">Buy/Upgrade Plan</span>
            </div>
          </Link>
          
          <button onClick={handleAddFamilyMember} className="group text-left w-full">
            <div className="h-full p-4 rounded-2xl border border-border/60 bg-card hover:border-accent/40 hover:shadow-lg hover:shadow-accent/5 transition-all flex flex-col items-center text-center gap-3">
              <div className="h-12 w-12 rounded-xl bg-accent/10 text-accent flex items-center justify-center group-hover:scale-110 transition-transform">
                <PlusCircle className="h-6 w-6" />
              </div>
              <span className="text-sm font-bold text-foreground">Add Family Members</span>
            </div>
          </button>

          <Link to="/patient/book" className="group">
            <div className="h-full p-4 rounded-2xl border border-border/60 bg-card hover:border-primary/40 hover:shadow-lg hover:shadow-primary/5 transition-all flex flex-col items-center text-center gap-3">
              <div className="h-12 w-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center group-hover:scale-110 transition-transform">
                <Stethoscope className="h-6 w-6" />
              </div>
              <span className="text-sm font-bold text-foreground">Book Appointment</span>
            </div>
          </Link>

          <Link to="/patient/appointments" className="group">
            <div className="h-full p-4 rounded-2xl border border-border/60 bg-card hover:border-amber-500/40 hover:shadow-lg hover:shadow-amber-500/5 transition-all flex flex-col items-center text-center gap-3">
              <div className="h-12 w-12 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Clock className="h-6 w-6" />
              </div>
              <span className="text-sm font-bold text-foreground">Upcoming Visits</span>
            </div>
          </Link>

          <Link to="/patient/prescriptions" className="group">
            <div className="h-full p-4 rounded-2xl border border-border/60 bg-card hover:border-emerald-500/40 hover:shadow-lg hover:shadow-emerald-500/5 transition-all flex flex-col items-center text-center gap-3">
              <div className="h-12 w-12 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                <FileText className="h-6 w-6" />
              </div>
              <span className="text-sm font-bold text-foreground">Prescriptions</span>
            </div>
          </Link>
        </div>

        {/* Stats row - Redesigned for better UI */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[
            { 
              label: 'Consultations', 
              value: appointments.length, 
              icon: Stethoscope, 
              color: 'text-primary',
              bg: 'bg-primary/5',
              border: 'border-primary/10',
              description: 'Total medical visits'
            },
            { 
              label: 'Upcoming', 
              value: upcomingAppointments.length, 
              icon: Clock, 
              color: 'text-amber-600',
              bg: 'bg-amber-500/5',
              border: 'border-amber-500/10',
              description: 'Scheduled appointments'
            },
            { 
              label: 'Health Score', 
              value: healthScore != null ? `${healthScore}%` : '—', 
              icon: Activity, 
              color: 'text-emerald-600',
              bg: 'bg-emerald-500/5',
              border: 'border-emerald-500/10',
              description: 'Based on vitals & meds'
            },
          ].map((s) => (
            <div
              key={s.label}
              className={`relative overflow-hidden group rounded-2xl border ${s.border} ${s.bg} p-5 transition-all hover:shadow-lg hover:scale-[1.02]`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className={`p-2.5 rounded-xl ${s.bg.replace('/5', '/10')} ${s.color}`}>
                  <s.icon className="h-6 w-6" strokeWidth={2.5} />
                </div>
                <div className="text-3xl font-black tracking-tight text-foreground tabular-nums">
                  {s.value}
                </div>
              </div>
              <div>
                <p className="text-sm font-bold text-foreground">{s.label}</p>
                <p className="text-xs text-muted-foreground">{s.description}</p>
              </div>
              {/* Decorative background icon */}
              <s.icon className={`absolute -right-4 -bottom-4 h-24 w-24 opacity-[0.03] ${s.color} rotate-12 group-hover:rotate-0 transition-transform duration-500`} />
            </div>
          ))}
        </div>

        {/* Two columns: plan + reminders | appointments + vitals */}
        <div className="grid lg:grid-cols-5 gap-6">
          <div className="lg:col-span-2 space-y-6 rounded-xl p-1">
            <PlanCard plan={currentPlan} isHighestPlan={isHighestPlan} />
            <MedicationReminder />
          </div>
          <div className="lg:col-span-3 space-y-6 rounded-xl bg-muted/20 p-4 md:p-5 border border-border/40">
            <Card className="shadow-card border border-border/60 rounded-xl overflow-hidden bg-card">
              <CardHeader className="border-b border-border/60 bg-muted/30 py-4">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base font-semibold flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-accent" strokeWidth={2} />
                    Upcoming Appointments
                  </CardTitle>
                  <Link to="/patient/appointments">
                    <Button variant="ghost" size="sm" className="rounded-lg">
                      View All
                      <ArrowRight className="h-4 w-4 ml-1" strokeWidth={2} />
                    </Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                {upcomingAppointments.length === 0 ? (
                  <div className="text-center py-14 px-4">
                    <div className="h-20 w-20 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-4">
                      <Calendar className="h-10 w-10 text-muted-foreground" strokeWidth={1.5} />
                    </div>
                    <p className="text-muted-foreground font-medium mb-1">No appointments scheduled yet</p>
                    <p className="text-sm text-muted-foreground mb-5">
                      Your plan runs from {PLAN_BENEFITS_AVAILABLE.dateRange}. You can book appointments anytime during this period.
                    </p>
                    <Link to="/patient/book">
                      <Button variant="default" className="rounded-xl bg-primary text-primary-foreground font-semibold">
                        Book Appointment
                      </Button>
                    </Link>
                  </div>
                ) : (
                  <ul className="divide-y divide-border/60">
                    {upcomingAppointments.slice(0, 3).map((appointment) => (
                      <li
                        key={appointment.id}
                        className="flex items-center justify-between p-4 hover:bg-muted/40 transition-colors"
                      >
                        <div className="flex items-center gap-4">
                          <div className={`h-11 w-11 rounded-xl flex items-center justify-center text-lg ${
                            appointment.serviceType === 'telehealth' ? 'bg-accent/15 text-accent' : 'bg-primary/15 text-primary'
                          }`}>
                            {appointment.serviceType === 'telehealth' ? '📹' : '🚨'}
                          </div>
                          <div>
                            <p className="font-medium text-foreground">
                              {appointment.serviceType === 'telehealth' ? 'Video Consultation' : 'Emergency'}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {new Date(appointment.dateTime).toLocaleDateString('en-US', {
                                weekday: 'short',
                                month: 'short',
                                day: 'numeric',
                              })}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge
                            variant={
                              appointment.status === 'pending' ? 'warning' :
                              appointment.status === 'doctor_assigned' ? 'info' :
                              appointment.status === 'in_progress' ? 'success' : 'secondary'
                            }
                            className="rounded-lg"
                          >
                            {appointment.status === 'pending' ? 'Pending' :
                             appointment.status === 'doctor_assigned' ? 'Assigned' :
                             appointment.status === 'in_progress' ? 'In Progress' : appointment.status}
                          </Badge>
                          {appointment.status === 'doctor_assigned' && appointment.serviceType === 'telehealth' && (
                            <Link to={`/patient/call/${appointment.id}`}>
                              <Button size="sm" variant="accent" className="rounded-lg">
                                Join Call
                              </Button>
                            </Link>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
            <HealthVitalsCard />
          </div>
        </div>

        <HealthTipsCarousel />
      </div>

      {/* Family Upgrade Dialog */}
      <Dialog open={showFamilyUpgradeDialog} onOpenChange={setShowFamilyUpgradeDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <div className="mx-auto h-12 w-12 rounded-full bg-amber-100 flex items-center justify-center mb-4">
              <AlertCircle className="h-6 w-6 text-amber-600" />
            </div>
            <DialogTitle className="text-center">Upgrade Required</DialogTitle>
            <DialogDescription className="text-center">
              You currently have an Individual plan. To add family members, you need to upgrade to a Family plan.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-3 py-4">
            <div className="rounded-lg bg-muted p-4 space-y-2">
              <div className="flex items-center gap-2 text-sm font-semibold">
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                Coverage for up to 4 members
              </div>
              <div className="flex items-center gap-2 text-sm font-semibold">
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                Shared telehealth credits
              </div>
              <div className="flex items-center gap-2 text-sm font-semibold">
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                Priority specialty coordination
              </div>
            </div>
          </div>
          <DialogFooter className="sm:justify-center gap-2">
            <Button variant="outline" onClick={() => setShowFamilyUpgradeDialog(false)}>
              Maybe Later
            </Button>
            <Link to="/patient/plans">
              <Button className="bg-primary text-primary-foreground font-bold">
                View Family Plans
              </Button>
            </Link>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
