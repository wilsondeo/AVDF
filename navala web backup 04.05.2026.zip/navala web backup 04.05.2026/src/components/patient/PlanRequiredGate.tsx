import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CreditCard, Lock } from 'lucide-react';

interface PlanRequiredGateProps {
  /** Page/feature name for the message, e.g. "My Appointments", "Prescriptions", "Book Appointment" */
  featureName: string;
}

export function PlanRequiredGate({ featureName }: PlanRequiredGateProps) {
  return (
    <Card className="shadow-card border-0 max-w-xl mx-auto">
      <CardHeader className="text-center pb-2">
        <div className="mx-auto mb-4 h-16 w-16 rounded-full bg-muted flex items-center justify-center">
          <Lock className="h-8 w-8 text-muted-foreground" />
        </div>
        <CardTitle className="text-xl">Plan required</CardTitle>
        <CardDescription>
          Your plan must be active to access {featureName}. Activate or purchase a plan to continue.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex justify-center pb-8">
        <Link to="/patient/plans">
          <Button variant="default" size="lg" className="gap-2">
            <CreditCard className="h-5 w-5" />
            View plans & activate
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
