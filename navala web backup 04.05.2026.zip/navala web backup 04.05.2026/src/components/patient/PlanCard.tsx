import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, ArrowRight, AlertCircle } from 'lucide-react';

interface PlanCardProps {
  plan: null | {
    endDate: string;
    plan: {
      name: string;
      description?: string;
      price: number | string;
      validityDays: number;
      services: any;
      features: any;
    };
  };
  /** When true, user is already on the highest-tier plan; upgrade button is disabled */
  isHighestPlan?: boolean;
}

export function PlanCard({ plan, isHighestPlan = false }: PlanCardProps) {
  if (!plan) {
    return (
      <Card className="shadow-card border-2 border-amber-500/50 ring-2 ring-amber-500/20 overflow-hidden bg-amber-50/30 dark:bg-amber-950/20">
        <div className="h-2 bg-amber-500" />
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-xl flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-warning" />
                No Active Plan
              </CardTitle>
              <CardDescription className="mt-1">
                Purchase a plan to access our healthcare services
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="bg-muted/50 rounded-lg p-4 mb-4">
            <p className="text-sm text-muted-foreground">
              Without an active plan, you cannot book appointments. 
              Choose a plan that fits your travel needs to get started.
            </p>
          </div>
          <Link to="/patient/plans">
            <Button className="w-full" size="lg">
              View Plans
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </CardContent>
      </Card>
    );
  }

  const services = Array.isArray(plan.plan.services)
    ? plan.plan.services
    : (typeof plan.plan.services === 'string' ? JSON.parse(plan.plan.services) : []);
  const features = Array.isArray(plan.plan.features)
    ? plan.plan.features
    : (typeof plan.plan.features === 'string' ? JSON.parse(plan.plan.features) : []);
  const price = typeof plan.plan.price === 'string' ? parseFloat(plan.plan.price) : plan.plan.price;

  return (
    <Card className="rounded-xl border border-border/60 overflow-hidden bg-card shadow-sm">
      <div className="h-1.5 bg-primary" />
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <CardTitle className="text-lg font-semibold">{plan.plan.name}</CardTitle>
              <Badge variant="success" className="rounded-md text-xs">Active</Badge>
            </div>
            {plan.plan.description && (
              <CardDescription className="mt-1 text-sm">{plan.plan.description}</CardDescription>
            )}
          </div>
          <div className="text-right shrink-0">
            <p className="text-2xl md:text-3xl font-bold text-foreground tabular-nums">${price}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Services */}
        <div>
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">Services included</p>
          <div className="flex flex-wrap gap-2">
            {services.map((service: string) => (
              <Badge key={service} variant="secondary" className="rounded-md">
                {service === 'telehealth' || service === 'TELEHEALTH'
                  ? 'Telehealth'
                  : service === 'EMERGENCY' || service === 'emergency'
                    ? 'Emergency'
                    : service}
              </Badge>
            ))}
          </div>
        </div>

        {/* Features - higher contrast icons */}
        <div>
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">Features</p>
          <ul className="grid grid-cols-1 gap-2">
            {features.slice(0, 4).map((feature: string) => (
              <li key={feature} className="flex items-center gap-2.5 text-sm text-foreground">
                <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400 shrink-0" strokeWidth={2.5} />
                {feature}
              </li>
            ))}
          </ul>
        </div>

        {/* Actions: Book Appointment disabled; Upgrade disabled when already on highest plan */}
        <div className="flex flex-col sm:flex-row gap-2 pt-2">
          <Button className="w-full rounded-xl font-semibold flex-1" variant="default" size="lg" disabled>
            Book Appointment
          </Button>
          {isHighestPlan ? (
            <Button variant="outline" className="rounded-xl w-full sm:w-auto" size="lg" disabled title="You're on the highest plan">
              Upgrade Plan
            </Button>
          ) : (
            <Link to="/patient/plans" className="order-1 sm:order-2">
              <Button variant="outline" className="rounded-xl w-full sm:w-auto" size="lg">
                Upgrade Plan
              </Button>
            </Link>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
