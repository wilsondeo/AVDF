import { useEffect, useMemo, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import {
  CreditCard,
  Lock,
  Shield,
  CheckCircle2,
  Loader2,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { Elements, PaymentElement, useElements, useStripe } from '@stripe/react-stripe-js';
import type { StripeElementsOptions } from '@stripe/stripe-js';
import { getStripePromise } from '@/config/stripe';
import { paymentApi, itineraryApi, type Plan, type UserItineraryItem } from '@/services/api';
import { toast } from 'sonner';
import type { ItineraryDestination } from '@/components/itinerary/ItineraryBuilder';

interface PaymentModalProps {
  open: boolean;
  onClose: () => void;
  plan: Plan | null;
  onSuccess: () => void;
  itinerary?: ItineraryDestination[];
  totalTax?: number;
}

function CheckoutForm({
  plan,
  amountToPay,
  onPaymentSuccess,
  onPaymentError,
  onCancel,
}: {
  plan: Plan;
  /** When upgrading, only this amount is charged (not full plan price). */
  amountToPay: number;
  onPaymentSuccess: (transactionId: string) => void;
  onPaymentError: (errorMsg: string) => void;
  onCancel: () => void;
}) {
  const stripe = useStripe();
  const elements = useElements();
  const [submitting, setSubmitting] = useState(false);
  const [elementComplete, setElementComplete] = useState(false);
  const [status, setStatus] = useState<'ready' | 'processing' | 'success'>('ready');

  const pollActivation = async () => {
    // Webhook is the source of truth. We poll /user/plan for up to ~30s.
    const maxAttempts = 15;
    for (let i = 0; i < maxAttempts; i++) {
      await new Promise((r) => setTimeout(r, 2000));
      const res = await paymentApi.getActiveUserPlan();
      const active = res.success ? res.data?.activePlan : null;
      const activePlanBusinessId = (active as any)?.plan?.planId || (active as any)?.planId;
      if (active && activePlanBusinessId === plan.planId) {
        return true;
      }
    }
    return false;
  };

  const handlePay = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    setSubmitting(true);
    setStatus('processing');

    const result = await stripe.confirmPayment({
      elements,
      redirect: 'if_required',
      confirmParams: {
        return_url: window.location.href,
      },
    });

    if (result.error) {
      onPaymentError(result.error.message || 'Payment failed');
      setSubmitting(false);
      return;
    }

    // Payment confirmed. Now wait for webhook activation.
    toast.success('Payment confirmed. Activating your plan...');
    const activated = await pollActivation();
    if (!activated) {
      toast.message('Payment succeeded, but activation is still processing. Please refresh in a few seconds.');
    }

    setSubmitting(false);
    onPaymentSuccess(result.paymentIntent?.id || 'Payment Processing');
  };

  return (
    <form onSubmit={handlePay} className="space-y-4">
      <div className="space-y-2">
        <Label>Payment Details</Label>
        <div className="rounded-lg border border-border p-3 min-h-[80px] flex items-stretch">
          <PaymentElement
            onChange={(e) => setElementComplete(e.complete)}
            options={{ layout: 'tabs' }}
          />
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground bg-accent/5 p-3 rounded-lg">
          <Lock className="h-4 w-4 text-accent shrink-0" />
          <span>Your payment is processed securely by Stripe</span>
        </div>
      </div>

      <Separator />

      <div className="flex items-center justify-between text-lg font-semibold">
        <span>Total</span>
        <span className="text-accent">${(Number(amountToPay) || (Number(plan.price) + (Number(totalTax) || 0))).toFixed(2)}</span>
      </div>

      <div className="grid grid-cols-2 gap-3 items-stretch">
        <Button type="button" variant="outline" className="w-full h-11" size="xl" onClick={onCancel} disabled={submitting}>
          Cancel
        </Button>
        <Button
          type="submit"
          variant="accent"
          className="w-full h-11"
          size="lg"
          disabled={!stripe || !elements || !elementComplete || submitting}
        >
          {submitting ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              <Shield className="h-4 w-4 mr-2" />
              Pay ${(Number(amountToPay) || (Number(plan.price) + (Number(totalTax) || 0))).toFixed(2)}
            </>
          )}
        </Button>
      </div>
    </form>
  );
}

export function PaymentModal({ open, onClose, plan, onSuccess, itinerary, totalTax }: PaymentModalProps) {
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [intentId, setIntentId] = useState<string | null>(null);
  const [amountToPay, setAmountToPay] = useState<number | null>(null);
  const [isUpgrade, setIsUpgrade] = useState(false);
  const [loadingIntent, setLoadingIntent] = useState(false);

  // Post-payment state
  const [paymentStatus, setPaymentStatus] = useState<'pending' | 'success' | 'failed'>('pending');
  const [transactionId, setTransactionId] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');

  const stripePromise = useMemo(() => {
    try {
      return getStripePromise();
    } catch (e) {
      return null;
    }
  }, []);

  useEffect(() => {
    if (!open || !plan) return;
    // create intent when modal opens
    (async () => {
      try {
        setLoadingIntent(true);
        setClientSecret(null);
        setIntentId(null);
        setAmountToPay(null);
        setIsUpgrade(false);
        const res = await paymentApi.createIntent(plan.planId, totalTax);
        if (!res.success || !res.data) {
          toast.error(res.message || 'Failed to start payment');
          return;
        }
        setClientSecret(res.data.clientSecret);
        setIntentId(res.data.paymentIntentId);
        const charged = res.data.amountCharged ?? (res.data.amountChargedCents != null ? res.data.amountChargedCents / 100 : undefined);
        if (typeof charged === 'number') {
          setAmountToPay(charged);
          setIsUpgrade(res.data.type === 'UPGRADE');
        }
      } finally {
        setLoadingIntent(false);
      }
    })();
  }, [open, plan]);

  const handleClose = () => {
    if (loadingIntent) return;
    onClose();
    setClientSecret(null);
    setIntentId(null);
    setAmountToPay(null);
    setIsUpgrade(false);
    setPaymentStatus('pending');
    setTransactionId('');
    setErrorMessage('');
  };

  if (!plan) return null;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        <DialogHeader className="shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-accent" />
            Complete Your Purchase
          </DialogTitle>
          <DialogDescription>
            Pay securely with Stripe to activate your plan
          </DialogDescription>
        </DialogHeader>

        {/* Scrollable body – no scrollbar on dialog itself */}
        <div className="overflow-y-auto overflow-x-hidden min-h-0 flex-1 pr-1 -mr-1 space-y-4">

          {paymentStatus === 'pending' && (
            <>
              {/* Plan Summary */}
              <div className="p-4 bg-muted/50 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold">{plan.name}</p>
                    {isUpgrade && amountToPay != null && (
                      <p className="text-xs text-muted-foreground mt-1">Upgrade: pay only the difference</p>
                    )}
                  </div>
                  <Badge variant="success">
                    {amountToPay != null && isUpgrade ? `$${(Number(amountToPay) || 0).toFixed(2)}` : `$${(Number(plan.price) + (totalTax || 0)).toFixed(2)}`}
                  </Badge>
                </div>
                <Separator />
              </div>
            </>
          )}

          {loadingIntent && (
            <div className="py-8 text-center space-y-3">
              <Loader2 className="h-8 w-8 text-accent animate-spin mx-auto" />
              <p className="text-sm text-muted-foreground">Preparing payment...</p>
            </div>
          )}

          {!loadingIntent && (!stripePromise || !clientSecret) && (
            <div className="py-6 text-center space-y-2">
              <p className="text-sm text-destructive">Stripe is not configured.</p>
              <p className="text-xs text-muted-foreground">
                Set <span className="font-mono">VITE_STRIPE_PUBLISHABLE_KEY</span> in the frontend .env and refresh.
              </p>
            </div>
          )}

          {!loadingIntent && stripePromise && clientSecret && paymentStatus === 'pending' && (
            <Elements stripe={stripePromise} options={{ clientSecret } as StripeElementsOptions}>
              <CheckoutForm
                plan={plan}
                amountToPay={amountToPay != null ? amountToPay : (Number(plan.price) + (totalTax || 0))}
                onCancel={handleClose}
                onPaymentSuccess={async (txId) => {
                  setTransactionId(txId);
                  setPaymentStatus('success');

                  // Save itinerary if provided
                  if (itinerary && itinerary.length > 0) {
                    try {
                      const destinations: UserItineraryItem[] = itinerary.map((dest, idx) => {
                        let actualTax = Number(dest.taxValue) || 0;
                        if (dest.taxType === 'PERCENTAGE') {
                          actualTax = (actualTax / 100) * Number(plan.price);
                        }
                        return {
                          locationId: dest.locationId,
                          arrivalDate: dest.arrivalDate,
                          departureDate: dest.departureDate,
                          taxPaid: actualTax,
                          visitOrder: idx + 1
                        };
                      });
                      await itineraryApi.save(destinations);
                    } catch (e) {
                      console.error('Failed to save itinerary after payment:', e);
                      toast.error('Payment succeeded, but failed to save travel itinerary.');
                    }
                  }
                }}
                onPaymentError={(msg) => {
                  setErrorMessage(msg);
                  setPaymentStatus('failed');
                }}
              />
            </Elements>
          )}

          {paymentStatus === 'success' && (
            <div className="py-6 text-center space-y-6 animate-scale-in">
              <div className="h-20 w-20 rounded-full bg-success/10 flex items-center justify-center mx-auto">
                <CheckCircle2 className="h-10 w-10 text-success" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-success mb-2">Payment Successful!</h2>
                <p className="text-muted-foreground">Your booking and plan activation are confirmed.</p>
              </div>

              <div className="bg-muted/30 border border-border rounded-xl p-4 text-left space-y-4">
                <div className="text-sm grid grid-cols-2 gap-y-3 items-center">
                  <span className="text-muted-foreground">Plan</span>
                  <span className="font-semibold text-right">{plan.name}</span>

                  <span className="text-muted-foreground">Amount Paid</span>
                  <span className="font-semibold text-accent text-right">${(Number(amountToPay) || (Number(plan.price) + (totalTax || 0))).toFixed(2)}</span>

                  <span className="text-muted-foreground">Transaction ID</span>
                  <span className="font-mono text-xs text-right break-all">{transactionId}</span>
                </div>
              </div>

              <Button
                className="w-full h-12 text-md font-semibold"
                variant="accent"
                onClick={() => {
                  onSuccess();
                  handleClose();
                }}
              >
                View Plan Confirmation
              </Button>
            </div>
          )}

          {paymentStatus === 'failed' && (
            <div className="py-6 text-center space-y-6 animate-scale-in">
              <div className="h-20 w-20 rounded-full bg-destructive/10 flex items-center justify-center mx-auto">
                <AlertCircle className="h-10 w-10 text-destructive" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-destructive mb-2">Payment Failed</h2>
                <p className="text-muted-foreground px-4">{errorMessage}</p>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="flex-1 h-12"
                  onClick={handleClose}
                >
                  Cancel
                </Button>
                <Button
                  className="flex-1 h-12"
                  onClick={() => setPaymentStatus('pending')}
                >
                  Try Again
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
