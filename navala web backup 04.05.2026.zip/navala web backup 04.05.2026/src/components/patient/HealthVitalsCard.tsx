import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Heart,
  Activity,
  Thermometer,
  Droplets,
  Plus,
  Pencil,
  Loader2,
} from 'lucide-react';
import { patientVitalsApi, type PatientVitalReading } from '@/services/api';
import { toast } from 'sonner';
import { format } from 'date-fns';

const VITAL_META = [
  { key: 'heartRate' as const, name: 'Heart Rate', unit: 'bpm', icon: Heart, color: 'text-red-600 dark:text-red-400', rangeLabel: '60–100 normal', max: 100 },
  { key: 'bloodPressure' as const, name: 'Blood Pressure', unit: 'mmHg', icon: Activity, color: 'text-blue-600 dark:text-blue-400', rangeLabel: '<120/80 ideal', max: 100 },
  { key: 'temperature' as const, name: 'Temperature', unit: '°F', icon: Thermometer, color: 'text-amber-600 dark:text-amber-400', rangeLabel: '97–99°F normal', max: 100 },
  { key: 'oxygenLevel' as const, name: 'Oxygen Level', unit: '%', icon: Droplets, color: 'text-emerald-600 dark:text-emerald-400', rangeLabel: '95–100% normal', max: 100 },
];

function getProgress(value: number | null, meta: (typeof VITAL_META)[0]): number {
  if (value == null) return 0;
  if (meta.key === 'heartRate') return Math.min(100, Math.max(0, (value / (meta.max || 100)) * 100));
  if (meta.key === 'oxygenLevel') return Math.min(100, Math.max(0, value));
  if (meta.key === 'temperature') return value >= 97 && value <= 99 ? 80 : 50;
  return 70;
}

export function HealthVitalsCard() {
  const [readings, setReadings] = useState<PatientVitalReading[]>([]);
  const [loading, setLoading] = useState(true);
  const [addOpen, setAddOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    heartRate: '',
    bloodPressureSystolic: '',
    bloodPressureDiastolic: '',
    temperature: '',
    oxygenLevel: '',
  });

  const load = async () => {
    try {
      setLoading(true);
      const res = await patientVitalsApi.getList(10);
      if (res.success && res.data) setReadings(res.data);
      else setReadings([]);
    } catch {
      setReadings([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const latest = readings[0] ?? null;

  const openAdd = () => {
    setForm({
      heartRate: '',
      bloodPressureSystolic: '',
      bloodPressureDiastolic: '',
      temperature: '',
      oxygenLevel: '',
    });
    setAddOpen(true);
  };

  const openEdit = () => {
    if (!latest) return;
    setForm({
      heartRate: latest.heartRate != null ? String(latest.heartRate) : '',
      bloodPressureSystolic: latest.bloodPressureSystolic != null ? String(latest.bloodPressureSystolic) : '',
      bloodPressureDiastolic: latest.bloodPressureDiastolic != null ? String(latest.bloodPressureDiastolic) : '',
      temperature: latest.temperature != null ? String(latest.temperature) : '',
      oxygenLevel: latest.oxygenLevel != null ? String(latest.oxygenLevel) : '',
    });
    setEditOpen(true);
  };

  const handleAdd = async () => {
    setSaving(true);
    try {
      const res = await patientVitalsApi.add({
        heartRate: form.heartRate ? parseInt(form.heartRate, 10) : null,
        bloodPressureSystolic: form.bloodPressureSystolic ? parseInt(form.bloodPressureSystolic, 10) : null,
        bloodPressureDiastolic: form.bloodPressureDiastolic ? parseInt(form.bloodPressureDiastolic, 10) : null,
        temperature: form.temperature ? parseFloat(form.temperature) : null,
        oxygenLevel: form.oxygenLevel ? parseInt(form.oxygenLevel, 10) : null,
      });
      if (res.success && res.data) {
        setReadings((prev) => [res.data!, ...prev]);
        setAddOpen(false);
        toast.success('Vitals added');
      } else toast.error(res.message || 'Failed to add');
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to add');
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = async () => {
    if (!latest) return;
    setSaving(true);
    try {
      const res = await patientVitalsApi.update(latest.id, {
        heartRate: form.heartRate ? parseInt(form.heartRate, 10) : null,
        bloodPressureSystolic: form.bloodPressureSystolic ? parseInt(form.bloodPressureSystolic, 10) : null,
        bloodPressureDiastolic: form.bloodPressureDiastolic ? parseInt(form.bloodPressureDiastolic, 10) : null,
        temperature: form.temperature ? parseFloat(form.temperature) : null,
        oxygenLevel: form.oxygenLevel ? parseInt(form.oxygenLevel, 10) : null,
      });
      if (res.success && res.data) {
        setReadings((prev) => [res.data!, ...prev.filter((r) => r.id !== latest.id)]);
        setEditOpen(false);
        toast.success('Vitals updated');
      } else toast.error(res.message || 'Failed to update');
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to update');
    } finally {
      setSaving(false);
    }
  };

  const displayValue = (meta: (typeof VITAL_META)[0]) => {
    if (meta.key === 'bloodPressure') {
      const v = latest?.bloodPressureSystolic != null && latest?.bloodPressureDiastolic != null
        ? `${latest.bloodPressureSystolic}/${latest.bloodPressureDiastolic}`
        : null;
      return v ?? '—';
    }
    const v = latest ? (latest[meta.key] as number | null) : null;
    return v != null ? v : '—';
  };

  const progressValue = (meta: (typeof VITAL_META)[0]) => {
    if (meta.key === 'bloodPressure') {
      const sys = latest?.bloodPressureSystolic;
      return sys != null ? Math.min(100, (120 / Math.max(sys, 1)) * 80) : 0;
    }
    const v = latest ? (latest[meta.key] as number | null) : null;
    return getProgress(v, meta);
  };

  return (
    <>
      <Card className="rounded-xl border border-border/60 bg-card shadow-sm">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Activity className="h-5 w-5 text-accent" strokeWidth={2} />
              Health Vitals Overview
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="h-8 rounded-lg" onClick={openAdd}>
                <Plus className="h-4 w-4 mr-1" />
                Add
              </Button>
              {latest && (
                <Button variant="ghost" size="sm" className="h-8 rounded-lg" onClick={openEdit}>
                  <Pencil className="h-4 w-4 mr-1" />
                  Edit
                </Button>
              )}
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            {latest?.recordedAt
              ? `Last updated ${format(new Date(latest.recordedAt), 'MMM d, yyyy HH:mm')}`
              : 'Add a Reading to track your vitals'}
          </p>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : !latest ? (
            <div className="text-center py-8">
              <p className="text-sm text-muted-foreground mb-4">No vitals recorded yet.</p>
              <Button variant="outline" size="sm" onClick={openAdd}>
                <Plus className="h-4 w-4 mr-2" />
                Add Reading
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              {VITAL_META.map((meta) => (
                <div
                  key={meta.key}
                  className="p-4 rounded-xl bg-muted/40 hover:bg-muted/60 border border-border/40 transition-colors space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="h-10 w-10 rounded-xl bg-background flex items-center justify-center border border-border/40">
                      <meta.icon className={`h-5 w-5 ${meta.color}`} strokeWidth={2} />
                    </div>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-muted-foreground">{meta.name}</p>
                    <p className="text-xl font-bold text-foreground tabular-nums mt-0.5">
                      {displayValue(meta)}
                      <span className="text-sm font-normal text-muted-foreground ml-1">{meta.unit}</span>
                    </p>
                    {meta.rangeLabel && (
                      <p className="text-xs text-muted-foreground mt-1">{meta.rangeLabel}</p>
                    )}
                  </div>
                  <Progress value={progressValue(meta)} className="h-1.5" />
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Vitals Reading</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>Heart rate (bpm)</Label>
              <Input
                type="number"
                min={0}
                value={form.heartRate}
                onChange={(e) => setForm((f) => ({ ...f, heartRate: e.target.value }))}
                placeholder="e.g. 72"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label>Systolic (mmHg)</Label>
                <Input
                  type="number"
                  min={0}
                  value={form.bloodPressureSystolic}
                  onChange={(e) => setForm((f) => ({ ...f, bloodPressureSystolic: e.target.value }))}
                  placeholder="120"
                />
              </div>
              <div>
                <Label>Diastolic (mmHg)</Label>
                <Input
                  type="number"
                  min={0}
                  value={form.bloodPressureDiastolic}
                  onChange={(e) => setForm((f) => ({ ...f, bloodPressureDiastolic: e.target.value }))}
                  placeholder="80"
                />
              </div>
            </div>
            <div>
              <Label>Temperature (°F)</Label>
              <Input
                type="number"
                step="0.1"
                value={form.temperature}
                onChange={(e) => setForm((f) => ({ ...f, temperature: e.target.value }))}
                placeholder="98.6"
              />
            </div>
            <div>
              <Label>Oxygen level (%)</Label>
              <Input
                type="number"
                min={0}
                max={100}
                value={form.oxygenLevel}
                onChange={(e) => setForm((f) => ({ ...f, oxygenLevel: e.target.value }))}
                placeholder="98"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(false)}>Cancel</Button>
            <Button onClick={handleAdd} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Add'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Vitals Reading</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>Heart rate (bpm)</Label>
              <Input
                type="number"
                min={0}
                value={form.heartRate}
                onChange={(e) => setForm((f) => ({ ...f, heartRate: e.target.value }))}
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label>Systolic (mmHg)</Label>
                <Input
                  type="number"
                  min={0}
                  value={form.bloodPressureSystolic}
                  onChange={(e) => setForm((f) => ({ ...f, bloodPressureSystolic: e.target.value }))}
                />
              </div>
              <div>
                <Label>Diastolic (mmHg)</Label>
                <Input
                  type="number"
                  min={0}
                  value={form.bloodPressureDiastolic}
                  onChange={(e) => setForm((f) => ({ ...f, bloodPressureDiastolic: e.target.value }))}
                />
              </div>
            </div>
            <div>
              <Label>Temperature (°F)</Label>
              <Input
                type="number"
                step="0.1"
                value={form.temperature}
                onChange={(e) => setForm((f) => ({ ...f, temperature: e.target.value }))}
              />
            </div>
            <div>
              <Label>Oxygen level (%)</Label>
              <Input
                type="number"
                min={0}
                max={100}
                value={form.oxygenLevel}
                onChange={(e) => setForm((f) => ({ ...f, oxygenLevel: e.target.value }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button onClick={handleEdit} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Save'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
