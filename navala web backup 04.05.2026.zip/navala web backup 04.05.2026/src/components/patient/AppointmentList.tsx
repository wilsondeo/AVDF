import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Appointment, useAppStore } from '@/lib/store';
import { Calendar, Video, Phone, User, MapPin, Clock, ArrowRight } from 'lucide-react';
import { format } from 'date-fns';

interface AppointmentListProps {
  appointments: Appointment[];
  title: string;
  emptyMessage: string;
  showViewAll?: boolean;
}

const statusConfig: Record<string, { variant: 'pending' | 'assigned' | 'inProgress' | 'completed' | 'cancelled'; label: string }> = {
  pending: { variant: 'pending', label: 'Waiting for Doctor' },
  doctor_assigned: { variant: 'assigned', label: 'Doctor Assigned' },
  in_progress: { variant: 'inProgress', label: 'In Progress' },
  completed: { variant: 'completed', label: 'Completed' },
  cancelled: { variant: 'cancelled', label: 'Cancelled' },
};

export function AppointmentList({ appointments, title, emptyMessage, showViewAll = true }: AppointmentListProps) {
  const { users, plans } = useAppStore();

  const getDoctor = (doctorId?: string) => {
    if (!doctorId) return null;
    return users.find(u => u.id === doctorId);
  };

  const getPlan = (planId: string) => {
    return plans.find(p => p.id === planId);
  };

  return (
    <Card className="shadow-card border-0">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-lg">{title}</CardTitle>
          <CardDescription>{appointments.length} appointment(s)</CardDescription>
        </div>
        {showViewAll && appointments.length > 0 && (
          <Link to="/patient/appointments">
            <Button variant="ghost" size="sm">
              View All
              <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </Link>
        )}
      </CardHeader>
      <CardContent>
        {appointments.length === 0 ? (
          <div className="text-center py-8">
            <Calendar className="h-12 w-12 text-muted-foreground/50 mx-auto mb-3" />
            <p className="text-muted-foreground">{emptyMessage}</p>
            <Link to="/patient/book">
              <Button variant="outline" className="mt-4">
                Book an Appointment
              </Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {appointments.slice(0, 5).map((appointment) => {
              const doctor = getDoctor(appointment.doctorId);
              const plan = getPlan(appointment.planId);
              const status = statusConfig[appointment.status];
              const canJoinCall = appointment.serviceType === 'telehealth' && 
                appointment.videoCallStarted && 
                appointment.status === 'in_progress';

              return (
                <div 
                  key={appointment.id} 
                  className="flex items-start gap-4 p-4 rounded-lg border border-border bg-card hover:shadow-md transition-shadow"
                >
                  {/* Service Type Icon */}
                  <div className={`h-12 w-12 rounded-xl flex items-center justify-center shrink-0 ${
                    appointment.serviceType === 'telehealth' 
                      ? 'bg-accent/10 text-accent' 
                      : 'bg-primary/10 text-primary'
                  }`}>
                    {appointment.serviceType === 'telehealth' ? (
                      <Video className="h-6 w-6" />
                    ) : (
                      <Phone className="h-6 w-6" />
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-medium">
                            {appointment.serviceType === 'telehealth' ? 'Telehealth Consultation' : 'Emergency Service'}
                          </h4>
                          <Badge variant={status.variant}>{status.label}</Badge>
                          <span className="text-xs font-mono text-muted-foreground">
                            #{appointment.id.slice(0, 8)}
                          </span>
                        </div>
                        <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3.5 w-3.5" />
                            {format(new Date(appointment.dateTime), 'MMM dd, yyyy')}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3.5 w-3.5" />
                            {format(new Date(appointment.dateTime), 'HH:mm')}
                          </span>
                          <span className="flex items-center gap-1">
                            <MapPin className="h-3.5 w-3.5" />
                            {appointment.city}
                          </span>
                        </div>
                        {/* Extra clinical details */}
                        <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground/90">
                          <span className="flex items-center gap-1">
                            <User className="h-3 w-3" />
                            Age {appointment.patientDetails.age}, {appointment.patientDetails.gender}
                          </span>
                          <span className="flex items-center gap-1">
                            <Phone className="h-3 w-3" />
                            {appointment.patientDetails.emergencyContact}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            Booked on {format(new Date(appointment.createdAt), 'MMM dd, yyyy')}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Doctor Info */}
                    {doctor && (
                      <div className="flex items-center gap-2 mt-2 text-sm">
                        <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center">
                          <User className="h-3 w-3 text-primary" />
                        </div>
                        <span>{doctor.name}</span>
                        {doctor.specialization && (
                          <span className="text-muted-foreground">• {doctor.specialization}</span>
                        )}
                      </div>
                    )}

                    {/* Plan Badge */}
                    {plan && (
                      <Badge variant="secondary" className="mt-2">
                        {plan.name}
                      </Badge>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="shrink-0">
                    {canJoinCall && (
                      <Link to={`/patient/call/${appointment.id}`}>
                        <Button variant="accent" size="sm">
                          <Video className="h-4 w-4 mr-1" />
                          Join Call
                        </Button>
                      </Link>
                    )}
                    {appointment.status === 'completed' && appointment.prescription && (
                      <Link to={`/patient/prescriptions/${appointment.id}`}>
                        <Button variant="outline" size="sm">
                          View Prescription
                        </Button>
                      </Link>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
