import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar } from 'lucide-react';
import { PLAN_BENEFITS_AVAILABLE } from '@/config/patientPlan';

interface PlanBenefitsBannerProps {
  /** Use compact single-line message */
  compact?: boolean;
}

export function PlanBenefitsBanner({ compact = false }: PlanBenefitsBannerProps) {
  return (
    <Card className="rounded-xl border border-primary/20 bg-primary/5 shadow-sm">
      <CardContent className="py-3 px-4">
        <div className="flex flex-col sm:flex-row sm:items-center gap-3">
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <Calendar className="h-4 w-4 text-primary" strokeWidth={2} />
            </div>
            <p className="text-sm text-foreground">
              {compact ? (
                PLAN_BENEFITS_AVAILABLE.shortMessage
              ) : (
                <>
                  Your plan is active from{' '}
                  <span className="inline-flex items-center font-semibold px-2 py-0.5 rounded-md bg-primary/15 text-primary">
                    {PLAN_BENEFITS_AVAILABLE.dateRange}
                  </span>
                  . Book appointments, prescriptions, and other benefits during this period.
                </>
              )}
            </p>
          </div>
          {/* {!compact && (
            <Link to="/patient/plans" className="shrink-0">
              <Button variant="outline" size="sm" className="rounded-lg">
                View Plan Details
              </Button>
            </Link>
          )} */}
        </div>
      </CardContent>
    </Card>
  );
}
