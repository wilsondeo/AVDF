import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  LayoutDashboard, 
  Calendar, 
  FileText, 
  CreditCard,
  Download,
  Pill,
  Stethoscope,
  User,
  Loader2
} from 'lucide-react';
import { PlanRequiredGate } from '@/components/patient/PlanRequiredGate';
import { format } from 'date-fns';
import { paymentApi } from '@/services/api';

const getNavigation = (hasActivePlan: boolean) => [
  { name: 'Dashboard', href: '/patient', icon: LayoutDashboard },
  { name: 'My Appointments', href: '/patient/appointments', icon: Calendar, disabled: !hasActivePlan },
  { name: 'Prescriptions', href: '/patient/prescriptions', icon: FileText, disabled: !hasActivePlan },
  { name: 'My Plan', href: '/patient/plans', icon: CreditCard },
  { name: 'New Plans', href: '/patient/new-plans', icon: CreditCard },
];

export default function PatientPrescriptionsPage() {
  const { getPatientAppointments, users } = useAppStore();
  const [hasActivePlan, setHasActivePlan] = useState<boolean | null>(null);
  const appointments = getPatientAppointments().filter(a => a.prescription);

  useEffect(() => {
    const load = async () => {
      const res = await paymentApi.getActiveUserPlan();
      setHasActivePlan(!!(res.success && res.data?.activePlan));
    };
    load();
  }, []);

  const getDoctor = (doctorId?: string) => {
    if (!doctorId) return null;
    return users.find(u => u.id === doctorId);
  };

  const handleDownload = (prescriptionId: string) => {
    // Mock download - in real app would generate PDF
    const link = document.createElement('a');
    link.href = '#';
    link.download = `prescription-${prescriptionId}.pdf`;
    alert('In production, this would download the prescription PDF');
  };

  if (hasActivePlan === null) {
    return (
      <DashboardLayout navigation={getNavigation(hasActivePlan ?? false)} title="Prescriptions">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </DashboardLayout>
    );
  }

  if (hasActivePlan === false) {
    return (
      <DashboardLayout navigation={getNavigation(hasActivePlan ?? false)} title="Prescriptions">
        <div className="space-y-8 animate-fade-in py-8">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">My Prescriptions</h1>
            <p className="text-muted-foreground mt-1">
              View and download your medical prescriptions
            </p>
          </div>
          <PlanRequiredGate featureName="Prescriptions" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout navigation={getNavigation(hasActivePlan ?? false)} title="Prescriptions">
      <div className="space-y-8 animate-fade-in">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground">My Prescriptions</h1>
          <p className="text-muted-foreground mt-1">
            View and download your medical prescriptions
          </p>
        </div>

        {appointments.length === 0 ? (
          <Card className="shadow-card border-0">
            <CardContent className="py-12 text-center">
              <FileText className="h-12 w-12 text-muted-foreground/50 mx-auto mb-3" />
              <p className="text-muted-foreground">No prescriptions yet</p>
              <p className="text-sm text-muted-foreground mt-1">
                Prescriptions will appear here after your consultations
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {appointments.map((appointment) => {
              const prescription = appointment.prescription!;
              const doctor = getDoctor(appointment.doctorId);

              return (
                <Card key={prescription.id} className="shadow-card border-0 overflow-hidden">
                  <div className="h-1 gradient-accent" />
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg flex items-center gap-2">
                          <Stethoscope className="h-5 w-5 text-accent" />
                          {prescription.diagnosis}
                        </CardTitle>
                        <CardDescription className="mt-1">
                          Prescribed on {format(new Date(prescription.createdAt), 'MMMM dd, yyyy')}
                        </CardDescription>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleDownload(prescription.id)}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Download PDF
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Doctor Info */}
                    {doctor && (
                      <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <User className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">{doctor.name}</p>
                          <p className="text-sm text-muted-foreground">{doctor.specialization}</p>
                        </div>
                      </div>
                    )}

                    {/* Medicines */}
                    <div>
                      <h4 className="font-medium flex items-center gap-2 mb-3">
                        <Pill className="h-4 w-4 text-accent" />
                        Prescribed Medicines
                      </h4>
                      <div className="space-y-3">
                        {prescription.medicines.map((medicine, i) => (
                          <div 
                            key={i} 
                            className="flex items-start justify-between p-3 bg-card border border-border rounded-lg"
                          >
                            <div>
                              <p className="font-medium">{medicine.name}</p>
                              <p className="text-sm text-muted-foreground">
                                {medicine.dosage} • {medicine.duration}
                              </p>
                            </div>
                            <Badge variant="secondary">{medicine.dosage}</Badge>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Doctor Notes */}
                    {prescription.notes && (
                      <div>
                        <h4 className="font-medium mb-2">Doctor's Notes</h4>
                        <div className="p-3 bg-muted/50 rounded-lg">
                          <p className="text-sm text-muted-foreground">{prescription.notes}</p>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
