import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import type { AppointmentRequestSummary } from '@/services/api';
import { Calendar, Video, Phone, User, MapPin, Clock, Mail, Stethoscope, Users } from 'lucide-react';
import { format } from 'date-fns';

interface PatientRequestListProps {
  requests: AppointmentRequestSummary[];
  title: string;
  emptyMessage: string;
}

const statusConfig: Record<string, { variant: 'pending' | 'assigned' | 'cancelled' | 'outline'; label: string }> = {
  PENDING: { variant: 'pending', label: 'Waiting for Doctor' },
  ASSIGNED: { variant: 'assigned', label: 'Doctor Assigned' },
  CANCELLED: { variant: 'cancelled', label: 'Cancelled' },
};

export function PatientRequestList({ requests, title, emptyMessage }: PatientRequestListProps) {
  return (
    <Card className="shadow-card border-0">
      <CardHeader>
        <CardTitle className="text-lg">{title}</CardTitle>
        <CardDescription>{requests.length} request(s)</CardDescription>
      </CardHeader>
      <CardContent>
        {requests.length === 0 ? (
          <div className="text-center py-8">
            <Calendar className="h-12 w-12 text-muted-foreground/50 mx-auto mb-3" />
            <p className="text-muted-foreground">{emptyMessage}</p>
            <Link to="/patient/book">
              <Button variant="outline" className="mt-4">
                Book an Appointment
              </Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {requests.map((req) => {
              const status = statusConfig[req.status] ?? { variant: 'outline' as const, label: req.status };
              const isAssigned = req.status === 'ASSIGNED';

              return (
                <div
                  key={req.requestUuid}
                  className="flex items-start gap-4 p-4 rounded-lg border border-border bg-card hover:shadow-md transition-shadow"
                >
                  <div
                    className={`h-12 w-12 rounded-xl flex items-center justify-center shrink-0 ${
                      req.serviceType === 'TELEHEALTH' ? 'bg-accent/10 text-accent' : 'bg-primary/10 text-primary'
                    }`}
                  >
                    {req.serviceType === 'TELEHEALTH' ? (
                      <Video className="h-6 w-6" />
                    ) : (
                      <Phone className="h-6 w-6" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0 space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="font-medium">
                        {req.serviceType === 'TELEHEALTH' ? 'Telehealth Consultation' : 'Emergency Service'}
                      </h4>
                      <Badge variant={status.variant}>{status.label}</Badge>
                    </div>

                    {/* Booked For Indicator */}
                    <div className="flex items-center gap-1.5">
                      {req.familyMember ? (
                        <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 bg-blue-50 border border-blue-200 rounded-full px-2.5 py-0.5">
                          <Users className="h-3 w-3" />
                          For: {req.familyMember.firstName} {req.familyMember.lastName}
                          {req.familyMember.relationship ? ` · ${req.familyMember.relationship}` : ''}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground bg-muted rounded-full px-2.5 py-0.5">
                          <User className="h-3 w-3" />
                          For: Myself
                        </span>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <MapPin className="h-3.5 w-3.5" />
                        {req.city}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3.5 w-3.5" />
                        {req.preferredDate 
                          ? `Scheduled for ${format(new Date(req.preferredDate), 'MMM dd, yyyy HH:mm')}`
                          : `Requested on ${format(new Date(req.createdAt), 'MMM dd, yyyy')}`
                        }
                      </span>
                    </div>
                    {isAssigned && req.assignedDoctor && (
                      <div className="mt-3 p-3 rounded-lg border border-border bg-muted/30 space-y-1.5">
                        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Assigned doctor</p>
                        <div className="flex items-center gap-2">
                          <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                            <User className="h-4 w-4 text-primary" />
                          </div>
                          <div>
                            <p className="font-medium">Dr. {req.assignedDoctor.name}</p>
                            {req.assignedDoctor.specialization && (
                              <p className="text-sm text-muted-foreground flex items-center gap-1">
                                <Stethoscope className="h-3 w-3" /> {req.assignedDoctor.specialization}
                              </p>
                            )}
                          </div>
                        </div>
                        {(req.assignedDoctor.email || req.assignedDoctor.phone) && (
                          <div className="flex flex-wrap gap-3 text-sm text-muted-foreground pt-1">
                            {req.assignedDoctor.email && (
                              <span className="flex items-center gap-1">
                                <Mail className="h-3 w-3" /> {req.assignedDoctor.email}
                              </span>
                            )}
                            {req.assignedDoctor.phone && (
                              <span className="flex items-center gap-1">
                                <Phone className="h-3 w-3" /> {req.assignedDoctor.phone}
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
