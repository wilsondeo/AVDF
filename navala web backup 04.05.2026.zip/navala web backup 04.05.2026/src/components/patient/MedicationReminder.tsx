import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Pill,
  Sun,
  Sunset,
  Moon,
  CheckCircle2,
  Plus,
  Pencil,
  Loader2,
} from 'lucide-react';
import { patientMedicationsApi, type PatientMedicationItem } from '@/services/api';
import { toast } from 'sonner';

const timeIcons = {
  morning: Sun,
  afternoon: Sunset,
  evening: Moon,
};

const timeLabels = {
  morning: 'Morning',
  afternoon: 'Afternoon',
  evening: 'Night',
};

const timeColors = {
  morning: 'text-amber-600 dark:text-amber-400 bg-amber-500/10',
  afternoon: 'text-accent bg-accent/10',
  evening: 'text-primary bg-primary/10',
};

export function MedicationReminder() {
  const [medications, setMedications] = useState<PatientMedicationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [addOpen, setAddOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editingMed, setEditingMed] = useState<PatientMedicationItem | null>(null);
  const [form, setForm] = useState({ name: '', dosage: '', timeOfDay: 'morning' as 'morning' | 'afternoon' | 'evening' });
  const [saving, setSaving] = useState(false);
  const [togglingId, setTogglingId] = useState<number | null>(null);

  const load = async () => {
    try {
      setLoading(true);
      const res = await patientMedicationsApi.getList();
      if (res.success && res.data) setMedications(res.data);
      else setMedications([]);
    } catch {
      setMedications([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const toggleMedication = async (id: number) => {
    const med = medications.find((m) => m.id === id);
    if (!med) return;
    setTogglingId(id);
    try {
      const res = await patientMedicationsApi.setTaken(id, !med.taken);
      if (res.success) {
        setMedications((prev) =>
          prev.map((m) => (m.id === id ? { ...m, taken: res.data!.taken } : m))
        );
      } else toast.error(res.message || 'Failed to update');
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to update');
    } finally {
      setTogglingId(null);
    }
  };

  const openAdd = () => {
    setForm({ name: '', dosage: '', timeOfDay: 'morning' });
    setAddOpen(true);
  };

  const openEdit = (med: PatientMedicationItem) => {
    setEditingMed(med);
    setForm({ name: med.name, dosage: med.dosage, timeOfDay: med.time });
    setEditOpen(true);
  };

  const handleAdd = async () => {
    if (!form.name.trim() || !form.dosage.trim()) {
      toast.error('Name and dosage are required');
      return;
    }
    setSaving(true);
    try {
      const res = await patientMedicationsApi.add({
        name: form.name.trim(),
        dosage: form.dosage.trim(),
        timeOfDay: form.timeOfDay,
      });
      if (res.success && res.data) {
        setMedications((prev) => [...prev, res.data!]);
        setAddOpen(false);
        toast.success('Medication added');
      } else toast.error(res.message || 'Failed to add');
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to add');
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = async () => {
    if (!editingMed || !form.name.trim() || !form.dosage.trim()) return;
    setSaving(true);
    try {
      const res = await patientMedicationsApi.update(editingMed.id, {
        name: form.name.trim(),
        dosage: form.dosage.trim(),
        timeOfDay: form.timeOfDay,
      });
      if (res.success && res.data) {
        setMedications((prev) =>
          prev.map((m) => (m.id === editingMed.id ? res.data! : m))
        );
        setEditOpen(false);
        setEditingMed(null);
        toast.success('Medication updated');
      } else toast.error(res.message || 'Failed to update');
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to update');
    } finally {
      setSaving(false);
    }
  };

  const completedCount = medications.filter((m) => m.taken).length;
  const progress = medications.length ? (completedCount / medications.length) * 100 : 0;

  return (
    <>
      <Card className="rounded-xl border border-border/60 bg-card shadow-sm">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between gap-2">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Pill className="h-5 w-5 text-accent" strokeWidth={2} />
              Today's Medications
            </CardTitle>
            <div className="flex items-center gap-2 shrink-0">
              <Button variant="outline" size="sm" className="h-8 rounded-lg" onClick={openAdd}>
                <Plus className="h-4 w-4 mr-1" />
                Add
              </Button>
              {medications.length > 0 && (
                <>
                  <span className="text-xs text-muted-foreground tabular-nums">{Math.round(progress)}%</span>
                  <Badge variant={progress === 100 ? 'success' : 'secondary'} className="rounded-md text-xs">
                    {completedCount}/{medications.length} taken
                  </Badge>
                </>
              )}
            </div>
          </div>
          {medications.length > 0 && (
            <div className="w-full h-2 bg-muted rounded-full mt-3 overflow-hidden">
              <div
                className="h-full bg-emerald-500 dark:bg-emerald-600 transition-all duration-500 rounded-full"
                style={{ width: `${progress}%` }}
              />
            </div>
          )}
        </CardHeader>
        <CardContent className="space-y-2">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : medications.length === 0 ? (
            <div className="text-center py-6">
              <p className="text-sm text-muted-foreground mb-3">No medications added yet.</p>
              <Button variant="outline" size="sm" onClick={openAdd}>
                <Plus className="h-4 w-4 mr-2" />
                Add Medication
              </Button>
            </div>
          ) : (
            medications.map((med) => {
              const TimeIcon = timeIcons[med.time];
              const label = timeLabels[med.time];
              return (
                <div
                  key={med.id}
                  className={`flex items-center gap-3 p-3 rounded-xl transition-colors ${
                    med.taken ? 'bg-emerald-500/10 opacity-80' : 'bg-muted/50 hover:bg-muted'
                  }`}
                >
                  <Checkbox
                    checked={med.taken}
                    onCheckedChange={() => toggleMedication(med.id)}
                    disabled={togglingId === med.id}
                    className="h-4 w-4 shrink-0 mt-0.5"
                  />
                  <div className={`h-8 w-8 rounded-lg flex items-center justify-center shrink-0 ${timeColors[med.time]}`}>
                    <TimeIcon className="h-4 w-4" strokeWidth={2} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-xs text-muted-foreground ${med.taken ? 'opacity-80' : ''}`}>{label}</p>
                    <p className={`font-medium text-sm ${med.taken ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
                      {med.name}
                    </p>
                    <p className="text-xs text-muted-foreground">{med.dosage}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 shrink-0"
                    onClick={() => openEdit(med)}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  {med.taken && (
                    <CheckCircle2 className="h-5 w-5 text-emerald-600 dark:text-emerald-400 shrink-0" strokeWidth={2} />
                  )}
                </div>
              );
            })
          )}
        </CardContent>
      </Card>

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Medication</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>Name</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                placeholder="e.g. Vitamin D3"
              />
            </div>
            <div>
              <Label>Dosage</Label>
              <Input
                value={form.dosage}
                onChange={(e) => setForm((f) => ({ ...f, dosage: e.target.value }))}
                placeholder="e.g. 1000 IU"
              />
            </div>
            <div>
              <Label>Time of day</Label>
              <Select
                value={form.timeOfDay}
                onValueChange={(v: 'morning' | 'afternoon' | 'evening') =>
                  setForm((f) => ({ ...f, timeOfDay: v }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="morning">Morning</SelectItem>
                  <SelectItem value="afternoon">Afternoon</SelectItem>
                  <SelectItem value="evening">Night</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(false)}>Cancel</Button>
            <Button onClick={handleAdd} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Add'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={editOpen} onOpenChange={(open) => { setEditOpen(open); if (!open) setEditingMed(null); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit medication</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>Name</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                placeholder="e.g. Vitamin D3"
              />
            </div>
            <div>
              <Label>Dosage</Label>
              <Input
                value={form.dosage}
                onChange={(e) => setForm((f) => ({ ...f, dosage: e.target.value }))}
                placeholder="e.g. 1000 IU"
              />
            </div>
            <div>
              <Label>Time of day</Label>
              <Select
                value={form.timeOfDay}
                onValueChange={(v: 'morning' | 'afternoon' | 'evening') =>
                  setForm((f) => ({ ...f, timeOfDay: v }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="morning">Morning</SelectItem>
                  <SelectItem value="afternoon">Afternoon</SelectItem>
                  <SelectItem value="evening">Night</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button onClick={handleEdit} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Save'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
