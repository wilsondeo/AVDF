import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Calendar, 
  Plane, 
  Map as MapIcon, 
  ChevronRight,
  Navigation2,
  DollarSign,
  Clock
} from 'lucide-react';
import { itineraryApi, UserItineraryItem } from '@/services/api';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';

export const PatientItineraryCard = () => {
  const [itineraries, setItineraries] = useState<UserItineraryItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchItinerary = async () => {
      try {
        const res = await itineraryApi.getMyItinerary();
        if (res.success && res.data) {
          setItineraries(res.data);
        }
      } catch (error) {
        console.error("Failed to fetch itinerary", error);
      } finally {
        setLoading(false);
      }
    };
    fetchItinerary();
  }, []);

  if (loading) return null;
  if (itineraries.length === 0) return null;

  const totalTaxPaid = itineraries.reduce((sum, item) => sum + (item.taxPaid || 0), 0);

  return (
    <Card className="shadow-card border-border/60 overflow-hidden group hover:shadow-lg transition-all duration-300">
      <CardHeader className="bg-primary/5 py-4 border-b border-primary/10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-primary/10 p-2 rounded-lg">
              <Plane className="h-5 w-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-base font-bold">Your Travel Itinerary</CardTitle>
              <CardDescription className="text-xs">
                {itineraries.length} Destinations planned
              </CardDescription>
            </div>
          </div>
          {totalTaxPaid > 0 && (
            <Badge variant="outline" className="bg-background font-mono text-[10px] py-0 border-primary/20">
              Tax Paid: ${totalTaxPaid.toFixed(2)}
            </Badge>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="relative">
          {/* Vertical line connector */}
          <div className="absolute left-[2.25rem] top-6 bottom-6 w-0.5 bg-gradient-to-b from-primary/30 to-muted z-0" />
          
          <div className="space-y-0 relative z-10 px-4 py-4">
            {itineraries.map((item, index) => (
              <div key={item.id || index} className="group/item flex items-start gap-4 p-3 rounded-xl hover:bg-muted/50 transition-colors">
                <div className="mt-1 flex-shrink-0">
                  <div className="h-8 w-8 rounded-full bg-background border-2 border-primary flex items-center justify-center text-xs font-bold text-primary shadow-sm group-hover/item:scale-110 transition-transform">
                    {index + 1}
                  </div>
                </div>
                
                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-foreground">
                      {item.location?.city || 'Unknown'}, {item.location?.country || ''}
                    </h4>
                    <div className="flex items-center gap-1 text-[10px] text-muted-foreground font-medium">
                      <Clock className="h-3 w-3" />
                      Trip segment {index + 1}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5 text-primary/60" />
                      {item.arrivalDate ? format(new Date(item.arrivalDate), 'MMM dd') : '—'} 
                      <ChevronRight className="h-3 w-3 mx-0.5" />
                      {item.departureDate ? format(new Date(item.departureDate), 'MMM dd') : '—'}
                    </div>
                  </div>
                  
                  {item.taxPaid !== undefined && item.taxPaid > 0 && (
                    <div className="flex items-center gap-1 text-[10px] font-semibold text-primary/70 bg-primary/5 w-fit px-2 py-0.5 rounded-full border border-primary/10 mt-1">
                      <DollarSign className="h-2.5 w-2.5" />
                      Local Compliance Tax: ${item.taxPaid.toFixed(2)}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="p-4 bg-muted/30 border-t border-border/40 text-center">
            <p className="text-[10px] text-muted-foreground flex items-center justify-center gap-1">
                <Navigation2 className="h-3 w-3" />
                This itinerary is used to coordinate your medical care across cities.
            </p>
        </div>
      </CardContent>
    </Card>
  );
};
