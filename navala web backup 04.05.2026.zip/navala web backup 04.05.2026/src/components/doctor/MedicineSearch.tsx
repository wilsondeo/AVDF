import React, { useState, useEffect, useRef } from 'react';
import { Check, ChevronsUpDown, Search, Pill, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { prescriptionApi } from "@/services/api";

interface MedicineSearchProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export function MedicineSearch({ value, onChange, placeholder = "Search or type medicine name..." }: MedicineSearchProps) {
  const [open, setOpen] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const debounceTimer = useRef<any>(null);

  useEffect(() => {
    if (searchValue.trim().length > 1) {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
      
      debounceTimer.current = setTimeout(async () => {
        setLoading(true);
        try {
          const res = await prescriptionApi.searchMedicines(searchValue);
          if (res.success && res.data) {
            setResults(res.data);
          }
        } catch (error) {
          console.error("Search failed", error);
        } finally {
          setLoading(false);
        }
      }, 300);
    } else {
      setResults([]);
    }
  }, [searchValue]);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between bg-white dark:bg-slate-900 border-none font-bold text-sm h-10 px-3 hover:bg-slate-50 dark:hover:bg-slate-800 transition-all text-left"
        >
          <div className="flex items-center gap-2 overflow-hidden">
            <Pill className="h-4 w-4 shrink-0 text-primary opacity-50" />
            <span className="truncate">{value || placeholder}</span>
          </div>
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[var(--radix-popover-trigger-width)] p-0" align="start">
        <Command shouldFilter={false}>
          <CommandInput 
            placeholder="Type to search..." 
            value={searchValue} 
            onValueChange={setSearchValue}
          />
          <CommandList>
            {loading && (
              <div className="py-6 flex items-center justify-center">
                <Loader2 className="h-4 w-4 animate-spin text-primary" />
              </div>
            )}
            {!loading && searchValue.trim() !== "" && results.length === 0 && (
                <CommandItem
                value={searchValue}
                onSelect={() => {
                  onChange(searchValue);
                  setOpen(false);
                }}
                className="cursor-pointer"
              >
                <Plus className="mr-2 h-4 w-4 text-primary" />
                Add "{searchValue}" to store
              </CommandItem>
            )}
            <CommandGroup>
              {results.map((item) => (
                <CommandItem
                  key={item.id}
                  value={item.name}
                  onSelect={() => {
                    onChange(item.name);
                    setOpen(false);
                  }}
                  className="cursor-pointer"
                >
                  <Check
                    className={cn(
                      "mr-2 h-4 w-4 text-primary",
                      value === item.name ? "opacity-100" : "opacity-0"
                    )}
                  />
                  {item.name}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

const Plus = ({ className }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M5 12h14"/><path d="M12 5v14"/></svg>
);
