import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useAppStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Bell, LogOut, User, Menu, X } from 'lucide-react';
import { useState } from 'react';
import navalaLogo from '@/assets/navala.png';

interface NavItem {
  name: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  disabled?: boolean;
}

interface DashboardLayoutProps {
  children: React.ReactNode;
  navigation: NavItem[];
  title: string;
}

export function DashboardLayout({ children, navigation, title }: DashboardLayoutProps) {
  const location = useLocation();
  const { currentUser, logout, notifications } = useAppStore();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const unreadNotifications = notifications.filter(n => n.userId === currentUser?.id && !n.read).length;

  const handleLogout = () => {
    const userRole = currentUser?.role;
    logout();
    // Redirect based on user role
    if (userRole === 'admin') {
      window.location.href = '/admin/login';
    } else {
    window.location.href = '/login';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Top Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-card shadow-sm print:hidden">
        <div className="flex h-16 items-center justify-between px-4 lg:px-8">
          {/* Logo & Mobile Menu */}
          <div className="flex items-center gap-4">
            <button
              className="lg:hidden p-2 hover:bg-muted rounded-lg"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
            <Link
              to={
                currentUser?.role === 'patient'
                  ? '/patient'
                  : currentUser?.role === 'admin'
                    ? '/admin'
                    : currentUser?.role === 'doctor'
                      ? '/doctor'
                      : '/'
              }
              className="flex items-center gap-3"
            >
              <img src={navalaLogo} alt="Navala" className="h-8 w-auto" />
            </Link>
            <span className="hidden sm:block text-sm font-medium text-muted-foreground border-l border-border pl-4">
              {title}
            </span>
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-2">
            {/* Notifications */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative hover:bg-accent/15 hover:text-accent">
                  <Bell className="h-5 w-5" />
                  {unreadNotifications > 0 && (
                    <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-destructive text-destructive-foreground text-xs flex items-center justify-center">
                      {unreadNotifications}
                    </span>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80">
                <DropdownMenuLabel>Notifications</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {notifications.length === 0 ? (
                  <div className="p-4 text-center text-sm text-muted-foreground">
                    No notifications yet
                  </div>
                ) : (
                  notifications.slice(0, 5).map(n => (
                    <DropdownMenuItem key={n.id} className="flex flex-col items-start p-3">
                      <span className="font-medium">{n.title}</span>
                      <span className="text-xs text-muted-foreground">{n.message}</span>
                    </DropdownMenuItem>
                  ))
                )}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Profile Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2 hover:bg-accent/15 hover:text-accent">
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="h-4 w-4 text-primary" />
                  </div>
                  <span className="hidden md:block font-medium">{currentUser?.name}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div>
                    <p className="font-medium">{currentUser?.name}</p>
                    <p className="text-xs text-muted-foreground">{currentUser?.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <Link to={currentUser?.role === 'patient' ? '/patient/profile' : currentUser?.role === 'admin' ? '/admin/profile' : '#'}>
                  <DropdownMenuItem>
                    <User className="mr-2 h-4 w-4" />
                    Profile Settings
                  </DropdownMenuItem>
                </Link>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-destructive">
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar Navigation - Desktop */}
        <aside className="hidden lg:flex w-64 flex-col border-r border-border bg-card min-h-[calc(100vh-4rem)] print:hidden">
          <nav className="flex-1 p-3 space-y-0.5">
            {navigation.map((item) => {
              const isActive = location.pathname === item.href;
              if (item.disabled) {
                return (
                  <span
                    key={item.name}
                    title="Plan required"
                    className={cn(
                      'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors cursor-not-allowed opacity-60'
                    )}
                  >
                    <item.icon className="h-5 w-5 shrink-0" strokeWidth={2} />
                    {item.name}
                  </span>
                );
              }
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  title={item.name}
                  className={cn(
                    'flex items-center gap-3 rounded-lg px-3 py-[0.1rem] text-[1rem] leading-[3rem] font-medium transition-colors border-l-2 border-transparent',
                    isActive
                      ? 'bg-primary/10 text-primary border-l-primary'
                      : 'text-muted-foreground hover:bg-muted hover:text-foreground border-l-transparent'
                  )}
                >
                  <item.icon className="h-5 w-5 shrink-0" strokeWidth={2} />
                  {item.name}
                </Link>
              );
            })}
          </nav>
        </aside>

        {/* Mobile Navigation Overlay */}
        {mobileMenuOpen && (
          <div className="lg:hidden fixed inset-0 z-40 bg-background/80 backdrop-blur-sm print:hidden" onClick={() => setMobileMenuOpen(false)}>
            <aside className="fixed left-0 top-16 w-64 h-full bg-card border-r border-border animate-slide-in-right print:hidden">
              <nav className="p-3 space-y-0.5">
                {navigation.map((item) => {
                  const isActive = location.pathname === item.href;
                  if (item.disabled) {
                    return (
                      <span
                        key={item.name}
                        title="Plan required"
                        className="flex items-center gap-3 rounded-lg px-3 py-[0.1rem] text-[1rem] leading-[3rem] font-medium opacity-60 cursor-not-allowed"
                      >
                        <item.icon className="h-5 w-5 shrink-0" strokeWidth={2} />
                        {item.name}
                      </span>
                    );
                  }
                  return (
                    <Link
                      key={item.name}
                      to={item.href}
                      onClick={() => setMobileMenuOpen(false)}
                      title={item.name}
                      className={cn(
                        'flex items-center gap-3 rounded-lg px-3 py-[0.1rem] text-[1rem] leading-[3rem] font-medium transition-colors border-l-2 border-transparent',
                        isActive
                          ? 'bg-primary/10 text-primary border-l-primary'
                          : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                      )}
                    >
                      <item.icon className="h-5 w-5 shrink-0" strokeWidth={2} />
                      {item.name}
                    </Link>
                  );
                })}
              </nav>
            </aside>
          </div>
        )}

        {/* Main Content */}
        <main className="flex-1 p-4 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  );
}
