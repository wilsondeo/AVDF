import React, { useState, useEffect } from 'react';
import {
  MapPin,
  Calendar,
  Plus,
  Trash2,
  Info,
  AlertCircle,
  TrendingDown,
  Navigation,
  CheckCircle2,
  Globe
} from 'lucide-react';
import { locationApi, systemConfigApi, DBLocation } from '@/services/api';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export interface ItineraryDestination {
  locationId: number;
  arrivalDate: string;
  departureDate: string;
  city?: string;
  selectedCountry?: string;
  selectedState?: string;
  taxValue: number;
  taxType?: 'FIXED' | 'PERCENTAGE';
}

interface ItineraryBuilderProps {
  onItineraryChange: (itinerary: ItineraryDestination[], totalTax: number) => void;
}

const ItineraryBuilder: React.FC<ItineraryBuilderProps> = ({ onItineraryChange }) => {
  const [locations, setLocations] = useState<DBLocation[]>([]);
  const [itinerary, setItinerary] = useState<ItineraryDestination[]>([]);
  const [taxEnabled, setTaxEnabled] = useState(true);
  const [taxStrategy, setTaxStrategy] = useState('SUM');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    try {
      const [locRes, taxEnabledRes, strategyRes] = await Promise.all([
        locationApi.getAll(),
        systemConfigApi.get('is_location_tax_enabled'),
        systemConfigApi.get('multi_city_tax_strategy')
      ]);

      if (locRes.success && locRes.data) {
        setLocations(locRes.data.filter(l => l.isTaxEnabled));
      }
      setTaxEnabled(taxEnabledRes.success ? taxEnabledRes.data === 'true' : true);
      setTaxStrategy(strategyRes.success ? strategyRes.data : 'SUM');
    } catch (error) {
      console.error('Failed to load itinerary data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    calculateAndNotify();
  }, [itinerary, taxEnabled, taxStrategy]);

  const calculateAndNotify = () => {
    let totalTax = 0;
    if (taxEnabled && itinerary.length > 0) {
      // Group by country to apply unique country tax logic
      const countryTaxes: Record<string, number> = {};
      itinerary.forEach(dest => {
        if (dest.selectedCountry && !countryTaxes[dest.selectedCountry]) {
          countryTaxes[dest.selectedCountry] = dest.taxValue;
        }
      });
      const uniqueCountryTaxValues = Object.values(countryTaxes);

      if (taxStrategy === 'SUM') {
        totalTax = uniqueCountryTaxValues.reduce((sum, val) => sum + val, 0);
      } else if (taxStrategy === 'MAX') {
        totalTax = Math.max(...uniqueCountryTaxValues, 0);
      } else if (taxStrategy === 'PRIMARY') {
        totalTax = itinerary[0].taxValue;
      }
    }
    onItineraryChange(itinerary, totalTax);
  };

  const addDestination = () => {
    const newDest: ItineraryDestination = {
      locationId: 0,
      arrivalDate: '',
      departureDate: '',
      taxValue: 0
    };
    setItinerary([...itinerary, newDest]);
  };

  const removeDestination = (index: number) => {
    const newItinerary = [...itinerary];
    newItinerary.splice(index, 1);
    setItinerary(newItinerary);
  };

  const updateDestination = (index: number, field: keyof ItineraryDestination, value: any) => {
    const newItinerary = [...itinerary];
    if (field === 'locationId') {
      const selectedLoc = locations.find(l => l.id === parseInt(value));
      newItinerary[index] = {
        ...newItinerary[index],
        locationId: parseInt(value),
        city: selectedLoc?.city,
        selectedCountry: selectedLoc?.country,
        selectedState: selectedLoc?.state,
        taxValue: selectedLoc?.taxValue || 0,
        taxType: selectedLoc?.taxType || 'FIXED'
      };
    } else {
      newItinerary[index] = { ...newItinerary[index], [field]: value };
    }
    setItinerary(newItinerary);
  };

  if (loading) return <div className="text-center p-4">Loading destinations...</div>;

  return (
    <div className="space-y-6 animate-in slide-in-from-bottom duration-700">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Navigation className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold tracking-tight">Your Travel Destinations</h3>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={addDestination}
          className="border-primary/20 hover:bg-primary/5 hover:text-primary transition-all"
        >
          <Plus className="h-4 w-4 mr-1" /> Add City
        </Button>
      </div>

      {itinerary.length === 0 ? (
        <Card className="border-dashed border-2 bg-muted/30">
          <CardContent className="flex flex-col items-center justify-center py-10 text-center">
            <div className="bg-primary/10 p-3 rounded-full mb-3">
              <MapPin className="h-6 w-6 text-primary/60" />
            </div>
            <p className="text-sm font-medium text-muted-foreground">No destinations added yet.</p>
            <p className="text-xs text-muted-foreground mt-1">Add cities to calculate government taxes and plan your trip.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="relative space-y-4">
          <div className="absolute left-6 top-8 bottom-8 w-0.5 bg-gradient-to-b from-primary/40 to-transparent z-0" />

          {itinerary.map((dest, index) => {
            const isFirstInCountry = dest.selectedCountry && 
              itinerary.findIndex(d => d.selectedCountry === dest.selectedCountry) === index;

            return (
              <div key={index} className="relative z-10 bg-card border rounded-xl p-4 pt-6 shadow-sm hover:shadow-md transition-all animate-in zoom-in-95 duration-300 group/dest">
              {/* Delete Button - Top Right */}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => removeDestination(index)}
                className="absolute top-2 right-2 text-muted-foreground/40 hover:text-red-500 hover:bg-red-50 rounded-full h-8 w-8 transition-all opacity-0 group-hover/dest:opacity-100 z-20"
              >
                <Trash2 className="h-4 w-4" />
              </Button>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-start">
              <div className="md:col-span-1 flex justify-center pt-2">
                <div className="bg-primary text-white h-7 w-7 rounded-full flex items-center justify-center text-xs font-bold shadow-lg ring-4 ring-background">
                  {index + 1}
                </div>
              </div>

              <div className="md:col-span-3 space-y-2">
                <div className="flex items-center gap-2 mb-1">
                  <Globe className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Country</span>
                </div>
                <Select
                  value={dest.selectedCountry || ""}
                  onValueChange={(val) => {
                    const newItinerary = [...itinerary];
                    newItinerary[index] = { 
                      ...newItinerary[index], 
                      selectedCountry: val, 
                      selectedState: '', 
                      locationId: 0, 
                      city: '',
                      taxValue: 0 
                    };
                    setItinerary(newItinerary);
                  }}
                >
                  <SelectTrigger className="w-full bg-background/50 border-primary/10 h-11">
                    <SelectValue placeholder="Select Country" />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from(new Set(locations.map(l => l.country))).sort().map(country => (
                      <SelectItem key={country} value={country}>
                        {country}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="md:col-span-3 space-y-2">
                <div className="flex items-center gap-2 mb-1">
                  <Navigation className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">City</span>
                </div>
                <Select
                  value={dest.locationId > 0 ? dest.locationId.toString() : ""}
                  onValueChange={(val) => {
                    const selectedLoc = locations.find(l => l.id === parseInt(val));
                    const newItinerary = [...itinerary];
                    newItinerary[index] = {
                      ...newItinerary[index],
                      locationId: parseInt(val),
                      city: selectedLoc?.city,
                      selectedCountry: selectedLoc?.country,
                      selectedState: selectedLoc?.state, // Auto-fill state
                      taxValue: selectedLoc?.taxValue || 0,
                      taxType: selectedLoc?.taxType || 'FIXED'
                    };
                    setItinerary(newItinerary);
                  }}
                  disabled={!dest.selectedCountry}
                >
                  <SelectTrigger className="w-full bg-background/50 border-primary/10 h-11">
                    <SelectValue placeholder={dest.selectedCountry ? "Select City" : "Choose Country first"} />
                  </SelectTrigger>
                  <SelectContent>
                    {locations
                      .filter(loc => loc.country === dest.selectedCountry)
                      .sort((a, b) => a.city.localeCompare(b.city))
                      .map(loc => (
                        <SelectItem key={loc.id} value={loc.id.toString()}>
                          {loc.city} {loc.state ? `(${loc.state})` : ''}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="md:col-span-2 space-y-2">
                <div className="flex items-center gap-2 mb-1">
                  <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Arrival</span>
                </div>
                <Input
                  type="date"
                  value={dest.arrivalDate}
                  onChange={(e) => updateDestination(index, 'arrivalDate', e.target.value)}
                  className="bg-background/50 border-primary/10 h-11"
                />
              </div>

              <div className="md:col-span-3 space-y-2">
                <div className="flex items-center gap-2 mb-1">
                  <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Departure</span>
                </div>
                <Input
                  type="date"
                  value={dest.departureDate}
                  onChange={(e) => updateDestination(index, 'departureDate', e.target.value)}
                  className="bg-background/50 border-primary/10 h-11"
                />
              </div>


              {/* State Row - Auto filled */}
              <div className="md:col-start-2 md:col-span-6 space-y-2 mt-2">
                <div className="flex items-center gap-2 mb-1">
                  <MapPin className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">State / Province</span>
                </div>
                <div className="w-full bg-muted/50 border border-dashed border-primary/10 rounded-lg px-4 py-2.5 text-sm text-foreground/80 flex items-center gap-2 min-h-[44px]">
                  {dest.selectedState ? (
                    <>
                      <CheckCircle2 className="h-4 w-4 text-success" />
                      <span className="font-semibold">{dest.selectedState}</span>
                    </>
                  ) : (
                    <span className="text-muted-foreground italic">Select a city to auto-fill state</span>
                  )}
                </div>
              </div>

              {taxEnabled && dest.taxValue > 0 && isFirstInCountry && (
                <div className="md:col-start-2 md:col-span-10 mt-1 flex items-center gap-2">
                  <Badge variant="secondary" className="bg-primary/5 text-primary text-[10px] font-mono border-primary/10 py-0">
                    Gov. Tax Contribution: ${(Number(dest.taxValue) || 0).toFixed(2)}
                  </Badge>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Info className="h-3 w-3 text-muted-foreground/50 cursor-help" />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs">Location-based government health charge for {dest.city}.</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {taxEnabled && itinerary.length > 0 && (
        <div className="bg-blue-50/50 border border-blue-100 rounded-xl p-4 flex items-start gap-4">
          <div className="bg-blue-100 p-2 rounded-full">
            <CheckCircle2 className="h-5 w-5 text-blue-600" />
          </div>
          <div className="space-y-1">
            <p className="text-sm font-semibold text-blue-900">Tax Calculation logic</p>
            <p className="text-xs text-blue-700">
              The admin has set the strategy to <b>{taxStrategy}</b>.
              {taxStrategy === 'SUM' && " Unique country taxes are being added to your total."}
              {taxStrategy === 'MAX' && " Only the highest tax rate among your destination countries will be charged."}
              {taxStrategy === 'PRIMARY' && " Only the first destination in your list determines the tax."}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default ItineraryBuilder;
