import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { prescriptionApi } from '@/services/api';
import { Stethoscope, Pill, Phone, MapPin, Mail, Loader2, Hospital } from 'lucide-react';
import { format } from 'date-fns';

export default function PrintPrescriptionPage() {
  const { uuid } = useParams();
  const navigate = useNavigate();
  const [prescription, setPrescription] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPrescription = async () => {
      if (!uuid) return;
      try {
        const res = await prescriptionApi.getById(uuid);
        if (res.success && res.data) {
          // If the getByAppointmentUuid fallback doesn't exactly match UUID param, 
          // we might just need to fetch the prescription by its own ID. 
          // Currently, getByAppointmentUuid exists. Let's use it or assume the UUID passed is appointmentUuid.
          setPrescription(res.data);
        } else {
           console.error("Not found");
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchPrescription();
  }, [uuid]);

  useEffect(() => {
    if (!loading && prescription) {
      setTimeout(() => {
        window.print();
        // optionally navigate back after print dialog closes, but it's often better to just let the user close the tab 
        // if they opened in a new tab.
      }, 500);
    }
  }, [loading, prescription]);

  if (loading) {
     return <div className="min-h-screen flex items-center justify-center bg-white"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>;
  }

  if (!prescription) {
     return <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <h1 className="text-xl font-bold">Prescription Not Found</h1>
        <button onClick={() => navigate(-1)} className="mt-4 text-primary">Go Back</button>
     </div>;
  }

  const familyMember = prescription.Appointment?.request?.familyMember ?? null;
  const accountHolder = prescription.patient || { firstName: 'Unknown', lastName: '' };
  const patient = familyMember || accountHolder;
  const doctor = prescription.Doctor || {};
  const doctorName = doctor.User ? `Dr. ${doctor.User.firstName} ${doctor.User.lastName}` : 'Attending Doctor';

  return (
    <div className="bg-white min-h-screen font-sans text-slate-800 p-8 print:p-0">
      <div className="max-w-3xl mx-auto bg-white print:w-full print:max-w-full">
        
        {/* Header */}
        <header className="flex items-center justify-between border-b-2 border-primary/20 pb-6 mb-8">
           <div className="flex items-center gap-3">
              <div className="h-14 w-14 rounded-xl bg-primary flex items-center justify-center">
                 <Hospital className="h-8 w-8 text-white" />
              </div>
              <div>
                 <h1 className="text-2xl font-black text-slate-900 tracking-tight">Navala Travel Health</h1>
                 <p className="text-sm font-semibold text-primary uppercase tracking-widest">Global Telemedicine</p>
              </div>
           </div>
           <div className="text-right text-xs text-slate-500 space-y-1">
              <p className="flex items-center justify-end gap-1"><Phone className="h-3 w-3" /> +1 (800) 555-0199</p>
              <p className="flex items-center justify-end gap-1"><Mail className="h-3 w-3" /> care@navala.health</p>
              <p className="flex items-center justify-end gap-1"><MapPin className="h-3 w-3" /> 123 Health Way, New York, NY</p>
           </div>
        </header>

        {/* Prescription Metadata */}
        <div className="flex justify-between items-start mb-10">
           <div>
              <h2 className="text-3xl font-serif italic text-slate-300 font-black tracking-tighter -mb-2">Rx</h2>
              <h3 className="text-xl font-bold text-slate-900">Medical Prescription</h3>
              <p className="text-xs font-bold text-slate-400">ID: {prescription.prescriptionUuid || prescription.id}</p>
           </div>
           <div className="text-right bg-slate-50 p-4 rounded-xl border border-slate-100">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Date of Issue</p>
              <p className="text-sm font-bold text-slate-900">{format(new Date(prescription.created_at || new Date()), 'MMMM dd, yyyy')}</p>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-3 mb-1">Prescribing Doctor</p>
              <p className="text-sm font-bold text-slate-900">{doctorName}</p>
              <p className="text-xs text-slate-500">{doctor.specialization || 'Medical Provider'}</p>
           </div>
        </div>

        {/* Patient Details */}
        <div className="bg-primary/5 border border-primary/10 rounded-2xl p-6 mb-10 flex justify-between">
           <div>
              <p className="text-[10px] font-bold text-primary uppercase tracking-widest mb-1">Patient Name</p>
              <p className="text-lg font-black text-slate-900">{patient.firstName} {patient.lastName}</p>
              {familyMember && (
                <p className="text-xs text-blue-600 font-semibold mt-1">
                  {familyMember.relationship || 'Family Member'} of {accountHolder.firstName} {accountHolder.lastName}
                </p>
              )}
           </div>
           <div className="text-right">
              <p className="text-[10px] font-bold text-primary uppercase tracking-widest mb-1">Patient Info</p>
              <p className="text-sm font-semibold text-slate-700">DOB: {patient.dateOfBirth || '--'}</p>
              <p className="text-sm font-semibold text-slate-700">Gender: {patient.gender || '--'}</p>
           </div>
        </div>

        {/* Diagnosis */}
        <div className="mb-10">
           <div className="flex items-center gap-2 mb-3">
              <Stethoscope className="h-5 w-5 text-primary" />
              <h4 className="text-lg font-bold text-slate-900">Diagnosis</h4>
           </div>
           <p className="text-slate-700 font-medium leading-relaxed pl-7">{prescription.diagnosis}</p>
        </div>

        {/* Medicines */}
        <div className="mb-12">
           <div className="flex items-center gap-2 mb-4 border-b border-slate-200 pb-2">
              <Pill className="h-5 w-5 text-accent" />
              <h4 className="text-lg font-bold text-slate-900">Medication Instructions</h4>
           </div>
           <div className="pl-7 space-y-6">
              {prescription.medicines?.map((med: any, i: number) => (
                 <div key={i} className="flex gap-4">
                    <div className="text-sm font-black text-slate-300 mt-0.5">{i + 1}.</div>
                    <div className="flex-1">
                       <h5 className="font-bold text-slate-900 text-lg mb-1">{med.name}</h5>
                       <div className="grid grid-cols-3 gap-4 mb-2">
                          <div>
                             <p className="text-[10px] font-bold text-slate-400 uppercase">Dosage</p>
                             <p className="text-sm font-semibold">{med.dosage}</p>
                          </div>
                          <div>
                             <p className="text-[10px] font-bold text-slate-400 uppercase">Frequency</p>
                             <p className="text-sm font-semibold">{med.frequency}</p>
                          </div>
                          <div>
                             <p className="text-[10px] font-bold text-slate-400 uppercase">Duration</p>
                             <p className="text-sm font-semibold">{med.duration}</p>
                          </div>
                       </div>
                       {med.foodInstructions && (
                          <p className="text-xs font-bold text-accent bg-accent/10 inline-block px-2 py-1 rounded-md">
                             {med.foodInstructions}
                          </p>
                       )}
                    </div>
                 </div>
              ))}
           </div>
        </div>

        <div className="grid grid-cols-2 gap-8 mb-16">
           {prescription.generalAdvice && (
              <div>
                 <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2 border-b border-slate-100 pb-1">General Advice</h4>
                 <p className="text-sm text-slate-700 leading-relaxed">{prescription.generalAdvice}</p>
              </div>
           )}
           {prescription.restrictions && (
              <div>
                 <h4 className="text-[10px] font-bold text-red-400 uppercase tracking-widest mb-2 border-b border-red-50 pb-1">Restrictions</h4>
                 <p className="text-sm text-red-600 leading-relaxed font-semibold">{prescription.restrictions}</p>
              </div>
           )}
        </div>

        {/* Footer / Signature */}
        <div className="mt-20 flex justify-between items-end border-t-2 border-slate-100 pt-8">
           <div className="text-xs text-slate-400">
              <p>This is a digitally generated and verified document.</p>
              <p>Valid only with the authorized provider's details above.</p>
           </div>
           <div className="w-48 text-center">
              <div className="border-b-2 border-slate-800 pb-1 mb-2">
                 {/* Dummy signature styling */}
                 <span className="font-serif italic text-2xl text-slate-800 opacity-80">{doctorName.replace('Dr. ', '')}</span>
              </div>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Provider Signature</p>
           </div>
        </div>

      </div>
      
      {/* Hide print button when printing */}
      <div className="fixed bottom-8 right-8 print:hidden">
         <button 
           onClick={() => window.print()}
           className="bg-primary text-white h-14 px-8 rounded-full shadow-2xl font-black uppercase tracking-widest hover:scale-105 transition-transform"
         >
           Print Document
         </button>
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        @media print {
           @page { margin: 15mm; }
           body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
      `}} />
    </div>
  );
}
