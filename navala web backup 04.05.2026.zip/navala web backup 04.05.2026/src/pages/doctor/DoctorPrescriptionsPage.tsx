import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { LayoutDashboard, Calendar, FileText, Users, Search, Download, Eye, Pill, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { useCallback, useEffect, useState } from 'react';
import { prescriptionApi } from '@/services/api';
import { Link } from 'react-router-dom';

const navigation = [
  { name: 'Dashboard', href: '/doctor', icon: LayoutDashboard },
  { name: 'Appointments', href: '/doctor/appointments', icon: Calendar },
  { name: 'Prescriptions', href: '/doctor/prescriptions', icon: FileText },
  { name: 'Patients', href: '/doctor/patients', icon: Users },
];

export default function DoctorPrescriptionsPage() {
  const [prescriptions, setPrescriptions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      const res = await prescriptionApi.getForDoctor();
      if (res.success && res.data) {
        setPrescriptions(res.data);
      }
    } catch (e) {
      console.error('Failed to load prescriptions', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const getDisplayName = (prescription: any): { name: string; isFamilyMember: boolean; accountHolder?: string } => {
    const fm = prescription.Appointment?.request?.familyMember;
    if (fm) {
      const holder = prescription.patient ? `${prescription.patient.firstName} ${prescription.patient.lastName}` : '';
      return { name: `${fm.firstName} ${fm.lastName}`, isFamilyMember: true, accountHolder: holder };
    }
    const name = prescription.patient ? `${prescription.patient.firstName} ${prescription.patient.lastName}` : 'Unknown';
    return { name, isFamilyMember: false };
  };

  const filteredPrescriptions = prescriptions.filter(prescription => {
    const { name } = getDisplayName(prescription);
    const accountName = prescription.patient ? `${prescription.patient.firstName} ${prescription.patient.lastName}` : '';
    return name.toLowerCase().includes(searchTerm.toLowerCase()) ||
           accountName.toLowerCase().includes(searchTerm.toLowerCase()) ||
           prescription.diagnosis.toLowerCase().includes(searchTerm.toLowerCase());
  });

  return (
    <DashboardLayout navigation={navigation} title="Prescriptions">
      <div className="space-y-6 animate-fade-in">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">Prescriptions</h1>
            <p className="text-muted-foreground mt-1">View and manage issued prescriptions</p>
          </div>
          <Button onClick={loadData} variant="outline" size="sm" disabled={loading}>
            Refresh
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[
            { label: 'Total Prescriptions', value: prescriptions.length, icon: FileText, color: 'text-primary' },
            { label: 'This Month', value: prescriptions.filter(p => new Date(p.created_at || new Date()).getMonth() === new Date().getMonth()).length, icon: Calendar, color: 'text-accent' },
            { label: 'Unique Patients', value: new Set(prescriptions.map(p => p.patient?.id)).size, icon: Users, color: 'text-success' },
          ].map((stat) => (
            <Card key={stat.label} className="shadow-card border-0">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                    <stat.icon className={`h-5 w-5 ${stat.color}`} />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">{stat.label}</p>
                    <p className="text-xl font-bold">{stat.value}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by patient name or diagnosis..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Prescriptions Table */}
        <Card className="shadow-card border-0">
          <CardHeader>
            <CardTitle>Issued Prescriptions</CardTitle>
            <CardDescription>
              {loading ? 'Loading...' : `${filteredPrescriptions.length} prescriptions found`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-12"><Loader2 className="h-12 w-12 animate-spin text-primary" /></div>
            ) : filteredPrescriptions.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                <p className="text-muted-foreground">No prescriptions found</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Prescription ID</TableHead>
                    <TableHead>Patient</TableHead>
                    <TableHead>Diagnosis</TableHead>
                    <TableHead>Medicines</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPrescriptions.map((prescription) => {
                    const { name: patientName, isFamilyMember, accountHolder } = getDisplayName(prescription);
                    const isDraft = prescription.status === 'DRAFT';
                    
                    return (
                      <TableRow key={prescription.id}>
                        <TableCell className="font-mono text-xs">#{prescription.prescriptionUuid?.slice(0, 8) || prescription.id}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                              <span className="text-primary text-xs font-semibold">{patientName.charAt(0)}</span>
                            </div>
                            <div>
                              <span className="font-medium block">{patientName}</span>
                              {isFamilyMember && accountHolder && (
                                <span className="text-xs text-blue-600 font-medium">via {accountHolder}</span>
                              )}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm">{prescription.diagnosis}</span>
                          {isDraft && <Badge variant="outline" className="ml-2 text-[10px] text-amber-500 border-amber-200 bg-amber-50">DRAFT</Badge>}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Pill className="h-4 w-4 text-accent" />
                            <span>{prescription.medicines?.length || 0} medications</span>
                          </div>
                        </TableCell>
                        <TableCell>{format(new Date(prescription.created_at || new Date()), 'MMM dd, yyyy')}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {prescription.Appointment ? (
                               <Link to={`/doctor/consultation/${prescription.Appointment.appointmentUuid}`}>
                                 <Button size="sm" variant="outline">
                                   <Eye className="h-4 w-4 mr-1" /> {isDraft ? 'Edit' : 'View'}
                                 </Button>
                               </Link>
                            ) : (
                               <Button size="sm" variant="outline" disabled>
                                 <Eye className="h-4 w-4 mr-1" /> View
                               </Button>
                            )}
                            <Button 
                               size="sm" 
                               variant="ghost" 
                               disabled={isDraft}
                               onClick={() => window.open(`/print/prescription/${prescription.prescriptionUuid || prescription.id}`, '_blank')}
                            >
                              <Download className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
