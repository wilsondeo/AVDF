import { useCallback, useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  LayoutDashboard,
  Calendar,
  FileText,
  Users,
  Video,
  Phone,
  User,
  MapPin,
  Clock,
  Play,
  Loader2,
} from 'lucide-react';
import { format } from 'date-fns';
import { Link } from 'react-router-dom';
import { appointmentApi, doctorApi } from '@/services/api';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

const navigation = [
  { name: 'Dashboard', href: '/doctor', icon: LayoutDashboard },
  { name: 'Appointments', href: '/doctor/appointments', icon: Calendar },
  { name: 'Prescriptions', href: '/doctor/prescriptions', icon: FileText },
  { name: 'Patients', href: '/doctor/patients', icon: Users },
  { name: 'Profile', href: '/doctor/profile', icon: User },
];

const statusConfig: Record<string, { variant: 'pending' | 'assigned' | 'inProgress' | 'completed'; label: string }> = {
  pending: { variant: 'pending', label: 'Pending' },
  doctor_assigned: { variant: 'assigned', label: 'Assigned' },
  in_progress: { variant: 'inProgress', label: 'In Progress' },
  completed: { variant: 'completed', label: 'Completed' },
};

export default function DoctorDashboard() {
  const { currentUser, startVideoCall } = useAppStore();
  const [appointments, setAppointments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isOnline, setIsOnline] = useState(false);
  const [isStatusLoading, setIsStatusLoading] = useState(false);

  const loadDoctorProfile = useCallback(async () => {
    try {
      const res = await doctorApi.getProfile();
      if (res.success && res.data) {
        // Handle both camelCase and snake_case from backend
        const status = res.data.isOnline ?? res.data.is_online;
        if (status !== undefined && status !== null) {
          setIsOnline(status);
          localStorage.setItem(`dr_online_${currentUser?.id}`, String(status));
          return;
        }
      }
      
      // Fallback to localStorage if backend returns nothing
      const localStatus = localStorage.getItem(`dr_online_${currentUser?.id}`);
      if (localStatus !== null) {
        setIsOnline(localStatus === 'true');
      }
    } catch (e) {
      console.error('Failed to load doctor profile', e);
      // Fallback on error
      const localStatus = localStorage.getItem(`dr_online_${currentUser?.id}`);
      if (localStatus !== null) {
        setIsOnline(localStatus === 'true');
      }
    }
  }, [currentUser?.id]);

  const handleStatusToggle = async (checked: boolean) => {
    setIsStatusLoading(true);
    // Optimistic update in localStorage
    localStorage.setItem(`dr_online_${currentUser?.id}`, String(checked));
    
    try {
      const res = await doctorApi.updateProfile({ 
        isOnline: checked,
        is_online: checked 
      });
      if (res.success) {
        setIsOnline(checked);
        toast.success(`You are now ${checked ? 'online' : 'offline'}`);
      } else {
        toast.error('Syncing error, but saved locally');
        setIsOnline(checked);
      }
    } catch (e) {
      toast.error('Connection error, saved locally');
      setIsOnline(checked);
    } finally {
      setIsStatusLoading(false);
    }
  };

  const loadAppointments = useCallback(async () => {
    try {
      setLoading(true);
      const res = await appointmentApi.getDoctorAppointments();
      if (res.success && res.data) {
        setAppointments(res.data);
      }
    } catch (e) {
      console.error('Failed to load appointments', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAppointments();
    loadDoctorProfile();
  }, [loadAppointments, loadDoctorProfile]);
  
  const todayAppointments = appointments.filter(a => {
    if (!a.appointmentDate) return false;
    const appointmentDate = new Date(a.appointmentDate).toDateString();
    return appointmentDate === new Date().toDateString() && a.status !== 'COMPLETED';
  });

  const handleStartCall = (appointmentUuid: string) => {
    startVideoCall(appointmentUuid);
  };

  return (
    <DashboardLayout navigation={navigation} title="Doctor Dashboard">
      <div className="space-y-8 animate-fade-in">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">Welcome, {currentUser?.name}</h1>
            <p className="text-muted-foreground mt-1">Manage your consultations and patients</p>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3 px-4 py-2 bg-card rounded-full border border-border shadow-sm">
              <div className={`h-2 w-2 rounded-full ${isOnline ? 'bg-success animate-pulse' : 'bg-slate-300'}`} />
              <Label htmlFor="live-status" className="text-sm font-bold cursor-pointer">
                {isOnline ? 'LIVE & ONLINE' : 'OFFLINE'}
              </Label>
              <Switch 
                id="live-status" 
                checked={isOnline} 
                onCheckedChange={handleStatusToggle}
                disabled={isStatusLoading}
              />
            </div>
            <Button onClick={loadAppointments} variant="outline" size="sm" disabled={loading} className="rounded-full">
              Refresh
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "Today's Appointments", value: todayAppointments.length, icon: Calendar, color: 'text-primary' },
            { label: 'Total Patients', value: new Set(appointments.map(a => a.patient?.id)).size, icon: Users, color: 'text-accent' },
            { label: 'Completed', value: appointments.filter(a => a.status === 'COMPLETED').length, icon: FileText, color: 'text-success' },
            { label: 'Scheduled', value: appointments.filter(a => a.status === 'SCHEDULED').length, icon: Clock, color: 'text-warning' },
          ].map((stat) => (
            <div key={stat.label} className="bg-card rounded-xl p-4 shadow-card border border-border">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                  <stat.icon className={`h-5 w-5 ${stat.color}`} />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <p className="text-xl font-bold">{stat.value}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Today's Appointments */}
        <Card className="shadow-card border-0">
          <CardHeader>
            <CardTitle>Today's Appointments</CardTitle>
            <CardDescription>{todayAppointments.length} scheduled for today</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
            ) : todayAppointments.length === 0 ? (
              <p className="text-center py-8 text-muted-foreground">No appointments scheduled for today</p>
            ) : (
              <div className="space-y-4">
                {todayAppointments.map((apt) => {
                  const isFamilyMember = !!apt.familyMember;
                  const patientName = isFamilyMember
                    ? `${apt.familyMember.firstName} ${apt.familyMember.lastName}`
                    : apt.patient ? `${apt.patient.firstName} ${apt.patient.lastName}` : 'Unknown Patient';
                  const status = statusConfig[apt.status] || { variant: 'outline', label: apt.status };
                  return (
                    <div key={apt.appointmentUuid} className="flex items-center justify-between p-4 rounded-lg border border-border">
                      <div className="flex items-center gap-4">
                        <div className={`h-12 w-12 rounded-xl flex items-center justify-center ${apt.serviceType === 'TELEHEALTH' ? 'bg-accent/10 text-accent' : 'bg-primary/10 text-primary'}`}>
                          {apt.serviceType === 'TELEHEALTH' ? <Video className="h-6 w-6" /> : <Phone className="h-6 w-6" />}
                        </div>
                        <div>
                          <p className="font-medium">{patientName}</p>
                          {isFamilyMember && (
                            <p className="text-xs text-blue-600 font-medium">
                              {apt.familyMember.relationship || 'Family'} of {apt.patient?.firstName} {apt.patient?.lastName}
                            </p>
                          )}
                          <div className="flex flex-col gap-1.5 text-xs mt-2 border border-border bg-card p-2 rounded-lg w-fit">
                            <div className="flex items-center gap-2 border-b pb-1">
                              <span className="text-muted-foreground w-16">Patient:</span>
                              <span className="font-medium flex items-center gap-1" title={apt.request?.timezone || 'UTC'}>
                                <Clock className="h-3 w-3" />
                                {apt.appointmentDate ? new Date(apt.appointmentDate).toLocaleString('en-US', { timeZone: apt.request?.timezone || 'UTC', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: true }) : '—'}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 pt-0.5">
                              <span className="text-accent/80 font-medium w-16">Your Time:</span>
                              <span className="font-bold text-accent flex items-center gap-1" title={apt.doctorTimezone || 'UTC'}>
                                <Clock className="h-3 w-3" />
                                {apt.appointmentDate ? new Date(apt.appointmentDate).toLocaleString('en-US', { timeZone: apt.doctorTimezone || 'UTC', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: true }) : '—'}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center gap-3 text-sm text-muted-foreground mt-2">
                            <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{apt.request?.city || '—'}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge variant={status.variant as any}>{status.label}</Badge>
                        {apt.serviceType === 'TELEHEALTH' && apt.status === 'SCHEDULED' && (
                          <Button size="sm" variant="accent" onClick={() => handleStartCall(apt.appointmentUuid)}>
                            <Video className="h-4 w-4 mr-1" /> Start Call
                          </Button>
                        )}
                        <Link to={`/doctor/consultation/${apt.appointmentUuid}`}>
                          <Button size="sm" variant="outline">View</Button>
                        </Link>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
