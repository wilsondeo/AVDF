import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { LayoutDashboard, Calendar, FileText, Users, Video, Phone, MapPin, Clock, Play, Info, User } from 'lucide-react';
import { format } from 'date-fns';
import { Link } from 'react-router-dom';
import { useCallback, useEffect, useState } from 'react';
import { appointmentApi } from '@/services/api';
import type { DoctorAppointment } from '@/services/api';
import { toast } from 'sonner';

const navigation = [
  { name: 'Dashboard', href: '/doctor', icon: LayoutDashboard },
  { name: 'Appointments', href: '/doctor/appointments', icon: Calendar },
  { name: 'Prescriptions', href: '/doctor/prescriptions', icon: FileText },
  { name: 'Patients', href: '/doctor/patients', icon: Users },
  { name: 'Profile', href: '/doctor/profile', icon: User },
];

const statusConfig: Record<string, { variant: 'default' | 'secondary' | 'destructive' | 'outline'; label: string }> = {
  SCHEDULED: { variant: 'default', label: 'Scheduled' },
  COMPLETED: { variant: 'secondary', label: 'Completed' },
  CANCELLED: { variant: 'destructive', label: 'Cancelled' },
};

export default function DoctorAppointmentsPage() {
  const [appointments, setAppointments] = useState<DoctorAppointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');

  const loadAppointments = useCallback(async () => {
    try {
      setLoading(true);
      const res = await appointmentApi.getDoctorAppointments();
      if (res.success && res.data) {
        setAppointments(res.data);
      } else {
        toast.error(res.message || 'Failed to load appointments');
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to load appointments');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAppointments();
  }, [loadAppointments]);

  const filteredAppointments = appointments.filter(
    (apt) => statusFilter === 'all' || apt.status === statusFilter
  );

  return (
    <DashboardLayout navigation={navigation} title="Appointments">
      <div className="space-y-6 animate-fade-in">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">My Appointments</h1>
            <p className="text-muted-foreground mt-1">Manage your patient consultations</p>
          </div>
          <div className="flex items-center gap-3">
            <Button onClick={loadAppointments} variant="outline" size="sm" disabled={loading}>
              Refresh
            </Button>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Filter status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="SCHEDULED">Scheduled</SelectItem>
                <SelectItem value="COMPLETED">Completed</SelectItem>
                <SelectItem value="CANCELLED">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Total', value: appointments.length },
            { label: 'Scheduled', value: appointments.filter((a) => a.status === 'SCHEDULED').length },
            { label: 'Completed', value: appointments.filter((a) => a.status === 'COMPLETED').length },
            { label: 'Cancelled', value: appointments.filter((a) => a.status === 'CANCELLED').length },
          ].map((stat) => (
            <Card key={stat.label} className="shadow-card border-0">
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground">{stat.label}</p>
                <p className="text-2xl font-bold">{stat.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="shadow-card border-0">
          <CardHeader>
            <CardTitle>All Appointments</CardTitle>
            <CardDescription>
              {loading ? 'Loading…' : `${filteredAppointments.length} appointments found`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Patient</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Service</TableHead>
                  <TableHead>Date & Time</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-24">Details</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAppointments.length === 0 && !loading && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                      No appointments assigned yet.
                    </TableCell>
                  </TableRow>
                )}
                {filteredAppointments.map((apt) => {
                  const status = statusConfig[apt.status] ?? { variant: 'outline' as const, label: apt.status };
                  const isForFamilyMember = !!apt.familyMember;
                  const displayName = isForFamilyMember
                    ? `${apt.familyMember!.firstName} ${apt.familyMember!.lastName}`.trim()
                    : apt.patient
                      ? `${apt.patient.firstName} ${apt.patient.lastName}`.trim()
                      : '—';

                  return (
                    <TableRow key={apt.appointmentUuid}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <span className="text-primary font-semibold">{displayName.charAt(0)}</span>
                          </div>
                          <div>
                            <p className="font-medium">{displayName}</p>
                            {isForFamilyMember && (
                              <p className="text-xs text-blue-600 font-medium">
                                {apt.familyMember!.relationship || 'Family'} of {apt.patient?.firstName ?? 'Patient'}
                              </p>
                            )}
                            {apt.patientDetails && (
                              <p className="text-xs text-muted-foreground">
                                Age: {apt.patientDetails.age}, {apt.patientDetails.gender}
                              </p>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <MapPin className="h-3 w-3 text-muted-foreground" />
                          {apt.city ?? '—'}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {apt.serviceType === 'TELEHEALTH' ? (
                            <><Video className="h-4 w-4 text-accent" /> Telehealth</>
                          ) : (
                            <><Phone className="h-4 w-4 text-primary" /> Emergency</>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3 text-muted-foreground" />
                          {apt.appointmentDate
                            ? format(new Date(apt.appointmentDate), 'MMM dd, yyyy HH:mm')
                            : '—'}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={status.variant}>{status.label}</Badge>
                      </TableCell>
                      <TableCell>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <Info className="h-4 w-4" />
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-80" align="end">
                            <div className="space-y-2">
                              <p className="font-medium text-sm">Patient details (for communication)</p>
                              {apt.patientDetails ? (
                                <dl className="text-sm space-y-1.5">
                                  <div><dt className="text-muted-foreground inline">Age:</dt> <dd className="inline">{apt.patientDetails.age}</dd></div>
                                  <div><dt className="text-muted-foreground inline">Gender:</dt> <dd className="inline">{apt.patientDetails.gender}</dd></div>
                                  <div><dt className="text-muted-foreground inline">Emergency contact:</dt> <dd className="inline">{apt.patientDetails.emergencyContact}</dd></div>
                                  {apt.patientDetails.notes && <div><dt className="text-muted-foreground inline">Notes:</dt> <dd className="inline break-words">{apt.patientDetails.notes}</dd></div>}
                                  {apt.patientDetails.allergies && <div><dt className="text-muted-foreground inline">Allergies / Cause:</dt> <dd className="inline break-words font-medium">{apt.patientDetails.allergies}</dd></div>}
                                </dl>
                              ) : (
                                <p className="text-muted-foreground text-xs">No details</p>
                              )}
                            </div>
                          </PopoverContent>
                        </Popover>
                      </TableCell>
                      <TableCell>
                        <Link to={`/doctor/consultation/${apt.appointmentUuid}`}>
                          <Button size="sm" variant="outline">View Details</Button>
                        </Link>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
