import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import {
  LayoutDashboard,
  User,
  Mail,
  Phone,
  MapPin,
  Shield,
  Edit,
  CheckCircle2,
  Calendar,
  FileText,
  Users,
} from 'lucide-react';
import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { userProfileApi, type UserProfile, type UpdateProfileRequest } from '@/services/api';
import { NotificationSettingsCard } from '@/components/settings/NotificationSettingsCard';

const navigation = [
  { name: 'Dashboard', href: '/doctor', icon: LayoutDashboard },
  { name: 'Appointments', href: '/doctor/appointments', icon: Calendar },
  { name: 'Prescriptions', href: '/doctor/prescriptions', icon: FileText },
  { name: 'Patients', href: '/doctor/patients', icon: Users },
];

function toInputDate(value: string | null | undefined): string {
  if (!value) return '';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '';
  return d.toISOString().slice(0, 10);
}

const GENDER_OPTIONS = [
  { value: '', label: 'Select…' },
  { value: 'Male', label: 'Male' },
  { value: 'Female', label: 'Female' },
  { value: 'Other', label: 'Other' },
];

/** Build form state from API profile. */
function formFromProfile(p: UserProfile | null): UpdateProfileRequest & { email?: string } {
  if (!p) {
    return {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      dateOfBirth: '',
      gender: '',
      city: '',
      state: '',
      country: 'United States',
    };
  }
  return {
    firstName: p.firstName ?? '',
    lastName: p.lastName ?? '',
    email: p.email ?? '',
    phone: p.phone ?? '',
    dateOfBirth: toInputDate(p.dateOfBirth) ?? '',
    gender: p.gender ?? '',
    city: p.city ?? '',
    state: p.state ?? '',
    country: p.country ?? 'United States',
  };
}

export default function DoctorProfilePage() {
  const navigate = useNavigate();
  const { currentUser, setUser } = useAppStore();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const [form, setForm] = useState<UpdateProfileRequest & { email?: string }>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    gender: '',
    city: '',
    state: '',
    country: 'United States',
  });

  const loadProfile = useCallback(async () => {
    try {
      setLoading(true);
      const res = await userProfileApi.getProfile();
      if (res.success && res.data) {
        setProfile(res.data);
        setForm(formFromProfile(res.data));
      }
    } catch (e) {
      toast.error('Failed to load profile');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadProfile();
  }, [loadProfile]);

  const handleSave = async () => {
    try {
      setSaving(true);
      const res = await userProfileApi.updateProfile({
        firstName: form.firstName,
        lastName: form.lastName,
        phone: form.phone,
        dateOfBirth: form.dateOfBirth,
        gender: form.gender,
        city: form.city,
        state: form.state,
        country: form.country,
      });
      if (res.success && res.data) {
        setProfile(res.data);
        setForm(formFromProfile(res.data));
        setUser({
          ...currentUser!,
          name: `${res.data.firstName} ${res.data.lastName}`.trim(),
          email: res.data.email,
        });
        setIsEditing(false);
        toast.success('Profile updated successfully!');
      }
    } catch (e) {
      toast.error('Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  if (loading && !profile) {
    return (
      <DashboardLayout navigation={navigation} title="My Profile">
        <div className="flex items-center justify-center min-h-[200px]">Loading profile...</div>
      </DashboardLayout>
    );
  }

  const initials = [form.firstName, form.lastName].filter(Boolean).map(n => n[0]).join('').toUpperCase() || 'D';

  return (
    <DashboardLayout navigation={navigation} title="My Profile">
      <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
        <Card className="shadow-card border-0 overflow-hidden">
          <div className="h-32 bg-primary/10" />
          <CardContent className="relative pb-6">
            <div className="absolute -top-16 left-6">
              <Avatar className="h-32 w-32 border-4 border-background shadow-lg">
                <AvatarImage src={currentUser?.avatar} />
                <AvatarFallback className="text-3xl bg-primary text-primary-foreground">
                  {initials}
                </AvatarFallback>
              </Avatar>
            </div>
            <div className="flex justify-end pt-2">
              <Button
                variant={isEditing ? 'default' : 'outline'}
                size="sm"
                disabled={saving}
                onClick={() => (isEditing ? handleSave() : setIsEditing(true))}
              >
                {isEditing ? (
                  <><CheckCircle2 className="h-4 w-4 mr-2" /> {saving ? 'Saving...' : 'Save Changes'}</>
                ) : (
                  <><Edit className="h-4 w-4 mr-2" /> Edit Profile</>
                )}
              </Button>
            </div>
            <div className="mt-8">
              <h1 className="text-2xl font-bold">{`${form.firstName} ${form.lastName}`}</h1>
              <p className="text-muted-foreground flex items-center gap-2 mt-1">
                <Mail className="h-4 w-4" /> {form.email}
              </p>
              <Badge className="mt-4 bg-primary/10 text-primary hover:bg-primary/20 border-0">
                <Shield className="h-3 w-3 mr-1" /> Doctor
              </Badge>
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-6">
          <Card className="shadow-card border-0">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <User className="h-5 w-5 text-primary" /> Personal Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>First Name</Label>
                  <Input 
                    value={form.firstName} 
                    onChange={e => setForm({...form, firstName: e.target.value})}
                    disabled={!isEditing}
                    className={!isEditing ? 'bg-muted' : ''}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Last Name</Label>
                  <Input 
                    value={form.lastName} 
                    onChange={e => setForm({...form, lastName: e.target.value})}
                    disabled={!isEditing}
                    className={!isEditing ? 'bg-muted' : ''}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Phone Number</Label>
                <Input 
                  value={form.phone} 
                  onChange={e => setForm({...form, phone: e.target.value})}
                  disabled={!isEditing}
                  className={!isEditing ? 'bg-muted' : ''}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Date of Birth</Label>
                  <Input 
                    type="date"
                    value={form.dateOfBirth} 
                    onChange={e => setForm({...form, dateOfBirth: e.target.value})}
                    disabled={!isEditing}
                    className={!isEditing ? 'bg-muted' : ''}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <select
                    value={form.gender}
                    onChange={e => setForm({...form, gender: e.target.value})}
                    disabled={!isEditing}
                    className={`flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 ${!isEditing ? 'bg-muted' : ''}`}
                  >
                    {GENDER_OPTIONS.map(opt => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-card border-0">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <MapPin className="h-5 w-5 text-primary" /> Location
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>City</Label>
                <Input 
                  value={form.city} 
                  onChange={e => setForm({...form, city: e.target.value})}
                  disabled={!isEditing}
                  className={!isEditing ? 'bg-muted' : ''}
                />
              </div>
              <div className="space-y-2">
                <Label>State</Label>
                <Input 
                  value={form.state} 
                  onChange={e => setForm({...form, state: e.target.value})}
                  disabled={!isEditing}
                  className={!isEditing ? 'bg-muted' : ''}
                />
              </div>
              <div className="space-y-2">
                <Label>Country</Label>
                <Input 
                  value={form.country} 
                  onChange={e => setForm({...form, country: e.target.value})}
                  disabled={!isEditing}
                  className={!isEditing ? 'bg-muted' : ''}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        <NotificationSettingsCard />
      </div>
    </DashboardLayout>
  );
}
