import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { LayoutDashboard, Calendar, FileText, Users, Search, Mail, Phone, MapPin, Clock, Eye, Loader2, User } from 'lucide-react';
import { format } from 'date-fns';
import { useState, useEffect, useCallback } from 'react';
import { appointmentApi } from '@/services/api';
import { Link } from 'react-router-dom';

const navigation = [
  { name: 'Dashboard', href: '/doctor', icon: LayoutDashboard },
  { name: 'Appointments', href: '/doctor/appointments', icon: Calendar },
  { name: 'Prescriptions', href: '/doctor/prescriptions', icon: FileText },
  { name: 'Patients', href: '/doctor/patients', icon: Users },
  { name: 'Profile', href: '/doctor/profile', icon: User },
];

export default function DoctorPatientsPage() {
  const [appointments, setAppointments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      const res = await appointmentApi.getDoctorAppointments();
      if (res.success && res.data) {
        setAppointments(res.data);
      }
    } catch (e) {
      console.error('Failed to load doctor patients', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Build list: account holders + family members as separate entries
  const patientsMap = new Map();
  appointments.forEach(apt => {
    if (apt.familyMember) {
      // Family member appointment — add the family member as a distinct patient entry
      const key = `family-${apt.patient?.id}-${apt.familyMember.firstName}-${apt.familyMember.lastName}`;
      if (!patientsMap.has(key)) {
        patientsMap.set(key, {
          id: key,
          firstName: apt.familyMember.firstName,
          lastName: apt.familyMember.lastName,
          relationship: apt.familyMember.relationship || 'Family Member',
          email: apt.patient?.email || '',
          city: apt.city,
          isFamilyMember: true,
          accountHolder: apt.patient ? `${apt.patient.firstName} ${apt.patient.lastName}` : '',
          patientDetails: apt.patientDetails,
          allAppointments: appointments.filter(a =>
            a.familyMember?.firstName === apt.familyMember?.firstName &&
            a.familyMember?.lastName === apt.familyMember?.lastName &&
            a.patient?.id === apt.patient?.id
          )
        });
      }
    } else if (apt.patient && !patientsMap.has(apt.patient.id)) {
      // Regular account holder appointment
      patientsMap.set(apt.patient.id, {
        ...apt.patient,
        city: apt.city,
        isFamilyMember: false,
        patientDetails: apt.patientDetails,
        allAppointments: appointments.filter(a => a.patient?.id === apt.patient.id && !a.familyMember)
      });
    }
  });

  const patients = Array.from(patientsMap.values());

  const filteredPatients = patients.filter(patient => {
    const fullName = `${patient.firstName || ''} ${patient.lastName || ''}`.toLowerCase();
    return fullName.includes(searchTerm.toLowerCase()) ||
           (patient.email || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
           (patient.city || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
           (patient.accountHolder || '').toLowerCase().includes(searchTerm.toLowerCase());
  });

  return (
    <DashboardLayout navigation={navigation} title="My Patients">
      <div className="space-y-6 animate-fade-in">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">My Patients</h1>
            <p className="text-muted-foreground mt-1">Patients you have consulted</p>
          </div>
          <Button onClick={loadData} variant="outline" size="sm" disabled={loading}>
            Refresh
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[
            { label: 'Total Patients', value: patients.length, color: 'text-primary' },
            { label: 'Active Cases', value: appointments.filter(a => a.status === 'SCHEDULED').length, color: 'text-accent' },
            { label: 'Completed Consults', value: appointments.filter(a => a.status === 'COMPLETED').length, color: 'text-success' },
          ].map((stat) => (
            <Card key={stat.label} className="shadow-card border-0">
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground">{stat.label}</p>
                <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by name, email or city..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Patients Grid */}
        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="h-12 w-12 animate-spin text-primary" /></div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredPatients.map((patient) => {
              const completedCount = patient.allAppointments.filter((a: any) => a.status === 'COMPLETED').length;
              const lastVisit = patient.allAppointments
                .filter((a: any) => a.appointmentDate)
                .sort((a: any, b: any) => new Date(b.appointmentDate).getTime() - new Date(a.appointmentDate).getTime())[0];
              
              return (
                <Card key={patient.id} className="shadow-card border-0 hover:shadow-lg transition-shadow">
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className={`h-12 w-12 rounded-full flex items-center justify-center ${
                          patient.isFamilyMember
                            ? 'bg-gradient-to-br from-blue-100 to-blue-200'
                            : 'bg-gradient-to-br from-primary/20 to-accent/20'
                        }`}>
                          <span className={`font-bold text-lg ${patient.isFamilyMember ? 'text-blue-600' : 'text-primary'}`}>
                            {patient.firstName.charAt(0)}
                          </span>
                        </div>
                        <div>
                          <h3 className="font-semibold">{patient.firstName} {patient.lastName}</h3>
                          {patient.isFamilyMember ? (
                            <p className="text-xs text-blue-600 font-medium">{patient.relationship} of {patient.accountHolder}</p>
                          ) : (
                            <p className="text-xs text-muted-foreground">ID: {patient.id}</p>
                          )}
                        </div>
                      </div>
                      <Badge variant={patient.isFamilyMember ? 'outline' : 'secondary'} className={patient.isFamilyMember ? 'border-blue-200 text-blue-700' : ''}>
                        {completedCount} visits
                      </Badge>
                    </div>
                    
                    <div className="space-y-2 text-sm">
                      {!patient.isFamilyMember && (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Mail className="h-3.5 w-3.5" />
                          <span className="truncate">{patient.email}</span>
                        </div>
                      )}
                      {patient.city && (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <MapPin className="h-3.5 w-3.5" />
                          <span>{patient.city}</span>
                        </div>
                      )}
                      {patient.patientDetails && (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <User className="h-3.5 w-3.5" />
                          <span>{patient.patientDetails.age}y, {patient.patientDetails.gender}</span>
                        </div>
                      )}
                      {lastVisit && (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Clock className="h-3.5 w-3.5" />
                          <span>Last visit: {format(new Date(lastVisit.appointmentDate), 'MMM dd, yyyy')}</span>
                        </div>
                      )}
                    </div>

                    <div className="mt-4 pt-4 border-t">
                      {patient.isFamilyMember ? (
                        <p className="text-xs text-blue-600 text-center font-medium">👨‍👩‍👧 Family Member — {patient.relationship}</p>
                      ) : (
                        <Link to={`/doctor/appointments?patientId=${patient.id}`}>
                          <Button size="sm" variant="outline" className="w-full">
                            <Eye className="h-4 w-4 mr-2" /> View History
                          </Button>
                        </Link>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {!loading && filteredPatients.length === 0 && (
          <Card className="shadow-card border-0">
            <CardContent className="py-12 text-center">
              <Users className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">No patients found</p>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
