import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  LayoutDashboard, 
  Calendar, 
  FileText, 
  Users, 
  Video, 
  Phone, 
  MapPin, 
  User, 
  AlertCircle, 
  Plus, 
  Trash2, 
  CheckCircle, 
  Play, 
  Loader2,
  Mic,
  MicOff,
  VideoOff,
  Monitor,
  Settings,
  MoreVertical,
  X,
  Stethoscope,
  Activity,
  History,
  Send,
  Sparkles,
  Info,
  Utensils,
  Ban,
  Heal,
  Clock
} from 'lucide-react';
import { format } from 'date-fns';
import { useParams, useNavigate } from 'react-router-dom';
import { useCallback, useEffect, useState, useRef } from 'react';
import { appointmentApi, prescriptionApi } from '@/services/api';
import { toast } from 'sonner';
import { MedicineSearch } from '@/components/doctor/MedicineSearch';

const navigation = [
  { name: 'Dashboard', href: '/doctor', icon: LayoutDashboard },
  { name: 'Appointments', href: '/doctor/appointments', icon: Calendar },
  { name: 'Prescriptions', href: '/doctor/prescriptions', icon: FileText },
  { name: 'Patients', href: '/doctor/patients', icon: Users },
];

export default function DoctorConsultationPage() {
  const { appointmentId } = useParams();
  const navigate = useNavigate();
  const [appointment, setAppointment] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const { startVideoCall } = useAppStore();
  
  // Call State
  const [callActive, setCallActive] = useState(false);
  const [muted, setMuted] = useState(false);
  const [videoOff, setVideoOff] = useState(false);
  const [screenSharing, setScreenSharing] = useState(false);
  const [callStartTime, setCallStartTime] = useState<Date | null>(null);
  const [callDuration, setCallDuration] = useState('00:00');

  // Prescription State
  const [diagnosis, setDiagnosis] = useState('');
  const [generalAdvice, setGeneralAdvice] = useState('');
  const [restrictions, setRestrictions] = useState('');
  const [notes, setNotes] = useState('');
  const [patientHistory, setPatientHistory] = useState<any[]>([]);
  const [medicines, setMedicines] = useState([{ name: '', dosage: '', duration: '', frequency: '', foodInstructions: '' }]);

  const loadAppointment = useCallback(async () => {
    if (!appointmentId) return;
    try {
      setLoading(true);
      let foundAppt = null;
      const res = await appointmentApi.getDoctorAppointments();
      if (res.success && res.data) {
        foundAppt = res.data.find((a: any) => a.appointmentUuid === appointmentId);
        setAppointment(foundAppt);
      }
      
      // Attempt to load existing draft prescription
      const draftRes = await prescriptionApi.getByAppointmentUuid(appointmentId);
      if (draftRes.success && draftRes.data) {
         const p = draftRes.data;
         // Only populate the editable fields if it is NOT issued yet
         if (p.status !== 'ISSUED') {
             setDiagnosis(p.diagnosis || '');
             setGeneralAdvice(p.generalAdvice || '');
             setRestrictions(p.restrictions || '');
             setNotes(p.notes || '');
             if (p.medicines && p.medicines.length > 0) {
                setMedicines(p.medicines.map((m: any) => ({
                   name: m.name,
                   dosage: m.dosage || '',
                   duration: m.duration || '',
                   frequency: m.frequency || '',
                   foodInstructions: m.foodInstructions || m.food_instructions || ''
                })));
             }
         }
      }

      // Load patient history
      const historyRes = await prescriptionApi.getForDoctor();
      if (historyRes.success && historyRes.data && foundAppt && foundAppt.patient) {
         const history = historyRes.data.filter((p: any) => p.patientId === foundAppt.patient.id && p.status === 'ISSUED');
         setPatientHistory(history);
      }

    } catch (e) {
      console.error('Failed to load consultation data', e);
    } finally {
      setLoading(false);
    }
  }, [appointmentId]);

  useEffect(() => {
    loadAppointment();
  }, [loadAppointment]);

  // Call Duration Timer
  useEffect(() => {
    let interval: any;
    if (callActive && callStartTime) {
      interval = setInterval(() => {
        const diff = Math.floor((new Date().getTime() - callStartTime.getTime()) / 1000);
        const mins = Math.floor(diff / 60).toString().padStart(2, '0');
        const secs = (diff % 60).toString().padStart(2, '0');
        setCallDuration(`${mins}:${secs}`);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [callActive, callStartTime]);

  const addMedicine = () => {
    setMedicines([...medicines, { name: '', dosage: '', duration: '', frequency: '', foodInstructions: '' }]);
  };
  const removeMedicine = (index: number) => {
    setMedicines(medicines.filter((_, i) => i !== index));
  };

  const updateMedicine = (index: number, field: string, value: string) => {
    const updated = medicines.map((m, i) => i === index ? { ...m, [field]: value } : m);
    setMedicines(updated);
  };

  const handleStartCall = () => {
    setCallActive(true);
    setCallStartTime(new Date());
    startVideoCall(appointment.appointmentUuid);
    toast.success('Video session initialized');
  };

  const handleEndCall = () => {
    setCallActive(false);
    toast.info('Call duration: ' + callDuration);
  };

  const handleSubmitPrescription = async (status: 'DRAFT' | 'ISSUED') => {
    if (!appointmentId || !appointment) return;
    if (status === 'ISSUED' && (!diagnosis || !medicines.some(m => m.name))) {
        toast.error('Diagnosis and at least one medication are required to issue prescription.');
        return;
    }

    try {
       setSubmitting(true);
       const res = await prescriptionApi.save({
          appointmentUuid: appointmentId,
          diagnosis,
          generalAdvice,
          restrictions,
          notes,
          status,
          medicines: medicines.filter(m => m.name.trim() !== '')
       });

       if (res.success) {
          if (status === 'DRAFT') {
             toast.success('Draft saved successfully');
          } else {
             toast.success('Prescription issued successfully');
             navigate('/doctor/appointments');
          }
       } else {
          toast.error(res.message || 'Failed to save prescription');
       }
    } catch (error) {
       toast.error('Network error occurred');
    } finally {
       setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <DashboardLayout navigation={navigation} title="Consultation">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  if (!appointment) {
    return (
      <DashboardLayout navigation={navigation} title="Consultation">
        <div className="flex flex-col items-center justify-center h-64 space-y-4">
          <AlertCircle className="h-12 w-12 text-muted-foreground opacity-20" />
          <p className="text-muted-foreground">Appointment record not found.</p>
          <Button variant="outline" onClick={() => navigate('/doctor/appointments')}>Back to Schedule</Button>
        </div>
      </DashboardLayout>
    );
  }

  const patient = appointment.patient;
  const familyMember = appointment.familyMember ?? null;
  const patientDetails = appointment.patientDetails;
  const displayName = familyMember
    ? `${familyMember.firstName} ${familyMember.lastName}`
    : patient ? `${patient.firstName} ${patient.lastName}` : 'Patient';

  return (
    <DashboardLayout navigation={navigation} title={`Consultation: ${displayName}`}>
      <div className="flex flex-col h-[calc(100vh-120px)] space-y-4 overflow-hidden animate-fade-in">
        
        {/* Header Hook */}
        <div className="flex items-center justify-between shrink-0 bg-white/50 dark:bg-slate-900/50 backdrop-blur-md p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
               <User className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tight">{displayName}</h1>
              {familyMember && (
                <p className="text-xs text-blue-600 font-semibold mb-0.5">
                  {familyMember.relationship || 'Family Member'} of {patient?.firstName} {patient?.lastName}
                </p>
              )}
              <div className="flex items-center gap-3 text-xs font-bold text-muted-foreground">
                <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {format(new Date(appointment.appointmentDate), 'MMM dd, yyyy')}</span>
                <span className="h-1 w-1 rounded-full bg-slate-300" />
                <span className="flex items-center gap-1 uppercase tracking-widest text-primary">{appointment.serviceType}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
             {callActive && (
               <div className="flex items-center gap-2 px-3 py-1 bg-red-500/10 text-red-500 rounded-full text-xs font-black animate-pulse">
                 <div className="h-2 w-2 rounded-full bg-red-500" />
                 LIVE: {callDuration}
               </div>
             )}
             <Badge variant="outline" className="font-bold border-primary/20 text-primary uppercase">
               Ref: {appointment.appointmentUuid.slice(0, 8)}
             </Badge>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col lg:flex-row gap-4 min-h-0 overflow-hidden">
          
          {/* Left Panel: Video Cockpit */}
          <div className="flex-[5] bg-slate-950 rounded-3xl relative overflow-hidden flex flex-col shadow-2xl border border-slate-800">
            {callActive ? (
              <>
                {/* Main Video (Patient) - Dummy */}
                <div className="flex-1 relative">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-800 via-slate-900 to-slate-950 flex items-center justify-center">
                    <div className="text-center space-y-4">
                      <div className="h-32 w-32 rounded-full bg-slate-800 border-2 border-slate-700 flex items-center justify-center mx-auto ring-8 ring-slate-900">
                        <User className="h-16 w-16 text-slate-500" />
                      </div>
                      <p className="text-slate-400 font-bold uppercase tracking-[0.2em] text-xs">Waiting for {displayName}...</p>
                    </div>
                  </div>

                  {/* Doctor Mini View (Self) */}
                  <div className="absolute bottom-6 right-6 w-48 h-32 bg-slate-800 rounded-2xl border-2 border-slate-700 shadow-2xl overflow-hidden ring-4 ring-black/20">
                     {!videoOff ? (
                       <div className="h-full w-full bg-slate-900 flex items-center justify-center italic text-[10px] text-slate-600 font-bold uppercase">
                         Local Camera Stream
                       </div>
                     ) : (
                       <div className="h-full w-full flex items-center justify-center bg-slate-900">
                         <VideoOff className="h-6 w-6 text-slate-700" />
                       </div>
                     )}
                     <div className="absolute top-2 left-2 px-2 py-0.5 bg-black/50 backdrop-blur-md rounded-full text-[8px] font-bold text-white uppercase">You</div>
                  </div>

                  {/* Top Bar Overlay */}
                  <div className="absolute top-6 left-6 right-6 flex items-center justify-between">
                     <div className="bg-black/40 backdrop-blur-md border border-white/10 px-4 py-2 rounded-2xl text-white">
                        <p className="text-[10px] font-bold text-white/60 uppercase tracking-widest leading-none mb-1">Encrypted Session</p>
                        <p className="text-sm font-black tracking-tight">{patient?.firstName} {patient?.lastName}</p>
                     </div>
                     <div className="flex gap-2">
                        <Button size="icon" variant="ghost" className="bg-white/5 hover:bg-white/10 text-white rounded-full"><Settings className="h-4 w-4" /></Button>
                        <Button size="icon" variant="ghost" className="bg-white/5 hover:bg-white/10 text-white rounded-full"><MoreVertical className="h-4 w-4" /></Button>
                     </div>
                  </div>
                </div>

                {/* Call Controls */}
                <div className="h-24 shrink-0 bg-slate-900/80 backdrop-blur-2xl border-t border-white/5 flex items-center justify-center gap-6 px-10">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => setMuted(!muted)}
                    className={`h-14 w-14 rounded-full transition-all border ${muted ? 'bg-red-500 text-white border-red-400 hover:bg-red-600' : 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'}`}
                  >
                    {muted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => setVideoOff(!videoOff)}
                    className={`h-14 w-14 rounded-full transition-all border ${videoOff ? 'bg-red-500 text-white border-red-400 hover:bg-red-600' : 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'}`}
                  >
                    {videoOff ? <VideoOff className="h-6 w-6" /> : <Video className="h-6 w-6" />}
                  </Button>

                  <Button 
                    variant="destructive" 
                    size="lg" 
                    onClick={handleEndCall}
                    className="h-14 px-8 rounded-full font-black uppercase tracking-widest shadow-2xl shadow-red-500/20"
                  >
                    <X className="h-6 w-6 mr-3" /> End Session
                  </Button>

                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => setScreenSharing(!screenSharing)}
                    className={`h-14 w-14 rounded-full transition-all border ${screenSharing ? 'bg-primary text-white border-primary/50' : 'bg-slate-800 text-slate-200 border-slate-700'}`}
                  >
                    <Monitor className="h-6 w-6" />
                  </Button>
                </div>
              </>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center bg-slate-900 relative">
                 <div className="absolute inset-0 pattern-medical opacity-5" />
                 <div className="relative z-10 text-center space-y-8 max-w-sm px-6">
                    <div className="h-24 w-24 rounded-3xl bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto mb-6 transform rotate-3">
                       <Video className="h-12 w-12 text-primary" />
                    </div>
                    <div className="space-y-3">
                       <h2 className="text-2xl font-black text-white tracking-tight">Ready for Consultation?</h2>
                       <p className="text-slate-400 text-sm leading-relaxed">
                         The encrypted HIPAA-compliant video session will be established once you click start.
                       </p>
                    </div>
                    <Button 
                      size="xl" 
                      className="w-full h-16 rounded-full bg-primary hover:bg-primary/90 text-white font-black uppercase tracking-[0.2em] shadow-[0_20px_50px_rgba(30,58,138,0.3)] transition-all hover:scale-105 active:scale-95"
                      onClick={handleStartCall}
                    >
                      <Play className="h-6 w-6 mr-3 fill-current" /> Initialize Call
                    </Button>
                    <div className="flex items-center justify-center gap-6 pt-4 text-slate-500">
                       <span className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest"><Mic className="h-3 w-3" /> Mic Ready</span>
                       <span className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest"><Video className="h-3 w-3" /> Cam Ready</span>
                    </div>
                 </div>
              </div>
            )}
          </div>

          {/* Right Panel: Medical Command Center */}
          <div className="flex-[4] flex flex-col bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-slate-100 dark:border-slate-800 overflow-hidden">
             
             <Tabs defaultValue="prescription" className="flex-1 flex flex-col min-h-0">
               <div className="px-6 pt-6 shrink-0 bg-slate-50/50 dark:bg-slate-900/50 border-b border-slate-100 dark:border-slate-800">
                 <TabsList className="grid w-full grid-cols-3 h-12 bg-slate-100 dark:bg-slate-800 rounded-2xl p-1 mb-6">
                   <TabsTrigger value="history" className="rounded-xl font-bold text-xs uppercase tracking-wider data-[state=active]:bg-white dark:data-[state=active]:bg-slate-700 shadow-sm transition-all flex items-center gap-2">
                     <History className="h-3.5 w-3.5" /> History
                   </TabsTrigger>
                   <TabsTrigger value="prescription" className="rounded-xl font-bold text-xs uppercase tracking-wider data-[state=active]:bg-white dark:data-[state=active]:bg-slate-700 shadow-sm transition-all flex items-center gap-2">
                     <Stethoscope className="h-3.5 w-3.5" /> Prescribe
                   </TabsTrigger>
                   <TabsTrigger value="notes" className="rounded-xl font-bold text-xs uppercase tracking-wider data-[state=active]:bg-white dark:data-[state=active]:bg-slate-700 shadow-sm transition-all flex items-center gap-2">
                     <Activity className="h-3.5 w-3.5" /> Stats
                   </TabsTrigger>
                 </TabsList>
               </div>

               <div className="flex-1 overflow-y-auto p-6 space-y-6">
                 
                 <TabsContent value="history" className="m-0 space-y-6">
                    <div className="space-y-4">
                       <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">Patient Records</h3>
                       <div className="grid grid-cols-2 gap-4">
                          <Card className="bg-slate-50 dark:bg-slate-800 border-none rounded-2xl p-4">
                             <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Age</p>
                             <p className="font-black text-slate-900 dark:text-white">{patientDetails?.age || '28'}y</p>
                          </Card>
                          <Card className="bg-slate-50 dark:bg-slate-800 border-none rounded-2xl p-4">
                             <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Gender</p>
                             <p className="font-black text-slate-900 dark:text-white uppercase">{patientDetails?.gender || 'Male'}</p>
                          </Card>
                       </div>
                       <Card className="border-red-100 bg-red-50/50 dark:bg-red-950/20 dark:border-red-900/20 rounded-2xl p-4">
                          <div className="flex items-center gap-2 text-red-500 mb-2">
                             <AlertCircle className="h-4 w-4" />
                             <span className="text-xs font-black uppercase tracking-widest">Medical Allergies</span>
                          </div>
                          <p className="text-sm font-medium text-red-700 dark:text-red-400">Penicillin, Peanuts (Severe)</p>
                       </Card>
                       <div className="space-y-3 pt-2">
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Visit History</p>
                          <div className="space-y-2">
                             {patientHistory.length === 0 ? (
                                <p className="text-sm text-slate-500 italic p-3 text-center">No past issued prescriptions.</p>
                             ) : (
                               patientHistory.map((p) => (
                                 <div key={p.id} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-800">
                                    <div>
                                       <p className="text-sm font-bold">{p.diagnosis}</p>
                                       <p className="text-[10px] text-muted-foreground font-medium">
                                          {format(new Date(p.created_at || new Date()), 'dd MMM yyyy')} • {p.medicines?.length || 0} Meds
                                       </p>
                                    </div>
                                    <Button size="icon" variant="ghost" className="h-8 w-8"><FileText className="h-4 w-4 text-primary" /></Button>
                                 </div>
                               ))
                             )}
                          </div>
                       </div>
                    </div>
                 </TabsContent>

                 <TabsContent value="prescription" className="m-0 space-y-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                         <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                           Diagnosis & Plan
                         </h3>
                         {diagnosis && (
                           <div className="h-4 w-4 rounded-full bg-success/20 flex items-center justify-center">
                             <CheckCircle className="h-2.5 w-2.5 text-success" />
                           </div>
                         )}
                      </div>
                      <Textarea
                         placeholder="Start typing the primary diagnosis..."
                         className="min-h-[100px] rounded-2xl bg-slate-50 dark:bg-slate-800 border-none focus-visible:ring-primary focus-visible:ring-1 resize-none font-medium"
                         value={diagnosis}
                         onChange={(e) => setDiagnosis(e.target.value)}
                      />
                    </div>

                    <div className="space-y-6 pt-4">
                       <div className="flex items-center justify-between">
                          <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                            New Medication
                          </h3>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={addMedicine}
                            className="bg-primary/5 border-primary/20 text-primary font-bold hover:bg-primary/10 rounded-full h-8"
                          >
                             <Plus className="h-3.5 w-3.5 mr-1" /> Add Medication
                          </Button>
                       </div>
                       
                       <div className="space-y-4">
                         {medicines.map((med, index) => (
                           <Card key={index} className="p-4 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl relative group overflow-hidden">
                              <div className="absolute top-0 right-0 w-1 pt-1 bottom-0 bg-primary/20 group-hover:bg-primary transition-colors" />
                              <div className="grid gap-4">
                                <div className="flex items-center gap-3">
                                   <div className="shrink-0 h-8 w-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-xs">
                                      {index + 1}
                                   </div>
                                   <MedicineSearch
                                      value={med.name}
                                      onChange={(val) => updateMedicine(index, 'name', val)}
                                   />
                                   {medicines.length > 1 && (
                                     <Button 
                                       variant="ghost" 
                                       size="icon" 
                                       className="h-8 w-8 text-slate-400 hover:text-red-500" 
                                       onClick={() => removeMedicine(index)}
                                     >
                                        <X className="h-4 w-4" />
                                     </Button>
                                   )}
                                </div>
                                <div className="grid grid-cols-3 gap-3">
                                   <div className="space-y-1">
                                      <p className="text-[10px] font-bold text-slate-400 uppercase px-1">Dosage</p>
                                      <Input 
                                         placeholder="500mg" 
                                         className="h-9 bg-white dark:bg-slate-900 border-none text-xs" 
                                         value={med.dosage}
                                         onChange={(e) => updateMedicine(index, 'dosage', e.target.value)}
                                      />
                                   </div>
                                   <div className="space-y-1">
                                      <p className="text-[10px] font-bold text-slate-400 uppercase px-1">Frequency</p>
                                      <Input 
                                         placeholder="Twice / day" 
                                         className="h-9 bg-white dark:bg-slate-900 border-none text-xs" 
                                         value={med.frequency}
                                         onChange={(e) => updateMedicine(index, 'frequency', e.target.value)}
                                      />
                                   </div>
                                   <div className="space-y-1">
                                      <p className="text-[10px] font-bold text-slate-400 uppercase px-1">Duration</p>
                                      <Input 
                                         placeholder="7 Days" 
                                         className="h-9 bg-white dark:bg-slate-900 border-none text-xs" 
                                         value={med.duration}
                                         onChange={(e) => updateMedicine(index, 'duration', e.target.value)}
                                      />
                                   </div>
                                </div>
                                
                                {/* Food Instructions Tags */}
                                <div className="space-y-2">
                                   <p className="text-[10px] font-bold text-slate-400 uppercase px-1">Food Instructions</p>
                                   <div className="flex flex-wrap gap-2">
                                      {['Before Food', 'After Food', 'With Food', 'Empty Stomach'].map((instr) => (
                                         <Button
                                            key={instr}
                                            variant="ghost"
                                            size="sm"
                                            className={`h-7 text-[10px] font-bold rounded-full border ${med.foodInstructions === instr ? 'bg-primary text-white border-primary' : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 text-slate-500'}`}
                                            onClick={() => updateMedicine(index, 'foodInstructions', med.foodInstructions === instr ? '' : instr)}
                                         >
                                            <Utensils className="h-3 w-3 mr-1" /> {instr}
                                         </Button>
                                      ))}
                                   </div>
                                </div>
                              </div>
                           </Card>
                         ))}
                       </div>

                       {/* Clinical Advice & Restrictions */}
                       <div className="space-y-6 pt-6 border-t border-slate-100 dark:border-slate-800">
                          <div className="space-y-3">
                             <div className="flex items-center justify-between">
                                <Label className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">General Advice</Label>
                                <div className="flex gap-2">
                                   {['Hydration', 'Full Rest', 'Soft Food'].map(tag => (
                                      <Button 
                                         key={tag} 
                                         variant="ghost" 
                                         className="h-6 px-2 text-[9px] font-black uppercase text-primary bg-primary/5 hover:bg-primary/10 rounded-md"
                                         onClick={() => setGeneralAdvice(prev => prev ? `${prev}, ${tag}` : tag)}
                                      >
                                         + {tag}
                                      </Button>
                                   ))}
                                </div>
                             </div>
                             <Input 
                                placeholder="e.g. Drink plenty of water, Avoid direct sunlight..."
                                className="h-10 bg-slate-50 dark:bg-slate-800 border-none font-medium text-sm"
                                value={generalAdvice}
                                onChange={(e) => setGeneralAdvice(e.target.value)}
                             />
                          </div>

                          <div className="space-y-3">
                             <div className="flex items-center justify-between">
                                <Label className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">Restrictions</Label>
                                <div className="flex gap-2">
                                   {['No Alcohol', 'No Sugary Food', 'No Lifting'].map(tag => (
                                      <Button 
                                         key={tag} 
                                         variant="ghost" 
                                         className="h-6 px-2 text-[9px] font-black uppercase text-red-500 bg-red-500/5 hover:bg-red-500/10 rounded-md"
                                         onClick={() => setRestrictions(prev => prev ? `${prev}, ${tag}` : tag)}
                                      >
                                         + {tag}
                                      </Button>
                                   ))}
                                </div>
                             </div>
                             <Input 
                                placeholder="e.g. No heavy lifting, Avoid caffeine..."
                                className="h-10 bg-slate-50 dark:bg-slate-800 border-none font-medium text-sm text-red-600 dark:text-red-400"
                                value={restrictions}
                                onChange={(e) => setRestrictions(e.target.value)}
                             />
                          </div>
                       </div>
                    </div>
                 </TabsContent>

                 <TabsContent value="notes" className="m-0 space-y-6">
                    <div className="space-y-4">
                       <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">Internal clinical Notes</h3>
                       <Textarea
                          placeholder="Your private observations for internal records..."
                          className="min-h-[150px] rounded-2xl bg-slate-50 dark:bg-slate-800 border-none focus-visible:ring-primary focus-visible:ring-1 resize-none"
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                       />
                       <div className="p-4 bg-accent/5 border border-accent/10 rounded-2xl flex items-start gap-3">
                          <Sparkles className="h-4 w-4 text-accent mt-0.5" />
                          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed italic">
                            These notes will not be visible to the patient. They are stored securely for medical review and follow-up care coordination.
                          </p>
                       </div>
                    </div>
                 </TabsContent>

               </div>

               {/* Command Center Footer */}
               <div className="p-6 shrink-0 bg-slate-50/50 dark:bg-slate-900/50 border-t border-slate-100 dark:border-slate-800 flex gap-4">
                  <Button 
                     size="xl" 
                     variant="outline"
                     className="flex-1 h-14 rounded-full font-black uppercase tracking-widest shadow-sm"
                     disabled={submitting}
                     onClick={() => handleSubmitPrescription('DRAFT')}
                  >
                     <FileText className="h-5 w-5 mr-3 text-slate-400" /> Save Draft
                  </Button>
                  <Button 
                     size="xl" 
                     className="flex-1 h-14 rounded-full bg-slate-900 dark:bg-primary dark:text-white dark:hover:bg-primary/90 text-white font-black uppercase tracking-[0.2em] shadow-xl hover:scale-[1.02] active:scale-98 transition-all"
                     disabled={submitting || !diagnosis || !medicines.some(m => m.name)}
                     onClick={() => handleSubmitPrescription('ISSUED')}
                  >
                     {submitting ? (
                        <><Loader2 className="h-5 w-5 mr-3 animate-spin" /> Processing...</>
                     ) : callActive ? (
                       <><Send className="h-5 w-5 mr-3" /> Finish & Issue</>
                     ) : (
                       <><CheckCircle className="h-5 w-5 mr-3" /> Issue Prescription</>
                     )}
                  </Button>
               </div>
               <p className="text-center text-[10px] text-muted-foreground pb-4 font-bold uppercase tracking-widest flex items-center justify-center gap-2">
                 <Info className="h-3 w-3" /> All medical data is stored securely in compliance with regulations
               </p>

             </Tabs>

          </div>

        </div>
      </div>
    </DashboardLayout>
  );
}
