import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Shield,
  Lock,
  Database,
  Mail,
  Globe,
  FileText,
  ArrowLeft,
  ChevronRight,
  CheckCircle,
  CreditCard,
  AlertTriangle,
  Scale,
} from 'lucide-react';
import navalaLogo from '@/assets/navala.png';

const sections = [
  {
    id: 'acceptance',
    icon: FileText,
    title: '1. Acceptance of Terms',
    content: (
      <>
        <p className="mb-4">
          By accessing or using the Navala Travel Health platform, you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using or accessing this site.
        </p>
        <p>
          These terms constitute a legally binding agreement between you and Navala Travel Health regarding your use of our website, mobile applications, and healthcare services.
        </p>
      </>
    ),
  },
  {
    id: 'accounts',
    icon: Lock,
    title: '2. User Accounts',
    content: (
      <>
        <p className="mb-3">When you create an account with us, you must provide information that is accurate, complete, and current at all times. Failure to do so constitutes a breach of the Terms, which may result in immediate termination of your account.</p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
          <li>You are responsible for safeguarding the password that you use to access the service.</li>
          <li>You agree not to disclose your password to any third party.</li>
          <li>You must notify us immediately upon becoming aware of any breach of security or unauthorized use of your account.</li>
          <li>You may not use as a username the name of another person or entity that is not lawfully available for use.</li>
        </ul>
      </>
    ),
  },
  {
    id: 'use-of-service',
    icon: CheckCircle,
    title: '3. Use of Service',
    content: (
      <>
        <p className="mb-3">Navala Travel Health provides a platform connecting travelers with healthcare professionals. Your use is subject to the following:</p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
          <li>You must be at least 18 years old to create an account and use the services independently.</li>
          <li>The services are intended for travel-related healthcare consultations and support.</li>
          <li>You agree not to use the service for any illegal or unauthorized purpose.</li>
          <li>You will not attempt to disrupt or interfere with the security or performance of the platform.</li>
        </ul>
      </>
    ),
  },
  {
    id: 'telehealth',
    icon: Shield,
    title: '4. Telehealth Services',
    content: (
      <>
        <p className="mb-4">
          Navala provides access to telehealth consultations. By using these services, you acknowledge that:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground mb-4">
          <li>Telehealth involves the delivery of healthcare services using electronic communications.</li>
          <li>There are potential risks associated with telehealth, including technical interruptions or limitations in physical examination.</li>
          <li>The healthcare professional determines whether a telehealth consultation is appropriate for your specific needs.</li>
          <li>In case of a medical emergency, you should seek immediate in-person emergency care.</li>
        </ul>
      </>
    ),
  },
  {
    id: 'payments',
    icon: CreditCard,
    title: '5. Fees and Payments',
    content: (
      <>
        <p className="mb-4">
          Certain features of the service may require payment. All fees are clearly stated at the time of purchase.
        </p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
          <li>Payments are processed securely via Stripe.</li>
          <li>Subscription plans are billed in advance on a recurring basis.</li>
          <li>Refunds are handled on a case-by-case basis according to our refund policy.</li>
          <li>We reserve the right to change our fees at any time, with notice provided to active subscribers.</li>
        </ul>
      </>
    ),
  },
  {
    id: 'intellectual-property',
    icon: Database,
    title: '6. Intellectual Property',
    content: (
      <>
        <p>
          The service and its original content, features, and functionality are and will remain the exclusive property of Navala Travel Health and its licensors. Our trademarks and trade dress may not be used in connection with any product or service without our prior written consent.
        </p>
      </>
    ),
  },
  {
    id: 'liability',
    icon: AlertTriangle,
    title: '7. Limitation of Liability',
    content: (
      <>
        <p className="mb-4">
          In no event shall Navala Travel Health, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses.
        </p>
        <p>
          Navala Travel Health does not provide direct medical advice; all medical consultations are performed by independent qualified healthcare professionals.
        </p>
      </>
    ),
  },
  {
    id: 'termination',
    icon: AlertTriangle,
    title: '8. Termination',
    content: (
      <>
        <p>
          We may terminate or suspend your account immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms. Upon termination, your right to use the Service will immediately cease.
        </p>
      </>
    ),
  },
  {
    id: 'governing-law',
    icon: Scale,
    title: '9. Governing Law',
    content: (
      <>
        <p>
          These Terms shall be governed and construed in accordance with the laws of the jurisdiction in which Navala Travel Health is incorporated, without regard to its conflict of law provisions.
        </p>
      </>
    ),
  },
  {
    id: 'contact',
    icon: Mail,
    title: '10. Contact Us',
    content: (
      <>
        <p className="mb-4">
          If you have any questions about these Terms, please contact us:
        </p>
        <p className="text-muted-foreground">
          <strong className="text-foreground">Navala Travel Health</strong><br />
          Legal Department<br />
          Email: info@navalaglobal.com
        </p>
      </>
    ),
  },
];

export default function TermsOfServicePage() {
  return (
    <div className="min-h-screen gradient-hero pattern-medical">
      {/* Top bar */}
      <header className="sticky top-0 z-10 border-b border-border/60 bg-card/80 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/login" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
            <img src={navalaLogo} alt="Navala" className="h-8 w-auto" />
          </Link>
          <Link to="/login">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Login
            </Button>
          </Link>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8 pb-16">
        {/* Hero */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-primary/10 text-primary mb-6">
            <FileText className="h-7 w-7" strokeWidth={2} />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground tracking-tight mb-3">
            Terms of Service
          </h1>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            Please read these terms carefully before using our services.
          </p>
          <p className="text-sm text-muted-foreground mt-4">
            Last updated: February 10, 2025
          </p>
        </div>

        {/* Table of contents - compact */}
        <Card className="mb-10 border-border/60 bg-card/50 shadow-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <ChevronRight className="h-4 w-4 text-accent" />
              On this page
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <nav className="flex flex-wrap gap-x-4 gap-y-1 text-sm">
              {sections.map((s) => (
                <a
                  key={s.id}
                  href={`#${s.id}`}
                  className="text-muted-foreground hover:text-accent transition-colors"
                >
                  {s.title}
                </a>
              ))}
            </nav>
          </CardContent>
        </Card>

        {/* Sections */}
        <div className="space-y-8">
          {sections.map((section) => {
            const Icon = section.icon;
            return (
              <Card
                key={section.id}
                id={section.id}
                className="border-border/60 bg-card shadow-card overflow-hidden scroll-mt-24"
              >
                <CardHeader className="pb-3 border-b border-border/60 bg-muted/30">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-primary/10 text-primary shrink-0">
                      <Icon className="h-5 w-5" strokeWidth={2} />
                    </div>
                    <CardTitle className="text-xl">{section.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 prose prose-slate dark:prose-invert max-w-none">
                  <div className="text-foreground text-[15px] leading-relaxed">
                    {section.content}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Footer CTA */}
        <div className="mt-14 text-center">
          <p className="text-muted-foreground text-sm mb-4">
            Questions? Contact us at info@navalaglobal.com
          </p>
          <Link to="/login">
            <Button variant="outline" size="lg" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Return to Login
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
