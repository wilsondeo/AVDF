import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { PatientRequestList } from '@/components/patient/PatientRequestList';
import { PlanRequiredGate } from '@/components/patient/PlanRequiredGate';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import {
  LayoutDashboard,
  Calendar,
  FileText,
  CreditCard,
  Loader2,
  FileSignature,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { appointmentApi, paymentApi } from '@/services/api';
import type { AppointmentRequestSummary } from '@/services/api';
import { toast } from 'sonner';

const getNavigation = (hasActivePlan: boolean) => [
  { name: 'Dashboard', href: '/patient', icon: LayoutDashboard },
  { name: 'My Appointments', href: '/patient/appointments', icon: Calendar, disabled: !hasActivePlan },
  { name: 'Prescriptions', href: '/patient/prescriptions', icon: FileText, disabled: !hasActivePlan },
  { name: 'Contracts', href: '/patient/contracts', icon: FileSignature },
  { name: 'My Plan', href: '/patient/plans', icon: CreditCard },
];

export default function PatientAppointmentsPage() {
  const [requests, setRequests] = useState<AppointmentRequestSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasActivePlan, setHasActivePlan] = useState<boolean | null>(null);

  const loadActivePlan = async () => {
    const res = await paymentApi.getActiveUserPlan();
    const active = res.success && res.data?.activePlan;
    setHasActivePlan(!!active);
  };

  const loadRequests = async () => {
    try {
      setLoading(true);
      const res = await appointmentApi.getMyRequests();
      if (res.success && res.data) {
        setRequests(res.data);
      } else {
        toast.error(res.message || 'Failed to load requests');
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to load requests');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadActivePlan();
  }, []);

  useEffect(() => {
    if (hasActivePlan === true) loadRequests();
  }, [hasActivePlan]);

  const pending = requests.filter((r) => r.status === 'PENDING');
  const assigned = requests.filter((r) => r.status === 'ASSIGNED');
  const cancelled = requests.filter((r) => r.status === 'CANCELLED');
  const upcoming = requests.filter((r) => r.status !== 'CANCELLED');

  if (hasActivePlan === null) {
    return (
      <DashboardLayout navigation={getNavigation(hasActivePlan ?? false)} title="My Appointments">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </DashboardLayout>
    );
  }

  if (hasActivePlan === false) {
    return (
      <DashboardLayout navigation={getNavigation(hasActivePlan ?? false)} title="My Appointments">
        <div className="space-y-6 animate-fade-in py-8">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">My Appointments</h1>
            <p className="text-muted-foreground mt-1">
              View and manage your booking requests
            </p>
          </div>
          <PlanRequiredGate featureName="My Appointments" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout navigation={getNavigation(hasActivePlan ?? false)} title="My Appointments">
      <div className="space-y-6 animate-fade-in">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">My Appointments</h1>
            <p className="text-muted-foreground mt-1">
              View and manage your booking requests. When a doctor is assigned, you'll see their profile here.
            </p>
          </div>
          <Link to="/patient/book">
            <Button size="sm" className="rounded-lg bg-primary text-primary-foreground font-semibold shadow-sm">
              Book Appointment
            </Button>
          </Link>
        </div>

        <Tabs defaultValue="upcoming" className="w-full">
          <TabsList>
            <TabsTrigger value="upcoming">Upcoming ({upcoming.length})</TabsTrigger>
            <TabsTrigger value="pending">Waiting for Doctor ({pending.length})</TabsTrigger>
            <TabsTrigger value="assigned">Doctor Assigned ({assigned.length})</TabsTrigger>
            <TabsTrigger value="cancelled">Cancelled ({cancelled.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming" className="mt-6">
            <PatientRequestList
              requests={upcoming}
              title="Upcoming"
              emptyMessage="No upcoming requests. Book an appointment to get started."
            />
          </TabsContent>

          <TabsContent value="pending" className="mt-6">
            <PatientRequestList
              requests={pending}
              title="Waiting for Doctor"
              emptyMessage="No requests waiting for a doctor."
            />
          </TabsContent>

          <TabsContent value="assigned" className="mt-6">
            <PatientRequestList
              requests={assigned}
              title="Doctor Assigned"
              emptyMessage="No appointments with a doctor assigned yet."
            />
          </TabsContent>

          <TabsContent value="cancelled" className="mt-6">
            <PatientRequestList
              requests={cancelled}
              title="Cancelled"
              emptyMessage="No cancelled requests."
            />
          </TabsContent>
        </Tabs>

        {loading && (
          <p className="text-sm text-muted-foreground text-center">Loading…</p>
        )}
      </div>
    </DashboardLayout>
  );
}
