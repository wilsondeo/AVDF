import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { 
  CheckCircle2, 
  Download, 
  CreditCard, 
  Users, 
  ShieldCheck, 
  MapPin, 
  Calendar,
  FileText,
  FileSignature,
  LayoutDashboard,
  ArrowLeft,
  Sparkles,
  Phone,
  Video,
  Info
} from 'lucide-react';
import { paymentApi, familyMembersApi, type Plan, type FamilyMember, type PaymentRecord } from '@/services/api';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import navalaLogo from '@/assets/navala.png';
import { PLAN_BENEFITS_AVAILABLE } from '@/config/patientPlan';
import { useNavigate } from 'react-router-dom';

export default function PlanConfirmationPage() {
  const { currentUser } = useAppStore();
  const navigate = useNavigate();
  const [activePlanData, setActivePlanData] = useState<any>(null);
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([]);
  const [latestPayment, setLatestPayment] = useState<PaymentRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentDate, setCurrentDate] = useState('');

  const navigation = [
    { name: 'Dashboard', href: '/patient', icon: LayoutDashboard },
    { name: 'My Appointments', href: '/patient/appointments', icon: Calendar },
    { name: 'Prescriptions', href: '/patient/prescriptions', icon: FileText },
    { name: 'Contracts', href: '/patient/contracts', icon: FileSignature },
    { name: 'My Plan', href: '/patient/plans', icon: CreditCard },
  ];

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        // 1. Get active plan
        const planRes = await paymentApi.getActiveUserPlan();
        if (planRes.success && planRes.data?.activePlan) {
          setActivePlanData(planRes.data.activePlan);
        }

        // 2. Get family members
        const familyRes = await familyMembersApi.getList();
        if (familyRes.success && familyRes.data) {
          setFamilyMembers(familyRes.data.familyMembers);
        }

        // 3. Get latest payment
        const paymentRes = await paymentApi.getMyPayments();
        if (paymentRes.success && paymentRes.data?.payments?.length > 0) {
          // Sort by date and get latest
          const sorted = [...paymentRes.data.payments].sort(
            (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
          );
          setLatestPayment(sorted[0]);
        }

        // Format date
        const now = new Date();
        setCurrentDate(new Intl.DateTimeFormat('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        }).format(now));

      } catch (error) {
        console.error('Error fetching confirmation data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleDownloadPDF = () => {
    window.print();
  };

  if (loading) {
    return (
      <DashboardLayout navigation={navigation} title="Plan Confirmation">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </DashboardLayout>
    );
  }

  const plan = activePlanData?.plan;
  const features = Array.isArray(plan?.features) 
    ? plan.features 
    : (typeof plan?.features === 'string' ? JSON.parse(plan.features) : []);
  const services = Array.isArray(plan?.services) 
    ? plan.services 
    : (typeof plan?.services === 'string' ? JSON.parse(plan.services) : []);

  return (
    <DashboardLayout navigation={navigation} title="Plan Confirmation">
      <div className="space-y-6 animate-fade-in print:hidden max-w-4xl mx-auto">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/patient/plans')}
            className="w-fit"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Plans
          </Button>
          <Button 
            onClick={handleDownloadPDF} 
            className="bg-primary text-white font-bold rounded-xl shadow-lg hover:scale-105 transition-transform"
          >
            <Download className="mr-2 h-4 w-4" />
            Download Confirmation PDF
          </Button>
        </div>

        {!activePlanData && (
          <Card className="border-destructive/20 bg-destructive/5">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3 text-destructive">
                <Info className="h-5 w-5" />
                <p className="font-medium">No active plan found. If you just made a purchase, please wait a moment and refresh.</p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Confirmation Document */}
      <div className="mt-8 flex justify-center">
        <div className="bg-white text-slate-900 w-full max-w-[850px] min-h-[1100px] p-8 sm:p-12 md:p-16 shadow-2xl border border-slate-100 rounded-3xl relative overflow-hidden print:shadow-none print:border-none print:p-0 print:m-0 print:w-full print:max-w-none print:min-h-0">
          
          {/* Decorative Gradient Background (Screen only) */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full -mr-32 -mt-32 blur-3xl print:hidden" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-accent/5 rounded-full -ml-32 -mb-32 blur-3xl print:hidden" />

          {/* Header */}
          <div className="flex items-start justify-between border-b border-slate-100 pb-8 mb-10 relative z-10">
            <div>
              <img src={navalaLogo} alt="Navala Travel Health" className="h-12 w-auto mb-4" />
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-success/10 text-success text-[10px] font-bold uppercase tracking-wider mb-2">
                <ShieldCheck className="h-3 w-3" />
                Official Confirmation
              </div>
              <h1 className="text-3xl font-black text-slate-900 tracking-tight">Plan Activation Details</h1>
              <p className="text-slate-500 text-sm mt-1">Confirmation ID: NTH-CONF-{latestPayment?.id?.toString().padStart(6, '0') || '000000'}</p>
            </div>
            <div className="text-right hidden sm:block">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Issue Date</p>
              <p className="font-bold text-slate-800">
                {latestPayment 
                  ? new Intl.DateTimeFormat('en-US', { year: 'numeric', month: 'long', day: 'numeric' }).format(new Date(latestPayment.createdAt)) 
                  : currentDate}
              </p>
            </div>
          </div>

          <div className="space-y-10 relative z-10">
            {/* User Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">Member Information</h3>
                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                  <p className="text-xs text-slate-400 font-bold uppercase mb-1">Primary Member</p>
                  <p className="text-xl font-black text-slate-900 leading-tight mb-2">{currentUser?.name}</p>
                  <p className="text-sm text-slate-600 font-medium">{currentUser?.email}</p>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">Plan Status</h3>
                <div className="bg-success/5 p-6 rounded-2xl border border-success/10 flex items-center justify-between">
                  <div>
                    <p className="text-xs text-success/70 font-bold uppercase mb-1">Current Status</p>
                    <p className="text-xl font-black text-success leading-tight">ACTIVE</p>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-success/20 flex items-center justify-center">
                    <CheckCircle2 className="h-6 w-6 text-success" />
                  </div>
                </div>
              </div>
            </div>

            {/* Plan Details Section */}
            <div className="space-y-4">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">Coverage Overview</h3>
              <Card className="border-slate-100 shadow-sm overflow-hidden rounded-2xl">
                <div className="p-6 bg-gradient-to-r from-slate-900 to-slate-800 text-white flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-2xl font-black tracking-tight">{plan?.name || 'Healthcare Plan'}</h2>
                    <p className="text-slate-300 text-sm mt-1">{plan?.description}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Coverage Period</p>
                    <p className="text-white font-black text-lg">
                      {PLAN_BENEFITS_AVAILABLE.fromLabel} – {PLAN_BENEFITS_AVAILABLE.toLabel}
                    </p>
                  </div>
                </div>
                <CardContent className="p-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    {/* Benefits */}
                    <div className="space-y-4">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                        Included Benefits
                      </p>
                      <ul className="space-y-3">
                        {features.map((feature: string, i: number) => (
                          <li key={i} className="flex items-start gap-3 text-sm text-slate-700">
                            <div className="mt-0.5 h-5 w-5 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0">
                              <CheckCircle2 className="h-3 w-3" />
                            </div>
                            <span className="font-medium">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Services */}
                    <div className="space-y-4">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                        Core Services
                      </p>
                      <div className="flex flex-wrap gap-3">
                        {services.map((service: string, i: number) => (
                          <div key={i} className="inline-flex items-center gap-2 px-4 py-2 bg-slate-50 border border-slate-100 rounded-xl text-sm font-bold text-slate-700">
                             {service === 'TELEHEALTH' && <Video className="h-4 w-4 text-primary" />}
                             {service === 'EMERGENCY' && <Phone className="h-4 w-4 text-primary" />}
                             {service === 'TELEHEALTH' ? '24/7 Telehealth' : service === 'EMERGENCY' ? 'Emergency Coordination' : service}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Family Members Section */}
            {(familyMembers.length > 0 || (plan?.maxPersons && plan.maxPersons > 1)) && (
              <div className="space-y-4">
                <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                  <Users className="h-4 w-4" /> Covered Family Members
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {/* Account Holder */}
                  <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center font-black text-primary">
                      {currentUser?.name?.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-900">{currentUser?.name}</p>
                      <p className="text-[10px] text-slate-500 font-bold uppercase">Account Holder</p>
                    </div>
                  </div>
                  
                  {/* Family Members */}
                  {familyMembers.map((member) => (
                    <div key={member.id} className="p-4 bg-white border border-slate-100 rounded-2xl flex items-center gap-3 shadow-sm">
                      <div className="h-10 w-10 rounded-full bg-accent/20 flex items-center justify-center font-black text-accent text-sm">
                        {member.firstName.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-900">{member.firstName} {member.lastName}</p>
                        <p className="text-[10px] text-slate-500 font-bold uppercase">{member.relationship || 'Dependent'}</p>
                      </div>
                    </div>
                  ))}
                  
                  {/* Empty Slots */}
                  {Array.from({ length: Math.max(0, (plan?.maxPersons || 1) - familyMembers.length - 1) }).map((_, i) => (
                    <div key={`empty-${i}`} className="p-4 bg-slate-50/50 border border-dashed border-slate-200 rounded-2xl flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center font-black text-slate-300">
                        +
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-300 italic">Available Slot</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Payment Section */}
            <div className="space-y-4">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                <CreditCard className="h-4 w-4" /> Payment Details
              </h3>
              <div className="bg-slate-900 rounded-3xl p-8 text-white">
                <div className="flex flex-col md:flex-row justify-between gap-8">
                  <div className="space-y-6 flex-1">
                    <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                      <div>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Transaction ID</p>
                        <p className="text-xs font-mono text-slate-300 break-all">{latestPayment?.stripePaymentIntentId || 'N/A'}</p>
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Invoice Date</p>
                        <p className="text-sm font-bold">
                          {latestPayment 
                            ? new Date(latestPayment.createdAt).toLocaleDateString('en-US') 
                            : new Date().toLocaleDateString('en-US')}
                        </p>
                      </div>
                      <div>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Payment Method</p>
                        <p className="text-sm font-bold flex items-center gap-2">
                          <CreditCard className="h-4 w-4" /> Credit Card (•••• 4242)
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs font-black text-success uppercase tracking-widest">● Paid in Full</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="w-full md:w-48 bg-white/5 rounded-2xl p-6 flex flex-col items-center justify-center border border-white/10">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Total Amount</p>
                    <p className="text-4xl font-black tracking-tighter">
                      ${latestPayment?.amount ? (Number(latestPayment.amount) / 100).toFixed(2) : plan?.price ? Number(plan.price).toFixed(2) : '0.00'}
                    </p>
                    <p className="text-[10px] text-slate-400 font-bold mt-1 uppercase">US Dollars</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="mt-20 pt-8 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-4 text-center md:text-left">
            <div className="space-y-1">
              <p className="text-xs text-slate-500 font-medium">Navala Travel Health | Global Medical Concierge</p>
              <p className="text-[10px] text-slate-400">Digitally verified document for World Cup 2026 coverage.</p>
            </div>
            <div className="flex items-center gap-6">
              <img src={navalaLogo} alt="" className="h-8 w-auto opacity-20 grayscale" />
              <div className="text-right">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Verification Code</p>
                <p className="text-xs font-mono text-slate-600">NTH-V-{Math.random().toString(36).substring(7).toUpperCase()}</p>
              </div>
            </div>
          </div>

          {/* Watermark (Print only) */}
          <div className="hidden print:block absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none rotate-[-45deg]">
             <span className="text-[200px] font-black tracking-tighter">NAVALA</span>
          </div>

        </div>
      </div>

      <div className="mt-12 text-center text-muted-foreground pb-20 print:hidden">
        <p className="text-sm">Need help with your plan? <a href="#" className="text-primary font-bold hover:underline">Contact Support</a></p>
      </div>

    </DashboardLayout>
  );
}
