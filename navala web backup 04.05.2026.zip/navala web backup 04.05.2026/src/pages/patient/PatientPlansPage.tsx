import { useState, useEffect, useCallback } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { PaymentModal } from '@/components/patient/PaymentModal';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  LayoutDashboard,
  Calendar,
  FileText,
  CreditCard,
  CheckCircle2,
  Star,
  ShieldCheck,
  Video,
  Phone,
  Users,
  FileSignature,
  Info,
  DollarSign,
  ArrowRight,
  Shield,
  Sparkles,
  Loader2
} from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { planApi, paymentApi, familyMembersApi, itineraryApi, systemConfigApi, type Plan, type FamilyMember, type UserItineraryItem } from '@/services/api';
import { PLAN_BENEFITS_AVAILABLE } from '@/config/patientPlan';
import ItineraryBuilder, { type ItineraryDestination } from '@/components/itinerary/ItineraryBuilder';

const navigation = [
  { name: 'Dashboard', href: '/patient', icon: LayoutDashboard },
  { name: 'My Appointments', href: '/patient/appointments', icon: Calendar },
  { name: 'Prescriptions', href: '/patient/prescriptions', icon: FileText },
  { name: 'Contracts', href: '/patient/contracts', icon: FileSignature },
  { name: 'My Plan', href: '/patient/plans', icon: CreditCard },
];

export default function PatientPlansPage() {
  const { currentUser } = useAppStore();
  const [currentPlan, setCurrentPlan] = useState<any>(null);
  const navigate = useNavigate();

  const [plans, setPlans] = useState<Plan[]>([]);
  type PlanCategory = 'INDIVIDUAL' | 'FAMILY_2' | 'FAMILY_3_4';
  type FilterKey = 'INDIVIDUAL' | 'FAMILY_2' | 'FAMILY_3_4';
  const [filter, setFilter] = useState<FilterKey>('INDIVIDUAL');
  const [loading, setLoading] = useState(true);
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([]);
  const [familyLoading, setFamilyLoading] = useState(false);

  const [itinerary, setItinerary] = useState<ItineraryDestination[]>([]);
  const [totalTax, setTotalTax] = useState(0);
  const [taxStrategy, setTaxStrategy] = useState('SUM');

  const [searchParams, setSearchParams] = useSearchParams();

  // Load active plans from API
  useEffect(() => {
    loadPlans();
    loadActivePlan();
    loadFamilyMembers();
    loadTaxStrategy();
    checkRedirectStatus();
  }, []);

  const loadTaxStrategy = async () => {
    try {
      const res = await systemConfigApi.get('multi_city_tax_strategy');
      if (res.success && res.data) {
        setTaxStrategy(res.data);
      }
    } catch (e) {
      console.error('Failed to load tax strategy', e);
    }
  };

  const loadFamilyMembers = useCallback(async () => {
    try {
      setFamilyLoading(true);
      const res = await familyMembersApi.getList();
      if (res.success && res.data) {
        setFamilyMembers(res.data.familyMembers);
      }
    } catch (e) {
      console.error('Failed to load family members', e);
    } finally {
      setFamilyLoading(false);
    }
  }, []);

  const checkRedirectStatus = async () => {
    const redirectStatus = searchParams.get('redirect_status');
    const paymentIntentId = searchParams.get('payment_intent');

    if (redirectStatus === 'succeeded' && paymentIntentId) {
      toast.success('Payment successful! Verifying plan activation...');
      // Poll for a few seconds to allow webhook to process
      setTimeout(() => {
        loadActivePlan();
      }, 2000);
      setTimeout(() => {
        loadActivePlan();
      }, 5000);

      // Clean up URL
      setSearchParams((params) => {
        params.delete('payment_intent');
        params.delete('payment_intent_client_secret');
        params.delete('redirect_status');
        return params;
      });
    } else if (redirectStatus === 'failed') {
      toast.error('Payment failed or cancelled.');
    }
  };

  const loadActivePlan = async () => {
    const res = await paymentApi.getActiveUserPlan();
    const active = res.success ? res.data?.activePlan : null;
    if (active && (active as any).plan) {
      setCurrentPlan(active);
    } else {
      setCurrentPlan(null);
    }
  };

  const loadPlans = async () => {
    try {
      setLoading(true);
      const response = await planApi.getActivePlans();
      if (response.success && response.data) {
        // Normalize plans to ensure services/features are arrays and sort by price ascending
        const normalizedPlans = response.data.plans
          .map(plan => ({
            ...plan,
            services: Array.isArray(plan.services)
              ? plan.services
              : (typeof plan.services === 'string' ? JSON.parse(plan.services) : []),
            features: Array.isArray(plan.features)
              ? plan.features
              : (typeof plan.features === 'string' ? JSON.parse(plan.features) : []),
            price: typeof plan.price === 'string' ? parseFloat(plan.price) : (plan.price || 0),
          }))
          .sort((a, b) => (a.price || 0) - (b.price || 0));
        setPlans(normalizedPlans);
      } else {
        toast.error(response.message || 'Failed to load plans');
      }
    } catch (error) {
      toast.error('An error occurred while loading plans');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectPlan = (plan: Plan) => {
    const currentPrice = currentPlan?.plan?.price != null ? Number(currentPlan.plan.price) : null;
    const selectedPrice = typeof plan.price === 'number' ? plan.price : Number(plan.price);
    if (currentPlan?.plan && currentPrice != null && selectedPrice <= currentPrice) {
      toast.info('Select a higher-tier plan to upgrade. Your current plan is the same price or higher.');
      return;
    }

    // Mandatory itinerary check
    if (itinerary.length === 0) {
      toast.error('Please add at least one destination to your itinerary before choosing a plan.');
      // Scroll to itinerary builder
      document.getElementById('itinerary-section')?.scrollIntoView({ behavior: 'smooth' });
      return;
    }

    setSelectedPlan(plan);
    setPaymentModalOpen(true);
  };

  const handlePaymentSuccess = () => {
    toast.success('Payment successful! Your plan will activate shortly.');
    loadActivePlan();
    navigate('/patient/plan-confirmation');
  };

  /** Display name for consistency: "Premium Plus Plan - Diamond" -> "Premium Health Plan - Diamond" */
  /** Display name for consistency: "Premium Plus Plan - Diamond" -> "Premium Health Plan - Diamond" */
  const getDisplayPlanName = (name: string) => {
    if (!name) return name;
    const n = name.trim();
    if (n.includes('Premium Plus') && n.includes('Diamond')) {
      return 'Premium Health Plan - Diamond';
    }
    return name;
  };

  const calculateTaxForPlan = useCallback((plan: Plan) => {
    if (!itinerary || itinerary.length === 0) return 0;
    
    const planPrice = Number(plan.price) || 0;
    let computedTax = 0;

    // Group by country to apply unique country tax logic
    const countryTaxes: Record<string, { value: number, type: string }> = {};
    itinerary.forEach(dest => {
      if (dest.selectedCountry && !countryTaxes[dest.selectedCountry]) {
        countryTaxes[dest.selectedCountry] = { 
          value: Number(dest.taxValue) || 0, 
          type: dest.taxType || 'FIXED' 
        };
      }
    });

    const uniqueTaxes = Object.values(countryTaxes);

    if (taxStrategy === 'SUM') {
      computedTax = uniqueTaxes.reduce((sum, tax) => {
        if (tax.type === 'PERCENTAGE') {
          return sum + (tax.value / 100) * planPrice;
        }
        return sum + tax.value;
      }, 0);
    } else if (taxStrategy === 'MAX') {
      const maxTax = Math.max(...uniqueTaxes.map(t => {
        if (t.type === 'PERCENTAGE') return (t.value / 100) * planPrice;
        return t.value;
      }), 0);
      computedTax = maxTax;
    } else if (taxStrategy === 'PRIMARY') {
      const first = itinerary[0];
      if (first.taxType === 'PERCENTAGE') {
        computedTax = (first.taxValue / 100) * planPrice;
      } else {
        computedTax = first.taxValue;
      }
    }
    
    return computedTax;
  }, [itinerary, taxStrategy]);

  /** Normalize feature text: Telehealth -> telehealth, In-person -> in-person */
  const normalizeFeatureText = (text: string) =>
    text.replace(/\bTelehealth\b/g, 'telehealth').replace(/\bIn-person\b/g, 'in-person');

  /** Validity with superscript "th", no space after en-dash */
  function ValidityWithSuperscript() {
    const from = PLAN_BENEFITS_AVAILABLE.fromLabel;
    const to = PLAN_BENEFITS_AVAILABLE.toLabel;
    const fromMatch = from.match(/^(.*?)(\d+)$/);
    const toMatch = to.match(/^(.*?)(\d+)$/);
    return (
      <span className="text-muted-foreground text-sm block mt-1">
        Validity: {fromMatch ? <>{fromMatch[1]}{fromMatch[2]}<sup>th</sup></> : from}
        –{toMatch ? <>{toMatch[1]}{toMatch[2]}<sup>th</sup></> : to}
      </span>
    );
  }

  const getCategoryFromPlan = (plan: Plan): FilterKey => {
    // 1) Prefer explicit maxPersons
    if (plan.maxPersons === 1) return 'INDIVIDUAL';
    if (plan.maxPersons === 2) return 'FAMILY_2';
    if (plan.maxPersons != null && plan.maxPersons >= 3) return 'FAMILY_3_4';

    // 2) Then use planTabName
    const tab = (plan.planTabName || '').toLowerCase();
    if (tab.includes('family of 3-4')) return 'FAMILY_3_4';
    if (tab.includes('family of 2')) return 'FAMILY_2';
    if (tab.includes('individual')) return 'INDIVIDUAL';

    // 3) Fallback to name
    const name = (plan.name || '').toLowerCase();
    if (name.includes('family of 3-4')) return 'FAMILY_3_4';
    if (name.includes('family of 2')) return 'FAMILY_2';
    return 'INDIVIDUAL';
  };

  const filteredPlans: Plan[] = plans.filter((p) => getCategoryFromPlan(p) === filter);

  if (loading) {
    return (
      <DashboardLayout navigation={navigation} title="My Plan">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout navigation={navigation} title="My Plan">
      <div className="space-y-8 animate-fade-in">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 text-accent mb-4">
            <Sparkles className="h-4 w-4" />
            <span className="text-sm font-medium">Healthcare Plans</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground">Choose Your Perfect Plan</h1>
          <p className="text-muted-foreground mt-2 max-w-xl mx-auto">
            Select a plan that fits your travel needs and get instant access to world-class healthcare.
          </p>
        </div>

        {/* Step 1: Itinerary Section */}
        <section id="itinerary-section" className="max-w-5xl mx-auto bg-card border rounded-2xl p-6 shadow-sm overflow-hidden">
          <div className="flex items-center gap-3 border-b pb-4 mb-6 -mx-6 px-6">
            <div className="bg-primary text-white h-7 w-7 rounded-full flex items-center justify-center font-bold text-sm shadow-md ring-2 ring-primary/20">1</div>
            <div>
              <h2 className="text-lg font-bold tracking-tight text-foreground">Step 1: Your Destinations</h2>
              <p className="text-xs text-muted-foreground">Add cities you plan to visit for tax calculation and care coordination</p>
            </div>
            {itinerary.length > 0 && (
              <Badge variant="success" className="ml-auto hidden sm:flex items-center gap-1 animate-in fade-in slide-in-from-right-2">
                <CheckCircle2 className="h-3 w-3" />
                Active Itinerary
              </Badge>
            )}
          </div>
          <ItineraryBuilder
            onItineraryChange={(newItinerary, tax) => {
              setItinerary(newItinerary);
              setTotalTax(tax);
            }}
          />
        </section>

        {/* Step 2: Plan Selection Section */}
        <section className="max-w-5xl mx-auto bg-card border rounded-2xl p-6 shadow-sm overflow-hidden">
          <div className="flex items-center gap-3 border-b pb-4 mb-8 -mx-6 px-6">
            <div className="bg-primary text-white h-7 w-7 rounded-full flex items-center justify-center font-bold text-sm shadow-md ring-2 ring-primary/20">2</div>
            <div>
              <h2 className="text-lg font-bold tracking-tight text-foreground">Step 2: Choose Your Plan</h2>
              <p className="text-xs text-muted-foreground">Compare and select the plan that works best for you</p>
            </div>
          </div>

          <Tabs value={filter} onValueChange={(v) => setFilter(v as FilterKey)} className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList className="inline-flex h-9 items-center justify-center rounded-full bg-muted p-1 gap-1">
                <TabsTrigger value="INDIVIDUAL" className="px-6 text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground rounded-full transition-all">
                  Individual
                </TabsTrigger>
                <TabsTrigger value="FAMILY_2" className="px-6 text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground rounded-full transition-all">
                  Family of 2
                </TabsTrigger>
                <TabsTrigger value="FAMILY_3_4" className="px-6 text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground rounded-full transition-all">
                  Family of 3–4
                </TabsTrigger>
              </TabsList>
            </div>
          </Tabs>

          {/* Current Plan Banner – integrated with covered members */}
          {currentPlan && currentPlan.plan && (
            <div className="mb-8">
              <div className="p-4 bg-success/5 border border-success/20 rounded-xl shadow-sm">
                <div className="flex items-start gap-4">
                  <div className="h-10 w-10 rounded-full bg-success/20 flex items-center justify-center shrink-0">
                    <Shield className="h-5 w-5 text-success" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <p className="font-bold text-success text-base leading-none">Active Plan: {currentPlan.plan.name}</p>
                      <div className="flex items-center gap-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="h-7 text-[10px] border-success/30 text-success hover:bg-success/10 hover:text-success font-bold px-3 rounded-full"
                          onClick={() => navigate('/patient/plan-confirmation')}
                        >
                          <FileText className="h-3 w-3 mr-1" />
                          View Confirmation
                        </Button>
                        <Badge variant="success" className="h-5 text-[10px] uppercase tracking-wider">Current</Badge>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground font-medium">
                      {PLAN_BENEFITS_AVAILABLE.fromLabel} – {PLAN_BENEFITS_AVAILABLE.toLabel}
                    </p>

                    {/* Integrated Family Members List */}
                    <div className="mt-3 pt-3 border-t border-success/10">
                      <p className="text-[11px] font-bold text-success/70 uppercase tracking-widest mb-2 flex items-center gap-1.5">
                        <Users className="h-3 w-3" />
                        Coverage Details
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {/* Account Holder */}
                        <div className="inline-flex items-center gap-1.5 bg-white border border-success/10 rounded-full px-2.5 py-1 shadow-sm">
                          <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center text-[10px] font-bold text-primary">
                            {(currentUser?.name || 'P').charAt(0).toUpperCase()}
                          </div>
                          <span className="text-xs font-medium text-slate-700">{currentUser?.name} (You)</span>
                        </div>

                        {/* Family Members */}
                        {familyLoading ? (
                          <Loader2 className="h-4 w-4 animate-spin text-success/50 ml-2" />
                        ) : familyMembers.length > 0 ? (
                          familyMembers.map((member) => (
                            <div key={member.id} className="inline-flex items-center gap-1.5 bg-white border border-success/10 rounded-full px-2.5 py-1 shadow-sm">
                              <div className="h-5 w-5 rounded-full bg-accent/20 flex items-center justify-center text-[10px] font-bold text-accent">
                                {member.firstName.charAt(0).toUpperCase()}
                              </div>
                              <span className="text-xs font-medium text-slate-700">{member.firstName} {member.lastName}</span>
                            </div>
                          ))
                        ) : currentPlan.plan.maxPersons > 1 ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 text-[11px] text-success hover:bg-success/10 hover:text-success px-2 -ml-1"
                            onClick={() => navigate('/patient/profile')}
                          >
                            + Add Family Member
                          </Button>
                        ) : (
                          <span className="text-[11px] text-muted-foreground italic">Individual coverage</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Plans Grid */}
          {filteredPlans.length === 0 ? (
            <div className="py-16 text-center bg-muted/20 border border-dashed rounded-2xl">
              <CreditCard className="h-16 w-16 mx-auto text-muted-foreground mb-4 opacity-30" />
              <h3 className="text-xl font-semibold mb-2">No plans available</h3>
              <p className="text-sm text-muted-foreground">Please check back later for available health plans.</p>
            </div>
          ) : (
            <div className="flex flex-wrap justify-center gap-8 pt-4">
              {filteredPlans.map((plan, index) => {
                const isCurrentPlan = currentPlan?.plan?.planId === plan.planId;
                const isMostPopular = index === 1 && plans.length > 1;
                
                // Tier-specific styles (Simplified & Unified)
                const tierStyles = { 
                  gradient: "from-slate-50 to-slate-100/50 dark:from-slate-900/50 dark:to-slate-900",
                  accent: isMostPopular ? "text-accent" : "text-primary",
                  border: isMostPopular ? "border-accent/40" : "border-slate-200",
                  icon: index === 0 ? Shield : index === 1 ? Sparkles : Star,
                };

                return (
                  <Card
                    key={plan.id}
                    className={`group relative overflow-hidden flex flex-col h-full w-full max-w-[420px] transition-all duration-500 ease-in-out border-2
                    ${!isCurrentPlan ? 'hover:shadow-2xl hover:translate-y-[-4px] cursor-pointer' : ''}
                    ${isMostPopular ? 'ring-4 ring-accent/10 border-accent/40 shadow-xl' : `shadow-lg ${tierStyles.border}`}
                    ${isCurrentPlan ? 'ring-4 ring-success/20 border-success/40' : ''}`}
                  >
                    {/* Top Tier Banner */}
                    <div className={`h-1.5 shrink-0 bg-gradient-to-r ${isMostPopular ? 'from-accent to-accent/60' : 'from-primary to-primary/60'}`} />

                    {/* Popular Badge */}
                    {isMostPopular && !isCurrentPlan && (
                      <div className="absolute top-4 right-4 z-20">
                        <Badge className="bg-accent text-accent-foreground px-3 py-1 text-[10px] font-bold shadow-lg animate-bounce-subtle flex items-center gap-1.5 rounded-full uppercase tracking-tighter">
                          <Sparkles className="h-3 w-3 fill-current" />
                          Recommended
                        </Badge>
                      </div>
                    )}

                    {/* Current Badge */}
                    {isCurrentPlan && (
                      <div className="absolute top-4 right-4 z-20">
                        <Badge variant="success" className="px-2 py-0.5 text-[10px] font-bold shadow-md rounded-full uppercase">Active</Badge>
                      </div>
                    )}

                    <CardHeader className={`text-center pt-8 pb-6 shrink-0 bg-gradient-to-b ${tierStyles.gradient} relative`}>
                      <div className={`mx-auto mb-3 h-10 w-10 rounded-xl bg-white dark:bg-slate-800 shadow-sm flex items-center justify-center ${tierStyles.accent}`}>
                        <tierStyles.icon className="h-6 w-6" strokeWidth={2.5} />
                      </div>
                      
                      <CardTitle className="text-xl font-black tracking-tight">{getDisplayPlanName(plan.name)}</CardTitle>
                      <CardDescription className="text-xs font-medium mt-1 opacity-80 line-clamp-1">{plan.description || 'No description'}</CardDescription>
                      
                      <div className="mt-6 relative inline-block">
                        <div className="flex items-baseline justify-center gap-1">
                          <span className="text-xl font-bold text-muted-foreground">$</span>
                          <span className="text-5xl font-black text-foreground tracking-tighter">
                            {(Number(plan.price) + calculateTaxForPlan(plan)).toFixed(0)}
                          </span>
                          <span className="text-base font-bold text-muted-foreground mt-auto pb-1.5">.{((Number(plan.price) + calculateTaxForPlan(plan)) % 1).toFixed(2).split('.')[1]}</span>
                        </div>
                        {calculateTaxForPlan(plan) > 0 && (
                          <p className="text-[9px] font-black text-primary uppercase tracking-[0.2em] mt-1.5 mb-1 bg-primary/5 rounded-full py-0.5 px-3 border border-primary/10">
                            Inc. Govt Taxes
                          </p>
                        )}
                        <div className="mt-2">
                          <ValidityWithSuperscript />
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent className="flex-1 flex flex-col pt-6 pb-6 px-6 bg-card">
                      <div className="flex-1 flex flex-col space-y-6">
                        <div className="shrink-0">
                          <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground mb-3 flex items-center gap-2">
                             <div className="h-px flex-1 bg-border/60"></div>
                             Services
                             <div className="h-px flex-1 bg-border/60"></div>
                          </p>
                          <div className="flex flex-wrap justify-center gap-2">
                            {Array.isArray(plan.services) && plan.services.length > 0 ? (
                              plan.services.map((service) => (
                                <Badge key={service} variant="secondary" className="flex items-center gap-1.5 px-2 py-0.5 bg-muted/40 text-[10px] font-bold hover:bg-muted/60 transition-all border-transparent rounded-lg">
                                  {service === 'TELEHEALTH' && <Video className="h-3 w-3" />}
                                  {service === 'EMERGENCY' && <Phone className="h-3 w-3" />}
                                  {service === 'TELEHEALTH' ? 'Telehealth' : service === 'EMERGENCY' ? 'Emergency' : service}
                                </Badge>
                              ))
                            ) : (
                              <Badge variant="secondary" className="text-[10px]">No services</Badge>
                            )}
                          </div>
                        </div>

                        {/* Features – checkmarks aligned with text */}
                        <div className="flex-1">
                          <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground mb-3 flex items-center gap-2">
                             <div className="h-px flex-1 bg-border/60"></div>
                             Plan Benefits
                             <div className="h-px flex-1 bg-border/60"></div>
                          </p>
                          <ul className="space-y-3 list-none p-0 m-0">
                            {Array.isArray(plan.features) && plan.features.length > 0 ? (
                              plan.features.map((feature, i) => {
                                const normalized = normalizeFeatureText(feature);
                                return (
                                  <li key={i} className="flex items-start gap-2.5 text-xs text-foreground/90 group/item">
                                    <div className={`mt-0.5 h-4 w-4 rounded-full flex items-center justify-center shrink-0 ${isMostPopular ? 'bg-accent/10 text-accent' : 'bg-primary/10 text-primary'}`}>
                                      <CheckCircle2 className="h-3 w-3" />
                                    </div>
                                    <span className="leading-tight font-medium group-hover/item:text-foreground transition-colors">{normalized}</span>
                                  </li>
                                );
                              })
                            ) : (
                              <li className="text-xs text-muted-foreground italic text-center">No features listed</li>
                            )}
                          </ul>
                        </div>
                      </div>

                      {/* Action Button */}
                      <div className="mt-6">
                        <Button
                          className={`w-full h-12 text-sm font-black uppercase tracking-[0.2em] shadow-xl transition-all duration-300
                            ${isCurrentPlan 
                              ? 'bg-muted text-muted-foreground cursor-default' 
                              : isMostPopular 
                                ? 'bg-accent hover:bg-accent/90 text-accent-foreground hover:scale-[1.03] active:scale-[0.98]' 
                                : 'bg-primary hover:bg-primary/90 text-primary-foreground hover:scale-[1.03] active:scale-[0.98]'}`}
                          onClick={() => isCurrentPlan ? navigate('/patient/plan-confirmation') : handleSelectPlan(plan)}
                          size="lg"
                        >
                          {isCurrentPlan ? (
                            <span className="flex items-center gap-2">
                              <FileText className="h-5 w-5" />
                              View Confirmation
                            </span>
                          ) : (
                            <span className="flex items-center gap-2">
                              Get Now
                            </span>
                          )}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                );
              })}
            </div>
          )}


          {/* Trust Badges */}
          <div className="flex flex-wrap justify-center gap-8 py-6 mt-6 border-t border-dashed grayscale opacity-70">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-foreground" />
              <span className="text-[11px] font-bold uppercase tracking-widest">Secure Payment</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-foreground" />
              <span className="text-[11px] font-bold uppercase tracking-widest">Instant Access</span>
            </div>
            <div className="flex items-center gap-2">
              <Star className="h-4 w-4 text-foreground" />
              <span className="text-[11px] font-bold uppercase tracking-widest">24/7 Concierge</span>
            </div>
          </div>
        </section>

      </div>

      {/* Payment Modal */}
      <PaymentModal
        open={paymentModalOpen}
        onClose={() => setPaymentModalOpen(false)}
        plan={selectedPlan}
        itinerary={itinerary}
        totalTax={selectedPlan ? calculateTaxForPlan(selectedPlan) : 0}
        onSuccess={handlePaymentSuccess}
      />
    </DashboardLayout>
  );
}
