import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  LayoutDashboard,
  Calendar,
  FileText,
  CreditCard,
  Download,
  Pill,
  Stethoscope,
  User,
  Loader2,
  FileSignature,
  Search,
  AlertTriangle,
  CheckCircle2,
  Users,
  Clock,
  ChevronDown,
  ChevronUp,
  Activity,
} from 'lucide-react';
import { PlanRequiredGate } from '@/components/patient/PlanRequiredGate';
import { format } from 'date-fns';
import { paymentApi, prescriptionApi } from '@/services/api';

const getNavigation = (hasActivePlan: boolean) => [
  { name: 'Dashboard', href: '/patient', icon: LayoutDashboard },
  { name: 'My Appointments', href: '/patient/appointments', icon: Calendar, disabled: !hasActivePlan },
  { name: 'Prescriptions', href: '/patient/prescriptions', icon: FileText, disabled: !hasActivePlan },
  { name: 'Contracts', href: '/patient/contracts', icon: FileSignature },
  { name: 'My Plan', href: '/patient/plans', icon: CreditCard },
];

export default function PatientPrescriptionsPage() {
  const [hasActivePlan, setHasActivePlan] = useState<boolean | null>(null);
  const [prescriptions, setPrescriptions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedId, setExpandedId] = useState<number | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        const planRes = await paymentApi.getActiveUserPlan();
        const isActive = !!(planRes.success && planRes.data?.activePlan);
        setHasActivePlan(isActive);
        if (isActive) {
          const prescRes = await prescriptionApi.getForPatient();
          if (prescRes.success && prescRes.data) {
            setPrescriptions(prescRes.data);
            if (prescRes.data.length > 0) setExpandedId(prescRes.data[0].id);
          }
        }
      } catch (err) {
        console.error('Failed to load prescriptions', err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const handleDownload = (prescriptionId: string) => {
    window.open(`/print/prescription/${prescriptionId}`, '_blank');
  };

  const toggleExpand = (id: number) => {
    setExpandedId(prev => (prev === id ? null : id));
  };

  const filteredPrescriptions = prescriptions.filter(p => {
    const fm = p.Appointment?.request?.familyMember;
    const patientName = fm ? `${fm.firstName} ${fm.lastName}` : '';
    const doctor = p.Doctor?.User ? `${p.Doctor.User.firstName} ${p.Doctor.User.lastName}` : '';
    return (
      (p.diagnosis || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      doctor.toLowerCase().includes(searchTerm.toLowerCase()) ||
      patientName.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const totalMedicines = prescriptions.reduce((acc, p) => acc + (p.medicines?.length || 0), 0);
  const familyCount = prescriptions.filter(p => p.Appointment?.request?.familyMember).length;

  if (loading || hasActivePlan === null) {
    return (
      <DashboardLayout navigation={getNavigation(false)} title="Prescriptions">
        <div className="flex flex-col items-center justify-center h-64 gap-3">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p className="text-muted-foreground font-medium">Loading your prescriptions…</p>
        </div>
      </DashboardLayout>
    );
  }

  if (hasActivePlan === false) {
    return (
      <DashboardLayout navigation={getNavigation(false)} title="Prescriptions">
        <div className="space-y-8 animate-fade-in py-8">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">My Prescriptions</h1>
            <p className="text-muted-foreground mt-1">View and download your medical prescriptions</p>
          </div>
          <PlanRequiredGate featureName="Prescriptions" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout navigation={getNavigation(true)} title="Prescriptions">
      <div className="space-y-8 animate-fade-in">

        {/* ── Hero Header ── */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary via-primary/90 to-accent p-8 text-white shadow-xl">
          <div className="absolute inset-0 opacity-10"
            style={{ backgroundImage: 'radial-gradient(circle at 80% 50%, white 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
          <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <FileText className="h-5 w-5 opacity-80" />
                <span className="text-sm font-bold uppercase tracking-widest opacity-80">Medical Records</span>
              </div>
              <h1 className="text-3xl font-black tracking-tight">My Prescriptions</h1>
              <p className="text-white/70 mt-1 text-sm">Your complete digital prescription history</p>
            </div>
            <div className="flex gap-4">
              <div className="bg-white/15 backdrop-blur-sm rounded-2xl p-4 text-center min-w-[80px]">
                <p className="text-3xl font-black">{prescriptions.length}</p>
                <p className="text-xs text-white/70 uppercase tracking-wider font-semibold mt-1">Total Rx</p>
              </div>
              <div className="bg-white/15 backdrop-blur-sm rounded-2xl p-4 text-center min-w-[80px]">
                <p className="text-3xl font-black">{totalMedicines}</p>
                <p className="text-xs text-white/70 uppercase tracking-wider font-semibold mt-1">Medicines</p>
              </div>
              {familyCount > 0 && (
                <div className="bg-white/15 backdrop-blur-sm rounded-2xl p-4 text-center min-w-[80px]">
                  <p className="text-3xl font-black">{familyCount}</p>
                  <p className="text-xs text-white/70 uppercase tracking-wider font-semibold mt-1">For Family</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ── Search Bar ── */}
        {prescriptions.length > 0 && (
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by diagnosis, doctor, or family member…"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="pl-11 h-12 rounded-xl border-border bg-card shadow-sm text-sm"
            />
          </div>
        )}

        {/* ── Empty State ── */}
        {prescriptions.length === 0 ? (
          <Card className="shadow-card border-0">
            <CardContent className="py-20 text-center">
              <div className="h-20 w-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-5">
                <FileText className="h-10 w-10 text-primary/50" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-2">No Prescriptions Yet</h3>
              <p className="text-muted-foreground text-sm max-w-sm mx-auto">
                After your consultation, your doctor will issue a digital prescription that appears here.
              </p>
            </CardContent>
          </Card>
        ) : filteredPrescriptions.length === 0 ? (
          <Card className="shadow-card border-0">
            <CardContent className="py-16 text-center">
              <Search className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
              <p className="text-muted-foreground font-medium">No results for "{searchTerm}"</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-5">
            {filteredPrescriptions.map((prescription, idx) => {
              const doctorName = prescription.Doctor?.User
                ? `Dr. ${prescription.Doctor.User.firstName} ${prescription.Doctor.User.lastName}`
                : 'Attending Doctor';
              const doctorSpec = prescription.Doctor?.specialization || 'Medical Provider';
              const doctorInitial = prescription.Doctor?.User?.firstName?.charAt(0) || 'D';
              const familyMember = prescription.Appointment?.request?.familyMember ?? null;
              const isExpanded = expandedId === prescription.id;
              const medicineCount = prescription.medicines?.length || 0;
              const dateIssued = prescription.created_at
                ? format(new Date(prescription.created_at), 'MMM dd, yyyy')
                : '—';

              return (
                <Card
                  key={prescription.id}
                  className="shadow-card border-0 overflow-hidden transition-all duration-300"
                  style={{ animationDelay: `${idx * 60}ms` }}
                >
                  {/* Top gradient bar */}
                  <div className="h-1.5 bg-gradient-to-r from-primary via-accent to-primary/60" />

                  {/* Card Header — always visible */}
                  <div
                    className="flex items-start justify-between gap-4 p-6 cursor-pointer hover:bg-muted/30 transition-colors"
                    onClick={() => toggleExpand(prescription.id)}
                  >
                    <div className="flex items-start gap-4 flex-1 min-w-0">
                      {/* Icon */}
                      <div className="h-12 w-12 shrink-0 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                        <Stethoscope className="h-6 w-6 text-primary" />
                      </div>

                      <div className="flex-1 min-w-0">
                        {/* Diagnosis */}
                        <h3 className="text-lg font-black text-foreground truncate">{prescription.diagnosis}</h3>

                        {/* Family member badge */}
                        {familyMember && (
                          <div className="flex items-center gap-1.5 mt-1">
                            <Users className="h-3.5 w-3.5 text-blue-500" />
                            <span className="text-xs font-semibold text-blue-600">
                              For {familyMember.firstName} {familyMember.lastName}
                              {familyMember.relationship ? ` · ${familyMember.relationship}` : ''}
                            </span>
                          </div>
                        )}

                        {/* Meta row */}
                        <div className="flex flex-wrap items-center gap-3 mt-2">
                          <span className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Clock className="h-3 w-3" /> {dateIssued}
                          </span>
                          <span className="flex items-center gap-1 text-xs text-muted-foreground">
                            <User className="h-3 w-3" /> {doctorName}
                          </span>
                          <Badge
                            variant="outline"
                            className="text-[10px] px-2 py-0.5 bg-emerald-50 border-emerald-200 text-emerald-700 font-semibold"
                          >
                            <CheckCircle2 className="h-2.5 w-2.5 mr-1" /> ISSUED
                          </Badge>
                          <Badge variant="outline" className="text-[10px] px-2 py-0.5">
                            <Pill className="h-2.5 w-2.5 mr-1" /> {medicineCount} Medicine{medicineCount !== 1 ? 's' : ''}
                          </Badge>
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 shrink-0">
                      <Button
                        variant="outline"
                        size="sm"
                        className="hidden md:flex items-center gap-1.5 rounded-xl font-semibold"
                        onClick={e => { e.stopPropagation(); handleDownload(prescription.prescriptionUuid || prescription.id); }}
                      >
                        <Download className="h-4 w-4" /> PDF
                      </Button>
                      <div className="h-8 w-8 rounded-full flex items-center justify-center bg-muted">
                        {isExpanded ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
                      </div>
                    </div>
                  </div>

                  {/* Expandable Details */}
                  {isExpanded && (
                    <div className="border-t border-border bg-muted/20 p-6 space-y-6">

                      {/* Family Member Banner */}
                      {familyMember && (
                        <div className="flex items-center gap-3 p-4 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-xl">
                          <div className="h-10 w-10 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center shrink-0">
                            <span className="text-blue-600 font-black text-base">{familyMember.firstName.charAt(0)}</span>
                          </div>
                          <div>
                            <p className="font-bold text-blue-900 dark:text-blue-300 text-sm">
                              Prescribed for: {familyMember.firstName} {familyMember.lastName}
                            </p>
                            {familyMember.relationship && (
                              <p className="text-xs text-blue-600 dark:text-blue-400 font-medium mt-0.5">{familyMember.relationship}</p>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Doctor Info */}
                      <div className="flex items-center gap-4 p-4 bg-card rounded-xl border border-border">
                        <div className="h-12 w-12 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center shrink-0">
                          <span className="text-primary font-black text-lg">{doctorInitial}</span>
                        </div>
                        <div>
                          <p className="font-bold text-foreground">{doctorName}</p>
                          <p className="text-sm text-muted-foreground">{doctorSpec}</p>
                        </div>
                        <div className="ml-auto">
                          <Badge className="bg-primary/10 text-primary border-0 font-semibold text-xs">Prescribing Physician</Badge>
                        </div>
                      </div>

                      {/* Clinical Notes */}
                      {(prescription.generalAdvice || prescription.restrictions) && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {prescription.generalAdvice && (
                            <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900">
                              <div className="flex items-center gap-2 mb-2">
                                <Activity className="h-4 w-4 text-emerald-600" />
                                <h4 className="text-xs font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-widest">General Advice</h4>
                              </div>
                              <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">{prescription.generalAdvice}</p>
                            </div>
                          )}
                          {prescription.restrictions && (
                            <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/20 border border-red-100 dark:border-red-900">
                              <div className="flex items-center gap-2 mb-2">
                                <AlertTriangle className="h-4 w-4 text-red-500" />
                                <h4 className="text-xs font-bold text-red-600 dark:text-red-400 uppercase tracking-widest">Restrictions</h4>
                              </div>
                              <p className="text-sm text-red-700 dark:text-red-300 font-medium leading-relaxed">{prescription.restrictions}</p>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Medicines */}
                      {prescription.medicines && prescription.medicines.length > 0 && (
                        <div>
                          <div className="flex items-center gap-2 mb-4">
                            <Pill className="h-4 w-4 text-accent" />
                            <h4 className="font-bold text-sm uppercase tracking-widest text-muted-foreground">Prescribed Medicines</h4>
                            <span className="ml-auto text-xs font-bold text-muted-foreground">{prescription.medicines.length} item{prescription.medicines.length !== 1 ? 's' : ''}</span>
                          </div>
                          <div className="space-y-3">
                            {prescription.medicines.map((medicine: any, i: number) => (
                              <div
                                key={i}
                                className="flex items-start gap-4 p-4 bg-card border border-border rounded-xl hover:border-primary/30 transition-colors"
                              >
                                <div className="h-8 w-8 rounded-full bg-accent/10 flex items-center justify-center shrink-0 mt-0.5">
                                  <span className="text-accent font-black text-xs">{i + 1}</span>
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="font-bold text-foreground">{medicine.name}</p>
                                  <div className="flex flex-wrap gap-2 mt-2">
                                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-primary/8 text-primary text-xs font-semibold border border-primary/15">
                                      💊 {medicine.dosage}
                                    </span>
                                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-muted text-muted-foreground text-xs font-semibold border border-border">
                                      🔁 {medicine.frequency}x daily
                                    </span>
                                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-muted text-muted-foreground text-xs font-semibold border border-border">
                                      📅 {medicine.duration} days
                                    </span>
                                    {medicine.foodInstructions && (
                                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-50 text-amber-700 border border-amber-200 text-xs font-semibold">
                                        🍽️ {medicine.foodInstructions}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Download Button — bottom */}
                      <div className="flex justify-end pt-2">
                        <Button
                          variant="default"
                          className="rounded-xl gap-2 font-bold"
                          onClick={() => handleDownload(prescription.prescriptionUuid || prescription.id)}
                        >
                          <Download className="h-4 w-4" />
                          Download PDF
                        </Button>
                      </div>
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
