import { useState, useEffect, useMemo } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore, ServiceType } from '@/lib/store';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { 
  LayoutDashboard, 
  Calendar as CalendarIcon, 
  FileText, 
  CreditCard,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Video,
  Phone,
  User,
  MapPin,
  Mail,
  Heart,
  Clock,
  Users,
  AlertCircle,
  FileSignature
} from 'lucide-react';
import { format, addHours, isBefore, startOfDay, setHours, setMinutes } from 'date-fns';
import { 
  paymentApi, 
  appointmentApi, 
  AppointmentServiceType, 
  familyMembersApi, 
  FamilyMember, 
  userProfileApi,
  locationApi,
  DBLocation
} from '@/services/api';
import { toast } from 'sonner';
import { CountryLocation } from '@/config/locations';
import { getTimezoneLabel } from '@/config/timezones';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
const getNavigation = (hasActivePlan: boolean) => [
  { name: 'Dashboard', href: '/patient', icon: LayoutDashboard },
  { name: 'My Appointments', href: '/patient/appointments', icon: CalendarIcon, disabled: !hasActivePlan },
  { name: 'Prescriptions', href: '/patient/prescriptions', icon: FileText, disabled: !hasActivePlan },
  { name: 'Contracts', href: '/patient/contracts', icon: FileSignature },
  { name: 'My Plan', href: '/patient/plans', icon: CreditCard },
];

interface BookingFormData {
  // Step 1: Location
  country: string;
  city: string;
  state: string;

  // Step 2: Patient Selection
  patientType: 'self' | 'family';
  familyMemberId?: number;

  // Step 3: Patient Details (Auto-filled)
  fullName: string;
  email: string;
  phone: string;
  age: string;
  gender: string;
  emergencyContact: string;
  emergencyContactName: string;
  allergies: string;
  
  // Step 4: Service & Date
  serviceType: ServiceType;
  date: Date | undefined;
  time: string; // HH:mm

  // Step 5: Review
  confirmed: boolean;
}

export default function BookAppointmentPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { currentUser, createAppointment } = useAppStore();
  const [currentPlan, setCurrentPlan] = useState<any | null>(null);
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([]);
  const [loadingActivePlan, setLoadingActivePlan] = useState(true);
  const [loadingFamily, setLoadingFamily] = useState(false);
  const [locations, setLocations] = useState<CountryLocation[]>([]);
  const [loadingLocations, setLoadingLocations] = useState(true);
  const [showNoPlanDialog, setShowNoPlanDialog] = useState(false);
  
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<BookingFormData>({
    country: '',
    city: '',
    state: '',
    patientType: 'self',
    fullName: currentUser?.name || '',
    email: currentUser?.email || '',
    phone: currentUser?.phone || '',
    age: '',
    gender: '',
    emergencyContact: '',
    emergencyContactName: '',
    allergies: '',
    serviceType: (searchParams.get('service') as ServiceType) || 'telehealth',
    date: new Date(),
    time: '',
    confirmed: false,
  });

  // Helper to calculate age from DOB
  const calculateAge = (dob: string | null | undefined) => {
    if (!dob) return '';
    try {
      const birthDate = new Date(dob);
      if (isNaN(birthDate.getTime())) return '';
      const today = new Date();
      let age = today.getFullYear() - birthDate.getFullYear();
      const m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      return age.toString();
    } catch (e) {
      return '';
    }
  };

  // Initial auto-fill for 'self' when currentUser is loaded
  useEffect(() => {
    if (currentUser && formData.patientType === 'self') {
      const fName = currentUser.firstName || '';
      const lName = currentUser.lastName || '';
      const fullName = currentUser.name || `${fName} ${lName}`.trim();
      
      setFormData(prev => ({
        ...prev,
        fullName: prev.fullName || fullName,
        email: prev.email || currentUser.email || '',
        phone: prev.phone || currentUser.phone || '',
        age: prev.age || calculateAge(currentUser.dateOfBirth),
        gender: prev.gender || currentUser.gender || '',
        emergencyContact: prev.emergencyContact || currentUser.emergencyContactPhone || '',
        emergencyContactName: prev.emergencyContactName || currentUser.emergencyContactName || '',
      }));
    }
  }, [currentUser, formData.patientType]);

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoadingActivePlan(true);
        
        // Load each piece of data independently to be more resilient
        const [planRes, familyRes, profileRes] = await Promise.allSettled([
          paymentApi.getActiveUserPlan(),
          familyMembersApi.getList(),
          userProfileApi.getProfile()
        ]);

        // Handle Profile for auto-fill
        if (profileRes.status === 'fulfilled' && profileRes.value.success && profileRes.value.data) {
          const p = profileRes.value.data;
          const fullName = `${p.firstName || ''} ${p.lastName || ''}`.trim();
          
          if (formData.patientType === 'self') {
            setFormData(prev => ({
              ...prev,
              fullName: prev.fullName || fullName,
              email: prev.email || p.email || '',
              phone: prev.phone || p.phone || '',
              age: prev.age || calculateAge(p.dateOfBirth),
              gender: prev.gender || p.gender || '',
              emergencyContact: prev.emergencyContact || p.emergencyContactPhone || '',
              emergencyContactName: prev.emergencyContactName || p.emergencyContactName || '',
            }));
          }
        }

        // Handle Plan
        if (planRes.status === 'fulfilled' && planRes.value.success) {
          const resValue = planRes.value as any;
          // The data might be in resValue.data.activePlan or directly in resValue.activePlan due to apiRequest spreading
          const active = resValue.data?.activePlan || resValue.activePlan;
          
          if (active && active.plan) {
            const rawPlan = active.plan;
            const baseServices = Array.isArray(rawPlan.services)
              ? rawPlan.services
              : (typeof rawPlan.services === 'string' ? JSON.parse(rawPlan.services) : []);

            const mappedServices: ServiceType[] = Array.from(
              new Set(
                baseServices
                  .map((s: any) => String(s).toUpperCase())
                  .map((s) => (s === 'TELEHEALTH' ? 'telehealth' : s === 'EMERGENCY' ? 'emergency' : null))
                  .filter((s): s is ServiceType => s !== null)
              )
            );

            setCurrentPlan({
              planId: active.planId || rawPlan.planId,
              endDate: active.endDate,
              plan: { ...rawPlan, services: mappedServices },
            });
          }
        }

        // Handle Family
        if (familyRes.status === 'fulfilled' && familyRes.value.success) {
          // The API returns { familyMembers: [...], maxSlots: ... }
          const members = (familyRes.value.data as any)?.familyMembers || [];
          setFamilyMembers(members);
        }
      } catch (err) {
        console.error('Failed to load booking data:', err);
      } finally {
        setLoadingActivePlan(false);
      }
    };
    loadData();
  }, [currentUser]);

  // Load locations from API
  useEffect(() => {
    const fetchLocations = async () => {
      try {
        setLoadingLocations(true);
        const res = await locationApi.getAll();
        if (res.success && res.data) {
          // Group flat list into CountryLocation[]
          const grouped = res.data.reduce((acc: CountryLocation[], curr: DBLocation) => {
            let country = acc.find(c => c.country === curr.country);
            if (!country) {
              country = { country: curr.country, cities: [] };
              acc.push(country);
            }
            country.cities.push({ name: curr.city, state: curr.state });
            return acc;
          }, []);
          setLocations(grouped);
        }
      } catch (err) {
        console.error('Failed to fetch locations:', err);
      } finally {
        setLoadingLocations(false);
      }
    };
    fetchLocations();
  }, []);

  // Update form when patient selection changes
  useEffect(() => {
    if (formData.patientType === 'self' && currentUser) {
      const fName = currentUser.firstName || '';
      const lName = currentUser.lastName || '';
      const fullName = currentUser.name || `${fName} ${lName}`.trim();

      setFormData(prev => ({
        ...prev,
        fullName: fullName,
        email: currentUser.email || '',
        phone: currentUser.phone || '',
        age: calculateAge(currentUser.dateOfBirth),
        gender: currentUser.gender || '',
        emergencyContact: currentUser.emergencyContactPhone || '',
        emergencyContactName: currentUser.emergencyContactName || '',
      }));
    } else if (formData.patientType === 'family' && formData.familyMemberId) {
      const member = familyMembers.find(m => m.id === formData.familyMemberId);
      if (member) {
        setFormData(prev => ({
          ...prev,
          fullName: `${member.firstName || ''} ${member.lastName || ''}`.trim(),
          email: '', 
          phone: '', 
          age: calculateAge(member.dateOfBirth),
          gender: member.gender || '',
          emergencyContact: currentUser?.emergencyContactPhone || '',
          emergencyContactName: currentUser?.emergencyContactName || '',
        }));
      }
    }
  }, [formData.patientType, formData.familyMemberId, familyMembers, currentUser]);

  const timeSlots = useMemo(() => {
    const slots = [];
    const targetTimezone = getTimezoneLabel(formData.country);
    
    // Get current time in the selected country's timezone
    let nowInTz;
    try {
      nowInTz = new Date(new Date().toLocaleString("en-US", { timeZone: targetTimezone }));
    } catch (e) {
      nowInTz = new Date();
    }
    
    const minTime = addHours(nowInTz, 1); // Must be at least 1 hour from "now" in that country

    for (let hour = 0; hour < 24; hour++) {
      const slotDate = formData.date ? new Date(formData.date) : new Date();
      slotDate.setHours(hour, 0, 0, 0);

      if (isBefore(minTime, slotDate)) {
        slots.push(format(slotDate, 'hh:mm a'));
      }
    }
    return slots;
  }, [formData.date, formData.country]);

  const handleNext = () => {
    if (step < 5) setStep(step + 1);
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmit = async () => {
    if (!formData.date || !formData.time) return;

    // Require active plan at confirm time — show popup instead of API error
    if (!currentPlan || !currentPlan.plan) {
      setShowNoPlanDialog(true);
      return;
    }

    // Parse "hh:mm a" (e.g., "02:30 PM")
    const appointmentDate = new Date(formData.date);
    const [timeStr, modifier] = formData.time.split(' ');
    let [hours, minutes] = timeStr.split(':').map(Number);
    
    if (modifier?.toUpperCase() === 'PM' && hours < 12) hours += 12;
    if (modifier?.toUpperCase() === 'AM' && hours === 12) hours = 0;
    
    appointmentDate.setHours(hours, minutes, 0, 0);

    try {
      const serviceTypeApi: AppointmentServiceType =
        formData.serviceType === 'telehealth' ? 'TELEHEALTH' : 'EMERGENCY';

      const res = await appointmentApi.createRequest({
        country: formData.country,
        state: formData.state,
        city: formData.city,
        age: parseInt(formData.age, 10),
        gender: formData.gender,
        emergencyContact: formData.emergencyContact || undefined,
        serviceType: serviceTypeApi,
        notes: formData.allergies.trim() || undefined,
        familyMemberId: formData.patientType === 'family' ? formData.familyMemberId : undefined,
        appointmentDate: appointmentDate.toISOString(),
      });

      if (!res.success) {
        toast.error(res.message || 'Failed to submit booking request');
        return;
      }

      toast.success('Booking request submitted');
      setStep(6);
    } catch (e: any) {
      toast.error(e?.message || 'Failed to submit booking request');
    }
  };

  const isStepValid = () => {
    switch (step) {
      case 1: // Location
        return formData.country && formData.city;
      case 2: // Patient Selection
        return formData.patientType === 'self' || (formData.patientType === 'family' && formData.familyMemberId);
      case 3: // Details
        return formData.fullName && formData.age && formData.gender;
      case 4: // Scheduling
        return formData.date && formData.time && formData.serviceType;
      case 5: // Review
        return formData.confirmed;
      default:
        return false;
    }
  };

  const steps = [
    { number: 1, title: 'Location' },
    { number: 2, title: 'Patient' },
    { number: 3, title: 'Details' },
    { number: 4, title: 'Schedule' },
    { number: 5, title: 'Confirm' },
  ];

  // When user has no plan, still allow going through steps; confirm will prompt to buy a plan
  // IMPORTANT: hooks must run before any early return
  const availableServices = useMemo(() => {
    const raw = currentPlan?.plan?.services;
    if (!raw) return ['telehealth', 'emergency'] as const;
    const arr = Array.isArray(raw)
      ? raw
      : typeof raw === 'string'
        ? (() => { try { return JSON.parse(raw || '[]'); } catch { return []; } })()
        : [];
    const normalized = (arr as string[]).map((x) => String(x).toLowerCase());
    if (!normalized.length) return ['telehealth', 'emergency'] as const;
    return normalized;
  }, [currentPlan]);

  const selectedCountry = locations.find(l => l.country === formData.country);

  if (loadingActivePlan) {
    return (
      <DashboardLayout navigation={getNavigation(!!currentPlan)} title="Book Appointment">
        <div className="flex items-center justify-center h-64">
          <CreditCard className="h-8 w-8 animate-pulse text-muted-foreground" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout navigation={getNavigation(!!currentPlan)} title="Book Appointment">
      <div className="max-w-3xl mx-auto animate-fade-in space-y-6">

        {step < 6 ? (
          <>
            {/* Stepper */}
            <div className="mb-8 overflow-x-auto pb-2">
              <div className="flex items-center justify-between min-w-[500px] px-4">
                {steps.map((s, i) => (
                  <div key={s.number} className="flex items-center">
                    <div className={`flex items-center ${i !== 0 ? 'flex-1' : ''}`}>
                      {i !== 0 && (
                        <div className={`h-0.5 w-6 md:w-12 mx-2 ${step > i ? 'bg-accent' : 'bg-border'}`} />
                      )}
                      <div className={`flex flex-col items-center`}>
                        <div className={`h-8 w-8 md:h-10 md:w-10 rounded-full flex items-center justify-center font-semibold text-sm ${
                          step > s.number 
                            ? 'bg-accent text-accent-foreground' 
                            : step === s.number 
                              ? 'bg-primary text-primary-foreground' 
                              : 'bg-muted text-muted-foreground'
                        }`}>
                          {step > s.number ? <CheckCircle2 className="h-5 w-5" /> : s.number}
                        </div>
                        <span className="text-[10px] md:text-xs mt-2 text-center font-medium">{s.title}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Step Content */}
            <Card className="shadow-card border-0">
              {step === 1 && (
                <>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <MapPin className="h-5 w-5 text-accent" />
                      Where are you located?
                    </CardTitle>
                    <CardDescription>
                      Select your current World Cup location
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Country *</Label>
                        <Select 
                          value={formData.country} 
                          onValueChange={(v) => {
                            setFormData({ ...formData, country: v, city: '', state: '' });
                          }}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select Country" />
                          </SelectTrigger>
                          <SelectContent>
                            {locations.map((loc) => (
                              <SelectItem key={loc.country} value={loc.country}>{loc.country}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>City *</Label>
                        <Select 
                          value={formData.city} 
                          onValueChange={(v) => {
                            const cityData = selectedCountry?.cities.find(c => c.name === v);
                            setFormData({ ...formData, city: v, state: cityData?.state || '' });
                          }}
                          disabled={!formData.country}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select City" />
                          </SelectTrigger>
                          <SelectContent>
                            {selectedCountry?.cities.map((city) => (
                              <SelectItem key={city.name} value={city.name}>{city.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>State / Province</Label>
                      <Input 
                        value={formData.state || '—'} 
                        readOnly 
                        className="bg-muted/50"
                        placeholder="State will be filled automatically"
                      />
                    </div>
                  </CardContent>
                </>
              )}

              {step === 2 && (
                <>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <Users className="h-5 w-5 text-accent" />
                      Who is this appointment for?
                    </CardTitle>
                    <CardDescription>
                      Select the person who needs medical attention
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid gap-3">
                      <div
                        className={`p-4 rounded-xl border-2 cursor-pointer transition-all flex items-center gap-4 ${
                          formData.patientType === 'self'
                            ? 'border-accent bg-accent/5'
                            : 'border-border hover:border-accent/50'
                        }`}
                        onClick={() => setFormData({ ...formData, patientType: 'self', familyMemberId: undefined })}
                      >
                        <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center">
                          <User className="h-5 w-5 text-accent" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold">Myself</h3>
                          <p className="text-xs text-muted-foreground">{currentUser?.firstName} {currentUser?.lastName}</p>
                        </div>
                        {formData.patientType === 'self' && <CheckCircle2 className="h-5 w-5 text-accent" />}
                      </div>

                      {familyMembers.length > 0 && (
                        <div className="pt-2">
                          <Label className="text-xs text-muted-foreground mb-2 block">Family Members Covered</Label>
                          <div className="grid gap-2">
                            {familyMembers.map((member) => (
                              <div
                                key={member.id}
                                className={`p-4 rounded-xl border-2 cursor-pointer transition-all flex items-center gap-4 ${
                                  formData.patientType === 'family' && formData.familyMemberId === member.id
                                    ? 'border-accent bg-accent/5'
                                    : 'border-border hover:border-accent/50'
                                }`}
                                onClick={() => setFormData({ ...formData, patientType: 'family', familyMemberId: member.id })}
                              >
                                <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center">
                                  <Users className="h-5 w-5 text-muted-foreground" />
                                </div>
                                <div className="flex-1">
                                  <h3 className="font-semibold">{member.firstName} {member.lastName}</h3>
                                  <p className="text-xs text-muted-foreground">{member.relationship} • {calculateAge(member.dateOfBirth)} years</p>
                                </div>
                                {formData.patientType === 'family' && formData.familyMemberId === member.id && (
                                  <CheckCircle2 className="h-5 w-5 text-accent" />
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </>
              )}

              {step === 3 && (
                <>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <FileText className="h-5 w-5 text-accent" />
                      Patient Details
                    </CardTitle>
                    <CardDescription>
                      Verify and complete the patient's information
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="fullName">Full Name *</Label>
                        <Input
                          id="fullName"
                          placeholder="John Doe"
                          value={formData.fullName}
                          onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="age">Age *</Label>
                        <Input
                          id="age"
                          type="number"
                          placeholder="25"
                          value={formData.age}
                          onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="gender">Gender *</Label>
                        <Select 
                          value={formData.gender} 
                          onValueChange={(v) => setFormData({ ...formData, gender: v })}
                        >
                          <SelectTrigger id="gender">
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="MALE">Male</SelectItem>
                            <SelectItem value="FEMALE">Female</SelectItem>
                            <SelectItem value="OTHER">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="emergencyContact">Emergency Contact (Optional)</Label>
                        <Input 
                          id="emergencyContact"
                          placeholder="Phone number" 
                          value={formData.emergencyContact}
                          onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="allergies">Symptoms / Reasons for Visit / Allergies</Label>
                      <Textarea 
                        id="allergies"
                        placeholder="Please describe symptoms or any known allergies..."
                        value={formData.allergies}
                        onChange={(e) => setFormData({ ...formData, allergies: e.target.value })}
                        rows={4}
                      />
                    </div>
                  </CardContent>
                </>
              )}

              {step === 4 && (
                <>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <Clock className="h-5 w-5 text-accent" />
                      Schedule Appointment
                    </CardTitle>
                    <CardDescription>
                      Choose service type and preferred time
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Timezone Label */}
                    <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 flex items-center gap-3">
                      <div className="h-8 w-8 rounded-full bg-orange-100 flex items-center justify-center">
                        <Clock className="h-4 w-4 text-orange-600" />
                      </div>
                      <div className="flex-1">
                        <p className="text-xs font-semibold text-orange-800 flex items-center gap-2">
                          Booking for {formData.country || 'selected location'} 
                          <Badge variant="outline" className="bg-orange-100 border-orange-300 text-[10px] py-0 h-4">
                            {new Date().toLocaleTimeString("en-US", { timeZone: getTimezoneLabel(formData.country), hour: '2-digit', minute: '2-digit', hour12: true })}
                          </Badge>
                        </p>
                        <p className="text-[10px] text-orange-600">
                          Current local time in <strong>{getTimezoneLabel(formData.country)}</strong>.
                        </p>
                      </div>
                      {currentPlan?.visitUsage && (
                        <div className="text-right">
                          <p className="text-[10px] font-bold text-orange-800 uppercase">Your Usage</p>
                          <p className="text-[10px] text-orange-600">
                            {currentPlan.visitUsage.telehealth.used}/{currentPlan.visitUsage.telehealth.limit === Infinity ? '∞' : currentPlan.visitUsage.telehealth.limit} visits
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Service Type */}
                    <div className="grid md:grid-cols-2 gap-4">
                      <div
                        className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                          formData.serviceType === 'telehealth'
                            ? 'border-accent bg-accent/5'
                            : 'border-border hover:border-accent/50'
                        } ${!availableServices.includes('telehealth') ? 'opacity-50 cursor-not-allowed' : ''}`}
                        onClick={() => availableServices.includes('telehealth') && setFormData({ ...formData, serviceType: 'telehealth' })}
                      >
                        <div className="flex items-center gap-3">
                          <Video className={`h-5 w-5 ${formData.serviceType === 'telehealth' ? 'text-accent' : 'text-muted-foreground'}`} />
                          <div className="flex-1">
                            <h3 className="font-semibold text-sm">Telehealth</h3>
                            <p className="text-[10px] text-muted-foreground">Video Call</p>
                          </div>
                          {formData.serviceType === 'telehealth' && <CheckCircle2 className="h-4 w-4 text-accent" />}
                        </div>
                      </div>

                      <div
                        className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                          formData.serviceType === 'emergency'
                            ? 'border-primary bg-primary/5'
                            : 'border-border hover:border-primary/50'
                        } ${!availableServices.includes('emergency') ? 'opacity-50 cursor-not-allowed' : ''}`}
                        onClick={() => availableServices.includes('emergency') && setFormData({ ...formData, serviceType: 'emergency' })}
                      >
                        <div className="flex items-center gap-3">
                          <Phone className={`h-5 w-5 ${formData.serviceType === 'emergency' ? 'text-primary' : 'text-muted-foreground'}`} />
                          <div className="flex-1">
                            <h3 className="font-semibold text-sm">Emergency</h3>
                            <p className="text-[10px] text-muted-foreground">In-person Visit</p>
                          </div>
                          {formData.serviceType === 'emergency' && <CheckCircle2 className="h-4 w-4 text-primary" />}
                        </div>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label>Select Date</Label>
                        <Calendar
                          mode="single"
                          selected={formData.date}
                          onSelect={(date) => setFormData({ ...formData, date, time: '' })}
                          disabled={(date) => isBefore(date, startOfDay(new Date()))}
                          className="rounded-md border"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Select Time (Available after 1 hour)</Label>
                        <div className="grid grid-cols-3 gap-2 max-h-[300px] overflow-y-auto p-1">
                          {timeSlots.length > 0 ? (
                            timeSlots.map((slot) => (
                              <Button
                                key={slot}
                                variant={formData.time === slot ? 'accent' : 'outline'}
                                size="sm"
                                className="text-xs"
                                onClick={() => setFormData({ ...formData, time: slot })}
                              >
                                {slot}
                              </Button>
                            ))
                          ) : (
                            <p className="col-span-3 text-xs text-center text-muted-foreground py-8">
                              No slots available for this date.
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </>
              )}

              {step === 5 && (
                <>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <CheckCircle2 className="h-5 w-5 text-accent" />
                      Review & Confirm
                    </CardTitle>
                    <CardDescription>
                      Please verify all details before submitting
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid gap-4">
                      <div className="p-4 rounded-lg bg-muted/30 border border-border">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3">Patient & Location</h4>
                        <div className="grid grid-cols-2 gap-y-2 text-sm">
                          <span className="text-muted-foreground">Patient:</span>
                          <span className="font-medium text-right">{formData.fullName}</span>
                          <span className="text-muted-foreground">Location:</span>
                          <span className="font-medium text-right">{formData.city}, {formData.country}</span>
                        </div>
                      </div>

                      <div className="p-4 rounded-lg bg-muted/30 border border-border">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3">Appointment Details</h4>
                        <div className="grid grid-cols-2 gap-y-2 text-sm">
                          <span className="text-muted-foreground">Service:</span>
                          <span className="font-medium text-right uppercase">{formData.serviceType}</span>
                          <span className="text-muted-foreground">Date:</span>
                          <span className="font-medium text-right">{formData.date ? format(formData.date, 'PPP') : '-'}</span>
                          <span className="text-muted-foreground">Time:</span>
                          <span className="font-medium text-right flex flex-col items-end">
                            <span>{formData.time}</span>
                            <span className="text-[10px] text-accent uppercase font-bold">{getTimezoneLabel(formData.country)}</span>
                          </span>
                        </div>
                      </div>

                      <div className="flex items-start space-x-3 p-4 bg-accent/5 rounded-lg border border-accent/20">
                        <Checkbox
                          id="confirm"
                          checked={formData.confirmed}
                          onCheckedChange={(checked) => setFormData({ ...formData, confirmed: !!checked })}
                        />
                        <label htmlFor="confirm" className="text-xs leading-relaxed cursor-pointer">
                          I confirm that the information provided is correct. I understand that a healthcare 
                          professional will be assigned to my case.
                        </label>
                      </div>
                    </div>
                  </CardContent>
                </>
              )}

              {/* Navigation Buttons */}
              <div className="flex items-center justify-between p-6 pt-0">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={step === 1 ? () => navigate('/patient') : handleBack}
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  {step === 1 ? 'Cancel' : 'Back'}
                </Button>

                {step < 5 ? (
                  <Button size="sm" onClick={handleNext} disabled={!isStepValid()}>
                    Next
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                ) : (
                  <Button size="sm" onClick={handleSubmit} disabled={!isStepValid()} variant="accent">
                    Confirm Booking
                    <CheckCircle2 className="h-4 w-4 ml-2" />
                  </Button>
                )}
              </div>
            </Card>
          </>
        ) : (
          /* Success State */
          <Card className="shadow-card border-0 text-center py-12">
            <CardContent>
              <div className="h-16 w-16 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 className="h-8 w-8 text-success" />
              </div>
              <h2 className="text-xl font-bold mb-2">Request Submitted!</h2>
              <p className="text-sm text-muted-foreground mb-8 max-w-sm mx-auto">
                Your appointment request has been received. 
                Check your dashboard for updates on your assigned doctor.
              </p>
              <div className="flex gap-3 justify-center">
                <Button size="sm" onClick={() => navigate('/patient/appointments')}>
                  My Appointments
                </Button>
                <Button size="sm" variant="outline" onClick={() => navigate('/patient')}>
                  Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* No active plan — only at confirm submit */}
      <Dialog open={showNoPlanDialog} onOpenChange={setShowNoPlanDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <div className="mx-auto h-12 w-12 rounded-full bg-amber-100 flex items-center justify-center mb-4">
              <AlertCircle className="h-6 w-6 text-amber-600" />
            </div>
            <DialogTitle className="text-center">Active plan required</DialogTitle>
            <DialogDescription className="text-center">
              You don&apos;t have an active plan yet. Please choose a plan to complete your booking request.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="sm:justify-center gap-2">
            <Button variant="outline" onClick={() => setShowNoPlanDialog(false)}>
              Go back
            </Button>
            <Link to="/patient/plans">
              <Button className="bg-primary text-primary-foreground font-bold">
                <CreditCard className="h-4 w-4 mr-2" />
                Buy a plan
              </Button>
            </Link>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
