import React, { useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  LayoutDashboard,
  Calendar,
  FileText,
  CreditCard,
  Sparkles,
  Stethoscope,
  Pill,
  FileSignature,
  Info,
  DollarSign,
  ArrowRight,
  ShieldCheck,
  Video,
  Phone,
  Shield,
  Star
} from 'lucide-react';
import { PLAN_BENEFITS_AVAILABLE } from '@/config/patientPlan';
import ItineraryBuilder, { ItineraryDestination } from '@/components/itinerary/ItineraryBuilder';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const navigation = [
  { name: 'Dashboard', href: '/patient', icon: LayoutDashboard },
  { name: 'My Appointments', href: '/patient/appointments', icon: Calendar },
  { name: 'Prescriptions', href: '/patient/prescriptions', icon: FileText },
  { name: 'Contracts', href: '/patient/contracts', icon: FileSignature },
  { name: 'My Plan', href: '/patient/plans', icon: CreditCard },
];

export default function PatientNewPlansPage() {
  const [totalTax, setTotalTax] = useState(0);
  const [itinerary, setItinerary] = useState<ItineraryDestination[]>([]);

  const handleItineraryChange = (newItinerary: ItineraryDestination[], tax: number) => {
    setItinerary(newItinerary);
    setTotalTax(tax);
  };

  return (
    <DashboardLayout navigation={navigation} title="New Plans">
      <div className="max-w-6xl mx-auto space-y-12 animate-fade-in pb-20">
        {/* Header Section */}
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary mb-2 shadow-sm border border-primary/5">
            <Sparkles className="h-4 w-4" />
            <span className="text-sm font-semibold tracking-wide uppercase">Navala 2026 Season Coverage</span>
          </div>
          <h1 className="text-3xl md:text-5xl font-extrabold text-foreground tracking-tight">Choose Your Care Plan</h1>
          <p className="text-muted-foreground mt-4 max-w-2xl mx-auto text-base md:text-lg leading-relaxed">
            Personalized medical coverage for international fans. Every plan includes telehealth
            and specialty care coordination during your stay.
          </p>
        </div>

        {/* Step 1: Itinerary Section */}
        <section className="bg-gradient-to-br from-card to-muted/20 border rounded-3xl p-6 md:p-8 shadow-xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full -mr-32 -mt-32 blur-3xl" />
          <div className="relative z-10 space-y-6">
            <div className="flex items-center gap-3 border-b pb-4 mb-6">
              <div className="bg-primary text-white h-8 w-8 rounded-full flex items-center justify-center font-bold shadow-md">1</div>
              <h2 className="text-xl font-bold tracking-tight">Step 1: Define Your Destinations</h2>
              <Badge variant="outline" className="ml-auto bg-primary/5 border-primary/20 text-primary">Required for Tax calculation</Badge>
            </div>
            <ItineraryBuilder onItineraryChange={handleItineraryChange} />
          </div>
        </section>

        {/* Step 2: Plan Selection Section */}
        <div className="space-y-8 pt-6">
          <div className="flex items-center gap-3 border-b pb-4">
            <div className="bg-primary text-white h-8 w-8 rounded-full flex items-center justify-center font-bold shadow-md">2</div>
            <h2 className="text-xl font-bold tracking-tight">Step 2: Compare & Buy</h2>
          </div>

          <Tabs defaultValue="individual" className="w-full">
            <TabsList className="grid grid-cols-3 max-w-xl mx-auto bg-muted/50 p-1 rounded-xl glass-morphism">
              <TabsTrigger value="individual" className="rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-md">Individual</TabsTrigger>
              <TabsTrigger value="family2" className="rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-md">Family of 2</TabsTrigger>
              <TabsTrigger value="family34" className="rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-md">Family of 3–4</TabsTrigger>
            </TabsList>

            {/* Individual */}
            <TabsContent value="individual" className="mt-10">
              <div className="flex flex-wrap justify-center gap-8">
                <PlanCard
                  label="Basic"
                  basePrice={100}
                  tax={totalTax}
                  visits={{ telehealth: '2', inPerson: '0' }}
                  prescription="$150"
                  specialty="Included"
                  delayMs={0}
                />
                <PlanCard
                  label="Premium"
                  basePrice={130}
                  tax={totalTax}
                  highlight
                  visits={{ telehealth: '4', inPerson: '2' }}
                  prescription="$250"
                  specialty="Included"
                  delayMs={120}
                />
              </div>
            </TabsContent>

            {/* Family of 2 */}
            <TabsContent value="family2" className="mt-10">
              <div className="flex flex-wrap justify-center gap-8">
                <PlanCard
                  label="Basic"
                  basePrice={150}
                  tax={totalTax}
                  visits={{ telehealth: '4', inPerson: '2' }}
                  prescription="$250"
                  specialty="Included"
                  delayMs={0}
                />
                <PlanCard
                  label="Premium"
                  basePrice={200}
                  tax={totalTax}
                  highlight
                  visits={{ telehealth: 'Unlimited', inPerson: '4' }}
                  prescription="$350"
                  specialty="Included"
                  delayMs={120}
                />
              </div>
            </TabsContent>

            {/* Family of 3–4 */}
            <TabsContent value="family34" className="mt-10">
              <div className="flex flex-wrap justify-center gap-8">
                <PlanCard
                  label="Basic"
                  basePrice={250}
                  tax={totalTax}
                  visits={{ telehealth: '5', inPerson: '4' }}
                  prescription="$375"
                  specialty="Included"
                  delayMs={0}
                />
                <PlanCard
                  label="Premium"
                  basePrice={325}
                  tax={totalTax}
                  highlight
                  visits={{ telehealth: 'Unlimited', inPerson: '6' }}
                  prescription="$500"
                  specialty="Included"
                  delayMs={120}
                />
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <p className="text-xs text-muted-foreground text-center max-w-2xl mx-auto py-10 opacity-70">
          Specialty Care Coordination includes linkage to specialty care providers, appointment scheduling
          and local guidance. All fees listed cover administrative coordination; specialist treatment
          costs are separate and paid directly to the clinic.
        </p>
      </div>
    </DashboardLayout>
  );
}

interface SummaryProps {
  label: string;
  basePrice: number;
  tax: number;
  visits: { telehealth: string; inPerson: string };
  prescription: string;
  specialty: string;
  highlight?: boolean;
  delayMs?: number;
}

function PlanCard({ label, basePrice, tax, visits, prescription, specialty, highlight, delayMs }: SummaryProps) {
  const totalPrice = Number(basePrice) + Number(tax);
  return (
    <Card
      className={`group/card relative overflow-hidden flex flex-col h-full w-full max-w-[420px] transition-all duration-500 ease-out animate-fade-in border-2
        ${highlight 
          ? 'ring-4 ring-primary/20 border-primary/40 bg-gradient-to-b from-primary/[0.02] to-transparent shadow-2xl md:scale-[1.02]' 
          : 'bg-card border-border shadow-lg'}
        hover:shadow-2xl hover:translate-y-[-8px] cursor-pointer`}
      style={delayMs ? { animationDelay: `${delayMs}ms` } : undefined}
    >
      {/* Top Banner strip */}
      <div
        className={`h-2 shrink-0 ${highlight ? 'bg-gradient-to-r from-primary via-primary/80 to-primary/60' : 'bg-muted-foreground/10'
          }`}
      />

      {/* Recommended badge */}
      {highlight && (
        <div className="absolute top-6 right-6 z-10">
          <Badge className="bg-primary text-primary-foreground flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest px-4 py-1.5 shadow-lg rounded-full animate-pulse">
            <Sparkles className="h-3 w-3 fill-current" />
            Best Value
          </Badge>
        </div>
      )}

      <CardHeader className="text-center pt-10 pb-6 shrink-0 relative overflow-hidden">
        {highlight && <div className="absolute -top-10 -right-10 w-32 h-32 bg-primary/5 rounded-full blur-3xl" />}
        <h3 className={`text-sm font-black uppercase tracking-[0.3em] leading-none mb-3 ${highlight ? 'text-primary' : 'text-muted-foreground'}`}>{label} Tier</h3>
        <CardDescription className="text-xs font-semibold opacity-70 px-4">
          Complete medical protection for your international stay
        </CardDescription>

        <div className="mt-8 space-y-1">
          <div className="flex items-baseline justify-center gap-1">
            <span className="text-xl font-bold text-muted-foreground">$</span>
            <span className="text-6xl font-black text-foreground tracking-tighter">{(Number(totalPrice) || 0).toFixed(0)}</span>
            <span className="text-xl font-bold text-muted-foreground mt-auto pb-2">.{( (Number(totalPrice) % 1).toFixed(2).split('.')[1] || '00' )}</span>
          </div>
          {tax > 0 && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center justify-center gap-1.5 py-1 px-4 bg-primary/5 border border-primary/10 rounded-full w-fit mx-auto cursor-help mt-2">
                    <span className="text-[10px] font-black uppercase tracking-widest text-primary/80">
                      Incl. Tax
                    </span>
                    <Info className="h-3 w-3 text-primary/60" />
                  </div>
                </TooltipTrigger>
                <TooltipContent className="max-w-[200px] text-xs font-medium">
                  This total includes base price (${basePrice}) plus government charges applicable to your selected destinations.
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col pt-4 pb-10 px-8 space-y-8">
        <div className="flex-1 flex flex-col space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-muted/30 border-2 border-transparent hover:border-primary/20 transition-all rounded-2xl p-4 text-center group/stat">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Video className="h-4 w-4 text-primary" />
                <span className="text-[10px] font-black uppercase tracking-wider text-muted-foreground">Telehealth</span>
              </div>
              <p className="text-2xl font-black text-foreground group-hover/stat:scale-110 transition-transform">{visits.telehealth}</p>
            </div>
            <div className="bg-muted/30 border-2 border-transparent hover:border-primary/20 transition-all rounded-2xl p-4 text-center group/stat">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Calendar className="h-4 w-4 text-primary" />
                <span className="text-[10px] font-black uppercase tracking-wider text-muted-foreground">In-Person</span>
              </div>
              <p className="text-2xl font-black text-foreground group-hover/stat:scale-110 transition-transform">{visits.inPerson}</p>
            </div>
          </div>

          <div className="space-y-4 pt-2">
            {[
              { icon: Pill, label: 'Pharmacy Coverage', value: prescription },
              { icon: FileText, label: 'Care Coordination', value: specialty },
              { icon: ShieldCheck, label: 'Digital Pass', value: 'Instant Access' }
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-xl border border-transparent hover:border-primary/10 hover:bg-primary/[0.02] transition-all group/item">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-muted group-hover/item:bg-primary/10 transition-colors">
                    <item.icon className="h-4 w-4 text-muted-foreground group-hover/item:text-primary" />
                  </div>
                  <span className="text-xs font-bold text-muted-foreground">{item.label}</span>
                </div>
                <span className="text-xs font-black text-foreground">{item.value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="pt-6">
          <Button
            className={`w-full py-7 text-sm font-black uppercase tracking-[0.2em] shadow-2xl transition-all duration-300
              ${highlight
                ? 'bg-primary hover:bg-primary/90 text-primary-foreground hover:scale-[1.03] active:scale-[0.98]'
                : 'bg-foreground hover:bg-foreground/90 text-background hover:scale-[1.03] active:scale-[0.98]'
              }`}
          >
            Select Plan <ArrowRight className="ml-2 h-4 w-4 group-hover/card:translate-x-2 transition-transform" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}


