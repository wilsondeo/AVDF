import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import {
  LayoutDashboard,
  CreditCard,
  User,
  Mail,
  Phone,
  MapPin,
  Shield,
  Edit,
  CheckCircle2,
  Users,
  UserPlus,
  Trash2,
  Calendar as CalendarIcon, 
  FileText,
  FileSignature,
  X,
} from 'lucide-react';
import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { userProfileApi, familyMembersApi, type UserProfile, type UpdateProfileRequest, type FamilyMember, paymentApi } from '@/services/api';
import { PLAN_BENEFITS_AVAILABLE } from '@/config/patientPlan';
import { NotificationSettingsCard } from '@/components/settings/NotificationSettingsCard';

const navigation = [
  { name: 'Dashboard', href: '/patient', icon: LayoutDashboard },
  { name: 'My Appointments', href: '/patient/appointments', icon: CalendarIcon },
  { name: 'Prescriptions', href: '/patient/prescriptions', icon: FileText },
  { name: 'Contracts', href: '/patient/contracts', icon: FileSignature },
  { name: 'My Plan', href: '/patient/plans', icon: CreditCard },
];

function formatDateOfBirth(value: string | null | undefined): string {
  if (!value) return '';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' });
}

function toInputDate(value: string | null | undefined): string {
  if (!value) return '';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '';
  return d.toISOString().slice(0, 10);
}

/** Calculate age in years from date of birth (date string or null). */
function ageFromDob(dateOfBirth: string | null | undefined): number | null {
  if (!dateOfBirth) return null;
  const d = new Date(dateOfBirth);
  if (Number.isNaN(d.getTime())) return null;
  const today = new Date();
  let age = today.getFullYear() - d.getFullYear();
  const m = today.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < d.getDate())) age--;
  return age >= 0 ? age : null;
}

const GENDER_OPTIONS = [
  { value: '', label: 'Select…' },
  { value: 'Male', label: 'Male' },
  { value: 'Female', label: 'Female' },
  { value: 'Other', label: 'Other' },
  { value: 'Prefer not to say', label: 'Prefer not to say' },
];

const RELATIONSHIP_OPTIONS = [
  { value: '', label: 'Select…' },
  { value: 'Spouse', label: 'Spouse' },
  { value: 'Child', label: 'Child' },
  { value: 'Parent', label: 'Parent' },
  { value: 'Sibling', label: 'Sibling' },
  { value: 'Other', label: 'Other' },
];

/** Build form state from API profile so we never miss a field. */
function formFromProfile(p: UserProfile | null): UpdateProfileRequest & { email?: string } {
  if (!p) {
    return {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      dateOfBirth: '',
      gender: '',
      streetAddress: '',
      city: '',
      state: '',
      zipCode: '',
      country: 'United States',
      emergencyContactName: '',
      emergencyContactPhone: '',
      emergencyContactRelationship: '',
      bloodType: '',
    };
  }
  return {
    firstName: p.firstName ?? '',
    lastName: p.lastName ?? '',
    email: p.email ?? '',
    phone: p.phone ?? '',
    dateOfBirth: toInputDate(p.dateOfBirth) ?? '',
    gender: p.gender ?? '',
    streetAddress: p.streetAddress ?? '',
    city: p.city ?? '',
    state: p.state ?? '',
    zipCode: p.zipCode ?? '',
    country: p.country ?? 'United States',
    emergencyContactName: p.emergencyContactName ?? '',
    emergencyContactPhone: p.emergencyContactPhone ?? '',
    emergencyContactRelationship: p.emergencyContactRelationship ?? '',
    bloodType: p.bloodType ?? '',
  };
}

export default function PatientProfilePage() {
  const navigate = useNavigate();
  const { currentUser, getPatientAppointments, setUser } = useAppStore();
  const appointments = getPatientAppointments();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const [form, setForm] = useState<UpdateProfileRequest & { email?: string }>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    gender: '',
    streetAddress: '',
    city: '',
    state: '',
    zipCode: '',
    country: 'United States',
    emergencyContactName: '',
    emergencyContactPhone: '',
    emergencyContactRelationship: '',
    bloodType: '',
  });
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([]);
  const [maxFamilySlots, setMaxFamilySlots] = useState(0);
  const [familyLoading, setFamilyLoading] = useState(false);
  const [familyFormOpen, setFamilyFormOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<FamilyMember | null>(null);
  const [familyForm, setFamilyForm] = useState({ firstName: '', lastName: '', dateOfBirth: '', gender: '', relationship: '' });
  const [familyFormErrors, setFamilyFormErrors] = useState<Record<string, string>>({});
  const [currentPlan, setCurrentPlan] = useState<any>(null);

  /** Name: letters, spaces, hyphen only; 2–50 chars; no leading/trailing spaces */
  const validateName = useCallback((value: string): string | null => {
    const trimmed = value.trim();
    if (!trimmed) return 'Please enter a valid name (letters only).';
    if (trimmed.length < 2 || trimmed.length > 50) return 'Please enter a valid name (letters only).';
    if (!/^[a-zA-Z\s\-]+$/.test(trimmed)) return 'Please enter a valid name (letters only).';
    return null;
  }, []);

  /** Phone: 10–15 digits, not all zeros */
  const validatePhone = useCallback((value: string): string | null => {
    if (!value.trim()) return null;
    const digits = value.replace(/\D/g, '');
    if (digits.length < 10 || digits.length > 15) return 'Please enter a valid phone number.';
    if (/^0+$/.test(digits)) return 'Please enter a valid phone number.';
    return null;
  }, []);

  /** ZIP: 6 digits only */
  const validateZipCode = useCallback((value: string): string | null => {
    if (!value.trim()) return null;
    const cleaned = value.trim().replace(/\s/g, '');
    if (!/^\d{6}$/.test(cleaned)) return 'Please enter a valid ZIP code (6 digits).';
    return null;
  }, []);

  /** DOB: valid date, not future, age 13+ */
  const validateDateOfBirth = useCallback((value: string): string | null => {
    if (!value.trim()) return null;
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return 'Please enter a valid date of birth.';
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (d > today) return 'Please enter a valid date of birth.';
    const age = (today.getTime() - d.getTime()) / (365.25 * 24 * 60 * 60 * 1000);
    if (age < 13) return 'You must be 13 years or older.';
    return null;
  }, []);

  /** Address: alphanumeric and , . - # / only; max 150 */
  const validateAddress = useCallback((value: string): string | null => {
    if (!value.trim()) return null;
    const trimmed = value.trim();
    if (trimmed.length > 150) return 'Please enter a valid address (max 150 characters).';
    if (!/^[a-zA-Z0-9\s,.\-#\/]+$/.test(trimmed)) return 'Please enter a valid address.';
    return null;
  }, []);

  /** City / State / Country: letters and spaces (and hyphen) only; 2–100 chars */
  const validatePlace = useCallback((value: string): string | null => {
    if (!value.trim()) return null;
    const trimmed = value.trim();
    if (trimmed.length < 2 || trimmed.length > 100) return 'Please enter a valid value.';
    if (!/^[a-zA-Z\s\-]+$/.test(trimmed)) return 'Please enter a valid value (letters only).';
    return null;
  }, []);

  /** Blood type: only A+, A-, B+, B-, AB+, AB-, O+, O- */
  const validateBloodType = useCallback((value: string): string | null => {
    if (!value.trim()) return null;
    if (!/^(A|B|AB|O)[+-]$/i.test(value.trim())) return 'Please enter a valid blood type (e.g. A+, O-).';
    return null;
  }, []);

  const loadProfile = useCallback(async () => {
    try {
      setLoading(true);
      const res = await userProfileApi.getProfile();
      const p = res.data;
      if (res.success && p) {
        setProfile(p);
        setForm(formFromProfile(p));
      } else if (res.message?.toLowerCase().includes('unauthorized')) {
        toast.error('Session expired. Please sign in again.');
        navigate('/login');
        return;
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to load profile');
    } finally {
      setLoading(false);
    }
  }, [navigate]);

  const loadActivePlan = async () => {
    try {
      const res = await paymentApi.getActiveUserPlan();
      if (res.success && res.data?.activePlan) {
        setCurrentPlan(res.data.activePlan);
      }
    } catch (e) {
      console.error('Failed to load active plan', e);
    }
  };

  useEffect(() => {
    loadProfile();
    loadActivePlan();
  }, [loadProfile]);

  const loadFamilyMembers = useCallback(async () => {
    try {
      setFamilyLoading(true);
      const res = await familyMembersApi.getList();
      if (res.success && res.data) {
        setFamilyMembers(res.data.familyMembers);
        setMaxFamilySlots(res.data.maxSlots);
      }
    } catch {
      setFamilyMembers([]);
      setMaxFamilySlots(0);
    } finally {
      setFamilyLoading(false);
    }
  }, []);

  useEffect(() => {
    if (profile) loadFamilyMembers();
  }, [profile, loadFamilyMembers]);

  const openAddFamilyForm = () => {
    setEditingMember(null);
    setFamilyForm({ firstName: '', lastName: '', dateOfBirth: '', gender: '', relationship: '' });
    setFamilyFormErrors({});
    setFamilyFormOpen(true);
  };
  const openEditFamilyForm = (member: FamilyMember) => {
    setEditingMember(member);
    setFamilyForm({
      firstName: member.firstName,
      lastName: member.lastName,
      dateOfBirth: toInputDate(member.dateOfBirth) ?? '',
      gender: member.gender ?? '',
      relationship: member.relationship ?? '',
    });
    setFamilyFormErrors({});
    setFamilyFormOpen(true);
  };
  const cancelFamilyForm = () => {
    setFamilyFormOpen(false);
    setEditingMember(null);
    setFamilyForm({ firstName: '', lastName: '', dateOfBirth: '', gender: '', relationship: '' });
    setFamilyFormErrors({});
  };
  const validateFamilyForm = (): boolean => {
    const err: Record<string, string> = {};
    const fn = (familyForm.firstName || '').trim();
    const ln = (familyForm.lastName || '').trim();
    if (!fn || fn.length < 2) err.firstName = 'First name is required (at least 2 characters).';
    if (!ln || ln.length < 2) err.lastName = 'Last name is required (at least 2 characters).';
    if (familyForm.dateOfBirth) {
      const dobErr = validateDateOfBirth(familyForm.dateOfBirth);
      if (dobErr) err.dateOfBirth = dobErr;
    }
    setFamilyFormErrors(err);
    return Object.keys(err).length === 0;
  };
  const handleSaveFamilyMember = async () => {
    if (!validateFamilyForm()) {
      toast.error('Please fix the errors before saving.');
      return;
    }

    // If adding a new member, ask for confirmation because it cannot be edited/deleted later
    if (!editingMember) {
      const confirmed = window.confirm(
        `Are you sure you want to add ${familyForm.firstName} ${familyForm.lastName} to your plan? \n\nImportant: Once added, family member details cannot be changed or removed.`
      );
      if (!confirmed) return;
    }

    try {
      if (editingMember) {
        // This part might not be reachable if we disable edit buttons, but keeping for safety
        const res = await familyMembersApi.update(editingMember.id, {
          firstName: familyForm.firstName.trim(),
          lastName: familyForm.lastName.trim(),
          dateOfBirth: familyForm.dateOfBirth || undefined,
          gender: familyForm.gender || undefined,
          relationship: familyForm.relationship || undefined,
        });
        if (res.success) {
          toast.success('Family member updated.');
          cancelFamilyForm();
          loadFamilyMembers();
        } else toast.error(res.message || 'Failed to update');
      } else {
        const res = await familyMembersApi.add({
          firstName: familyForm.firstName.trim(),
          lastName: familyForm.lastName.trim(),
          dateOfBirth: familyForm.dateOfBirth || undefined,
          gender: familyForm.gender || undefined,
          relationship: familyForm.relationship || undefined,
        });
        if (res.success) {
          toast.success('Family member added successfully to your plan.');
          cancelFamilyForm();
          loadFamilyMembers();
        } else toast.error(res.message || 'Failed to add');
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Something went wrong');
    }
  };
  const handleDeleteFamilyMember = async (member: FamilyMember) => {
    if (!window.confirm(`Remove ${member.firstName} ${member.lastName} from family members?`)) return;
    try {
      const res = await familyMembersApi.delete(member.id);
      if (res.success) {
        toast.success('Family member removed.');
        loadFamilyMembers();
      } else toast.error(res.message || 'Failed to remove');
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Something went wrong');
    }
  };

  // Prefill first name, last name, email from store so they are never blank (e.g. before API loads or when API returns 401)
  useEffect(() => {
    if (!currentUser) return;
    const nameParts = (currentUser.name || '').trim().split(/\s+/);
    const first = nameParts[0] || '';
    const last = nameParts.slice(1).join(' ') || '';
    setForm((prev) => ({
      ...prev,
      firstName: prev.firstName || first,
      lastName: prev.lastName || last,
      email: prev.email || currentUser.email || '',
    }));
  }, [currentUser]);

  const getInitials = (firstName: string, lastName: string) => {
    return [firstName, lastName].filter(Boolean).map((n) => n[0]).join('').toUpperCase().slice(0, 2) || 'U';
  };

  const fullName = profile ? `${profile.firstName || ''} ${profile.lastName || ''}`.trim() : (currentUser?.name ?? '');
  const completedAppointments = appointments.filter((a) => a.status === 'completed').length;
  const totalAppointments = appointments.length;

  const handleSave = async () => {
    setFieldErrors({});
    const errors: Record<string, string> = {};

    const fnErr = validateName(form.firstName);
    if (fnErr) errors.firstName = fnErr;
    const lnErr = validateName(form.lastName);
    if (lnErr) errors.lastName = lnErr;
    if (form.phone) {
      const pe = validatePhone(form.phone);
      if (pe) errors.phone = pe;
    }
    if (form.dateOfBirth) {
      const de = validateDateOfBirth(form.dateOfBirth);
      if (de) errors.dateOfBirth = de;
    }
    if (form.streetAddress) {
      const ae = validateAddress(form.streetAddress);
      if (ae) errors.streetAddress = ae;
    }
    if (form.city) {
      const ce = validatePlace(form.city);
      if (ce) errors.city = ce;
    }
    if (form.state) {
      const se = validatePlace(form.state);
      if (se) errors.state = se;
    }
    if (form.country) {
      const coErr = validatePlace(form.country);
      if (coErr) errors.country = coErr;
    }
    if (form.zipCode) {
      const ze = validateZipCode(form.zipCode);
      if (ze) errors.zipCode = ze;
    }
    if (form.emergencyContactRelationship) {
      const rel = validatePlace(form.emergencyContactRelationship);
      if (rel) errors.emergencyContactRelationship = rel;
    }
    if (form.emergencyContactName) {
      const ecn = validateName(form.emergencyContactName);
      if (ecn) errors.emergencyContactName = ecn;
    }
    if (form.emergencyContactPhone) {
      const ecp = validatePhone(form.emergencyContactPhone);
      if (ecp) errors.emergencyContactPhone = ecp;
    }
    if (form.bloodType) {
      const bt = validateBloodType(form.bloodType);
      if (bt) errors.bloodType = bt;
    }

    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      toast.error('Please fix the validation errors before saving.');
      return;
    }

    const payload: UpdateProfileRequest = {
      firstName: form.firstName.trim(),
      lastName: form.lastName.trim(),
      phone: form.phone?.trim() || undefined,
      dateOfBirth: form.dateOfBirth || undefined,
      gender: form.gender?.trim() || undefined,
      streetAddress: form.streetAddress?.trim() || undefined,
      city: form.city?.trim() || undefined,
      state: form.state?.trim() || undefined,
      zipCode: form.zipCode?.trim() || undefined,
      country: form.country?.trim() || undefined,
      emergencyContactName: form.emergencyContactName?.trim() || undefined,
      emergencyContactPhone: form.emergencyContactPhone?.trim() || undefined,
      emergencyContactRelationship: form.emergencyContactRelationship?.trim() || undefined,
      bloodType: form.bloodType?.trim() || undefined,
    };
    try {
      setSaving(true);
      const res = await userProfileApi.updateProfile(payload);
      const data = res.data;
      if (res.success && data) {
        setProfile(data);
        setForm(formFromProfile(data));
        setUser({
          ...currentUser!,
          name: `${data.firstName || ''} ${data.lastName || ''}`.trim(),
          email: data.email,
          phone: data.phone ?? undefined,
          city: data.city ?? undefined,
        });
        setIsEditing(false);
        toast.success('Profile updated successfully!');
      } else {
        if (res.message?.toLowerCase().includes('unauthorized')) {
          toast.error('Session expired. Please sign in again.');
          navigate('/login');
          return;
        }
        toast.error(res.message || 'Failed to update profile');
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  if (loading && !profile) {
    return (
      <DashboardLayout navigation={navigation} title="My Profile">
        <div className="flex items-center justify-center min-h-[200px]">Loading profile...</div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout navigation={navigation} title="My Profile">
      <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
        <Card className="shadow-card border-0 overflow-hidden">
          <div className="h-32 gradient-primary" />
          <CardContent className="relative pb-6">
            <div className="absolute -top-16 left-6">
              <div className="relative">
                <Avatar className="h-32 w-32 border-4 border-background shadow-lg">
                  <AvatarImage src={currentUser?.avatar} />
                  <AvatarFallback className="text-3xl bg-accent text-accent-foreground">
                    {getInitials(form.firstName, form.lastName)}
                  </AvatarFallback>
                </Avatar>
                {/* <button type="button" className="absolute bottom-2 right-2 h-8 w-8 rounded-full bg-accent text-accent-foreground flex items-center justify-center shadow-md hover:bg-accent/90 transition-colors">
                  <Camera className="h-4 w-4" />
                </button> */}
              </div>
            </div>
            <div className="flex justify-end pt-2">
              <Button
                variant={isEditing ? 'accent' : 'outline'}
                size="sm"
                disabled={saving}
                onClick={() => (isEditing ? handleSave() : setIsEditing(true))}
              >
                {isEditing ? (
                  <>
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    {saving ? 'Saving…' : 'Save Changes'}
                  </>
                ) : (
                  <>
                    <Edit className="h-4 w-4 mr-2" />
                    Edit Profile
                  </>
                )}
              </Button>
            </div>
            <div className="mt-8">
              <h1 className="text-2xl font-bold">{fullName || 'Patient'}</h1>
              <p className="text-muted-foreground flex items-center gap-2 mt-1">
                <Mail className="h-4 w-4" />
                {profile?.email ?? currentUser?.email ?? '—'}
              </p>
              {currentPlan && (
                <div className="flex flex-wrap gap-2 mt-4">
                  <Badge variant="success" className="flex items-center gap-1">
                    <Shield className="h-3 w-3" />
                    {currentPlan.plan.name}
                  </Badge>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-6">
          <Card className="shadow-card border-0">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <User className="h-5 w-5 text-accent" />
                Personal Information
              </CardTitle>
              <p className="text-sm text-muted-foreground">Data you provided at registration. You can edit and save anytime.</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    id="firstName"
                    placeholder="First"
                    value={form.firstName}
                    onChange={(e) => {
                      const v = e.target.value.replace(/[^a-zA-Z\s\-]/g, '');
                      setForm((f) => ({ ...f, firstName: v }));
                      if (fieldErrors.firstName) setFieldErrors((p) => ({ ...p, firstName: '' }));
                    }}
                    disabled={!isEditing}
                    maxLength={50}
                    className={!isEditing ? 'bg-muted' : fieldErrors.firstName ? 'border-destructive' : ''}
                  />
                  <Input
                    id="lastName"
                    placeholder="Last"
                    value={form.lastName}
                    onChange={(e) => {
                      const v = e.target.value.replace(/[^a-zA-Z\s\-]/g, '');
                      setForm((f) => ({ ...f, lastName: v }));
                      if (fieldErrors.lastName) setFieldErrors((p) => ({ ...p, lastName: '' }));
                    }}
                    disabled={!isEditing}
                    maxLength={50}
                    className={!isEditing ? 'bg-muted' : fieldErrors.lastName ? 'border-destructive' : ''}
                  />
                </div>
                {(fieldErrors.firstName || fieldErrors.lastName) && (
                  <p className="text-xs text-destructive">{fieldErrors.firstName || fieldErrors.lastName}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input id="email" type="email" value={form.email ?? ''} disabled className="bg-muted" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  value={form.phone ?? ''}
                  onChange={(e) => {
                    setForm((f) => ({ ...f, phone: e.target.value }));
                    if (fieldErrors.phone) setFieldErrors((p) => ({ ...p, phone: '' }));
                  }}
                  disabled={!isEditing}
                  className={!isEditing ? 'bg-muted' : fieldErrors.phone ? 'border-destructive' : ''}
                  placeholder="e.g. +1 555-0000"
                />
                {fieldErrors.phone && <p className="text-xs text-destructive">{fieldErrors.phone}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="dob">Date of Birth</Label>
                <Input
                  id="dob"
                  type="date"
                  max={new Date().toISOString().slice(0, 10)}
                  value={form.dateOfBirth ?? ''}
                  onChange={(e) => {
                    setForm((f) => ({ ...f, dateOfBirth: e.target.value }));
                    if (fieldErrors.dateOfBirth) setFieldErrors((p) => ({ ...p, dateOfBirth: '' }));
                  }}
                  disabled={!isEditing}
                  className={!isEditing ? 'bg-muted' : fieldErrors.dateOfBirth ? 'border-destructive' : ''}
                />
                {fieldErrors.dateOfBirth && <p className="text-xs text-destructive">{fieldErrors.dateOfBirth}</p>}
                {!isEditing && form.dateOfBirth && (
                  <p className="text-sm text-muted-foreground">
                    {formatDateOfBirth(form.dateOfBirth)}
                    {ageFromDob(form.dateOfBirth) != null && (
                      <span className="ml-2 font-medium">Age: {ageFromDob(form.dateOfBirth)} years</span>
                    )}
                  </p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="gender">Gender</Label>
                <select
                  id="gender"
                  value={form.gender ?? ''}
                  onChange={(e) => setForm((f) => ({ ...f, gender: e.target.value }))}
                  disabled={!isEditing}
                  className={`flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 ${!isEditing ? 'bg-muted' : ''}`}
                >
                  {GENDER_OPTIONS.map((opt) => (
                    <option key={opt.value || 'empty'} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-card border-0">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <MapPin className="h-5 w-5 text-accent" />
                Address Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="address">Street Address</Label>
                <Input
                  id="address"
                  value={form.streetAddress ?? ''}
                  onChange={(e) => {
                    const v = e.target.value;
                    if (v.length <= 150) setForm((f) => ({ ...f, streetAddress: v }));
                    if (fieldErrors.streetAddress) setFieldErrors((p) => ({ ...p, streetAddress: '' }));
                  }}
                  disabled={!isEditing}
                  maxLength={150}
                  className={!isEditing ? 'bg-muted' : fieldErrors.streetAddress ? 'border-destructive' : ''}
                  placeholder="Street address"
                />
                {fieldErrors.streetAddress && <p className="text-xs text-destructive">{fieldErrors.streetAddress}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="city">City</Label>
                <Input
                  id="city"
                  value={form.city ?? ''}
                  onChange={(e) => {
                    const v = e.target.value.replace(/[^a-zA-Z\s\-]/g, '');
                    if (v.length <= 100) setForm((f) => ({ ...f, city: v }));
                    if (fieldErrors.city) setFieldErrors((p) => ({ ...p, city: '' }));
                  }}
                  disabled={!isEditing}
                  maxLength={100}
                  className={!isEditing ? 'bg-muted' : fieldErrors.city ? 'border-destructive' : ''}
                />
                {fieldErrors.city && <p className="text-xs text-destructive">{fieldErrors.city}</p>}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="state">State</Label>
                  <Input
                    id="state"
                    value={form.state ?? ''}
                    onChange={(e) => {
                      const v = e.target.value.replace(/[^a-zA-Z\s\-]/g, '');
                      if (v.length <= 100) setForm((f) => ({ ...f, state: v }));
                      if (fieldErrors.state) setFieldErrors((p) => ({ ...p, state: '' }));
                    }}
                    disabled={!isEditing}
                    maxLength={100}
                    className={!isEditing ? 'bg-muted' : fieldErrors.state ? 'border-destructive' : ''}
                  />
                  {fieldErrors.state && <p className="text-xs text-destructive">{fieldErrors.state}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="zip">ZIP Code</Label>
                  <Input
                    id="zip"
                    value={form.zipCode ?? ''}
                    onChange={(e) => {
                      const v = e.target.value.replace(/\D/g, '').slice(0, 6);
                      setForm((f) => ({ ...f, zipCode: v }));
                      if (fieldErrors.zipCode) setFieldErrors((p) => ({ ...p, zipCode: '' }));
                    }}
                    disabled={!isEditing}
                    maxLength={6}
                    inputMode="numeric"
                    className={!isEditing ? 'bg-muted' : fieldErrors.zipCode ? 'border-destructive' : ''}
                  />
                  {fieldErrors.zipCode && <p className="text-xs text-destructive">{fieldErrors.zipCode}</p>}
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="country">Country</Label>
                <Input
                  id="country"
                  value={form.country ?? ''}
                  onChange={(e) => {
                    const v = e.target.value.replace(/[^a-zA-Z\s\-]/g, '');
                    if (v.length <= 100) setForm((f) => ({ ...f, country: v }));
                    if (fieldErrors.country) setFieldErrors((p) => ({ ...p, country: '' }));
                  }}
                  disabled={!isEditing}
                  maxLength={100}
                  className={!isEditing ? 'bg-muted' : fieldErrors.country ? 'border-destructive' : ''}
                />
                {fieldErrors.country && <p className="text-xs text-destructive">{fieldErrors.country}</p>}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="shadow-card border-0">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Users className="h-5 w-5 text-accent" />
              Family Members
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              {maxFamilySlots === 0
                ? 'Your plan covers only you. Upgrade to a family plan to add family members.'
                : `You can add up to ${maxFamilySlots} family member(s) on your current plan.`}
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            {familyLoading ? (
              <p className="text-sm text-muted-foreground">Loading family members…</p>
            ) : maxFamilySlots > 0 ? (
              <>
                <div className="space-y-3">
                  {familyMembers.map((member) => (
                    <div
                      key={member.id}
                      className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border bg-muted/30 p-3"
                    >
                      <div className="min-w-0">
                        <p className="font-medium">
                          {member.firstName} {member.lastName}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {member.relationship && <span>{member.relationship}</span>}
                          {member.relationship && member.gender && ' · '}
                          {member.gender && <span>{member.gender}</span>}
                          {(member.relationship || member.gender) && member.dateOfBirth && ' · '}
                          {member.dateOfBirth && (
                            <>
                              {formatDateOfBirth(member.dateOfBirth)}
                              {ageFromDob(member.dateOfBirth) != null && (
                                <span className="ml-1 font-medium">({ageFromDob(member.dateOfBirth)} years)</span>
                              )}
                            </>
                          )}
                        </p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {/* Edit and Remove buttons are hidden after a member is added to the plan */}
                        <Badge variant="outline" className="text-[10px] font-normal text-muted-foreground uppercase tracking-wider">
                          Added to plan
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
                {!familyFormOpen && familyMembers.length < maxFamilySlots && (
                  <Button type="button" variant="outline" onClick={openAddFamilyForm}>
                    <UserPlus className="h-4 w-4 mr-2" />
                    Add family member
                  </Button>
                )}
                {familyFormOpen && (
                  <div className="rounded-lg border border-border bg-muted/20 p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">{editingMember ? 'Edit family member' : 'Add family member'}</h4>
                      <Button type="button" variant="ghost" size="sm" onClick={cancelFamilyForm}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-2">
                        <Label>First name</Label>
                        <Input
                          value={familyForm.firstName}
                          onChange={(e) => setFamilyForm((f) => ({ ...f, firstName: e.target.value }))}
                          placeholder="First name"
                          className={familyFormErrors.firstName ? 'border-destructive' : ''}
                        />
                        {familyFormErrors.firstName && <p className="text-xs text-destructive">{familyFormErrors.firstName}</p>}
                      </div>
                      <div className="space-y-2">
                        <Label>Last name</Label>
                        <Input
                          value={familyForm.lastName}
                          onChange={(e) => setFamilyForm((f) => ({ ...f, lastName: e.target.value }))}
                          placeholder="Last name"
                          className={familyFormErrors.lastName ? 'border-destructive' : ''}
                        />
                        {familyFormErrors.lastName && <p className="text-xs text-destructive">{familyFormErrors.lastName}</p>}
                      </div>
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-2">
                        <Label>Date of birth</Label>
                        <Input
                          type="date"
                          max={new Date().toISOString().slice(0, 10)}
                          value={familyForm.dateOfBirth}
                          onChange={(e) => setFamilyForm((f) => ({ ...f, dateOfBirth: e.target.value }))}
                          className={familyFormErrors.dateOfBirth ? 'border-destructive' : ''}
                        />
                        {familyFormErrors.dateOfBirth && <p className="text-xs text-destructive">{familyFormErrors.dateOfBirth}</p>}
                        {familyForm.dateOfBirth && ageFromDob(familyForm.dateOfBirth) != null && (
                          <p className="text-xs text-muted-foreground">Age: {ageFromDob(familyForm.dateOfBirth)} years</p>
                        )}
                      </div>
                      <div className="space-y-2">
                        <Label>Gender</Label>
                        <select
                          value={familyForm.gender}
                          onChange={(e) => setFamilyForm((f) => ({ ...f, gender: e.target.value }))}
                          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                        >
                          {GENDER_OPTIONS.map((opt) => (
                            <option key={opt.value || 'empty'} value={opt.value}>{opt.label}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Relationship</Label>
                      <select
                        value={familyForm.relationship}
                        onChange={(e) => setFamilyForm((f) => ({ ...f, relationship: e.target.value }))}
                        className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                      >
                        {RELATIONSHIP_OPTIONS.map((opt) => (
                          <option key={opt.value || 'empty'} value={opt.value}>{opt.label}</option>
                        ))}
                      </select>
                    </div>
                    <div className="flex gap-2">
                      <Button onClick={handleSaveFamilyMember}>
                        <CheckCircle2 className="h-4 w-4 mr-2" />
                        {editingMember ? 'Save changes' : 'Add member'}
                      </Button>
                      <Button variant="outline" onClick={cancelFamilyForm}>Cancel</Button>
                    </div>
                  </div>
                )}
              </>
            ) : null}
          </CardContent>
        </Card>

        <NotificationSettingsCard />

        {/* <Card className="shadow-card border-0">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Shield className="h-5 w-5 text-accent" />
              Health Summary
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="text-center p-4 rounded-xl bg-accent/10">
                <p className="text-3xl font-bold text-accent">{totalAppointments}</p>
                <p className="text-sm text-muted-foreground">Total Visits</p>
              </div>
              <div className="text-center p-4 rounded-xl bg-success/10">
                <p className="text-3xl font-bold text-success">{completedAppointments}</p>
                <p className="text-sm text-muted-foreground">Completed</p>
              </div>
              <div className="text-center p-4 rounded-xl bg-primary/10">
                <p className="text-3xl font-bold text-primary">
                  {appointments.filter((a) => (a as { prescription?: unknown }).prescription).length}
                </p>
                <p className="text-sm text-muted-foreground">Prescriptions</p>
              </div>
              <div className="text-center p-4 rounded-xl bg-primary/10">
                <p className="text-sm font-bold text-primary">{PLAN_BENEFITS_AVAILABLE.fromLabel} – {PLAN_BENEFITS_AVAILABLE.toLabel}</p>
                <p className="text-xs text-muted-foreground">Plan period</p>
              </div>
            </div>
          </CardContent>
        </Card> */}

        <Card className="shadow-card border-0">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Phone className="h-5 w-5 text-destructive" />
              Emergency Contact
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="emergency-name">Contact Name</Label>
                <Input
                  id="emergency-name"
                  value={form.emergencyContactName ?? ''}
                  onChange={(e) => {
                    const v = e.target.value.replace(/[^a-zA-Z\s\-]/g, '');
                    if (v.length <= 50) setForm((f) => ({ ...f, emergencyContactName: v }));
                    if (fieldErrors.emergencyContactName) setFieldErrors((p) => ({ ...p, emergencyContactName: '' }));
                  }}
                  disabled={!isEditing}
                  maxLength={50}
                  className={!isEditing ? 'bg-muted' : fieldErrors.emergencyContactName ? 'border-destructive' : ''}
                  placeholder="Contact name"
                />
                {fieldErrors.emergencyContactName && <p className="text-xs text-destructive">{fieldErrors.emergencyContactName}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="emergency-phone">Contact Phone</Label>
                <Input
                  id="emergency-phone"
                  value={form.emergencyContactPhone ?? ''}
                  onChange={(e) => {
                    setForm((f) => ({ ...f, emergencyContactPhone: e.target.value }));
                    if (fieldErrors.emergencyContactPhone) setFieldErrors((p) => ({ ...p, emergencyContactPhone: '' }));
                  }}
                  disabled={!isEditing}
                  className={!isEditing ? 'bg-muted' : fieldErrors.emergencyContactPhone ? 'border-destructive' : ''}
                  placeholder="e.g. +1 555-9999"
                />
                {fieldErrors.emergencyContactPhone && <p className="text-xs text-destructive">{fieldErrors.emergencyContactPhone}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="emergency-relation">Relationship</Label>
                <Input
                  id="emergency-relation"
                  value={form.emergencyContactRelationship ?? ''}
                  onChange={(e) => {
                    const v = e.target.value.replace(/[^a-zA-Z\s\-]/g, '');
                    if (v.length <= 50) setForm((f) => ({ ...f, emergencyContactRelationship: v }));
                    if (fieldErrors.emergencyContactRelationship) setFieldErrors((p) => ({ ...p, emergencyContactRelationship: '' }));
                  }}
                  disabled={!isEditing}
                  maxLength={50}
                  className={!isEditing ? 'bg-muted' : fieldErrors.emergencyContactRelationship ? 'border-destructive' : ''}
                  placeholder="e.g. Spouse"
                />
                {fieldErrors.emergencyContactRelationship && <p className="text-xs text-destructive">{fieldErrors.emergencyContactRelationship}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="blood-type">Blood Type</Label>
                <Input
                  id="blood-type"
                  value={form.bloodType ?? ''}
                  onChange={(e) => {
                    const v = e.target.value.toUpperCase().replace(/[^ABO+-]/g, '').slice(0, 4);
                    setForm((f) => ({ ...f, bloodType: v }));
                    if (fieldErrors.bloodType) setFieldErrors((p) => ({ ...p, bloodType: '' }));
                  }}
                  disabled={!isEditing}
                  maxLength={4}
                  className={!isEditing ? 'bg-muted' : fieldErrors.bloodType ? 'border-destructive' : ''}
                  placeholder="e.g. O+"
                />
                {fieldErrors.bloodType && <p className="text-xs text-destructive">{fieldErrors.bloodType}</p>}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
