import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Download, FileSignature, LayoutDashboard, Calendar, FileText, CreditCard } from 'lucide-react';
import navalaLogo from '@/assets/navala.png';
import { paymentApi } from '@/services/api';

export default function PatientContractsPage() {
  const { currentUser } = useAppStore();
  const [currentDate, setCurrentDate] = useState('');
  const [activePlan, setActivePlan] = useState<any>(null);

  // Local navigation config so we don't have to update it globally if we missed files
  const navigation = [
    { name: 'Dashboard', href: '/patient', icon: LayoutDashboard },
    { name: 'My Appointments', href: '/patient/appointments', icon: Calendar },
    { name: 'Prescriptions', href: '/patient/prescriptions', icon: FileText },
    { name: 'Contracts', href: '/patient/contracts', icon: FileSignature },
    { name: 'My Plan', href: '/patient/plans', icon: CreditCard },
  ];

  useEffect(() => {
    // Format the current date nicely for the contract timestamp
    const now = new Date();
    const formatted = new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(now);
    setCurrentDate(formatted);

    const loadPlan = async () => {
      const res = await paymentApi.getActiveUserPlan();
      if (res.success && res.data?.activePlan) {
        setActivePlan(res.data.activePlan.plan);
      }
    };
    loadPlan();
  }, []);

  const handleDownloadPDF = () => {
    // We use the native browser print dialog, which offers "Save as PDF" reliably.
    window.print();
  };

  return (
    <DashboardLayout navigation={navigation} title="My Contracts">
      
      {/* 
        Tailwind 'print:' modifiers are used extensively here. 
        When 'Download PDF' is clicked, the browser print dialog will ONLY render
        the content within the 'print:block' sections, ensuring a clean A4 PDF export.
      */}

      {/* Screen-only UI: Header & Action Button */}
      <div className="space-y-6 animate-fade-in print:hidden">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between mb-8">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground flex items-center gap-2">
              <FileSignature className="h-6 w-6 text-primary" />
              Service Contract
            </h1>
            <p className="text-muted-foreground mt-1">
              View and download your official Navala Travel Health agreement.
            </p>
          </div>
          
          <Button 
            onClick={handleDownloadPDF} 
            className="bg-primary text-primary-foreground font-bold rounded-lg shadow-sm w-full sm:w-auto"
          >
            <Download className="mr-2 h-4 w-4" />
            Download PDF
          </Button>
        </div>

        {/* Informational Banner */}
        <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 flex gap-3 text-sm text-amber-800">
          <FileSignature className="h-5 w-5 shrink-0 text-amber-600 mt-0.5" />
          <p>
            <strong>Official Document:</strong> The pages below represent your legally binding agreement with Navala Travel Health. 
            Click the "Download PDF" button above to save a copy for your records.
          </p>
        </div>
      </div>

      {/* 
        Contract Document Area 
        This is styled to look like 2 physical A4 paper pages on screen, and properly paginates when printing to PDF.
      */}
      <div className="mt-8 space-y-8 flex flex-col items-center">
        
        {/* ================= PAGE 1 ================= */}
        <div className="bg-white text-slate-900 w-full max-w-[800px] min-h-[1056px] p-10 sm:p-14 md:p-20 shadow-xl border rounded flex flex-col relative print:shadow-none print:border-none print:p-0 print:m-0 print:w-full print:max-w-none print:min-h-0 print:break-after-page">
          
          {/* Header */}
          <div className="flex items-start justify-between border-b-2 border-slate-900 pb-6 mb-8 mt-4">
            <img src={navalaLogo} alt="Navala Travel Health" className="h-14 w-auto print:h-12" />
            <div className="text-right">
              <h2 className="font-bold text-lg uppercase tracking-wider text-slate-800">Medical Services Contract</h2>
              <p className="text-sm text-slate-600">Document Ref: NTH-{Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}</p>
            </div>
          </div>

          <div className="flex-1 space-y-6 text-sm">
            <div className="space-y-1">
              <p className="text-slate-500 uppercase text-xs font-bold tracking-widest">Patient Information</p>
              <div className="bg-slate-50 p-4 rounded-md border border-slate-100 flex justify-between">
                <div>
                  <span className="block text-xs text-slate-500">Name</span>
                  <span className="font-bold text-lg text-slate-800">{currentUser?.name || 'Patient Name'}</span>
                </div>
                <div className="text-right">
                  <span className="block text-xs text-slate-500">Email Address</span>
                  <span className="font-medium text-slate-800">{currentUser?.email || 'patient@example.com'}</span>
                </div>
              </div>
              {/* Show Plan Name if Available */}
              <div className="bg-slate-50 p-4 rounded-md border border-slate-100 flex justify-between mt-2">
                <div>
                  <span className="block text-xs text-slate-500">Active Healthcare Plan</span>
                  <span className="font-bold text-lg text-slate-800">{activePlan ? activePlan.name : 'N/A'}</span>
                </div>
                <div className="text-right">
                  <span className="block text-xs text-slate-500">Coverage Type</span>
                  <span className="font-medium text-slate-800">{activePlan && activePlan.maxPersons > 1 ? 'Family' : 'Individual'}</span>
                </div>
              </div>
            </div>

            <div className="space-y-1 mt-6">
              <p className="text-slate-500 uppercase text-xs font-bold tracking-widest">Coverage Period</p>
              <div className="bg-primary/5 p-4 rounded-md border border-primary/20">
                <p className="font-semibold text-primary">Valid strictly between: <span className="font-black text-lg ml-2">9 Jun to 20 July</span></p>
              </div>
            </div>

            <div className="space-y-4 pt-6 text-justify">
              <h3 className="font-bold text-base text-slate-800">1. Nature of the Agreement</h3>
              <p>This Medical Services Contract ("Agreement") is entered into between Navala Travel Health ("Provider") and the aforementioned individual ("Patient"). This Agreement establishes the terms under which the Provider will deliver healthcare services, including telehealth and facilitated in-person care, during the specified Coverage Period associated with the World Cup 2026 travel timeline.</p>
              
              <h3 className="font-bold text-base text-slate-800">2. Scope of Services</h3>
              <p>During the Coverage Period <strong>(9 Jun to 20 July)</strong>, the Patient is entitled to access the Provider's global network of healthcare professionals. Services include but are not limited to 24/7 on-demand telehealth consultations, emergency medical coordination, and prescription management as permitted by local jurisdiction.</p>
              
              <h3 className="font-bold text-base text-slate-800">3. Acknowledgment of Limitations</h3>
              <p>The Patient acknowledges that Navala Travel Health is a facilitator and direct provider of telehealth care, but relies on third-party local healthcare facilities for emergency and intensive physical care. The Provider strives to guarantee preferential access but is not liable for systemic delays at third-party local facilities.</p>
            </div>
          </div>

          {/* Footer - Page 1 */}
          <div className="mt-16 pt-6 border-t border-slate-200 flex justify-between text-xs text-slate-500">
            <span>Page 1 of 2</span>
            <span>Generated on: {currentDate}</span>
          </div>
        </div>

        {/* ================= PAGE 2 ================= */}
        <div className="bg-white text-slate-900 w-full max-w-[800px] min-h-[1056px] p-10 sm:p-14 md:p-20 shadow-xl border rounded flex flex-col relative print:shadow-none print:border-none print:p-0 print:m-0 print:w-full print:max-w-none print:min-h-0 print:block">
          
          <div className="flex-1 space-y-6 text-sm">
            <h2 className="font-bold text-xl uppercase tracking-wider text-slate-800 pb-4 border-b-2 border-slate-900 mb-8 mt-4">Terms of Coverage & Agreement</h2>

            <div className="space-y-4 text-justify">
              <h3 className="font-bold text-base text-slate-800">4. Privacy and Data Sharing</h3>
              <p>The Patient consents to the collection, processing, and sharing of their medical and personal data by Navala Travel Health with partnered local practitioners, hospitals, and pharmacies solely for the purpose of administering necessary medical care. All data will be handled in compliance with HIPAA guidelines to ensure maximum patient confidentiality.</p>

              <h3 className="font-bold text-base text-slate-800">5. Exclusions and Out-of-Pocket Expenses</h3>
              <p>While the plan covers coordination and associated telehealth professional fees, the Patient accepts that certain localized treatments, specialized surgeries, and physical pharmacy prescriptions may incur additional out-of-pocket expenses governed by the local medical facility, which fall outside the scope of the pre-paid Navala coverage strictly bounded by the dates <strong>9 Jun to 20 July</strong>.</p>
              
              <h3 className="font-bold text-base text-slate-800">6. Termination and Liability</h3>
              <p>This agreement automatically terminates at the end of the Coverage Period. The Provider reserves the right to terminate this agreement immediately in the event of fraudulent representation by the Patient. The Provider's total liability under this contract shall not exceed the total fees paid by the Patient for the plan.</p>
            </div>

            {/* Signatures */}
            <div className="pt-24 flex justify-between items-end">
              <div className="w-64">
                <div className="border-b border-slate-400 pb-1 mb-2">
                  <span className="font-script text-2xl text-slate-700 italic">Navala Medical Board</span>
                </div>
                <p className="text-xs text-slate-500 font-bold">Authorized Signatory</p>
                <p className="text-xs text-slate-500">Navala Travel Health</p>
              </div>

              <div className="w-64">
                <div className="border-b border-slate-400 pb-1 mb-2 h-8 flex items-end">
                  <span className="font-handwriting text-xl text-slate-800 font-medium">Electronically Accepted</span>
                </div>
                <p className="text-xs text-slate-500 font-bold">{currentUser?.name}</p>
                <p className="text-xs text-slate-500">Patient / Beneficiary</p>
              </div>
            </div>
          </div>

          {/* Footer - Page 2 */}
          <div className="mt-16 pt-6 border-t border-slate-200 flex justify-between text-xs text-slate-500">
            <span>Page 2 of 2</span>
            <span>Generated on: {currentDate}</span>
          </div>
        </div>

      </div>
    </DashboardLayout>
  );
}
