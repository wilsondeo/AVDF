import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  LayoutDashboard, 
  Calendar, 
  FileText, 
  CreditCard,
  Video,
  VideoOff,
  Mic,
  MicOff,
  Phone,
  User,
  Clock,
  MessageSquare
} from 'lucide-react';

const navigation = [
  { name: 'Dashboard', href: '/patient', icon: LayoutDashboard },
  { name: 'My Appointments', href: '/patient/appointments', icon: Calendar },
  { name: 'Prescriptions', href: '/patient/prescriptions', icon: FileText },
  { name: 'My Plan', href: '/patient/plans', icon: CreditCard },
];

export default function VideoCallPage() {
  const { appointmentId } = useParams();
  const navigate = useNavigate();
  const { appointments, users } = useAppStore();
  
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [isMicOn, setIsMicOn] = useState(true);
  const [callTime, setCallTime] = useState(0);

  const appointment = appointments.find(a => a.id === appointmentId);
  const doctor = appointment?.doctorId ? users.find(u => u.id === appointment.doctorId) : null;

  useEffect(() => {
    const timer = setInterval(() => {
      setCallTime(prev => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  if (!appointment || !doctor) {
    return (
      <DashboardLayout navigation={navigation} title="Video Call">
        <div className="text-center py-12">
          <p>Appointment not found or video call not available</p>
          <Button onClick={() => navigate('/patient')} className="mt-4">
            Back to Dashboard
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout navigation={navigation} title="Video Consultation">
      <div className="max-w-5xl mx-auto animate-fade-in">
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Main Video Area */}
          <div className="lg:col-span-3 space-y-4">
            {/* Video Container */}
            <Card className="shadow-card border-0 overflow-hidden">
              <div className="relative bg-sidebar aspect-video flex items-center justify-center">
                {/* Doctor Video (Main) */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center text-sidebar-foreground">
                    <div className="h-24 w-24 rounded-full bg-sidebar-accent flex items-center justify-center mx-auto mb-4">
                      <User className="h-12 w-12" />
                    </div>
                    <p className="text-lg font-medium">{doctor.name}</p>
                    <p className="text-sm opacity-70">{doctor.specialization}</p>
                  </div>
                </div>

                {/* Self Video (Picture-in-Picture) */}
                <div className="absolute bottom-4 right-4 w-32 h-24 md:w-48 md:h-36 bg-primary/80 rounded-lg border-2 border-primary-foreground/20 flex items-center justify-center">
                  {isVideoOn ? (
                    <div className="text-primary-foreground text-center">
                      <User className="h-8 w-8 mx-auto mb-1" />
                      <p className="text-xs">You</p>
                    </div>
                  ) : (
                    <VideoOff className="h-8 w-8 text-primary-foreground" />
                  )}
                </div>

                {/* Call Status */}
                <div className="absolute top-4 left-4 flex items-center gap-2">
                  <Badge variant="success" className="animate-pulse">
                    <span className="h-2 w-2 rounded-full bg-success-foreground mr-2" />
                    Live
                  </Badge>
                  <Badge variant="secondary" className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {formatTime(callTime)}
                  </Badge>
                </div>
              </div>

              {/* Controls */}
              <CardContent className="py-4">
                <div className="flex items-center justify-center gap-4">
                  <Button
                    variant={isMicOn ? 'outline' : 'destructive'}
                    size="icon"
                    className="h-12 w-12 rounded-full"
                    onClick={() => setIsMicOn(!isMicOn)}
                  >
                    {isMicOn ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
                  </Button>
                  
                  <Button
                    variant={isVideoOn ? 'outline' : 'destructive'}
                    size="icon"
                    className="h-12 w-12 rounded-full"
                    onClick={() => setIsVideoOn(!isVideoOn)}
                  >
                    {isVideoOn ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
                  </Button>

                  <Button
                    variant="destructive"
                    size="icon"
                    className="h-14 w-14 rounded-full"
                    onClick={() => navigate('/patient/appointments')}
                  >
                    <Phone className="h-6 w-6 rotate-[135deg]" />
                  </Button>

                  <Button
                    variant="outline"
                    size="icon"
                    className="h-12 w-12 rounded-full"
                  >
                    <MessageSquare className="h-5 w-5" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar - Patient Info */}
          <div className="space-y-4">
            <Card className="shadow-card border-0">
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3">Consultation Details</h3>
                <dl className="space-y-3 text-sm">
                  <div>
                    <dt className="text-muted-foreground">Doctor</dt>
                    <dd className="font-medium">{doctor.name}</dd>
                  </div>
                  <div>
                    <dt className="text-muted-foreground">Specialization</dt>
                    <dd>{doctor.specialization}</dd>
                  </div>
                  <div>
                    <dt className="text-muted-foreground">City</dt>
                    <dd>{appointment.city}</dd>
                  </div>
                </dl>
              </CardContent>
            </Card>

            <Card className="shadow-card border-0">
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3">Tips</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Ensure good lighting</li>
                  <li>• Use headphones for better audio</li>
                  <li>• Have your symptoms ready to describe</li>
                  <li>• Keep any medications handy</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
