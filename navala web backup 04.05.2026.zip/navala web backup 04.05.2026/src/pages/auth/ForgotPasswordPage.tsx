import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Mail, KeyRound, ArrowLeft, Shield, Globe, Sparkles } from 'lucide-react';
import { authApi } from '@/services/api';
import { toast } from 'sonner';
import navalaLogo from '@/assets/navala.png';
import loginBg from '@/assets/loginbg.jpg';

type Step = 'email' | 'reset';

export default function ForgotPasswordPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>('email');
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email.trim()) {
      setError('Please enter your email');
      return;
    }
    setLoading(true);
    try {
      const res = await authApi.forgotPassword(email.trim());
      if (res.success) {
        toast.success('OTP sent to your email. Check your inbox.');
        setStep('reset');
      } else {
        setError(res.message || 'Failed to send OTP');
        toast.error(res.message);
      }
    } catch (err) {
      setError('Something went wrong. Please try again.');
      toast.error('Failed to send OTP');
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!otp.trim()) {
      setError('Please enter the OTP');
      return;
    }
    if (newPassword.length < 8) {
      setError('Password must be at least 8 characters');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('New password and confirm password do not match');
      return;
    }
    setLoading(true);
    try {
      const res = await authApi.resetPassword({
        email: email.trim(),
        otp: otp.trim(),
        newPassword,
        confirmPassword,
      });
      if (res.success) {
        toast.success('Password reset successfully. You can now log in.');
        navigate('/login');
      } else {
        setError(res.message || 'Failed to reset password');
        toast.error(res.message);
      }
    } catch (err) {
      setError('Something went wrong. Please try again.');
      toast.error('Failed to reset password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-background">
      {/* Left Column - Branding (Desktop Only) */}
      <div className="hidden lg:flex w-1/2 bg-slate-900 border-r relative flex-col justify-between overflow-hidden">
        {/* Background Image */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-40"
          style={{ backgroundImage: `url(${loginBg})` }} 
        />
        {/* Dark Gradient Overlay for text readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-slate-900/60 via-slate-900/80 to-slate-900" />
        <div className="absolute inset-0 bg-primary/10 mix-blend-overlay" />
        
        <div className="relative z-10 p-12 lg:p-16 flex flex-col h-full justify-center text-slate-100 max-w-2xl mx-auto w-full">
          <Link to="/" className="inline-flex items-center gap-3 mb-12">
            <img src={navalaLogo} alt="Logo" className="h-12 w-auto brightness-200" />
            <div className="text-left">
              <h1 className="text-xl font-bold tracking-tight text-white uppercase leading-tight">Navala Travel Health</h1>
              <p className="text-sm text-slate-300 leading-tight">World Cup 2026 Medical Access</p>
            </div>
          </Link>
          
          <div className="space-y-6 mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/20 border border-primary/30 text-primary-100 text-sm font-medium mb-2">
              <Sparkles className="h-4 w-4" /> Account Recovery
            </div>
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
              Regain access to <br/>
              <span className="text-primary-300">your health vault.</span>
            </h1>
            <p className="text-lg text-slate-300 max-w-md leading-relaxed">
              Don't worry if you forgot your password. We'll send you a secure one-time password to get you back into your account immediately.
            </p>
          </div>

          <div className="space-y-6">
            <div className="flex gap-4 items-start">
              <div className="p-3 bg-white/10 backdrop-blur-sm rounded-xl shrink-0 border border-white/5">
                <Shield className="h-6 w-6 text-primary-300" />
              </div>
              <div className="space-y-1 mt-0.5">
                <h3 className="font-semibold text-white">HIPAA Compliant Security</h3>
                <p className="text-slate-400 text-sm">Your medical data is protected with 256-bit encryption.</p>
              </div>
            </div>
            
            <div className="flex gap-4 items-start">
              <div className="p-3 bg-white/10 backdrop-blur-sm rounded-xl shrink-0 border border-white/5">
                <Globe className="h-6 w-6 text-accent-300" />
              </div>
              <div className="space-y-1 mt-0.5">
                <h3 className="font-semibold text-white">Global Access</h3>
                <p className="text-slate-400 text-sm">Reach medical professionals from anywhere in the world.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Column - Recovery Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12 relative overflow-y-auto">
        <div className="w-full max-w-md space-y-8 animate-fade-in my-auto">
          {/* Logo visible only on mobile */}
          <div className="flex lg:hidden justify-center mb-8">
            <Link to="/" className="flex items-center gap-3">
              <img src={navalaLogo} alt="Logo" className="h-10 w-auto" />
              <div className="text-left">
                <h1 className="text-lg font-bold tracking-tight text-foreground uppercase leading-tight">Navala Travel Health</h1>
                <p className="text-xs font-medium text-muted-foreground leading-tight">World Cup 2026 Medical Access</p>
              </div>
            </Link>
          </div>

          <div className="text-center lg:text-left space-y-2 mb-8">
            <div className="lg:hidden mx-auto mb-4 h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
              {step === 'email' ? (
                <Mail className="h-8 w-8 text-primary" />
              ) : (
                <KeyRound className="h-8 w-8 text-primary" />
              )}
            </div>
            <div className="hidden lg:flex items-center gap-3 mb-6 text-primary">
              {step === 'email' ? <Mail className="h-6 w-6" /> : <KeyRound className="h-6 w-6" />}
              <span className="font-semibold tracking-wide uppercase text-sm">
                {step === 'email' ? 'Password Recovery' : 'Reset Password'}
              </span>
            </div>
            <h2 className="text-2xl md:text-3xl font-bold tracking-tight text-foreground">
              {step === 'email' ? 'Forgot password?' : 'Reset your password'}
            </h2>
            <p className="text-muted-foreground">
              {step === 'email'
                ? 'Enter your email and we’ll send you a one-time password (OTP).'
                : 'Enter the OTP from your email and choose a new password.'}
            </p>
          </div>

          <div>
            {step === 'email' ? (
              <form onSubmit={handleSendOtp} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="patient@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={loading}
                    required
                  />
                </div>
                {error && (
                  <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3">
                    <p className="text-sm text-destructive text-center">{error}</p>
                  </div>
                )}
                <Button type="submit" className="w-full h-12 text-md transition-all hover:scale-[1.02]" size="lg" disabled={loading}>
                  {loading ? 'Sending OTP...' : 'Send OTP'}
                </Button>
              </form>
            ) : (
              <form onSubmit={handleResetPassword} className="space-y-4">
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input value={email} disabled className="bg-muted" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="otp">OTP (from email)</Label>
                  <Input
                    id="otp"
                    type="text"
                    inputMode="numeric"
                    maxLength={6}
                    placeholder="000000"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                    disabled={loading}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="newPassword">New password</Label>
                  <Input
                    id="newPassword"
                    type="password"
                    placeholder="At least 8 characters"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    disabled={loading}
                    minLength={8}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm password</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="Re-enter new password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    disabled={loading}
                  />
                </div>
                {error && (
                  <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3">
                    <p className="text-sm text-destructive text-center">{error}</p>
                  </div>
                )}
                <Button type="submit" className="w-full h-12 text-md transition-all hover:scale-[1.02]" size="lg" disabled={loading}>
                  {loading ? 'Resetting...' : 'Reset password'}
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  className="w-full h-12"
                  disabled={loading}
                  onClick={() => { setStep('email'); setError(''); setOtp(''); setNewPassword(''); setConfirmPassword(''); }}
                >
                  Use a different email
                </Button>
              </form>
            )}
          </div>

          <div className="mt-8 pt-6 border-t flex justify-center">
            <Link
              to="/login"
              className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to login
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
