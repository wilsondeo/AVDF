import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useAppStore, UserRole } from '@/lib/store';
import { User, Stethoscope, Shield, Heart, Eye, EyeOff, CheckCircle2, Sparkles, Video, Globe } from 'lucide-react';
import { authApi, setAuthToken } from '@/services/api';
import { toast } from 'sonner';
import navalaLogo from '@/assets/navala.png';
import loginBg from '@/assets/loginbg.jpg';

type LoginMode = 'patient' | 'doctor';

export default function LoginPage({ mode = 'patient' }: { mode?: LoginMode }) {
  const navigate = useNavigate();
  const { setUser } = useAppStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (!email || !password) {
      setError('Please enter your email and password');
      setLoading(false);
      return;
    }

    try {
      let response;

      // Call appropriate API endpoint based on fixed mode
      if (mode === 'patient') {
        response = await authApi.patientLogin(email, password);
      } else if (mode === 'doctor') {
        response = await authApi.doctorLogin(email, password);
      } else {
        setError('Invalid login mode');
        setLoading(false);
        return;
      }

      if (response.success && response.data) {
        // Store tokens
        setAuthToken(response.data.accessToken);
        if (response.data.refreshToken) {
          localStorage.setItem('refreshToken', response.data.refreshToken);
        }

        // Update user in store
        setUser({
          id: response.data.user.id.toString(),
          uuid: response.data.user.userUuid,
          email: response.data.user.email,
          name: `${response.data.user.firstName} ${response.data.user.lastName}`,
          role: response.data.user.role.toLowerCase() as UserRole,
        });

        toast.success('Login successful!');

        // Navigate based on mode
        if (mode === 'patient') {
          navigate('/patient');
        } else if (mode === 'doctor') {
          navigate('/doctor');
        }
      } else {
        setError(response.message || 'Invalid email or password');
        toast.error(response.message || 'Login failed');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
      toast.error('An error occurred during login');
    } finally {
      setLoading(false);
    }
  };

  const roleConfig = {
    patient: {
      icon: User,
      title: 'Patient Login',
      description: 'Access your health dashboard and book appointments',
      demo: 'patient@example.com',
    },
    doctor: {
      icon: Stethoscope,
      title: 'Provider Login',
      description: 'Manage your patients and consultations',
      demo: 'doctor@example.com',
    },
    admin: {
      icon: Shield,
      title: 'Admin Login',
      description: 'System administration and management',
      demo: 'admin@navala.com',
    },
  };

  const currentRoleKey: LoginMode = mode;
  const CurrentRoleIcon = roleConfig[currentRoleKey].icon;

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-background">
      {/* Left Column - Branding (Desktop Only) */}
      <div className="hidden lg:flex w-1/2 bg-slate-900 border-r relative flex-col justify-between overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-40"
          style={{ backgroundImage: `url(${loginBg})` }}
        />
        {/* Dark Gradient Overlay for text readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-slate-900/60 via-slate-900/80 to-slate-900" />
        <div className="absolute inset-0 bg-primary/10 mix-blend-overlay" />

        <div className="relative z-10 p-12 lg:p-16 flex flex-col h-full justify-center text-slate-100 max-w-2xl mx-auto w-full">
          <Link to="/" className="inline-flex items-center gap-3 mb-12">
            <img src={navalaLogo} alt="Logo" className="h-12 w-auto brightness-200" />
            <div className="text-left">
              <h1 className="text-xl font-bold tracking-tight text-white uppercase leading-tight">Navala Travel Health</h1>
              <p className="text-sm text-slate-300 leading-tight">World Cup 2026 Medical Access</p>
            </div>
          </Link>

          <div className="space-y-6 mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/20 border border-primary/30 text-primary-100 text-sm font-medium mb-2">
              <Sparkles className="h-4 w-4" /> Seamless Care Everywhere
            </div>
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
              Your health, <br />
              <span className="text-primary-300">secured globally.</span>
            </h1>
            <p className="text-lg text-slate-300 max-w-md leading-relaxed">
              Log in to instantly access world-class healthcare, manage your active plans, and book priority consultations anytime.
            </p>
          </div>

          <div className="space-y-6">
            <div className="flex gap-4 items-start">
              <div className="p-3 bg-white/10 backdrop-blur-sm rounded-xl shrink-0 border border-white/5">
                <Shield className="h-6 w-6 text-primary-300" />
              </div>
              <div className="space-y-1 mt-0.5">
                <h3 className="font-semibold text-white">HIPAA Compliant Security</h3>
                <p className="text-slate-400 text-sm">Your medical data is protected with 256-bit encryption.</p>
              </div>
            </div>

            <div className="flex gap-4 items-start">
              <div className="p-3 bg-white/10 backdrop-blur-sm rounded-xl shrink-0 border border-white/5">
                <Globe className="h-6 w-6 text-accent-300" />
              </div>
              <div className="space-y-1 mt-0.5">
                <h3 className="font-semibold text-white">Global Access</h3>
                <p className="text-slate-400 text-sm">Reach medical professionals from anywhere in the world.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Column - Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12 relative">
        <div className="w-full max-w-md space-y-8 animate-fade-in">
          {/* Logo visible only on mobile */}
          <div className="flex lg:hidden justify-center mb-8">
            <Link to="/" className="flex items-center gap-3">
              <img src={navalaLogo} alt="Logo" className="h-10 w-auto" />
              <div className="text-left">
                <h1 className="text-lg font-bold tracking-tight text-foreground uppercase leading-tight">Navala Travel Health</h1>
                <p className="text-xs font-medium text-muted-foreground leading-tight">World Cup 2026 Medical Access</p>
              </div>
            </Link>
          </div>

          <div className="text-center lg:text-left space-y-2 mb-8">
            <div className="lg:hidden mx-auto mb-4 h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
              <CurrentRoleIcon className="h-8 w-8 text-primary" />
            </div>
            <div className="hidden lg:flex items-center gap-3 mb-6 text-primary">
              <CurrentRoleIcon className="h-6 w-6" />
              <span className="font-semibold tracking-wide uppercase text-sm">Welcome Back</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-bold tracking-tight text-foreground">
              {roleConfig[currentRoleKey].title}
            </h2>
            <p className="text-muted-foreground">
              {roleConfig[currentRoleKey].description}
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder={roleConfig[currentRoleKey].demo}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={loading}
                required
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                {mode === 'patient' && (
                  <Link to="/forgot-password" className="text-xs text-primary hover:underline">
                    Forgot password?
                  </Link>
                )}
              </div>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={loading}
                  required
                  className="pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((p) => !p)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1 rounded"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3">
                <p className="text-sm text-destructive text-center">{error}</p>
              </div>
            )}

            <Button type="submit" className="w-full h-12 text-md transition-all hover:scale-[1.02]" size="lg" disabled={loading}>
              {loading ? 'Signing in...' : 'Sign In'}
            </Button>
          </form>

          <div className="mt-8 space-y-4">
            <div className="relative w-full">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-border" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-4 text-muted-foreground font-medium">Or</span>
              </div>
            </div>

            {mode === 'patient' ? (
              <>
                <p className="text-center text-sm text-muted-foreground pt-2">
                  Don't have an account?{' '}
                  <Link to="/register" className="font-medium text-primary hover:text-primary/80 transition-colors">
                    Create one
                  </Link>
                </p>
                <div className="grid grid-cols-2 gap-3 pt-6 border-t">
                  <Button variant="outline" className="w-full text-xs h-12 bg-slate-50 text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-xl" asChild>
                    <Link to="/doctor/login">
                      <Stethoscope className="mr-2 h-4 w-4" />
                      Provider Portal
                    </Link>
                  </Button>
                  <Button variant="outline" className="w-full text-xs h-12 bg-slate-50 text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-xl" asChild>
                    <Link to="/admin/login">
                      <Shield className="mr-2 h-4 w-4" />
                      Admin Portal
                    </Link>
                  </Button>
                </div>
              </>
            ) : mode === 'doctor' ? (
              <div className="grid grid-cols-2 gap-3 pt-6 border-t">
                <Button variant="outline" className="w-full text-xs h-12 bg-slate-50 text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-xl" asChild>
                  <Link to="/login">
                    <User className="mr-2 h-4 w-4" />
                    Patient Portal
                  </Link>
                </Button>
                <Button variant="outline" className="w-full text-xs h-12 bg-slate-50 text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-xl" asChild>
                  <Link to="/admin/login">
                    <Shield className="mr-2 h-4 w-4" />
                    Admin Portal
                  </Link>
                </Button>
              </div>
            ) : null}
            <p className="text-center text-xs text-muted-foreground pt-4">
              <Link to="/privacy-policy" className="hover:text-foreground transition-colors">
                Privacy Policy
              </Link>
              <span className="mx-2">•</span>
              <Link to="/terms-of-service" className="hover:text-foreground transition-colors">
                Terms of Service
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
