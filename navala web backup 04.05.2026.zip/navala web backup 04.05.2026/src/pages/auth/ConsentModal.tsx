import React, { useEffect, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { ScrollArea } from '@/components/ui/scroll-area';
import { authApi } from '@/services/api';
import { Shield, ChevronRight, Loader2 } from 'lucide-react';

interface ConsentSection {
  id: string;
  category: string;
  title: string;
  content: string;
}

interface ConsentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ConsentModal({ isOpen, onClose }: ConsentModalProps) {
  const [sections, setSections] = useState<ConsentSection[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetchConsent();
    }
  }, [isOpen]);

  const fetchConsent = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await authApi.getConsent();
      if (response.success && response.data) {
        setSections(response.data.sections);
      } else {
        setError(response.message || 'Failed to load consent content');
      }
    } catch (err) {
      setError('An error occurred while fetching consent content');
    } finally {
      setLoading(false);
    }
  };

  // Group sections by category
  const categories = sections.reduce((acc, section) => {
    if (!acc[section.category]) {
      acc[section.category] = [];
    }
    acc[section.category].push(section);
    return acc;
  }, {} as Record<string, ConsentSection[]>);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] flex flex-col p-0 overflow-hidden gap-0">
        <DialogHeader className="p-6 pb-4 border-b">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-full bg-primary/10">
              <Shield className="h-5 w-5 text-primary" />
            </div>
            <DialogTitle className="text-xl md:text-2xl font-bold">Consent & Data Sharing</DialogTitle>
          </div>
          <DialogDescription className="text-left">
            Please review how Navala Travel Health handles your health data and telehealth services.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 min-h-0 overflow-y-auto px-6">
          <div className="py-4 pb-40">
              {loading ? (
                <div className="flex flex-col items-center justify-center py-12 space-y-4">
                  <Loader2 className="h-8 w-8 text-primary animate-spin" />
                  <p className="text-sm text-muted-foreground font-medium">Fetching secure content...</p>
                </div>
              ) : error ? (
                <div className="text-center py-12">
                  <p className="text-destructive font-medium">{error}</p>
                  <button 
                    onClick={fetchConsent}
                    className="mt-4 text-sm text-primary hover:underline font-semibold"
                  >
                    Try Again
                  </button>
                </div>
              ) : (
                <Accordion type="single" collapsible className="w-full space-y-3" defaultValue="category-0">
                  {Object.entries(categories).map(([category, items], idx) => (
                    <AccordionItem 
                      key={category} 
                      value={`category-${idx}`}
                      className="border rounded-xl px-4 bg-muted/20 hover:bg-muted/30 transition-colors border-border/50"
                    >
                      <AccordionTrigger className="hover:no-underline py-4 text-left font-bold text-slate-800">
                        <span className="flex items-center gap-2">
                          {category === 'Data Usage' && <span className="w-2 h-2 rounded-full bg-blue-500" />}
                          {category === 'Telehealth' && <span className="w-2 h-2 rounded-full bg-green-500" />}
                          {category === 'Data Sharing' && <span className="w-2 h-2 rounded-full bg-amber-500" />}
                          {category === 'Cross-Border Transfer' && <span className="w-2 h-2 rounded-full bg-purple-500" />}
                          {category === 'User Rights' && <span className="w-2 h-2 rounded-full bg-indigo-500" />}
                          {category}
                        </span>
                      </AccordionTrigger>
                      <AccordionContent className="pb-4 space-y-4">
                        {items.map((item) => (
                          <div key={item.id} className="space-y-2">
                            <h4 className="font-semibold text-sm text-slate-900 flex items-center gap-2">
                              <ChevronRight className="h-3 w-3 text-primary" />
                              {item.title}
                            </h4>
                            <p className="text-slate-600 text-sm leading-relaxed whitespace-pre-wrap ml-5">
                              {item.content}
                            </p>
                          </div>
                        ))}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              )}
          </div>
        </div>

        <div className="p-6 bg-slate-50 border-t flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-primary text-white rounded-lg hover:bg-primary/90 transition-all font-semibold shadow-sm active:scale-95"
          >
            I Understand
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
