import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useAppStore } from '@/lib/store';
import { User, Heart, Shield, ChevronDown, ChevronUp, Phone, MapPin, Eye, EyeOff, Sparkles, Globe } from 'lucide-react';
import { authApi } from '@/services/api';
import { setAuthToken } from '@/services/api';
import { toast } from 'sonner';
import navalaLogo from '@/assets/navala.png';
import loginBg from '@/assets/loginbg.jpg';
import ConsentModal from './ConsentModal';

export default function RegisterPage() {
  const navigate = useNavigate();
  const { setUser } = useAppStore();
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    dateOfBirth: '',
    streetAddress: '',
    city: '',
    state: '',
    zipCode: '',
    country: 'United States',
    emergencyContactName: '',
    emergencyContactPhone: '',
    emergencyContactRelationship: '',
    bloodType: '',
    gender: '',
    consentTerms: false,
    consentData: false,
  });
  const [showOptional, setShowOptional] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState('');
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [showConsentModal, setShowConsentModal] = useState(false);

  /** First/Last name: letters only, spaces and hyphen allowed, 2–50 chars, no leading/trailing spaces */
  function validateName(value: string): string | null {
    const trimmed = value.trim();
    if (!trimmed) return null; // required check done separately
    if (trimmed.length < 2) return 'Please enter a valid name (letters only).';
    if (trimmed.length > 50) return 'Please enter a valid name (letters only).';
    if (trimmed !== value) return 'Please enter a valid name (letters only).'; // no leading/trailing spaces
    if (!/^[a-zA-Z\s\-]+$/.test(trimmed)) return 'Please enter a valid name (letters only).';
    return null;
  }

  /** Email: valid format, no spaces, no consecutive dots, no leading/trailing dot in local part */
  function validateEmail(value: string): string | null {
    const trimmed = value.trim();
    if (!trimmed) return null;
    if (/\s/.test(trimmed)) return 'Please enter a valid email address.';
    if (/\.\./.test(trimmed)) return 'Please enter a valid email address.';
    const [local, domain] = trimmed.split('@');
    if (!local || !domain || local.startsWith('.') || local.endsWith('.')) return 'Please enter a valid email address.';
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(trimmed)) return 'Please enter a valid email address.';
    return null;
  }

  /** Phone: digits only (optional +), 10–15 digits, not all zeros */
  function validatePhone(value: string): string | null {
    if (!value.trim()) return null;
    const digits = value.replace(/\D/g, '');
    if (digits.length < 10 || digits.length > 15) return 'Please enter a valid phone number.';
    if (/^0+$/.test(digits)) return 'Please enter a valid phone number.';
    return null;
  }

  /** Password: min 8, 1 upper, 1 lower, 1 number, 1 special, no spaces */
  function validatePassword(value: string, email?: string): string | null {
    if (!value) return null;
    if (value.length < 8) return 'Password must be at least 8 characters with uppercase, lowercase, number, and special character.';
    if (/\s/.test(value)) return 'Password must be at least 8 characters with uppercase, lowercase, number, and special character.';
    if (!/[A-Z]/.test(value) || !/[a-z]/.test(value) || !/\d/.test(value) || !/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
      return 'Password must be at least 8 characters with uppercase, lowercase, number, and special character.';
    }
    if (email && value.toLowerCase() === email.toLowerCase()) return 'Password must be at least 8 characters with uppercase, lowercase, number, and special character.';
    return null;
  }

  /** Confirm password: must match password */
  function validateConfirmPassword(confirm: string, password: string): string | null {
    if (!confirm) return null;
    if (confirm !== password) return 'Passwords do not match.';
    return null;
  }

  /** ZIP/Postal: 6 digits only */
  function validateZipCode(value: string): string | null {
    if (!value.trim()) return null;
    const cleaned = value.trim().replace(/\s/g, '');
    if (!/^\d{6}$/.test(cleaned)) return 'Please enter a valid ZIP code (6 digits).';
    return null;
  }

  /** Date of birth: valid date, not future, age 13+ */
  function validateDateOfBirth(value: string): string | null {
    if (!value.trim()) return null;
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return 'Please enter a valid date of birth.';
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (d > today) return 'Please enter a valid date of birth.';
    const age = (today.getTime() - d.getTime()) / (365.25 * 24 * 60 * 60 * 1000);
    if (age < 13) return 'You must be 13 years or older.';
    return null;
  }

  /** Address: alphanumeric and , . - # / only, max 150 chars */
  function validateAddress(value: string): string | null {
    if (!value.trim()) return null;
    const trimmed = value.trim();
    if (trimmed.length > 150) return 'Please enter a valid address (max 150 characters).';
    if (!/^[a-zA-Z0-9\s,.\-#\/]+$/.test(trimmed)) return 'Please enter a valid address.';
    return null;
  }

  /** City / State / Country: letters and spaces (and hyphen) only; 2–100 chars */
  function validatePlace(value: string): string | null {
    if (!value.trim()) return null;
    const trimmed = value.trim();
    if (trimmed.length > 100) return 'Please enter a valid value (letters only).';
    if (!/^[a-zA-Z\s\-]+$/.test(trimmed)) return 'Please enter a valid value (letters only).';
    return null;
  }

  /** Blood type: only A+, A-, B+, B-, AB+, AB-, O+, O- */
  function validateBloodType(value: string): string | null {
    if (!value.trim()) return null;
    if (!/^(A|B|AB|O)[+-]$/i.test(value.trim())) return 'Please enter a valid blood type (e.g. A+, O-).';
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setFieldErrors({});

    const errors: Record<string, string> = {};

    // 1. First Name / Last Name (required, letters only, 2–50, no leading/trailing spaces)
    const firstNameTrimmed = formData.firstName.trim();
    const lastNameTrimmed = formData.lastName.trim();
    if (!firstNameTrimmed) errors.firstName = 'Please enter a valid name (letters only).';
    else { const e1 = validateName(formData.firstName); if (e1) errors.firstName = e1; }
    if (!lastNameTrimmed) errors.lastName = 'Please enter a valid name (letters only).';
    else { const e2 = validateName(formData.lastName); if (e2) errors.lastName = e2; }

    // 2. Email (required, valid format)
    const emailTrimmed = formData.email.trim().toLowerCase();
    if (!emailTrimmed) errors.email = 'Please enter a valid email address.';
    else { const e3 = validateEmail(formData.email); if (e3) errors.email = e3; }

    // 3. Phone (optional but if provided must be valid)
    const phoneErr = validatePhone(formData.phone);
    if (phoneErr) errors.phone = phoneErr;

    // 4. Password (required, 8+ with upper, lower, number, special)
    if (!formData.password) errors.password = 'Password must be at least 8 characters with uppercase, lowercase, number, and special character.';
    else { const e4 = validatePassword(formData.password, emailTrimmed || formData.email); if (e4) errors.password = e4; }

    // 5. Confirm Password (must match)
    const confirmErr = validateConfirmPassword(formData.confirmPassword, formData.password);
    if (confirmErr) errors.confirmPassword = confirmErr;

    // 6. ZIP (optional but if provided must be 6 digits)
    const zipErr = validateZipCode(formData.zipCode);
    if (zipErr) errors.zipCode = zipErr;

    // 7. Date of Birth (optional but if provided must be valid)
    const dobErr = validateDateOfBirth(formData.dateOfBirth);
    if (dobErr) errors.dateOfBirth = dobErr;

    // 8. Address (optional but if provided must be valid)
    const addressErr = validateAddress(formData.streetAddress);
    if (addressErr) errors.streetAddress = addressErr;

    if (formData.city) { const ce = validatePlace(formData.city); if (ce) errors.city = ce; }
    if (formData.state) { const se = validatePlace(formData.state); if (se) errors.state = se; }
    if (formData.country) { const co = validatePlace(formData.country); if (co) errors.country = co; }
    if (formData.bloodType) { const bt = validateBloodType(formData.bloodType); if (bt) errors.bloodType = bt; }
    if (formData.gender) { const ge = validatePlace(formData.gender); if (ge) errors.gender = ge; }
    if (formData.emergencyContactRelationship) {
      const rel = validatePlace(formData.emergencyContactRelationship);
      if (rel) errors.emergencyContactRelationship = rel;
    }

    if (formData.emergencyContactName) {
      const ecn = validatePlace(formData.emergencyContactName);
      if (ecn) errors.emergencyContactName = ecn;
    }

    const ecPhoneErr = validatePhone(formData.emergencyContactPhone);
    if (ecPhoneErr) errors.emergencyContactPhone = ecPhoneErr;

    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      setError('Please fix the validation errors below before submitting.');
      return;
    }

    if (!formData.consentTerms || !formData.consentData) {
      setError('You must agree to both terms and data sharing to create an account.');
      return;
    }

    setLoading(true);
    try {
      const response = await authApi.patientRegister({
        email: emailTrimmed,
        password: formData.password,
        firstName: firstNameTrimmed,
        lastName: lastNameTrimmed,
        ...(formData.phone && { phone: formData.phone }),
        ...(formData.dateOfBirth && { dateOfBirth: formData.dateOfBirth }),
        ...(formData.streetAddress && { streetAddress: formData.streetAddress }),
        ...(formData.city && { city: formData.city }),
        ...(formData.state && { state: formData.state }),
        ...(formData.zipCode && { zipCode: formData.zipCode }),
        ...(formData.country && { country: formData.country }),
        ...(formData.emergencyContactName && { emergencyContactName: formData.emergencyContactName }),
        ...(formData.emergencyContactPhone && { emergencyContactPhone: formData.emergencyContactPhone }),
        ...(formData.emergencyContactRelationship && { emergencyContactRelationship: formData.emergencyContactRelationship }),
        ...(formData.bloodType && { bloodType: formData.bloodType }),
        ...(formData.gender && { gender: formData.gender }),
      });

      if (response.success && response.data) {
        setAuthToken(response.data.accessToken);
        if (response.data.refreshToken) {
          localStorage.setItem('refreshToken', response.data.refreshToken);
        }
        setUser({
          id: response.data.user.id.toString(),
          uuid: response.data.user.userUuid,
          email: response.data.user.email,
          name: `${response.data.user.firstName} ${response.data.user.lastName}`,
          role: response.data.user.role.toLowerCase() as 'patient' | 'doctor' | 'admin',
        });
        toast.success('Registration successful!');
        navigate('/patient');
      } else {
        const msg = response.message || 'Registration failed. Please try again.';
        if (typeof msg === 'string' && (msg.toLowerCase().includes('isemail') || (msg.toLowerCase().includes('email') && msg.toLowerCase().includes('fail')))) {
          setFieldErrors((p) => ({ ...p, email: 'Please enter a valid email address.' }));
          setError('Please fix the validation errors below before submitting.');
        } else {
          setError(msg);
        }
        toast.error(typeof msg === 'string' ? msg : 'Registration failed');
      }
    } catch (err) {
      const msg = err && typeof err === 'object' && 'message' in err ? String((err as { message: string }).message) : '';
      if (msg && (msg.toLowerCase().includes('isemail') || (msg.toLowerCase().includes('email') && msg.toLowerCase().includes('fail')))) {
        setFieldErrors((p) => ({ ...p, email: 'Please enter a valid email address.' }));
        setError('Please enter a valid email address.');
      } else {
        setError('An error occurred. Please try again.');
      }
      toast.error('An error occurred during registration');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-background">
      {/* Left Column - Branding (Desktop Only) */}
      <div className="hidden lg:flex w-1/2 bg-slate-900 border-r relative flex-col justify-between overflow-hidden">
        {/* Background Image */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-40"
          style={{ backgroundImage: `url(${loginBg})` }} 
        />
        {/* Dark Gradient Overlay for text readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-slate-900/60 via-slate-900/80 to-slate-900" />
        <div className="absolute inset-0 bg-primary/10 mix-blend-overlay" />
        
        <div className="relative z-10 p-12 lg:p-16 flex flex-col h-full justify-center text-slate-100 max-w-2xl mx-auto w-full">
          <Link to="/" className="inline-flex items-center gap-3 mb-12">
            <img src={navalaLogo} alt="Logo" className="h-12 w-auto brightness-200" />
            <div className="text-left">
              <h1 className="text-xl font-bold tracking-tight text-white uppercase leading-tight">Navala Travel Health</h1>
              <p className="text-sm text-slate-300 leading-tight">World Cup 2026 Medical Access</p>
            </div>
          </Link>
          
          <div className="space-y-6 mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/20 border border-primary/30 text-primary-100 text-sm font-medium mb-2">
              <Sparkles className="h-4 w-4" /> Seamless Care Everywhere
            </div>
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-white leading-tight">
              Join the future of <br/>
              <span className="text-primary-300">travel healthcare.</span>
            </h1>
            <p className="text-lg text-slate-300 max-w-md leading-relaxed">
              Create your account today to instantly access world-class healthcare, manage your active plans, and book priority consultations anytime.
            </p>
          </div>

          <div className="space-y-6">
            <div className="flex gap-4 items-start">
              <div className="p-3 bg-white/10 backdrop-blur-sm rounded-xl shrink-0 border border-white/5">
                <Shield className="h-6 w-6 text-primary-300" />
              </div>
              <div className="space-y-1 mt-0.5">
                <h3 className="font-semibold text-white">HIPAA Compliant Security</h3>
                <p className="text-slate-400 text-sm">Your medical data is protected with 256-bit encryption.</p>
              </div>
            </div>
            
            <div className="flex gap-4 items-start">
              <div className="p-3 bg-white/10 backdrop-blur-sm rounded-xl shrink-0 border border-white/5">
                <Globe className="h-6 w-6 text-accent-300" />
              </div>
              <div className="space-y-1 mt-0.5">
                <h3 className="font-semibold text-white">Global Access</h3>
                <p className="text-slate-400 text-sm">Reach medical professionals from anywhere in the world.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Column - Register Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12 relative overflow-y-auto">
        <div className="w-full max-w-lg space-y-8 animate-fade-in my-auto">
          {/* Logo visible only on mobile */}
          <div className="flex lg:hidden justify-center mb-8">
            <Link to="/" className="flex items-center gap-3">
              <img src={navalaLogo} alt="Logo" className="h-10 w-auto" />
              <div className="text-left">
                <h1 className="text-lg font-bold tracking-tight text-foreground uppercase leading-tight">Navala Travel Health</h1>
                <p className="text-xs font-medium text-muted-foreground leading-tight">World Cup 2026 Medical Access</p>
              </div>
            </Link>
          </div>

          <div className="text-center lg:text-left space-y-2 mb-8">
            <div className="lg:hidden mx-auto mb-4 h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
              <User className="h-8 w-8 text-primary" />
            </div>
            <div className="hidden lg:flex items-center gap-3 mb-6 text-primary">
              <User className="h-6 w-6" />
              <span className="font-semibold tracking-wide uppercase text-sm">Create an Account</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-bold tracking-tight text-foreground">
              Patient Registration
            </h2>
            <p className="text-muted-foreground">
              Create your account to access healthcare services
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name *</Label>
                  <Input
                    id="firstName"
                    placeholder="John"
                    value={formData.firstName}
                    onChange={(e) => {
                       const v = e.target.value.replace(/[^a-zA-Z\s\-]/g, '');
                      setFormData({ ...formData, firstName: v });
                      if (fieldErrors.firstName) setFieldErrors((p) => ({ ...p, firstName: '' }));
                    }}
                    onBlur={(e) => setFormData((p) => ({ ...p, firstName: e.target.value.trim() }))}
                    required
                    disabled={loading}
                    maxLength={50}
                    className={fieldErrors.firstName ? 'border-destructive' : ''}
                  />
                  {fieldErrors.firstName && <p className="text-xs text-destructive">{fieldErrors.firstName}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name *</Label>
                  <Input
                    id="lastName"
                    placeholder="Doe"
                    value={formData.lastName}
                    onChange={(e) => {
                      const v = e.target.value.replace(/[^a-zA-Z\s\-]/g, '');
                      setFormData({ ...formData, lastName: v });
                      if (fieldErrors.lastName) setFieldErrors((p) => ({ ...p, lastName: '' }));
                    }}
                    onBlur={(e) => setFormData((p) => ({ ...p, lastName: e.target.value.trim() }))}
                    required
                    disabled={loading}
                    maxLength={50}
                    className={fieldErrors.lastName ? 'border-destructive' : ''}
                  />
                  {fieldErrors.lastName && <p className="text-xs text-destructive">{fieldErrors.lastName}</p>}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="john@example.com"
                  value={formData.email}
                  onChange={(e) => {
                    setFormData({ ...formData, email: e.target.value });
                    if (fieldErrors.email) setFieldErrors((p) => ({ ...p, email: '' }));
                  }}
                  onBlur={(e) => setFormData((p) => ({ ...p, email: e.target.value.trim().toLowerCase() }))}
                  required
                  disabled={loading}
                  className={fieldErrors.email ? 'border-destructive' : ''}
                />
                {fieldErrors.email && <p className="text-xs text-destructive">{fieldErrors.email}</p>}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="password">Password *</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="••••••••"
                      value={formData.password}
                      onChange={(e) => {
                        const v = e.target.value;
                        setFormData({ ...formData, password: v });
                        if (fieldErrors.password) setFieldErrors((p) => ({ ...p, password: '' }));
                        if (fieldErrors.confirmPassword && formData.confirmPassword) setFieldErrors((p) => ({ ...p, confirmPassword: v !== formData.confirmPassword ? 'Passwords do not match.' : '' }));
                      }}
                      required
                      disabled={loading}
                      minLength={8}
                      className={`pr-10 ${fieldErrors.password ? 'border-destructive' : ''}`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((p) => !p)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1 rounded"
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  <p className="text-xs text-muted-foreground">Min. 8 chars: upper, lower, number, special</p>
                  {fieldErrors.password && <p className="text-xs text-destructive">{fieldErrors.password}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm *</Label>
                  <div className="relative">
                    <Input
                      id="confirmPassword"
                      type={showConfirmPassword ? 'text' : 'password'}
                      placeholder="••••••••"
                      value={formData.confirmPassword}
                      onChange={(e) => {
                        const v = e.target.value;
                        setFormData({ ...formData, confirmPassword: v });
                        setFieldErrors((p) => ({
                          ...p,
                          confirmPassword: v && v !== formData.password ? 'Passwords do not match.' : '',
                        }));
                      }}
                      required
                      disabled={loading}
                      minLength={8}
                      className={`pr-10 ${fieldErrors.confirmPassword ? 'border-destructive' : ''}`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword((p) => !p)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-1 rounded"
                      aria-label={showConfirmPassword ? 'Hide password' : 'Show password'}
                    >
                      {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {fieldErrors.confirmPassword && <p className="text-xs text-destructive">{fieldErrors.confirmPassword}</p>}
                </div>
              </div>

              {/* Optional profile details – shown at registration and editable in profile */}
              <div className="border rounded-lg overflow-hidden">
                <button
                  type="button"
                  onClick={() => setShowOptional(!showOptional)}
                  className="w-full flex items-center justify-between gap-2 px-3 py-2.5 text-left text-sm font-medium text-muted-foreground hover:bg-muted/50 transition-colors"
                >
                  <span>Optional details (phone, address, emergency contact)</span>
                  {showOptional ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </button>
                {showOptional && (
                  <div className="px-3 pb-3 pt-1 space-y-3 border-t bg-muted/20">
                    <p className="text-xs text-muted-foreground">You can add these now or later in your profile.</p>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <Label htmlFor="reg-phone" className="text-xs">Phone</Label>
                        <Input
                          id="reg-phone"
                          type="tel"
                          inputMode="numeric"
                          placeholder="e.g. 5551234567"
                          value={formData.phone}
                          onChange={(e) => {
                            const v = e.target.value.replace(/[^\d+\s-]/g, '');
                            setFormData({ ...formData, phone: v });
                            if (fieldErrors.phone) setFieldErrors((prev) => ({ ...prev, phone: '' }));
                          }}
                          disabled={loading}
                          className={fieldErrors.phone ? 'border-destructive' : ''}
                        />
                        {fieldErrors.phone && <p className="text-xs text-destructive">{fieldErrors.phone}</p>}
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="reg-dob" className="text-xs">Date of Birth</Label>
                        <Input
                          id="reg-dob"
                          type="date"
                          max={new Date().toISOString().slice(0, 10)}
                          value={formData.dateOfBirth}
                          onChange={(e) => {
                            setFormData({ ...formData, dateOfBirth: e.target.value });
                            if (fieldErrors.dateOfBirth) setFieldErrors((p) => ({ ...p, dateOfBirth: '' }));
                          }}
                          disabled={loading}
                          className={fieldErrors.dateOfBirth ? 'border-destructive' : ''}
                        />
                        {fieldErrors.dateOfBirth && <p className="text-xs text-destructive">{fieldErrors.dateOfBirth}</p>}
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <Label htmlFor="reg-gender" className="text-xs">Gender</Label>
                        <select
                          id="reg-gender"
                          value={formData.gender}
                          onChange={(e) => {
                            setFormData({ ...formData, gender: e.target.value });
                            if (fieldErrors.gender) setFieldErrors((p) => ({ ...p, gender: '' }));
                          }}
                          disabled={loading}
                          className={`flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 ${fieldErrors.gender ? 'border-destructive' : ''}`}
                        >
                          <option value="">Select Gender</option>
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                          <option value="Other">Other</option>
                          <option value="Prefer not to say">Prefer not to say</option>
                        </select>
                        {fieldErrors.gender && <p className="text-xs text-destructive">{fieldErrors.gender}</p>}
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="reg-address" className="text-xs flex items-center gap-1"><MapPin className="h-3 w-3" /> Street Address</Label>
                      <Input
                        id="reg-address"
                        placeholder="Street address (letters, numbers, , . - # /)"
                        value={formData.streetAddress}
                        onChange={(e) => {
                          const v = e.target.value;
                          if (v.length <= 150) setFormData({ ...formData, streetAddress: v });
                          if (fieldErrors.streetAddress) setFieldErrors((p) => ({ ...p, streetAddress: '' }));
                        }}
                        onBlur={(e) => setFormData((p) => ({ ...p, streetAddress: e.target.value.trim() }))}
                        disabled={loading}
                        maxLength={150}
                        className={fieldErrors.streetAddress ? 'border-destructive' : ''}
                      />
                      {fieldErrors.streetAddress && <p className="text-xs text-destructive">{fieldErrors.streetAddress}</p>}
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <Label htmlFor="reg-city" className="text-xs">City</Label>
                        <Input
                          id="reg-city"
                          placeholder="City"
                          value={formData.city}
                          onChange={(e) => {
                            const v = e.target.value.replace(/[^a-zA-Z\s\-]/g, '');
                            if (v.length <= 100) setFormData({ ...formData, city: v });
                            if (fieldErrors.city) setFieldErrors((p) => ({ ...p, city: '' }));
                          }}
                          disabled={loading}
                          maxLength={100}
                          className={fieldErrors.city ? 'border-destructive' : ''}
                        />
                        {fieldErrors.city && <p className="text-xs text-destructive">{fieldErrors.city}</p>}
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="reg-country" className="text-xs">Country</Label>
                        <Input
                          id="reg-country"
                          placeholder="Country"
                          value={formData.country}
                          onChange={(e) => {
                            const v = e.target.value.replace(/[^a-zA-Z\s\-]/g, '');
                            if (v.length <= 100) setFormData({ ...formData, country: v });
                            if (fieldErrors.country) setFieldErrors((p) => ({ ...p, country: '' }));
                          }}
                          disabled={loading}
                          maxLength={100}
                          className={fieldErrors.country ? 'border-destructive' : ''}
                        />
                        {fieldErrors.country && <p className="text-xs text-destructive">{fieldErrors.country}</p>}
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <Label htmlFor="reg-state" className="text-xs">State</Label>
                        <Input
                          id="reg-state"
                          placeholder="State"
                          value={formData.state}
                          onChange={(e) => {
                            const v = e.target.value.replace(/[^a-zA-Z\s\-]/g, '');
                            if (v.length <= 100) setFormData({ ...formData, state: v });
                            if (fieldErrors.state) setFieldErrors((p) => ({ ...p, state: '' }));
                          }}
                          disabled={loading}
                          maxLength={100}
                          className={fieldErrors.state ? 'border-destructive' : ''}
                        />
                        {fieldErrors.state && <p className="text-xs text-destructive">{fieldErrors.state}</p>}
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="reg-zip" className="text-xs">ZIP Code</Label>
                        <Input
                          id="reg-zip"
                          placeholder="6 digits"
                          value={formData.zipCode}
                          onChange={(e) => {
                            const v = e.target.value.replace(/\D/g, '').slice(0, 6);
                            setFormData({ ...formData, zipCode: v });
                            if (fieldErrors.zipCode) setFieldErrors((prev) => ({ ...prev, zipCode: '' }));
                          }}
                          disabled={loading}
                          maxLength={6}
                          inputMode="numeric"
                          className={fieldErrors.zipCode ? 'border-destructive' : ''}
                        />
                        {fieldErrors.zipCode && <p className="text-xs text-destructive">{fieldErrors.zipCode}</p>}
                      </div>
                    </div>
                    <div className="pt-2 border-t">
                      <p className="text-xs font-medium text-muted-foreground mb-2 flex items-center gap-1"><Phone className="h-3 w-3" /> Emergency Contact</p>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1.5">
                          <Label htmlFor="reg-ec-name" className="text-xs">Name</Label>
                          <Input
                            id="reg-ec-name"
                            placeholder="Contact name"
                            value={formData.emergencyContactName}
                            onChange={(e) => setFormData({ ...formData, emergencyContactName: e.target.value })}
                            disabled={loading}
                          />
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="reg-ec-phone" className="text-xs">Phone</Label>
                          <Input
                            id="reg-ec-phone"
                            type="tel"
                            inputMode="numeric"
                            placeholder="e.g. 5551234567"
                            value={formData.emergencyContactPhone}
                            onChange={(e) => {
                              const v = e.target.value.replace(/[^\d+\s-]/g, '');
                              setFormData({ ...formData, emergencyContactPhone: v });
                              if (fieldErrors.emergencyContactPhone) setFieldErrors((prev) => ({ ...prev, emergencyContactPhone: '' }));
                            }}
                            disabled={loading}
                            className={fieldErrors.emergencyContactPhone ? 'border-destructive' : ''}
                          />
                          {fieldErrors.emergencyContactPhone && <p className="text-xs text-destructive">{fieldErrors.emergencyContactPhone}</p>}
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3 mt-2">
                        <div className="space-y-1.5">
                          <Label htmlFor="reg-ec-relation" className="text-xs">Relationship</Label>
                          <Input
                            id="reg-ec-relation"
                            placeholder="e.g. Spouse"
                            value={formData.emergencyContactRelationship}
                            onChange={(e) => {
                              const v = e.target.value.replace(/[^a-zA-Z\s\-]/g, '');
                              if (v.length <= 50) setFormData({ ...formData, emergencyContactRelationship: v });
                              if (fieldErrors.emergencyContactRelationship) setFieldErrors((p) => ({ ...p, emergencyContactRelationship: '' }));
                            }}
                            disabled={loading}
                            maxLength={50}
                            className={fieldErrors.emergencyContactRelationship ? 'border-destructive' : ''}
                          />
                          {fieldErrors.emergencyContactRelationship && <p className="text-xs text-destructive">{fieldErrors.emergencyContactRelationship}</p>}
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="reg-blood" className="text-xs">Blood Type</Label>
                          <Input
                            id="reg-blood"
                            placeholder="e.g. O+"
                            value={formData.bloodType}
                            onChange={(e) => {
                              const v = e.target.value.toUpperCase().replace(/[^ABO+-]/g, '').slice(0, 4);
                              setFormData({ ...formData, bloodType: v });
                              if (fieldErrors.bloodType) setFieldErrors((p) => ({ ...p, bloodType: '' }));
                            }}
                            disabled={loading}
                            maxLength={4}
                            className={fieldErrors.bloodType ? 'border-destructive' : ''}
                          />
                          {fieldErrors.bloodType && <p className="text-xs text-destructive">{fieldErrors.bloodType}</p>}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {error && (
                <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3">
                  <p className="text-sm text-destructive text-center">{error}</p>
                </div>
              )}

              <div className="space-y-3 pt-2 border-t">
                <div className="flex items-start space-x-2">
                  <Checkbox 
                    id="consentTerms" 
                    checked={formData.consentTerms}
                    onCheckedChange={(checked) => setFormData({ ...formData, consentTerms: checked === true })}
                    disabled={loading}
                    className="mt-1"
                  />
                  <Label 
                    htmlFor="consentTerms" 
                    className="text-sm font-medium leading-relaxed peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    I agree to the <Link to="/terms-of-service" className="text-primary hover:underline">Terms of Service</Link> & <Link to="/privacy-policy" className="text-primary hover:underline">Privacy Policy</Link> *
                  </Label>
                </div>
                <div className="flex items-start space-x-2">
                  <Checkbox 
                    id="consentData" 
                    checked={formData.consentData}
                    onCheckedChange={(checked) => setFormData({ ...formData, consentData: checked === true })}
                    disabled={loading}
                    className="mt-1"
                  />
                  <div className="grid gap-1.5 leading-none">
                    <Label 
                      htmlFor="consentData" 
                      className="text-sm font-medium leading-relaxed peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      I consent to{' '}
                      <span
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setShowConsentModal(true);
                        }}
                        className="text-primary hover:underline cursor-pointer font-semibold underline decoration-2 underline-offset-4"
                      >
                        Telehealth & Data Sharing *
                      </span>
                    </Label>
                  </div>
                </div>
              </div>

              <Button type="submit" className="w-full h-12 text-md transition-all hover:scale-[1.02]" size="lg" disabled={loading}>
                {loading ? 'Creating Account...' : 'Create Account'}
              </Button>
            </form>

            <div className="mt-8 space-y-4">
              <div className="relative w-full">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-border" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-background px-4 text-muted-foreground font-medium">Or</span>
                </div>
              </div>
              
              <p className="text-center text-sm text-muted-foreground pt-2">
                Already have an account?{' '}
                <Link to="/login" className="font-medium text-primary hover:text-primary/80 transition-colors">
                  Sign in
                </Link>
              </p>
              
              <p className="text-center text-xs text-muted-foreground px-4">
                Note: Only patients can self-register. Doctors and admins must be created by administrators.
              </p>
              
              <p className="text-center text-xs text-muted-foreground pt-2">
                <Link to="/privacy-policy" className="hover:text-foreground transition-colors">
                  Privacy Policy
                </Link>
                <span className="mx-2">•</span>
                <Link to="/terms-of-service" className="hover:text-foreground transition-colors">
                  Terms of Service
                </Link>
              </p>
            </div>
        </div>
      </div>
      <ConsentModal 
        isOpen={showConsentModal} 
        onClose={() => setShowConsentModal(false)} 
      />
    </div>
  );
}
