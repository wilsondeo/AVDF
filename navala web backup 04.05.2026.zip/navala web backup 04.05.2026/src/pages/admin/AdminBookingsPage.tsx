import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandInput, CommandList, CommandEmpty, CommandGroup, CommandItem } from '@/components/ui/command';
import {
  LayoutDashboard,
  Users,
  Calendar,
  CreditCard,
  BarChart3,
  Video,
  Phone,
  Search,
  Receipt,
  CalendarCheck,
  Info,
  Trash2,
  ChevronsUpDown,
  Clock,
} from 'lucide-react';
import { format } from 'date-fns';
import { useEffect, useState } from 'react';
import { appointmentApi, AppointmentRequestStatus, AdminAppointmentRequest } from '@/services/api';
import { adminDoctorApi } from '@/services/api';
import { toast } from 'sonner';
import { adminNavigation } from '@/config/adminNavigation';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const AssignDoctorCombobox = ({ req, doctors, onAssign }: { req: any, doctors: any[], onAssign: (reqUuid: string, docId: string) => void }) => {
  const [open, setOpen] = useState(false);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-[200px] justify-between text-left font-normal bg-card hover:bg-accent/10 hover:text-accent border-accent/20"
        >
          Assign Doctor
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[280px] p-0" align="start">
        <Command>
          <CommandInput placeholder="Search doctor by name..." />
          <CommandList>
            <CommandEmpty>No doctor found.</CommandEmpty>
            <CommandGroup>
              {doctors.filter((d) => d.isActive).map((doc) => (
                <CommandItem
                  key={doc.id}
                  value={doc.name}
                  onSelect={() => {
                    onAssign(req.requestUuid, String(doc.id));
                    setOpen(false);
                  }}
                  className="flex flex-col items-start py-2 cursor-pointer"
                >
                  <div className="font-medium text-[13px]">{doc.name}</div>
                  <div className="text-[11px] text-muted-foreground flex items-center gap-1 mt-0.5">
                    <Clock className="h-3 w-3" />
                    Local Time: {new Date().toLocaleString('en-US', { timeZone: doc.timezone || 'UTC', hour: '2-digit', minute: '2-digit', hour12: true, timeZoneName: 'short' })}
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
};

export default function AdminBookingsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | AppointmentRequestStatus>('all');
  const [requests, setRequests] = useState<AdminAppointmentRequest[]>([]);
  const [loading, setLoading] = useState(false);
  const [doctors, setDoctors] = useState<any[]>([]);
  const [deleteTarget, setDeleteTarget] = useState<AdminAppointmentRequest | null>(null);
  const [deleting, setDeleting] = useState(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const [reqRes, docRes] = await Promise.all([
        appointmentApi.getAdminRequests(statusFilter === 'all' ? {} : { status: statusFilter }),
        adminDoctorApi.getDoctors(),
      ]);

      if (reqRes.success && reqRes.data) {
        setRequests(reqRes.data);
      } else {
        toast.error(reqRes.message || 'Failed to load booking requests');
      }

      if (docRes.success && docRes.data) {
        // Normalize: API returns Doctor with nested User; ensure name, isActive, doctorUuid for dropdown
        setDoctors(
          docRes.data.map((d: any) => ({
            ...d,
            id: d.id,
            doctorUuid: d.doctorUuid,
            name: d.name ?? (d.User ? `${d.User.firstName ?? ''} ${d.User.lastName ?? ''}`.trim() : 'Doctor'),
            isActive: d.isActive ?? d.User?.isActive ?? true,
          }))
        );
      }
    } catch (e: any) {
      toast.error(e?.message || 'Failed to load booking data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusFilter]);

  const handleStatusChange = async (requestUuid: string, newStatus: AppointmentRequestStatus) => {
    try {
      const res = await appointmentApi.updateRequestStatus(requestUuid, newStatus);
      if (!res.success) {
        toast.error(res.message || 'Failed to update status');
        return;
      }
      toast.success('Status updated');
      await loadData();
    } catch (e: any) {
      toast.error(e?.message || 'Failed to update status');
    }
  };

  const handleAssignDoctor = async (requestUuid: string, doctorId: string) => {
    // Select value is string; doctor id may be number
    const doctor = doctors.find((d) => String(d.id) === String(doctorId));
    if (!doctor || !doctor.doctorUuid) {
      toast.error('Selected doctor is invalid');
      return;
    }
    try {
      const res = await appointmentApi.assignDoctor({
        requestUuid,
        doctorUuid: doctor.doctorUuid,
      });
      if (!res.success) {
        toast.error(res.message || 'Failed to assign doctor');
        return;
      }
      toast.success('Doctor assigned');
      await loadData();
    } catch (e: any) {
      toast.error(e?.message || 'Failed to assign doctor');
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deleteTarget) return;
    try {
      setDeleting(true);
      // Permanent delete from database
      const res = await appointmentApi.deleteRequest(deleteTarget.requestUuid);
      if (!res.success) {
        toast.error(res.message || 'Failed to delete booking');
        return;
      }
      toast.success('Booking permanently deleted');
      setRequests((prev) => prev.filter((r) => r.requestUuid !== deleteTarget.requestUuid));
      setDeleteTarget(null);
    } catch (e: any) {
      toast.error(e?.message || 'Failed to delete booking');
    } finally {
      setDeleting(false);
    }
  };

  const filteredRequests = requests.filter((req) => {
    const patientName = (req.patient?.firstName + ' ' + req.patient?.lastName).toLowerCase();
    const familyName = req.familyMember ? (req.familyMember.firstName + ' ' + req.familyMember.lastName).toLowerCase() : '';
    const matchesSearch =
      patientName.includes(searchTerm.toLowerCase()) ||
      familyName.includes(searchTerm.toLowerCase()) ||
      req.city.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  return (
    <DashboardLayout navigation={adminNavigation} title="Bookings Management">
      <div className="space-y-6 animate-fade-in">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Bookings Management</h1>
          <p className="text-muted-foreground mt-1">View and manage all appointment bookings</p>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by patient name or city..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={loadData} disabled={loading}>
              {loading ? 'Refreshing...' : 'Refresh'}
            </Button>
            <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as any)}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="PENDING">Pending</SelectItem>
                <SelectItem value="ASSIGNED">Assigned</SelectItem>
                <SelectItem value="CANCELLED">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Bookings Table */}
        <Card className="shadow-card border-0">
          <CardHeader>
            <CardTitle>All Booking Requests</CardTitle>
            <CardDescription>{filteredRequests.length} request(s) found</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Booking ID</TableHead>
                  <TableHead>Patient</TableHead>
                  <TableHead>City</TableHead>
                  <TableHead>Service</TableHead>
                  <TableHead>Preferred Time</TableHead>
                  <TableHead>Symptoms / Allergies</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Doctor</TableHead>
                  <TableHead className="w-24">Details</TableHead>
                  <TableHead className="w-16 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRequests.map((req) => (
                    <TableRow key={req.requestUuid}>
                      <TableCell className="font-mono text-xs">#{req.requestUuid.slice(0, 8)}</TableCell>
                      <TableCell className="font-medium">
                        {req.familyMember ? (
                          <div className="flex flex-col">
                            <span className="font-semibold">{req.familyMember.firstName} {req.familyMember.lastName}</span>
                            <span className="text-xs text-blue-600 font-medium">{req.familyMember.relationship || 'Family Member'} of {req.patient?.firstName}</span>
                          </div>
                        ) : (
                          req.patient ? `${req.patient.firstName} ${req.patient.lastName}` : 'Unknown'
                        )}
                      </TableCell>
                      <TableCell>{req.city}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {req.serviceType === 'TELEHEALTH' ? <Video className="h-4 w-4 text-accent" /> : <Phone className="h-4 w-4 text-primary" />}
                          {req.serviceType === 'TELEHEALTH' ? 'Telehealth' : 'Emergency'}
                        </div>
                      </TableCell>
                      <TableCell>
                        {req.preferredDate ? (
                          <div className="flex flex-col">
                            <span className="font-medium text-xs">{format(new Date(req.preferredDate), 'hh:mm a')}</span>
                            <div className="flex items-center gap-1">
                              <span className="text-[10px] text-muted-foreground">{format(new Date(req.preferredDate), 'MMM dd')}</span>
                              <Badge variant="outline" className="text-[9px] px-1 h-3.5 bg-orange-50 text-orange-700 border-orange-200">
                                {req.timezone || 'UTC'}
                              </Badge>
                            </div>
                          </div>
                        ) : (
                          <span className="text-muted-foreground text-xs">—</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="max-w-[150px] truncate text-xs" title={req.patientDetails?.allergies || req.patientDetails?.notes || ''}>
                          {req.patientDetails?.allergies || req.patientDetails?.notes || '—'}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-1">
                          <Badge variant="secondary" className="w-fit">{req.plan?.name ?? '-'}</Badge>
                          {req.visitUsage && (
                            <div className="flex flex-col text-[10px] text-muted-foreground leading-tight">
                              <span className={req.visitUsage.telehealth.remaining <= 0 ? "text-destructive font-semibold" : "text-orange-600 font-medium"}>
                                Tele: {req.visitUsage.telehealth.used}/{req.visitUsage.telehealth.limit === Infinity ? '∞' : req.visitUsage.telehealth.limit}
                              </span>
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{format(new Date(req.createdAt), 'MMM dd, yyyy')}</TableCell>
                      <TableCell>
                        <Select
                          value={req.status}
                          onValueChange={(v) => handleStatusChange(req.requestUuid, v as AppointmentRequestStatus)}
                        >
                          <SelectTrigger className="w-[130px]">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="PENDING">Pending</SelectItem>
                            <SelectItem value="ASSIGNED">Assigned</SelectItem>
                            <SelectItem value="CANCELLED">Cancelled</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        {req.status === 'PENDING' ? (
                          <AssignDoctorCombobox req={req} doctors={doctors} onAssign={handleAssignDoctor} />
                        ) : (
                          <span className="text-sm">{req.assignedDoctor?.name ?? '—'}</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <Info className="h-4 w-4" />
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-80" align="end">
                            <div className="space-y-2">
                              <p className="font-medium text-sm border-b pb-1">Patient & Visit Details</p>
                              {req.familyMember && (
                                <div className="bg-blue-50 border border-blue-200 rounded p-2 text-sm">
                                  <p className="font-semibold text-blue-800">👨‍👩‍👧 Booked for Family Member</p>
                                  <p className="text-blue-700">{req.familyMember.firstName} {req.familyMember.lastName} ({req.familyMember.relationship || 'Family'})</p>
                                  <p className="text-blue-600 text-xs">Account holder: {req.patient?.firstName} {req.patient?.lastName}</p>
                                </div>
                              )}
                              {req.patientDetails ? (
                                <dl className="text-sm space-y-1.5">
                                  <div className="flex justify-between"><dt className="text-muted-foreground">Country:</dt> <dd className="font-medium">{req.patientDetails?.country || req.country || '—'}</dd></div>
                                  <div className="flex justify-between"><dt className="text-muted-foreground">City:</dt> <dd className="font-medium">{req.patientDetails?.city || req.city || '—'}</dd></div>
                                  <div className="flex justify-between"><dt className="text-muted-foreground">Timezone:</dt> <dd className="font-medium text-accent">{req.timezone || 'UTC'}</dd></div>
                                  <div className="flex justify-between"><dt className="text-muted-foreground">State:</dt> <dd className="font-medium">{req.patientDetails?.state || req.state || '—'}</dd></div>
                                  <div className="border-t my-1"></div>
                                  <div className="flex justify-between"><dt className="text-muted-foreground">Age:</dt> <dd>{req.patientDetails.age}</dd></div>
                                  <div className="flex justify-between"><dt className="text-muted-foreground">Gender:</dt> <dd>{req.patientDetails.gender}</dd></div>
                                  <div className="flex justify-between"><dt className="text-muted-foreground">Emergency contact:</dt> <dd>{req.patientDetails.emergencyContact}</dd></div>
                                  {req.patientDetails.notes && (
                                    <div className="border-t pt-1">
                                      <dt className="text-muted-foreground text-xs uppercase font-bold">Notes:</dt>
                                      <dd className="text-xs break-words bg-muted/50 p-1.5 rounded mt-0.5">{req.patientDetails.notes}</dd>
                                    </div>
                                  )}
                                  {req.patientDetails.allergies && (
                                    <div className="border-t pt-1">
                                      <dt className="text-muted-foreground text-xs uppercase font-bold text-destructive">Allergies / Cause:</dt>
                                      <dd className="text-xs break-words font-medium bg-destructive/5 p-1.5 rounded mt-0.5">{req.patientDetails.allergies}</dd>
                                    </div>
                                  )}
                                </dl>
                              ) : (
                                <p className="text-muted-foreground text-xs">No details</p>
                              )}
                            </div>
                          </PopoverContent>
                        </Popover>
                    </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-destructive hover:text-destructive"
                          title="Delete booking"
                          onClick={() => setDeleteTarget(req)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
      {/* Delete confirmation dialog */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && !deleting && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete booking?</AlertDialogTitle>
            <AlertDialogDescription>
              This will cancel and remove this booking from the list. You can&apos;t undo this action.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleting}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      </DashboardLayout>
  );
}
