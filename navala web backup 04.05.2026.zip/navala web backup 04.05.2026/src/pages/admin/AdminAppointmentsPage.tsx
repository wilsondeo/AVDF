import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { LayoutDashboard, Users, Calendar, CreditCard, BarChart3, Video, Phone, Receipt, CalendarCheck } from 'lucide-react';
import { format } from 'date-fns';
import { useEffect, useState } from 'react';
import { appointmentApi } from '@/services/api';
import type { AdminAppointment } from '@/services/api';
import { toast } from 'sonner';
import { adminNavigation } from '@/config/adminNavigation';

const statusVariant: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
  SCHEDULED: 'default',
  COMPLETED: 'secondary',
  CANCELLED: 'destructive',
};

export default function AdminAppointmentsPage() {
  const [appointments, setAppointments] = useState<AdminAppointment[]>([]);
  const [loading, setLoading] = useState(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const res = await appointmentApi.getAdminAppointments();
      if (res.success && res.data) {
        setAppointments(res.data);
      } else {
        toast.error(res.message || 'Failed to load appointments');
      }
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : 'Failed to load appointments');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <DashboardLayout navigation={adminNavigation} title="Appointments">
      <div className="space-y-6 animate-fade-in">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">All Appointments</h1>
          <p className="text-muted-foreground mt-1">View all confirmed appointments (patient, doctor, date, status)</p>
        </div>

        <Card className="shadow-card border-0">
          <CardHeader>
            <CardTitle>Appointments</CardTitle>
            <CardDescription>
              {loading ? 'Loading…' : `${appointments.length} appointment(s) found`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Appointment ID</TableHead>
                  <TableHead>Patient</TableHead>
                  <TableHead>Doctor</TableHead>
                  <TableHead>Service</TableHead>
                  <TableHead>Request ID</TableHead>
                  <TableHead>Date / Time</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {appointments.length === 0 && !loading && (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                      No appointments yet. Assign a doctor from Bookings to create appointments.
                    </TableCell>
                  </TableRow>
                )}
                {appointments.map((apt) => (
                  <TableRow key={apt.appointmentUuid}>
                    <TableCell className="font-mono text-xs">#{apt.appointmentUuid.slice(0, 8)}</TableCell>
                    <TableCell className="font-medium">
                      {apt.request?.familyMember
                        ? (
                          <div className="flex flex-col">
                            <span>{apt.request.familyMember.firstName} {apt.request.familyMember.lastName}</span>
                            <span className="text-xs text-muted-foreground">(Family: {apt.request.familyMember.relationship})</span>
                          </div>
                        )
                        : apt.patient
                          ? `${apt.patient.firstName} ${apt.patient.lastName}`
                          : '—'}
                    </TableCell>
                    <TableCell>{apt.doctor?.name ?? '—'}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        {apt.serviceType === 'TELEHEALTH' ? (
                          <Video className="h-4 w-4 text-accent" />
                        ) : (
                          <Phone className="h-4 w-4 text-primary" />
                        )}
                        {apt.serviceType === 'TELEHEALTH' ? 'Telehealth' : 'Emergency'}
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-xs">
                      {apt.request?.requestUuid ? `#${apt.request.requestUuid.slice(0, 8)}` : '—'}
                    </TableCell>
                    <TableCell>
                      {apt.appointmentDate ? (
                        <div className="flex flex-col gap-1.5 text-xs min-w-[200px]">
                          <div className="flex items-center justify-between gap-2 border-b pb-1">
                            <span className="text-muted-foreground w-12">Patient:</span>
                            <span className="font-medium whitespace-nowrap" title={apt.request?.timezone || 'UTC'}>
                              {new Date(apt.appointmentDate).toLocaleString('en-US', { timeZone: apt.request?.timezone || 'UTC', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: true })}
                            </span>
                          </div>
                          <div className="flex items-center justify-between gap-2 pt-0.5">
                            <span className="text-accent/80 font-medium w-12">Doctor:</span>
                            <span className="font-bold text-accent whitespace-nowrap" title={apt.doctor?.timezone || 'UTC'}>
                              {new Date(apt.appointmentDate).toLocaleString('en-US', { timeZone: apt.doctor?.timezone || 'UTC', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: true })}
                            </span>
                          </div>
                        </div>
                      ) : (
                        '—'
                      )}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {format(new Date(apt.createdAt), 'MMM dd, yyyy')}
                    </TableCell>
                    <TableCell>
                      <Badge variant={statusVariant[apt.status] ?? 'outline'}>{apt.status}</Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
