import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { NotificationSettingsCard } from '@/components/settings/NotificationSettingsCard';
import { LayoutDashboard, Users, CreditCard, FileText, User, Mail, Shield } from 'lucide-react';
import { useState, useEffect } from 'react';
import { userProfileApi, type UserProfile } from '@/services/api';
import { toast } from 'sonner';
import { adminNavigation } from '@/config/adminNavigation';

export default function AdminProfilePage() {
  const { currentUser } = useAppStore();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        setLoading(true);
        const res = await userProfileApi.getProfile();
        if (!cancelled && res.success && res.data) setProfile(res.data);
      } catch {
        if (!cancelled) toast.error('Failed to load profile');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  const fullName = profile
    ? `${profile.firstName ?? ''} ${profile.lastName ?? ''}`.trim()
    : currentUser?.name ?? 'Admin';
  const email = profile?.email ?? currentUser?.email ?? '—';
  const initials = fullName
    .split(/\s+/)
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2) || 'A';

  return (
    <DashboardLayout navigation={adminNavigation} title="Profile Settings">
      <div className="space-y-6 animate-fade-in max-w-2xl">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Profile Settings</h1>
          <p className="text-muted-foreground mt-1">Your account and notification preferences</p>
        </div>

        <Card className="shadow-card border-0">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <User className="h-5 w-5 text-accent" />
              Account
            </CardTitle>
            <CardDescription>Your admin account details</CardDescription>
          </CardHeader>
          <CardContent className="flex items-center gap-4">
            {loading ? (
              <p className="text-sm text-muted-foreground">Loading…</p>
            ) : (
              <>
                <Avatar className="h-14 w-14 border-2 border-border">
                  <AvatarFallback className="bg-primary/10 text-primary text-lg">{initials}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold text-foreground">{fullName}</p>
                  <p className="text-sm text-muted-foreground flex items-center gap-1.5 mt-0.5">
                    <Mail className="h-4 w-4" />
                    {email}
                  </p>
                  <Badge variant="secondary" className="mt-2 flex items-center gap-1 w-fit">
                    <Shield className="h-3 w-3" />
                    Admin
                  </Badge>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <NotificationSettingsCard />
      </div>
    </DashboardLayout>
  );
}
