import React, { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { adminNavigation } from '@/config/adminNavigation';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  Globe,
  MapPin,
  DollarSign,
  CheckCircle2,
  XCircle,
  Settings2
} from 'lucide-react';
import {
  locationApi,
  systemConfigApi,
  DBLocation,
  SystemConfig
} from '@/services/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const AdminLocationsPage = () => {
  const [locations, setLocations] = useState<DBLocation[]>([]);
  const [configs, setConfigs] = useState<SystemConfig[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingLocation, setEditingLocation] = useState<DBLocation | null>(null);
  const { toast } = useToast();

  // Form State
  const [formData, setFormData] = useState({
    country: '',
    city: '',
    state: '',
    taxValue: 0,
    taxType: 'FIXED' as 'FIXED' | 'PERCENTAGE',
    isTaxEnabled: true
  });

  // Global Settings State
  const [globalSettings, setGlobalSettings] = useState({
    is_location_tax_enabled: true,
    multi_city_tax_strategy: 'SUM'
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [locRes, configRes] = await Promise.all([
        locationApi.getAll(),
        systemConfigApi.getAll()
      ]);

      if (locRes.success && locRes.data) {
        setLocations(locRes.data);
      }

      if (configRes.success && configRes.data) {
        setConfigs(configRes.data);
        const mappedSettings = { ...globalSettings };
        configRes.data.forEach(c => {
          if (c.configKey === 'is_location_tax_enabled') mappedSettings.is_location_tax_enabled = c.configValue === 'true';
          if (c.configKey === 'multi_city_tax_strategy') mappedSettings.multi_city_tax_strategy = c.configValue;
        });
        setGlobalSettings(mappedSettings);
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSaveLocation = async () => {
    try {
      let res;
      if (editingLocation) {
        res = await locationApi.update(editingLocation.id, formData);
      } else {
        res = await locationApi.create(formData);
      }

      if (res.success) {
        toast({
          title: "Success",
          description: `Location ${editingLocation ? 'updated' : 'added'} successfully`
        });
        setIsAddDialogOpen(false);
        setEditingLocation(null);
        setFormData({ country: '', city: '', state: '', taxValue: Number(0), isTaxEnabled: true });
        fetchData();
      }
    } catch (error) {
      toast({ title: "Error", description: "Operation failed", variant: "destructive" });
    }
  };

  const handleDeleteLocation = async (id: number) => {
    if (!window.confirm("Are you sure you want to delete this location?")) return;
    try {
      const res = await locationApi.delete(id);
      if (res.success) {
        toast({ title: "Deleted", description: "Location removed" });
        fetchData();
      }
    } catch (error) {
      toast({ title: "Error", description: "Delete failed", variant: "destructive" });
    }
  };

  const handleUpdateGlobalSettings = async (updates: Partial<typeof globalSettings>) => {
    const newSettings = { ...globalSettings, ...updates };
    setGlobalSettings(newSettings);
    try {
      const res = await systemConfigApi.updateTaxSettings(newSettings);
      if (res.success) {
        toast({ title: "Updated", description: "Global tax settings saved" });
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to update settings", variant: "destructive" });
    }
  };

  const filteredLocations = locations.filter(loc =>
    loc.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
    loc.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
    loc.state.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <DashboardLayout navigation={adminNavigation} title="Location & Tax Manager">
      <div className="p-6 space-y-8 animate-in fade-in duration-500">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Location & Tax Manager</h1>
            <p className="text-muted-foreground">Manage destinations and government tax rates.</p>
          </div>

          <Dialog open={isAddDialogOpen} onOpenChange={(open) => {
            setIsAddDialogOpen(open);
            if (!open) {
              setEditingLocation(null);
              setFormData({ country: '', city: '', state: '', taxValue: Number(0), taxType: 'FIXED', isTaxEnabled: true });
            }
          }}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="mr-2 h-4 w-4" /> Add Destination
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>{editingLocation ? 'Edit Destination' : 'Add New Destination'}</DialogTitle>
                <DialogDescription>
                  Set the city, state, country and its associated tax rate.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="city" className="text-right">City</Label>
                  <Input id="city" value={formData.city} onChange={e => setFormData({ ...formData, city: e.target.value })} className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="state" className="text-right">State</Label>
                  <Input id="state" value={formData.state} onChange={e => setFormData({ ...formData, state: e.target.value })} className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="country" className="text-right">Country</Label>
                  <Input id="country" value={formData.country} onChange={e => setFormData({ ...formData, country: e.target.value })} className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="taxType" className="text-right">Tax Type</Label>
                  <div className="col-span-3">
                    <Select
                      value={formData.taxType}
                      onValueChange={(val: 'FIXED' | 'PERCENTAGE') => setFormData({ ...formData, taxType: val })}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="FIXED">Fixed Amount ($)</SelectItem>
                        <SelectItem value="PERCENTAGE">Percentage (%)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="tax" className="text-right">
                    {formData.taxType === 'FIXED' ? 'Tax ($)' : 'Tax (%)'}
                  </Label>
                  <Input id="tax" type="number" value={formData.taxValue} onChange={e => setFormData({ ...formData, taxValue: parseFloat(e.target.value) })} className="col-span-3" />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label className="text-right">Enabled</Label>
                  <Switch checked={formData.isTaxEnabled} onCheckedChange={checked => setFormData({ ...formData, isTaxEnabled: checked })} />
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleSaveLocation}>Save Destination</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <Tabs defaultValue="locations" className="w-full">
          <TabsList className="grid w-full grid-cols-2 max-w-[400px] mb-6">
            <TabsTrigger value="locations">Destinations</TabsTrigger>
            <TabsTrigger value="settings">Global Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="locations" className="space-y-6">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Destination List</CardTitle>
                    <CardDescription>Total {locations.length} cities available.</CardDescription>
                  </div>
                  <div className="relative w-64">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search locations..."
                      className="pl-8"
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <div className="relative w-full overflow-auto">
                    <table className="w-full caption-bottom text-sm">
                      <thead className="[&_tr]:border-b bg-muted/50">
                        <tr className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                          <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Location</th>
                          <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">State</th>
                          <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Country</th>
                          <th className="h-12 px-4 text-center align-middle font-medium text-muted-foreground">Tax Rate</th>
                          <th className="h-12 px-4 text-center align-middle font-medium text-muted-foreground">Status</th>
                          <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="[&_tr:last-child]:border-0">
                        {loading ? (
                          <tr><td colSpan={6} className="h-24 text-center">Loading...</td></tr>
                        ) : filteredLocations.length === 0 ? (
                          <tr><td colSpan={6} className="h-24 text-center">No locations found.</td></tr>
                        ) : filteredLocations.map(loc => (
                          <tr key={loc.id} className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                            <td className="p-4 align-middle font-medium">
                              <div className="flex items-center">
                                <MapPin className="mr-2 h-4 w-4 text-primary" />
                                {loc.city}
                              </div>
                            </td>
                            <td className="p-4 align-middle">{loc.state}</td>
                            <td className="p-4 align-middle">
                              <div className="flex items-center">
                                <Globe className="mr-2 h-4 w-4 text-muted-foreground" />
                                {loc.country}
                              </div>
                            </td>
                            <td className="p-4 align-middle text-center">
                              <Badge variant="outline" className="font-mono bg-primary/5">
                                {loc.taxType === 'PERCENTAGE' ? `${Number(loc.taxValue)}%` : `$${(Number(loc.taxValue) || 0).toFixed(2)}`}
                              </Badge>
                            </td>
                            <td className="p-4 align-middle text-center">
                              {loc.isTaxEnabled ? (
                                <Badge variant="secondary" className="bg-green-100 text-green-700 hover:bg-green-100 border-green-200">
                                  <CheckCircle2 className="mr-1 h-3 w-3" /> Enabled
                                </Badge>
                              ) : (
                                <Badge variant="secondary" className="bg-red-100 text-red-700 hover:bg-red-100 border-red-200">
                                  <XCircle className="mr-1 h-3 w-3" /> Disabled
                                </Badge>
                              )}
                            </td>
                            <td className="p-4 align-middle text-right">
                              <div className="flex justify-end gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => {
                                    setEditingLocation(loc);
                                    setFormData({
                                      city: loc.city,
                                      state: loc.state,
                                      country: loc.country,
                                      taxValue: loc.taxValue,
                                      taxType: loc.taxType || 'FIXED',
                                      isTaxEnabled: loc.isTaxEnabled
                                    });
                                    setIsAddDialogOpen(true);
                                  }}
                                >
                                  <Edit2 className="h-4 w-4 text-muted-foreground" />
                                </Button>
                                <Button variant="ghost" size="icon" onClick={() => handleDeleteLocation(loc.id)}>
                                  <Trash2 className="h-4 w-4 text-red-500" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <div className="grid gap-6 md:grid-cols-2">
              <Card className="border-primary/20 shadow-lg">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Settings2 className="h-5 w-5 text-primary" />
                    <CardTitle>Global Tax Controls</CardTitle>
                  </div>
                  <CardDescription>Configure how taxes are applied site-wide.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50 border">
                    <div className="space-y-0.5">
                      <Label className="text-base">Calculate Taxes</Label>
                      <p className="text-sm text-muted-foreground">Toggle tax visibility for all users.</p>
                    </div>
                    <Switch
                      checked={globalSettings.is_location_tax_enabled}
                      onCheckedChange={(checked) => handleUpdateGlobalSettings({ is_location_tax_enabled: checked })}
                    />
                  </div>

                  <div className="space-y-3 p-4 rounded-lg border bg-card">
                    <Label>Multi-City Calculation Mode</Label>
                    <Select
                      value={globalSettings.multi_city_tax_strategy}
                      onValueChange={(val) => handleUpdateGlobalSettings({ multi_city_tax_strategy: val })}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select Strategy" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="SUM">Cumulative (Sum of Unique Countries)</SelectItem>
                        <SelectItem value="MAX">Highest Rate (Most Expensive Country)</SelectItem>
                        <SelectItem value="PRIMARY">Primary Destination Only</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground bg-muted p-2 rounded italic">
                      {globalSettings.multi_city_tax_strategy === 'SUM' && "Users visit multiple cities but only pay tax once per country."}
                      {globalSettings.multi_city_tax_strategy === 'MAX' && "Users are only charged the tax rate of the most expensive country selected."}
                      {globalSettings.multi_city_tax_strategy === 'PRIMARY' && "Only the first city in the user's list determines the tax."}
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-primary/5 border-dashed border-primary/30">
                <CardHeader>
                  <CardTitle className="text-primary">System Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="mt-1 bg-primary/10 p-2 rounded-full">
                      <DollarSign className="h-4 w-4 text-primary" />
                    </div>
                    <div className="text-sm">
                      <p className="font-semibold">Current Logic</p>
                      <p className="text-muted-foreground">Taxes are automatically added to the Plan price before purchase if enabled.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="mt-1 bg-primary/10 p-2 rounded-full">
                      <CheckCircle2 className="h-4 w-4 text-primary" />
                    </div>
                    <div className="text-sm">
                      <p className="font-semibold">Compliance</p>
                      <p className="text-muted-foreground">Transparency is maintained by showing a breakdown on the checkout page.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
};

export default AdminLocationsPage;
