import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  LayoutDashboard,
  Users,
  Calendar,
  CalendarCheck,
  CreditCard,
  BarChart3,
  Receipt,
  Search,
  DollarSign,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  User,
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { adminApi, planApi, Transaction, TransactionStats, Plan } from '@/services/api';
import { adminNavigation } from '@/config/adminNavigation';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

export default function AdminTransactionsPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [stats, setStats] = useState<TransactionStats>({
    totalRevenue: 0,
    thisMonthRevenue: 0,
    refundedAmount: 0,
    totalTransactions: 0
  });
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('SUCCESS'); // Default to SUCCESS
  const [liveOnly, setLiveOnly] = useState(true); // Default to live only
  const [planFilter, setPlanFilter] = useState('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [plans, setPlans] = useState<Plan[]>([]);
  const [limit] = useState(20);
  const [offset, setOffset] = useState(0);
  const [totalCount, setTotalCount] = useState(0);

  // Debounce search term
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
      setOffset(0); // Reset to first page on search change
    }, 500);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [txnResponse, statsResponse] = await Promise.all([
        adminApi.getTransactions({
          limit,
          offset,
          search: debouncedSearchTerm,
          status: statusFilter,
          liveOnly,
          planId: planFilter,
          startDate: startDate || undefined,
          endDate: endDate || undefined,
        }),
        adminApi.getTransactionStats({
          liveOnly,
          planId: planFilter,
          startDate: startDate || undefined,
          endDate: endDate || undefined,
        })
      ]);

      if (txnResponse.success && txnResponse.data) {
        setTransactions(txnResponse.data.payments);
        setTotalCount(txnResponse.data.count);
      }

      if (statsResponse.success && statsResponse.data) {
        setStats(statsResponse.data);
      }
    } catch (error) {
      console.error('Failed to fetch transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [debouncedSearchTerm, statusFilter, liveOnly, planFilter, startDate, endDate, offset, limit]);

  useEffect(() => {
    planApi.getAllPlans().then(res => {
      if (res.success && res.data) {
        setPlans(res.data.plans);
      }
    });
  }, []);

  return (
    <DashboardLayout navigation={adminNavigation} title="Transactions">
      <div className="space-y-6 animate-fade-in">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Transactions</h1>
          <p className="text-muted-foreground mt-1">Track all payment transactions</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Total Revenue', value: `$${stats.totalRevenue.toFixed(2)}`, icon: DollarSign, color: 'text-success', trend: 'Total', trendUp: true },
            { label: 'This Month', value: `$${stats.thisMonthRevenue.toFixed(2)}`, icon: TrendingUp, color: 'text-primary', trend: 'Month', trendUp: true },
            { label: 'Transactions', value: stats.totalTransactions, icon: Receipt, color: 'text-accent', trend: 'Count', trendUp: true },
            { label: 'Refunded', value: `$${stats.refundedAmount.toFixed(2)}`, icon: ArrowDownRight, color: 'text-destructive', trend: 'Total', trendUp: false },
          ].map((stat) => (
            <Card key={stat.label} className="shadow-card border-0">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                      <stat.icon className={`h-5 w-5 ${stat.color}`} />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">{stat.label}</p>
                      <p className="text-xl font-bold">{stat.value}</p>
                    </div>
                  </div>
                  <div className={`flex items-center text-xs ${stat.trendUp ? 'text-success' : 'text-destructive'}`}>
                    {/* Static trend for now as backend doesn't provide trend % yet */}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by transaction ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={(val) => { setStatusFilter(val); setOffset(0); }}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="SUCCESS">Completed</SelectItem>
              <SelectItem value="PENDING">Pending</SelectItem>
              <SelectItem value="FAILED">Failed</SelectItem>
            </SelectContent>
          </Select>

          <div className="flex items-center gap-2">
            <Input
              type="date"
              value={startDate}
              onChange={(e) => { setStartDate(e.target.value); setOffset(0); }}
              className="w-40"
              placeholder="Start Date"
            />
            <span className="text-muted-foreground">-</span>
            <Input
              type="date"
              value={endDate}
              onChange={(e) => { setEndDate(e.target.value); setOffset(0); }}
              className="w-40"
              placeholder="End Date"
            />
          </div>
          
          <Select value={planFilter} onValueChange={(val) => { setPlanFilter(val); setOffset(0); }}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="All Plans" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Plans</SelectItem>
              {plans.map(p => (
                <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex items-center space-x-2 bg-background border rounded-md px-3 py-2 shadow-sm whitespace-nowrap">
            <Switch
              id="live-mode"
              checked={liveOnly}
              onCheckedChange={(checked) => { setLiveOnly(checked); setOffset(0); }}
            />
            <Label htmlFor="live-mode" className="cursor-pointer text-sm font-medium">
              Live Data Only
            </Label>
          </div>
        </div>

        {/* Transactions Table */}
        <Card className="shadow-card border-0">
          <CardHeader>
            <CardTitle>Transaction History</CardTitle>
            <CardDescription>{totalCount} transactions found</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Transaction ID</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Patient</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8">Loading transactions...</TableCell>
                  </TableRow>
                ) : transactions.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8">No transactions found</TableCell>
                  </TableRow>
                ) : (
                  transactions.map((txn) => (
                    <TableRow key={txn.id}>
                      <TableCell className="font-mono text-xs" title={txn.stripePaymentIntentId}>
                        {/* Display internal ID or shorten stripe ID */}
                        {txn.stripePaymentIntentId.slice(0, 18)}...
                      </TableCell>
                      <TableCell>{format(new Date(txn.createdAt), 'MMM dd, yyyy HH:mm')}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                            <span className="text-primary text-xs font-semibold">
                              {txn.User?.firstName ? txn.User.firstName.charAt(0) : '?'}
                            </span>
                          </div>
                          <span className="font-medium">
                            {txn.User ? `${txn.User.firstName} ${txn.User.lastName}` : 'Unknown User'}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{txn.Plan?.name || 'Unknown Plan'}</Badge>
                      </TableCell>
                      <TableCell className="font-semibold">
                        {/* Amount is in cents */}
                        ${(txn.amount / 100).toFixed(2)} {txn.currency.toUpperCase()}
                      </TableCell>
                      <TableCell>
                        <span className="text-xs uppercase text-muted-foreground">{txn.type}</span>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={txn.status === 'SUCCESS' ? 'default' : txn.status === 'PENDING' ? 'secondary' : 'destructive'}
                          className={txn.status === 'SUCCESS' ? 'bg-success' : ''}
                        >
                          {txn.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>

            {/* Pagination controls could go here */}
            <div className="flex items-center justify-end space-x-2 py-4">
              <button
                className="px-3 py-1 text-sm border rounded hover:bg-muted disabled:opacity-50"
                onClick={() => setOffset(Math.max(0, offset - limit))}
                disabled={offset === 0 || loading}
              >
                Previous
              </button>
              <div className="text-xs text-muted-foreground">
                Page {Math.floor(offset / limit) + 1} of {Math.ceil(totalCount / limit)}
              </div>
              <button
                className="px-3 py-1 text-sm border rounded hover:bg-muted disabled:opacity-50"
                onClick={() => setOffset(offset + limit)}
                disabled={offset + limit >= totalCount || loading}
              >
                Next
              </button>
            </div>

          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
