import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { LayoutDashboard, Users, Calendar, CalendarCheck, CreditCard, BarChart3, Receipt, Plus, Edit, Check, Video, Phone, DollarSign, Loader2, User } from 'lucide-react';
import { useState, useEffect } from 'react';
import { planApi, type Plan } from '@/services/api';
import { toast } from 'sonner';
import { adminNavigation } from '@/config/adminNavigation';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

type PlanCategory = 'INDIVIDUAL' | 'FAMILY_2' | 'FAMILY_3_4';

export default function AdminNewPlansPage() {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<Plan | null>(null);
  const [formData, setFormData] = useState({
    // New structured fields for plan type & benefits
    planCategory: 'INDIVIDUAL' as PlanCategory,
    telehealthVisits: '',
    inPersonVisits: '',
    prescriptionCoverage: '',
    includesSpecialtyCare: true,
    // Legacy fields still used by API
    name: '',
    price: 0,
    validityDays: 30,
    description: '',
    isActive: true,
  });

  // Helper to ensure services/features are arrays
  const normalizePlan = (plan: Plan): Plan => {
    return {
      ...plan,
      services: Array.isArray(plan.services) 
        ? plan.services 
        : (typeof plan.services === 'string' ? JSON.parse(plan.services) : []),
      features: Array.isArray(plan.features)
        ? plan.features
        : (typeof plan.features === 'string' ? JSON.parse(plan.features) : []),
      price: typeof plan.price === 'string' ? parseFloat(plan.price) : (plan.price || 0),
    };
  };

  // Load plans on mount
  useEffect(() => {
    loadPlans();
  }, []);

  const loadPlans = async () => {
    try {
      setLoading(true);
      const response = await planApi.getAllPlans();
      if (response.success && response.data && Array.isArray(response.data.plans)) {
        // Normalize plans to ensure services/features are arrays
        const normalizedPlans = response.data.plans.map(normalizePlan);
        setPlans(normalizedPlans);
      } else {
        toast.error(response.message || 'Failed to load plans');
        setPlans([]);
      }
    } catch (error) {
      toast.error('An error occurred while loading plans');
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePlan = async () => {
    if (formData.price <= 0 || formData.validityDays < 1) {
      toast.error('Please enter a valid price and validity in days');
      return;
    }

    const tele = formData.telehealthVisits.trim();
    const inPerson = formData.inPersonVisits.trim();
    const presc = formData.prescriptionCoverage.trim();

    const services: string[] = [];
    if (tele && tele !== '0') services.push('TELEHEALTH');
    if (inPerson && inPerson !== '0') services.push('EMERGENCY');

    if (services.length === 0) {
      toast.error('Please set telehealth or in‑person visits greater than 0');
      return;
    }

    const baseFeatures = [
      `Telehealth visits: ${tele || '0'}`,
      `In-person visits: ${inPerson || '0'}`,
      `Prescription coverage: $${presc || '0'}`,
      `Specialty care coordination: ${formData.includesSpecialtyCare ? 'Included' : 'Not included'}`,
    ];

    const allFeatures = baseFeatures;

    const categoryLabelMap: Record<PlanCategory, string> = {
      INDIVIDUAL: 'Individual',
      FAMILY_2: 'Family of 2',
      FAMILY_3_4: 'Family of 3-4',
    };

    const generatedName = `${categoryLabelMap[formData.planCategory]}`;
    const finalName = formData.name.trim() || generatedName;

    try {
      const response = await planApi.createPlan({
        name: finalName,
        price: formData.price,
        validityDays: formData.validityDays,
        description: formData.description,
        services,
        features: allFeatures,
        isActive: formData.isActive,
      });

      if (response.success) {
        toast.success('Plan created successfully');
        setIsDialogOpen(false);
        resetForm();
        loadPlans();
      } else {
        toast.error(response.message || 'Failed to create plan');
      }
    } catch (error) {
      toast.error('An error occurred while creating plan');
    }
  };

  const handleUpdatePlan = async (planId: string, updates: Partial<Plan>) => {
    try {
      const response = await planApi.updatePlan(planId, updates);
      if (response.success) {
        toast.success('Plan updated successfully');
        loadPlans();
      } else {
        toast.error(response.message || 'Failed to update plan');
      }
    } catch (error) {
      toast.error('An error occurred while updating plan');
    }
  };

  const handleDeletePlan = async (planId: string) => {
    if (!confirm('Are you sure you want to delete this plan?')) {
      return;
    }

    try {
      const response = await planApi.deletePlan(planId);
      if (response.success) {
        toast.success('Plan deleted successfully');
        loadPlans();
      } else {
        toast.error(response.message || 'Failed to delete plan');
      }
    } catch (error) {
      toast.error('An error occurred while deleting plan');
    }
  };

  const handleEditPlan = (plan: Plan) => {
    const normalizedPlan = normalizePlan(plan);
    setEditingPlan(normalizedPlan);
    setFormData({
      planCategory: 'INDIVIDUAL',
      telehealthVisits: '',
      inPersonVisits: '',
      prescriptionCoverage: '',
      includesSpecialtyCare: true,
      name: normalizedPlan.name,
      price: typeof normalizedPlan.price === 'string' ? parseFloat(normalizedPlan.price) : normalizedPlan.price,
      validityDays: normalizedPlan.validityDays,
      description: normalizedPlan.description || '',
      isActive: normalizedPlan.isActive,
      });
    setIsDialogOpen(true);
  };

  const handleSaveEdit = async () => {
    if (!editingPlan) return;

    if (formData.price <= 0 || formData.validityDays < 1) {
      toast.error('Please enter a valid price and validity in days');
      return;
    }

    const tele = formData.telehealthVisits.trim();
    const inPerson = formData.inPersonVisits.trim();
    const presc = formData.prescriptionCoverage.trim();

    const services: string[] = [];
    if (tele && tele !== '0') services.push('TELEHEALTH');
    if (inPerson && inPerson !== '0') services.push('EMERGENCY');

    if (services.length === 0) {
      toast.error('Please set telehealth or in‑person visits greater than 0');
      return;
    }

    const baseFeatures = [
      `Telehealth visits: ${tele || '0'}`,
      `In-person visits: ${inPerson || '0'}`,
      `Prescription coverage: $${presc || '0'}`,
      `Specialty care coordination: ${formData.includesSpecialtyCare ? 'Included' : 'Not included'}`,
    ];
    const allFeatures = baseFeatures;

    const categoryLabelMap: Record<PlanCategory, string> = {
      INDIVIDUAL: 'Individual',
      FAMILY_2: 'Family of 2',
      FAMILY_3_4: 'Family of 3-4',
    };
    const generatedName = `${categoryLabelMap[formData.planCategory]}`;
    const finalName = formData.name.trim() || generatedName;

    try {
      const response = await planApi.updatePlan(editingPlan.planId, {
        name: finalName,
        price: formData.price,
        validityDays: formData.validityDays,
        description: formData.description,
        services,
        features: allFeatures,
        isActive: formData.isActive,
      });

      if (response.success) {
        toast.success('Plan updated successfully');
      setIsDialogOpen(false);
        setEditingPlan(null);
        resetForm();
        loadPlans();
      } else {
        toast.error(response.message || 'Failed to update plan');
      }
    } catch (error) {
      toast.error('An error occurred while updating plan');
    }
  };

  const resetForm = () => {
    setFormData({
      planCategory: 'INDIVIDUAL',
      telehealthVisits: '',
      inPersonVisits: '',
      prescriptionCoverage: '',
      includesSpecialtyCare: true,
      name: '',
      price: 0,
      validityDays: 30,
      description: '',
      isActive: true,
    });
    setEditingPlan(null);
  };

  const activePlans = plans.filter(p => p.isActive);
  const totalPlans = plans.length;

  type FilterKey = 'INDIVIDUAL' | 'FAMILY_2' | 'FAMILY_3_4';
  const [filter, setFilter] = useState<FilterKey>('INDIVIDUAL');

  const getCategoryFromPlan = (plan: Plan): FilterKey => {
    const name = (plan.name || '').toLowerCase();
    if (name.includes('family of 3-4')) return 'FAMILY_3_4';
    if (name.includes('family of 2')) return 'FAMILY_2';
    return 'INDIVIDUAL';
  };

  const filteredPlans = plans.filter((p) => getCategoryFromPlan(p) === filter);

  if (loading) {
    return (
      <DashboardLayout navigation={adminNavigation} title="Plans Management">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout navigation={adminNavigation} title="Plans Management">
      <div className="space-y-6 animate-fade-in">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">Plans Management</h1>
            <p className="text-muted-foreground mt-1">Manage subscription plans and pricing</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open) {
              resetForm();
            }
          }}>
            <DialogTrigger asChild>
              <Button><Plus className="h-4 w-4 mr-2" /> Create Plan</Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>{editingPlan ? 'Edit Plan' : 'Create New Plan'}</DialogTitle>
                <DialogDescription>
                  {editingPlan ? 'Update plan details' : 'Add a new subscription plan to the platform'}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto">
                <div className="space-y-2">
                  <Label>Plan Type</Label>
                  <select
                    className="border rounded-md h-9 px-2 text-sm bg-background w-full max-w-xs"
                    value={formData.planCategory}
                    onChange={(e) =>
                      setFormData({ ...formData, planCategory: e.target.value as PlanCategory })
                    }
                  >
                    <option value="INDIVIDUAL">Individual plan</option>
                    <option value="FAMILY_2">Family of 2</option>
                    <option value="FAMILY_3_4">Family of 3-4</option>
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Plan Name (optional)</Label>
                    <Input
                      placeholder="If empty, name is generated from type + tier"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Price ($) *</Label>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="100"
                      value={formData.price || ''}
                      onChange={(e) =>
                        setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })
                      }
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Validity (Days) *</Label>
                  <Input
                    type="number"
                    value={formData.validityDays}
                    onChange={(e) => setFormData({ ...formData, validityDays: parseInt(e.target.value) || 30 })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea
                    placeholder="Plan description..."
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Telehealth visits *</Label>
                    <Input
                      placeholder="e.g. 2 or 4"
                      value={formData.telehealthVisits}
                      onChange={(e) => setFormData({ ...formData, telehealthVisits: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>In-person visits *</Label>
                    <Input
                      placeholder="e.g. 0, 2, 4"
                      value={formData.inPersonVisits}
                      onChange={(e) => setFormData({ ...formData, inPersonVisits: e.target.value })}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Prescription coverage ($)</Label>
                    <Input
                      placeholder="e.g. 150"
                      value={formData.prescriptionCoverage}
                      onChange={(e) =>
                        setFormData({ ...formData, prescriptionCoverage: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-2 flex items-center gap-2">
                    <Switch
                      checked={formData.includesSpecialtyCare}
                      onCheckedChange={(checked) =>
                        setFormData({ ...formData, includesSpecialtyCare: checked })
                      }
                    />
                    <Label>Specialty care coordination included</Label>
                  </div>
                </div>
                {/* Features are auto-generated from telehealth, in-person, prescription, and specialty-care fields. */}
                <div className="flex items-center gap-2">
                  <Switch
                    checked={formData.isActive}
                    onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                  />
                  <Label>Active</Label>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => {
                  setIsDialogOpen(false);
                  resetForm();
                }}>Cancel</Button>
                <Button onClick={editingPlan ? handleSaveEdit : handleCreatePlan}>
                  {editingPlan ? 'Save Changes' : 'Create Plan'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filter tabs */}
        <Tabs value={filter} onValueChange={(v) => setFilter(v as FilterKey)} className="w-full">
          <div className="flex justify-center">
            <TabsList className="inline-flex h-9 items-center justify-center rounded-full bg-muted p-1 mb-4 gap-1">
              <TabsTrigger value="INDIVIDUAL" className="px-4 text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground rounded-full">
                Individual
              </TabsTrigger>
              <TabsTrigger value="FAMILY_2" className="px-4 text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground rounded-full">
                Family of 2
              </TabsTrigger>
              <TabsTrigger value="FAMILY_3_4" className="px-4 text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground rounded-full">
                Family of 3–4
              </TabsTrigger>
            </TabsList>
          </div>
        </Tabs>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Total Plans', value: totalPlans, icon: CreditCard, color: 'text-primary' },
            { label: 'Active Plans', value: activePlans.length, icon: Check, color: 'text-success' },
            { label: 'Inactive Plans', value: totalPlans - activePlans.length, icon: CreditCard, color: 'text-muted-foreground' },
            { label: 'Total Revenue', value: `$${plans.reduce((acc, p) => {
              const price = typeof p.price === 'string' ? parseFloat(p.price) : (p.price || 0);
              return acc + price;
            }, 0).toFixed(2)}`, icon: DollarSign, color: 'text-warning' },
          ].map((stat) => (
            <Card key={stat.label} className="shadow-card border-0">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                    <stat.icon className={`h-5 w-5 ${stat.color}`} />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">{stat.label}</p>
                    <p className="text-xl font-bold">{stat.value}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Plans Grid */}
        {filteredPlans.length === 0 ? (
          <Card className="shadow-card border-0">
            <CardContent className="p-12 text-center">
              <CreditCard className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No plans yet</h3>
              <p className="text-muted-foreground mb-4">Create your first plan to get started</p>
              <Button onClick={() => setIsDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" /> Create Plan
              </Button>
            </CardContent>
          </Card>
        ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPlans.map((plan) => (
            <Card key={plan.id} className={`shadow-card border-0 ${!plan.isActive && 'opacity-60'}`}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{plan.name}</CardTitle>
                  <Switch
                    checked={plan.isActive}
                      onCheckedChange={(checked) => handleUpdatePlan(plan.planId, { isActive: checked })}
                  />
                </div>
                  <CardDescription>{plan.description || 'No description'}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-bold">${plan.price}</span>
                  <span className="text-muted-foreground">/ {plan.validityDays} days</span>
                </div>

                  <div className="flex gap-2 flex-wrap">
                    {Array.isArray(plan.services) ? (
                      plan.services.map((service) => (
                        <Badge key={service} variant="secondary" className="flex items-center gap-1">
                          {service === 'TELEHEALTH' && <Video className="h-3 w-3" />}
                          {service === 'EMERGENCY' && <Phone className="h-3 w-3" />}
                          {service}
                    </Badge>
                      ))
                    ) : (
                      <Badge variant="secondary">No services</Badge>
                  )}
                </div>

                <div className="space-y-2">
                    {Array.isArray(plan.features) && plan.features.length > 0 ? (
                      plan.features.slice(0, 4).map((feature, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm">
                      <Check className="h-4 w-4 text-success" />
                      <span>{feature}</span>
                    </div>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground">No features listed</p>
                    )}
                </div>

                <div className="pt-4 border-t flex items-center justify-between">
                  <div>
                      <p className="text-xs text-muted-foreground">Plan ID</p>
                      <p className="font-mono text-xs">{plan.planId}</p>
                  </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => handleEditPlan(plan)}>
                    <Edit className="h-4 w-4 mr-1" /> Edit
                  </Button>
                      <Button 
                        size="sm" 
                        variant="destructive" 
                        onClick={() => handleDeletePlan(plan.planId)}
                      >
                        Delete
                      </Button>
                    </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        )}
      </div>
    </DashboardLayout>
  );
}
