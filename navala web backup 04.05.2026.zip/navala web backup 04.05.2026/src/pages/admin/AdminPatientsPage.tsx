import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  LayoutDashboard,
  Users,
  Calendar,
  CalendarCheck,
  CreditCard,
  BarChart3,
  Search,
  Mail,
  Receipt,
  Eye,
  User,
  Phone,
  Stethoscope,
  Video,
  Pencil,
  MoreVertical,
  UserX,
  UserCheck,
  Loader2,
  Droplets,
  Globe2,
  Calendar as CalendarIcon,
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { adminPatientsApi, planApi, adminFamilyMembersApi, itineraryApi } from '@/services/api';
import type { AdminPatient, Plan, AdminUpdateUserPayload, FamilyMember, UserItineraryItem } from '@/services/api';
import { toast } from 'sonner';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { adminNavigation } from '@/config/adminNavigation';

function field(value: string | null | undefined, fallback = '—') {
  return value?.trim() || fallback;
}

export default function AdminPatientsPage() {
  const [patients, setPatients] = useState<AdminPatient[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [viewPatient, setViewPatient] = useState<AdminPatient | null>(null);
  const [editPatient, setEditPatient] = useState<AdminPatient | null>(null);
  const [editForm, setEditForm] = useState<AdminUpdateUserPayload>({});
  const [plans, setPlans] = useState<Plan[]>([]);
  const [selectedPlanId, setSelectedPlanId] = useState<string>('');
  const [planFilter, setPlanFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('active'); // default to 'active'
  const [granting, setGranting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [togglingStatus, setTogglingStatus] = useState<number | null>(null);
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([]);
  const [familyLoading, setFamilyLoading] = useState(false);
  const [userItineraries, setUserItineraries] = useState<UserItineraryItem[]>([]);
  const [itineraryLoading, setItineraryLoading] = useState(false);
  const [statusConfirm, setStatusConfirm] = useState<{ patient: AdminPatient; nextActive: boolean } | null>(null);
  const [itineraryModalPatient, setItineraryModalPatient] = useState<AdminPatient | null>(null);

  const loadPatients = async () => {
    try {
      setLoading(true);
      const res = await adminPatientsApi.getPatients();
      if (res.success && res.data) {
        setPatients(res.data.patients);
      } else {
        toast.error(res.message || 'Failed to load patients');
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to load patients');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPatients();
  }, []);

  useEffect(() => {
    planApi.getAllPlans().then((res) => {
      if (res.success && res.data?.plans) setPlans(res.data.plans);
    });
  }, []);

  useEffect(() => {
    if (viewPatient || editPatient) {
      setSelectedPlanId('');
      planApi.getAllPlans().then((res) => {
        if (res.success && res.data?.plans) setPlans(res.data.plans);
      });
    }
  }, [viewPatient, editPatient]);

  useEffect(() => {
    if (editPatient) {
      setEditForm({
        firstName: editPatient.firstName,
        lastName: editPatient.lastName,
        phone: editPatient.phone ?? undefined,
        dateOfBirth: editPatient.dateOfBirth ?? undefined,
        streetAddress: editPatient.streetAddress ?? undefined,
        city: editPatient.city ?? undefined,
        state: editPatient.state ?? undefined,
        zipCode: editPatient.zipCode ?? undefined,
        country: editPatient.country ?? undefined,
        emergencyContactName: editPatient.emergencyContactName ?? undefined,
        emergencyContactPhone: editPatient.emergencyContactPhone ?? undefined,
        emergencyContactRelationship: editPatient.emergencyContactRelationship ?? undefined,
        bloodType: editPatient.bloodType ?? undefined,
        gender: editPatient.gender ?? undefined,
        isActive: editPatient.isActive,
      });
    }
  }, [editPatient]);

  const filteredPatients = patients.filter((p) => {
    const matchesSearch =
      `${p.firstName} ${p.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.phone && p.phone.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesPlan =
      planFilter === 'all' || (planFilter === 'none' ? !p.activePlan : p.activePlan?.planId === planFilter);
    const matchesStatus =
      statusFilter === 'all' || (statusFilter === 'active' && p.isActive) || (statusFilter === 'inactive' && !p.isActive);
    return matchesSearch && matchesPlan && matchesStatus;
  });

  const withActivePlan = patients.filter((p) => p.activePlan).length;
  const totalAppointments = patients.reduce((sum, p) => sum + p.appointmentCount, 0);
  const totalCompleted = patients.reduce((sum, p) => sum + p.completedCount, 0);

  const handleSaveEdit = async () => {
    if (!editPatient) return;
    setSaving(true);
    try {
      const res = await adminPatientsApi.updateUser(editPatient.id, editForm);
      if (res.success && res.data) {
        toast.success('Patient updated');
        setPatients((prev) => prev.map((p) => (p.id === editPatient.id ? { ...p, ...res.data!.user } : p)));
        setEditPatient(null);
        if (viewPatient?.id === editPatient.id) setViewPatient((prev) => (prev ? { ...prev, ...res.data!.user } : null));
      } else {
        toast.error(res.message || 'Failed to update');
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to update');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleStatus = async () => {
    if (!statusConfirm) return;
    const { patient, nextActive } = statusConfirm;
    setTogglingStatus(patient.id);
    try {
      const res = await adminPatientsApi.updateUserStatus(patient.id, nextActive);
      if (res.success) {
        toast.success(nextActive ? 'Patient activated' : 'Patient deactivated');
        setPatients((prev) => prev.map((p) => (p.id === patient.id ? { ...p, isActive: nextActive } : p)));
        setViewPatient((prev) => (prev?.id === patient.id ? { ...prev, isActive: nextActive } : prev));
        setStatusConfirm(null);
      } else {
        toast.error(res.message || 'Failed to update status');
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to update status');
    } finally {
      setTogglingStatus(null);
    }
  };

  useEffect(() => {
    if (viewPatient) {
      loadFamilyForViewPatient(viewPatient);
      loadItineraryForViewPatient(viewPatient);
    } else {
      setFamilyMembers([]);
      setUserItineraries([]);
    }
  }, [viewPatient?.id]);

  useEffect(() => {
    if (itineraryModalPatient) {
      loadItineraryForViewPatient(itineraryModalPatient);
    }
  }, [itineraryModalPatient?.id]);

  const loadItineraryForViewPatient = async (patient: AdminPatient | null) => {
    if (!patient) {
      setUserItineraries([]);
      return;
    }
    try {
      setItineraryLoading(true);
      const res = await itineraryApi.getForUser(patient.id);
      if (res.success && res.data) {
        setUserItineraries(res.data);
      } else {
        setUserItineraries([]);
      }
    } catch (e) {
      console.error('Failed to load itinerary:', e);
      setUserItineraries([]);
    } finally {
      setItineraryLoading(false);
    }
  };

  const loadFamilyForViewPatient = async (patient: AdminPatient | null) => {
    if (!patient) {
      setFamilyMembers([]);
      return;
    }
    console.log('Loading family members for patient ID:', patient.id);
    try {
      setFamilyLoading(true);
      const res = await adminFamilyMembersApi.getForUser(patient.id);
      console.log('Family members response:', res);
      if (res.success && res.data) {
        setFamilyMembers(res.data.familyMembers || []);
      } else {
        toast.error(res.message || 'Failed to load family members');
        setFamilyMembers([]);
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to load family members');
      setFamilyMembers([]);
    } finally {
      setFamilyLoading(false);
    }
  };

  return (
    <DashboardLayout navigation={adminNavigation} title="Patients Management">
      <div className="space-y-6 animate-fade-in">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Patients Management</h1>
          <p className="text-muted-foreground mt-1">View, edit, and manage all patient details from the users table</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Total Patients', value: patients.length, color: 'text-primary' },
            { label: 'With Active Plan', value: withActivePlan, color: 'text-success' },
            { label: 'Total Appointments', value: totalAppointments, color: 'text-accent' },
            { label: 'Completed Consults', value: totalCompleted, color: 'text-warning' },
          ].map((stat) => (
            <Card key={stat.label} className="shadow-card border-0">
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground">{stat.label}</p>
                <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row gap-4 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, email, or phone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={planFilter} onValueChange={setPlanFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter by plan" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All plans</SelectItem>
              {plans.filter((p) => p.isActive).map((plan) => (
                <SelectItem key={plan.id} value={plan.planId}>
                  {plan.name}
                </SelectItem>
              ))}
              <SelectItem value="none">No plan</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex items-center space-x-2 bg-background border rounded-md px-3 py-2 shadow-sm">
            <Switch
              id="show-all-status"
              checked={statusFilter === 'all'}
              onCheckedChange={(checked) => setStatusFilter(checked ? 'all' : 'active')}
            />
            <Label htmlFor="show-all-status" className="cursor-pointer text-sm font-medium">
              Show All Patients
            </Label>
          </div>
        </div>

        <Card className="shadow-card border-0">
          <CardHeader>
            <CardTitle>All Patients</CardTitle>
            <CardDescription>
              {loading ? 'Loading…' : `${filteredPatients.length} patients`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Patient</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Travel Itinerary</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPatients.length === 0 && !loading && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                      No patients found.
                    </TableCell>
                  </TableRow>
                )}
                {filteredPatients.map((patient) => {
                  const fullName = `${patient.firstName} ${patient.lastName}`.trim();
                  return (
                    <TableRow key={patient.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <span className="text-primary font-semibold">
                              {(fullName || patient.email).charAt(0).toUpperCase()}
                            </span>
                          </div>
                          <div>
                            <p className="font-medium">{fullName || '—'}</p>
                            {patient.phone && (
                              <p className="text-xs text-muted-foreground flex items-center gap-1">
                                <Phone className="h-3 w-3" /> {patient.phone}
                              </p>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <p className="text-sm flex items-center gap-1">
                            <Mail className="h-3 w-3" /> {patient.email}
                          </p>
                          {patient.createdAt && (
                            <p className="text-xs text-muted-foreground">
                              Registered {format(new Date(patient.createdAt), 'MMM dd, yyyy')}
                            </p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setItineraryModalPatient(patient)}
                        >
                          <Globe2 className="h-4 w-4 mr-2 text-primary" />
                          View
                        </Button>
                      </TableCell>
                      <TableCell>
                        {patient.activePlan ? (
                          <Badge variant="default" className="bg-success">
                            {patient.activePlan.planName}
                          </Badge>
                        ) : (
                          <Badge variant="secondary">No Plan</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant={patient.isActive ? 'default' : 'secondary'}>
                          {patient.isActive ? 'Active' : 'Inactive'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setViewPatient(patient)}
                          >
                            <Eye className="h-4 w-4 mr-1" /> View
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => setEditPatient(patient)}>
                            <Pencil className="h-4 w-4 mr-1" /> Edit
                          </Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button size="icon" variant="ghost" className="h-8 w-8">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem
                                onClick={() => setStatusConfirm(patient.isActive ? { patient, nextActive: false } : { patient, nextActive: true })}
                              >
                                {patient.isActive ? (
                                  <><UserX className="h-4 w-4 mr-2" /> Deactivate</>
                                ) : (
                                  <><UserCheck className="h-4 w-4 mr-2" /> Activate</>
                                )}
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* View dialog – all details from users table */}
        <Dialog
          open={!!viewPatient}
          onOpenChange={async (open) => {
            if (!open) {
              setViewPatient(null);
              setFamilyMembers([]);
            }
          }}
        >
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            {viewPatient && (
              <>
                <DialogHeader>
                  <DialogTitle>
                    {viewPatient.firstName} {viewPatient.lastName}
                  </DialogTitle>
                  <DialogDescription>
                    {viewPatient.email}
                    {viewPatient.createdAt && (
                      <> · Registered {format(new Date(viewPatient.createdAt), 'MMM dd, yyyy')}</>
                    )}
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-6 pt-2">
                  <div className="flex flex-wrap gap-2">
                    <Badge variant={viewPatient.isActive ? 'default' : 'secondary'}>
                      {viewPatient.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                    <Button size="sm" variant="outline" onClick={() => { setEditPatient(viewPatient); setViewPatient(null); }}>
                      <Pencil className="h-4 w-4 mr-1" /> Edit
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setStatusConfirm(viewPatient.isActive ? { patient: viewPatient, nextActive: false } : { patient: viewPatient, nextActive: true })}
                    >
                      {viewPatient.isActive ? <><UserX className="h-4 w-4 mr-1" /> Deactivate</> : <><UserCheck className="h-4 w-4 mr-1" /> Activate</>}
                    </Button>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                      <User className="h-4 w-4" /> Profile (stored in users table)
                    </h4>
                    <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm p-4 rounded-lg bg-muted/50">
                      <div><dt className="text-muted-foreground">Email</dt><dd>{viewPatient.email}</dd></div>
                      <div><dt className="text-muted-foreground">Phone</dt><dd>{field(viewPatient.phone)}</dd></div>
                      <div><dt className="text-muted-foreground">Date of birth</dt><dd>{field(viewPatient.dateOfBirth)}</dd></div>
                      <div><dt className="text-muted-foreground">Gender</dt><dd>{field(viewPatient.gender)}</dd></div>
                      <div><dt className="text-muted-foreground">Blood type</dt><dd className="flex items-center gap-1">{viewPatient.bloodType ? <Droplets className="h-3 w-3" /> : null}{field(viewPatient.bloodType)}</dd></div>
                      <div className="col-span-2"><dt className="text-muted-foreground">Address</dt><dd>{field(viewPatient.streetAddress)} {field(viewPatient.city)} {field(viewPatient.state)} {field(viewPatient.zipCode)} {field(viewPatient.country)}</dd></div>
                      <div><dt className="text-muted-foreground">Emergency contact</dt><dd>{field(viewPatient.emergencyContactName)}</dd></div>
                      <div><dt className="text-muted-foreground">Emergency phone</dt><dd>{field(viewPatient.emergencyContactPhone)}</dd></div>
                      <div><dt className="text-muted-foreground">Relationship</dt><dd>{field(viewPatient.emergencyContactRelationship)}</dd></div>
                    </dl>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                      <Users className="h-4 w-4" /> Family members (plan coverage)
                    </h4>
                    {familyLoading ? (
                      <p className="text-sm text-muted-foreground">Loading family members…</p>
                    ) : familyMembers.length === 0 ? (
                      <p className="text-sm text-muted-foreground">
                        No family members added for this patient.
                      </p>
                    ) : (
                      <ul className="space-y-2 text-sm">
                        {familyMembers.map((m) => (
                          <li
                            key={m.id}
                            className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 rounded-md border border-border bg-muted/40 px-3 py-2"
                          >
                            <div>
                              <p className="font-medium">
                                {m.firstName} {m.lastName}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {[
                                  m.relationship || null,
                                  m.gender || null,
                                  m.dateOfBirth || null,
                                ]
                                  .filter(Boolean)
                                  .join(' · ')}
                              </p>
                            </div>
                          </li>
                        ))}
                      </ul>
                    )}
                    {viewPatient && !familyLoading && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="mt-3"
                        onClick={() => loadFamilyForViewPatient(viewPatient)}
                      >
                        Refresh family members
                      </Button>
                    )}
                  </div>

                  {viewPatient.activePlan && (
                    <div>
                      <h4 className="font-medium text-sm mb-2">Active Plan</h4>
                      <div className="p-3 rounded-lg bg-muted/50 text-sm">
                        <span className="font-medium">{viewPatient.activePlan.planName}</span>
                        <span className="text-muted-foreground ml-2">
                          until {format(new Date(viewPatient.activePlan.endDate), 'MMM dd, yyyy')}
                        </span>
                      </div>
                    </div>
                  )}

                  <div>
                    <h4 className="font-medium text-sm mb-2">Grant plan</h4>
                    <div className="flex flex-wrap items-center gap-2">
                      <Select value={selectedPlanId} onValueChange={setSelectedPlanId}>
                        <SelectTrigger className="w-[220px]">
                          <SelectValue placeholder="Select a plan" />
                        </SelectTrigger>
                        <SelectContent>
                          {plans.map((p) => (
                            <SelectItem key={p.planId} value={p.planId}>
                              {p.name} ({p.planId})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Button
                        size="sm"
                        disabled={granting || !selectedPlanId}
                        onClick={async () => {
                          if (!viewPatient || !selectedPlanId) return;
                          setGranting(true);
                          try {
                            const res = await adminPatientsApi.grantPlan(viewPatient.id, selectedPlanId);
                            if (res.success && res.data) {
                              toast.success('Plan granted');
                              setViewPatient((prev) =>
                                prev
                                  ? { ...prev, activePlan: { planId: res.data!.planId, planName: res.data!.planName, endDate: res.data!.endDate } }
                                  : null
                              );
                              loadPatients();
                            } else {
                              toast.error(res.message || 'Failed to grant plan');
                            }
                          } catch (e) {
                            toast.error(e instanceof Error ? e.message : 'Failed to grant plan');
                          } finally {
                            setGranting(false);
                          }
                        }}
                      >
                        {granting ? 'Granting…' : 'Grant plan'}
                      </Button>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm mb-3 flex items-center gap-2">
                      <Globe2 className="h-4 w-4" /> Travel Itinerary
                    </h4>
                    {itineraryLoading ? (
                      <p className="text-sm text-muted-foreground">Loading itinerary…</p>
                    ) : userItineraries.length === 0 ? (
                      <p className="text-sm text-muted-foreground bg-muted p-4 rounded-lg border border-dashed text-center">
                        No travel itinerary defined for this patient.
                      </p>
                    ) : (
                      <div className="relative space-y-3">
                        <div className="absolute left-4 top-4 bottom-4 w-0.5 bg-muted z-0" />
                        {userItineraries.map((it, idx) => (
                          <div key={it.id || idx} className="relative z-10 flex gap-4 bg-muted/30 p-3 rounded-lg border">
                            <div className="h-6 w-6 rounded-full bg-primary text-white flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                              {idx + 1}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between">
                                <p className="text-sm font-bold truncate">
                                  {it.location?.city}, {it.location?.country}
                                </p>
                                {it.taxPaid ? (
                                  <Badge variant="outline" className="text-[10px] font-mono">
                                    Tax: ${it.taxPaid.toFixed(2)}
                                  </Badge>
                                ) : null}
                              </div>
                              <p className="text-xs text-muted-foreground mt-1">
                                {it.arrivalDate ? format(new Date(it.arrivalDate), 'MMM dd, yyyy') : '—'} 
                                <span className="mx-1">→</span>
                                {it.departureDate ? format(new Date(it.departureDate), 'MMM dd, yyyy') : '—'}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {viewPatient.latestRequestDetails && (
                    <div>
                      <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                        <Stethoscope className="h-4 w-4" /> Details from latest booking
                      </h4>
                      <dl className="grid grid-cols-2 gap-2 text-sm p-3 rounded-lg bg-muted/50">
                        <div><dt className="text-muted-foreground">Age</dt><dd>{viewPatient.latestRequestDetails.age}</dd></div>
                        <div><dt className="text-muted-foreground">Gender</dt><dd>{viewPatient.latestRequestDetails.gender}</dd></div>
                        <div><dt className="text-muted-foreground">Emergency contact</dt><dd>{viewPatient.latestRequestDetails.emergencyContact}</dd></div>
                        {viewPatient.latestRequestDetails.city && <div><dt className="text-muted-foreground">City</dt><dd>{viewPatient.latestRequestDetails.city}</dd></div>}
                        {viewPatient.latestRequestDetails.allergies && (
                          <div className="col-span-2">
                            <dt className="text-muted-foreground">Allergies / Cause</dt>
                            <dd className="mt-0.5 font-medium">{viewPatient.latestRequestDetails.allergies}</dd>
                          </div>
                        )}
                        {viewPatient.latestRequestDetails.notes && (
                          <div className="col-span-2">
                            <dt className="text-muted-foreground">Notes</dt>
                            <dd className="mt-0.5">{viewPatient.latestRequestDetails.notes}</dd>
                          </div>
                        )}
                      </dl>
                    </div>
                  )}

                  {viewPatient.appointments && viewPatient.appointments.length > 0 && (
                    <div>
                      <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                        <CalendarIcon className="h-4 w-4" /> Appointments ({viewPatient.appointments.length})
                      </h4>
                      <div className="border rounded-lg overflow-hidden">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Date</TableHead>
                              <TableHead>Doctor</TableHead>
                              <TableHead>Service</TableHead>
                              <TableHead>Status</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {viewPatient.appointments.map((apt) => (
                              <TableRow key={apt.appointmentUuid}>
                                <TableCell className="text-sm">
                                  {apt.appointmentDate ? format(new Date(apt.appointmentDate), 'MMM dd, yyyy HH:mm') : apt.createdAt ? format(new Date(apt.createdAt), 'MMM dd, yyyy') : '—'}
                                </TableCell>
                                <TableCell className="text-sm">{apt.doctorName}</TableCell>
                                <TableCell className="text-sm">
                                  {apt.serviceType === 'TELEHEALTH' ? <Video className="h-3 w-3 inline mr-1" /> : <Phone className="h-3 w-3 inline mr-1" />}
                                  {apt.serviceType === 'TELEHEALTH' ? 'Telehealth' : 'Emergency'}
                                </TableCell>
                                <TableCell><Badge variant="outline" className="text-xs">{apt.status}</Badge></TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  )}
                  {(!viewPatient.appointments || viewPatient.appointments.length === 0) && (
                    <p className="text-sm text-muted-foreground">No appointments yet.</p>
                  )}
                </div>
              </>
            )}
          </DialogContent>
        </Dialog>

        {/* Itinerary Modal */}
        <Dialog open={!!itineraryModalPatient} onOpenChange={(open) => !open && setItineraryModalPatient(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Globe2 className="h-5 w-5 text-primary" />
                Travel Itinerary
              </DialogTitle>
              <DialogDescription>
                Planned destinations for {itineraryModalPatient?.firstName} {itineraryModalPatient?.lastName}
              </DialogDescription>
            </DialogHeader>

            <div className="py-4">
              {itineraryLoading ? (
                <div className="flex flex-col items-center justify-center py-10 space-y-3">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  <p className="text-sm text-muted-foreground font-medium">Fetching travel data...</p>
                </div>
              ) : userItineraries.length === 0 ? (
                <div className="text-center py-12 px-6 bg-muted/30 rounded-2xl border border-dashed">
                  <div className="bg-muted h-12 w-12 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Globe2 className="h-6 w-6 text-muted-foreground/40" />
                  </div>
                  <h3 className="font-bold text-foreground">No destinations found</h3>
                  <p className="text-sm text-muted-foreground mt-1 max-w-[200px] mx-auto">This patient hasn't defined any travel plans yet.</p>
                </div>
              ) : (
                <div className="relative space-y-4">
                  <div className="absolute left-6 top-8 bottom-8 w-0.5 bg-gradient-to-b from-primary/20 to-transparent z-0" />
                  {userItineraries.map((it, idx) => (
                    <div key={it.id || idx} className="relative z-10 flex gap-4 bg-card border rounded-xl p-4 shadow-sm">
                      <div className="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold shadow-md shrink-0 ring-4 ring-background">
                        {idx + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <p className="font-bold text-foreground truncate">
                            {it.location?.city}, {it.location?.country}
                          </p>
                          {it.taxPaid ? (
                            <Badge variant="outline" className="text-[10px] bg-primary/5 border-primary/10 text-primary">
                              ${it.taxPaid.toFixed(2)}
                            </Badge>
                          ) : null}
                        </div>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            <span>{it.arrivalDate ? format(new Date(it.arrivalDate), 'MMM dd') : '—'}</span>
                          </div>
                          <span className="opacity-30">→</span>
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            <span>{it.departureDate ? format(new Date(it.departureDate), 'MMM dd, yyyy') : '—'}</span>
                          </div>
                        </div>
                        {it.location?.state && (
                          <p className="text-[10px] text-muted-foreground mt-2 uppercase tracking-wider font-semibold opacity-70">
                            {it.location.state}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setItineraryModalPatient(null)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit dialog */}
        <Dialog open={!!editPatient} onOpenChange={(open) => !open && setEditPatient(null)}>
          <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
            {editPatient && (
              <>
                <DialogHeader>
                  <DialogTitle>Edit patient</DialogTitle>
                  <DialogDescription>
                    {editPatient.firstName} {editPatient.lastName} · {editPatient.email}
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>First name</Label>
                      <Input
                        value={editForm.firstName ?? ''}
                        onChange={(e) => setEditForm((f) => ({ ...f, firstName: e.target.value }))}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Last name</Label>
                      <Input
                        value={editForm.lastName ?? ''}
                        onChange={(e) => setEditForm((f) => ({ ...f, lastName: e.target.value }))}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input value={editPatient.email} disabled className="bg-muted" />
                  </div>
                  <div className="space-y-2">
                    <Label>Phone</Label>
                    <Input
                      value={editForm.phone ?? ''}
                      onChange={(e) => setEditForm((f) => ({ ...f, phone: e.target.value || undefined }))}
                      placeholder="Optional"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Date of birth</Label>
                    <Input
                      type="date"
                      value={editForm.dateOfBirth ?? ''}
                      onChange={(e) => setEditForm((f) => ({ ...f, dateOfBirth: e.target.value || undefined }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Gender</Label>
                    <Select
                      value={editForm.gender ?? ''}
                      onValueChange={(v) => setEditForm((f) => ({ ...f, gender: v || undefined }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select gender" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Male">Male</SelectItem>
                        <SelectItem value="Female">Female</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                        <SelectItem value="Prefer not to say">Prefer not to say</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Street address</Label>
                    <Input
                      value={editForm.streetAddress ?? ''}
                      onChange={(e) => setEditForm((f) => ({ ...f, streetAddress: e.target.value || undefined }))}
                      placeholder="Optional"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>City</Label>
                      <Input
                        value={editForm.city ?? ''}
                        onChange={(e) => setEditForm((f) => ({ ...f, city: e.target.value || undefined }))}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>State / Region</Label>
                      <Input
                        value={editForm.state ?? ''}
                        onChange={(e) => setEditForm((f) => ({ ...f, state: e.target.value || undefined }))}
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>ZIP / Postcode</Label>
                      <Input
                        value={editForm.zipCode ?? ''}
                        onChange={(e) => setEditForm((f) => ({ ...f, zipCode: e.target.value || undefined }))}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Country</Label>
                      <Input
                        value={editForm.country ?? ''}
                        onChange={(e) => setEditForm((f) => ({ ...f, country: e.target.value || undefined }))}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Emergency contact name</Label>
                    <Input
                      value={editForm.emergencyContactName ?? ''}
                      onChange={(e) => setEditForm((f) => ({ ...f, emergencyContactName: e.target.value || undefined }))}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Emergency contact phone</Label>
                      <Input
                        value={editForm.emergencyContactPhone ?? ''}
                        onChange={(e) => setEditForm((f) => ({ ...f, emergencyContactPhone: e.target.value || undefined }))}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Relationship</Label>
                      <Input
                        value={editForm.emergencyContactRelationship ?? ''}
                        onChange={(e) => setEditForm((f) => ({ ...f, emergencyContactRelationship: e.target.value || undefined }))}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Blood type</Label>
                    <Input
                      value={editForm.bloodType ?? ''}
                      onChange={(e) => setEditForm((f) => ({ ...f, bloodType: e.target.value || undefined }))}
                      placeholder="e.g. A+"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="edit-isActive"
                      checked={editForm.isActive ?? true}
                      onChange={(e) => setEditForm((f) => ({ ...f, isActive: e.target.checked }))}
                      className="rounded border-input"
                    />
                    <Label htmlFor="edit-isActive">Account active (can log in)</Label>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setEditPatient(null)}>Cancel</Button>
                  <Button disabled={saving} onClick={handleSaveEdit}>
                    {saving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Saving…</> : 'Save'}
                  </Button>
                </DialogFooter>
              </>
            )}
          </DialogContent>
        </Dialog>

        {/* Deactivate / Activate confirmation */}
        <Dialog open={!!statusConfirm} onOpenChange={(open) => !open && setStatusConfirm(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{statusConfirm?.nextActive ? 'Activate patient' : 'Deactivate patient'}</DialogTitle>
              <DialogDescription>
                {statusConfirm?.nextActive
                  ? 'This patient will be able to log in again.'
                  : 'This patient will not be able to log in until you activate them again.'}
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setStatusConfirm(null)}>Cancel</Button>
              <Button
                variant={statusConfirm?.nextActive ? 'default' : 'destructive'}
                disabled={togglingStatus !== null}
                onClick={handleToggleStatus}
              >
                {togglingStatus !== null ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                {statusConfirm?.nextActive ? 'Activate' : 'Deactivate'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
