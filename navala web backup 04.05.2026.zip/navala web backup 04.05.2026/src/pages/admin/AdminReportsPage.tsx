import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  LayoutDashboard,
  Users,
  Calendar,
  CalendarCheck,
  CreditCard,
  BarChart3,
  Receipt,
  TrendingUp,
  Video,
  Phone,
  DollarSign,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend,
} from 'recharts';
import { adminNavigation } from '@/config/adminNavigation';
import { useState, useEffect, useMemo } from 'react';
import { adminApi, paymentApi } from '@/services/api';

// Colors for charts
const COLORS = ['hsl(var(--primary))', 'hsl(var(--accent))', 'hsl(var(--success))', 'hsl(var(--warning))', '#f472b6', '#60a5fa'];

export default function AdminReportsPage() {
  const [loading, setLoading] = useState(false);
  const [reportData, setReportData] = useState<any>(null);

  const loadReportData = async () => {
    try {
      setLoading(true);
      const [statsRes, analyticsRes] = await Promise.all([
        adminApi.getTransactionStats({ liveOnly: true }),
        adminApi.getReportsAnalytics()
      ]);
      
      if (statsRes.success && analyticsRes.success) {
        setReportData({
          ...statsRes.data,
          ...analyticsRes.data
        });
      }
    } catch (e) {
      console.error('Failed to load report stats', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReportData();
  }, []);

  const totalRevenue = reportData?.totalRevenue || 0;
  const totalTransactions = reportData?.totalTransactions || 0;
  const telehealthCount = reportData?.metrics?.telehealthCount || 0;
  const emergencyCount = reportData?.metrics?.emergencyCount || 0;
  const patientCount = reportData?.metrics?.patientCount || 0;
  const activeDoctors = reportData?.metrics?.activeDoctors || 0;
  const totalAppointments = reportData?.metrics?.totalAppointments || 0;
  
  const revenueTrend = reportData?.revenueTrend || [];
  const serviceDistribution = reportData?.serviceDistribution || [];
  const appointmentTrend = reportData?.appointmentTrend || [];
  const planDistribution = reportData?.planDistribution || [];

  return (
    <DashboardLayout navigation={adminNavigation} title="Reports & Analytics">
      <div className="space-y-6 animate-fade-in">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Reports & Analytics</h1>
          <p className="text-muted-foreground mt-1">Platform insights and performance metrics</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Total Revenue', value: `$${totalRevenue.toLocaleString()}`, icon: DollarSign, color: 'text-success', change: '' },
            { label: 'Telehealth Sessions', value: telehealthCount, icon: Video, color: 'text-accent', change: '' },
            { label: 'Emergency Calls', value: emergencyCount, icon: Phone, color: 'text-primary', change: '' },
            { label: 'Total Transactions', value: totalTransactions, icon: Receipt, color: 'text-warning', change: '' },
          ].map((stat) => (
            <Card key={stat.label} className="shadow-card border-0">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                    <stat.icon className={`h-5 w-5 ${stat.color}`} />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">{stat.label}</p>
                    <div className="flex items-baseline gap-2">
                      <p className="text-xl font-bold">{stat.value}</p>
                      <span className="text-xs text-success">{stat.change}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Charts Row 1 */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Monthly Revenue */}
          <Card className="shadow-card border-0">
            <CardHeader>
              <CardTitle>Monthly Revenue</CardTitle>
              <CardDescription>Revenue trend over the last 6 months</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={revenueTrend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickFormatter={(v) => `$${v}`} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                      formatter={(value: number) => [`$${value.toFixed(2)}`, 'Revenue']}
                    />
                    <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Service Type Distribution */}
          <Card className="shadow-card border-0">
            <CardHeader>
              <CardTitle>Service Distribution</CardTitle>
              <CardDescription>Telehealth vs Emergency services</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={serviceDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={90}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {serviceDistribution.map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                      formatter={(value: number) => [`${value}%`, 'Percentage']}
                    />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 2 */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Appointment Trends */}
          <Card className="shadow-card border-0">
            <CardHeader>
              <CardTitle>Appointment Trends</CardTitle>
              <CardDescription>Weekly completed vs pending appointments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={appointmentTrend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="week" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                    />
                    <Legend />
                    <Line type="monotone" dataKey="completed" stroke="hsl(var(--success))" strokeWidth={2} dot={{ r: 4 }} />
                    <Line type="monotone" dataKey="pending" stroke="hsl(var(--warning))" strokeWidth={2} dot={{ r: 4 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Plan Subscribers */}
          <Card className="shadow-card border-0">
            <CardHeader>
              <CardTitle>Plan Distribution</CardTitle>
              <CardDescription>Subscribers by plan type</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={planDistribution} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis type="category" dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} width={100} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                      formatter={(value: number) => [`${value} subscribers`, 'Total']}
                    />
                    <Bar dataKey="subscribers" radius={[0, 4, 4, 0]}>
                      {planDistribution.map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Summary Stats */}
        <Card className="shadow-card border-0">
          <CardHeader>
            <CardTitle>Platform Summary</CardTitle>
            <CardDescription>Key performance indicators at a glance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
              {[
                { label: 'Total Patients', value: patientCount },
                { label: 'Active Doctors', value: activeDoctors },
                { label: 'Total Appointments', value: totalAppointments },
                { label: 'Active Plans', value: reportData?.planDistribution?.reduce((acc: number, p: any) => acc + p.subscribers, 0) || 0 },
                { label: 'Completion Rate', value: totalAppointments > 0 ? `${Math.round((appointmentTrend.reduce((acc, t) => acc + t.completed, 0) / totalAppointments) * 100)}%` : '0%' },
              ].map((item) => (
                <div key={item.label} className="text-center p-4 rounded-lg bg-muted/50">
                  <p className="text-2xl font-bold text-primary">{item.value}</p>
                  <p className="text-xs text-muted-foreground mt-1">{item.label}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
