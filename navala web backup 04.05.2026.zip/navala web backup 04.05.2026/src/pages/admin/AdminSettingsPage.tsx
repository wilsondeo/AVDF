import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { adminNavigation } from '@/config/adminNavigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { 
  Settings, 
  Users, 
  ShieldCheck, 
  Save, 
  Loader2, 
  Video,
  Clock,
  Globe,
  DollarSign
} from 'lucide-react';
import { systemConfigApi } from '@/services/api';
import { toast } from 'sonner';

export default function AdminSettingsPage() {
  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [configs, setConfigs] = useState({
    max_patients_per_slot: '5',
    is_location_tax_enabled: true,
    multi_city_tax_strategy: 'HIGHEST',
    is_emergency_enabled: true,
    telehealth_price: '50',
  });

  useEffect(() => {
    loadConfigs();
  }, []);

  const loadConfigs = async () => {
    try {
      setLoading(true);
      const res = await systemConfigApi.getAll();
      if (res.success && res.data) {
        const mapped: any = {};
        res.data.forEach(c => {
          mapped[c.configKey] = c.configValue;
        });
        setConfigs(prev => ({
          ...prev,
          ...mapped,
          is_location_tax_enabled: mapped.is_location_tax_enabled === 'true' || mapped.is_location_tax_enabled === true,
          is_emergency_enabled: mapped.is_emergency_enabled === 'true' || mapped.is_emergency_enabled === true,
        }));
      }
    } catch (e) {
      console.error('Failed to load configs', e);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async (key: string, value: any) => {
    setIsSaving(true);
    try {
      const stringValue = String(value);
      const res = await systemConfigApi.update(key, stringValue);
      if (res.success) {
        setConfigs(prev => ({ ...prev, [key]: value }));
        toast.success('Setting updated successfully');
      } else {
        toast.error('Failed to update setting');
      }
    } catch (e) {
      toast.error('Failed to update setting');
    } finally {
      setIsSaving(false);
    }
  };

  if (loading) {
    return (
      <DashboardLayout navigation={adminNavigation} title="Settings">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout navigation={adminNavigation} title="System Settings">
      <div className="space-y-6 animate-fade-in max-w-4xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">System Settings</h1>
            <p className="text-muted-foreground mt-1">Global overrides and configuration management</p>
          </div>
        </div>

        {/* Global Capacity */}
        <Card className="border-none shadow-premium overflow-hidden group">
          <div className="absolute top-0 left-0 w-1 pt-1 h-full bg-primary" />
          <CardHeader className="bg-slate-50/50 dark:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center transition-transform group-hover:scale-110">
                <Users className="h-5 w-5" />
              </div>
              <div>
                <CardTitle>Scheduling & Capacity</CardTitle>
                <CardDescription>Control patient volume per time slot</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-6 space-y-6">
            <div className="flex items-center justify-between gap-8 p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800">
              <div className="space-y-1">
                <Label className="text-base font-bold">Max Patients per Slot</Label>
                <p className="text-sm text-muted-foreground">The system will stop accepting bookings for a slot once this number of patients is reached.</p>
              </div>
              <div className="flex items-center gap-2 w-32">
                <Input 
                  type="number" 
                  value={configs.max_patients_per_slot}
                  onChange={(e) => setConfigs({ ...configs, max_patients_per_slot: e.target.value })}
                  className="font-bold text-center"
                />
                <Button 
                   size="icon" 
                   onClick={() => handleUpdate('max_patients_per_slot', configs.max_patients_per_slot)}
                   className="shrink-0"
                   disabled={isSaving}
                >
                   {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Billing & Tax */}
        <Card className="border-none shadow-premium overflow-hidden group">
          <div className="absolute top-0 left-0 w-1 pt-1 h-full bg-accent" />
          <CardHeader className="bg-slate-50/50 dark:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-accent/10 text-accent flex items-center justify-center transition-transform group-hover:scale-110">
                <DollarSign className="h-5 w-5" />
              </div>
              <div>
                <CardTitle>Regional & Tax Settings</CardTitle>
                <CardDescription>Manage how taxes and pricing are calculated</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800">
              <div className="space-y-1">
                <Label className="text-base font-bold">Location-Based Tax</Label>
                <p className="text-sm text-muted-foreground">Automatically calculate tax based on patient's visited destinations.</p>
              </div>
              <Switch 
                checked={configs.is_location_tax_enabled}
                onCheckedChange={(v) => handleUpdate('is_location_tax_enabled', v)}
                disabled={isSaving}
              />
            </div>

            <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800">
              <div className="space-y-1">
                <Label className="text-base font-bold">Tax Strategy</Label>
                <p className="text-sm text-muted-foreground">How multiple destination taxes are combined (per country).</p>
              </div>
              <div className="flex items-center gap-2">
                <Select
                  value={configs.multi_city_tax_strategy}
                  onValueChange={(v) => handleUpdate('multi_city_tax_strategy', v)}
                  disabled={isSaving}
                >
                  <SelectTrigger className="w-48 font-bold">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="SUM">SUM (Unique Countries)</SelectItem>
                    <SelectItem value="MAX">MAX (Highest Country)</SelectItem>
                    <SelectItem value="PRIMARY">PRIMARY (First only)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800">
              <div className="space-y-1">
                <Label className="text-base font-bold">Emergency Service Price ($)</Label>
                <p className="text-sm text-muted-foreground">Fixed price for immediate emergency consultations.</p>
              </div>
              <div className="flex items-center gap-2 w-32">
                <Input 
                  type="number" 
                  value={configs.telehealth_price}
                  onChange={(e) => setConfigs({ ...configs, telehealth_price: e.target.value })}
                  className="font-bold text-center"
                />
                <Button 
                   size="icon" 
                   variant="outline"
                   onClick={() => handleUpdate('telehealth_price', configs.telehealth_price)}
                   className="shrink-0"
                   disabled={isSaving}
                >
                   {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Security & Access */}
        <Card className="border-none shadow-premium overflow-hidden group">
          <div className="absolute top-0 left-0 w-1 pt-1 h-full bg-slate-400" />
          <CardHeader className="bg-slate-50/50 dark:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-500 flex items-center justify-center transition-transform group-hover:scale-110">
                <ShieldCheck className="h-5 w-5" />
              </div>
              <div>
                <CardTitle>System Maintenance</CardTitle>
                <CardDescription>Administrative safety controls</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="p-4 border border-dashed border-slate-200 dark:border-slate-700 rounded-2xl">
               <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="font-bold text-slate-700 dark:text-slate-200">Emergency Bookings Locked</p>
                    <p className="text-xs text-muted-foreground">Forcefully disable all new emergency requests during system maintenance.</p>
                  </div>
                  <Button variant="ghost" className="text-destructive font-black text-xs hover:bg-destructive/10">ENABLE LOCK</Button>
               </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
