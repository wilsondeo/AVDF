import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { useAppStore } from '@/lib/store';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { LayoutDashboard, Users, Calendar, CalendarCheck, CreditCard, BarChart3, Search, Mail, MapPin, Receipt, Plus, Stethoscope, UserCheck, Upload, AlertCircle, CheckCircle2, Phone, KeyRound, Pencil, Trash2, Send } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import { cities } from '@/lib/store';
import { adminDoctorApi } from '@/services/api';
import { toast } from 'sonner';
import { countryTimezones, getTimezoneLabel } from '@/config/timezones';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { adminNavigation } from '@/config/adminNavigation';

const specializations = [
  'General Medicine',
  'Emergency Medicine',
  'Internal Medicine',
  'Travel Medicine',
  'Family Medicine',
  'Pediatrics',
  'Cardiology',
];

export default function AdminDoctorsPage() {
  const { users, appointments, updateDoctor } = useAppStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('list');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [realDoctors, setRealDoctors] = useState<any[]>([]);
  const [isLoadingList, setIsLoadingList] = useState(false);

  // Single Doctor Form State (password: empty = backend auto-generates)
  const [newDoctor, setNewDoctor] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    city: '',
    timezone: 'UTC',
    specialization: '',
    yearsOfExperience: '',
    sendEmail: true,
  });
  const [createdPassword, setCreatedPassword] = useState<string | null>(null);

  // Edit doctor dialog
  const [editOpen, setEditOpen] = useState(false);
  const [editingDoctor, setEditingDoctor] = useState<any>(null);
  const [editForm, setEditForm] = useState({ name: '', email: '', password: '', phone: '', city: '', timezone: 'UTC', specialization: '', yearsOfExperience: '', isActive: true });
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);

  // Bulk Upload State
  const [bulkFile, setBulkFile] = useState<File | null>(null);
  const [bulkSendEmail, setBulkSendEmail] = useState(true);
  const [uploadSummary, setUploadSummary] = useState<any>(null);

  const generateRandomPassword = () => {
    const length = 8 + Math.floor(Math.random() * 5);
    const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lower = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';
    const symbols = '!@#$%^&*';
    const all = upper + lower + numbers + symbols;
    let p = '';
    p += upper[Math.floor(Math.random() * upper.length)];
    p += lower[Math.floor(Math.random() * lower.length)];
    p += numbers[Math.floor(Math.random() * numbers.length)];
    p += symbols[Math.floor(Math.random() * symbols.length)];
    for (let i = p.length; i < length; i++) p += all[Math.floor(Math.random() * all.length)];
    return p.split('').sort(() => Math.random() - 0.5).join('');
  };

  const fetchDoctorsList = async (isBackground = false) => {
    if (!isBackground) setIsLoadingList(true);
    try {
      const response = await adminDoctorApi.getDoctors();
      if (response.success && response.data) {
        const mapped = response.data.map((d: any) => ({
          id: d.id.toString(),
          doctorUuid: d.doctorUuid,
          name: `${d.User?.firstName ?? ''} ${d.User?.lastName ?? ''}`.trim(),
          email: d.User?.email ?? '',
          phone: d.phone ?? '',
          city: d.city ?? '',
          specialization: d.specialization ?? '',
          yearsOfExperience: d.yearsOfExperience ?? 0,
          timezone: d.timezone ?? 'UTC',
          plainPassword: d.plainPassword ?? '',
          isActive: d.User?.isActive ?? true,
          isOnline: d.isOnline ?? d.is_online ?? d.User?.isOnline ?? d.User?.is_online ?? false,
          appointments: [],
        }));
        setRealDoctors(mapped);
      }
    } catch (error) {
      console.error('Failed to fetch doctors:', error);
    } finally {
      if (!isBackground) setIsLoadingList(false);
    }
  };

  useEffect(() => {
    fetchDoctorsList();
    // Silent auto-refresh every 10 seconds
    const interval = setInterval(() => fetchDoctorsList(true), 10000);
    return () => clearInterval(interval);
  }, []);

  const doctors = realDoctors.length > 0 ? realDoctors : users.filter(u => u.role === 'doctor');

  const getDoctorStats = (doctorId: string) => {
    const doctorAppts = appointments.filter(a => a.doctorId === doctorId);
    return {
      total: doctorAppts.length,
      completed: doctorAppts.filter(a => a.status === 'completed').length,
      inProgress: doctorAppts.filter(a => a.status === 'in_progress').length,
    };
  };

  const filteredDoctors = doctors.filter(doctor =>
    doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doctor.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doctor.specialization?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const listToDisplay = realDoctors.length > 0 ? realDoctors.filter(doctor =>
    doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doctor.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doctor.specialization?.toLowerCase().includes(searchTerm.toLowerCase())
  ) : filteredDoctors;

  const handleAddDoctor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDoctor.name || !newDoctor.email || !newDoctor.specialization) {
      toast.error('Required fields are missing');
      return;
    }

    setIsSubmitting(true);
    setCreatedPassword(null);
    try {
      const response = await adminDoctorApi.createDoctor({
        name: newDoctor.name,
        email: newDoctor.email,
        password: newDoctor.password.trim() || undefined,
        phone: newDoctor.phone,
        city: newDoctor.city,
        timezone: newDoctor.timezone,
        specialization: newDoctor.specialization,
        yearsOfExperience: parseInt(newDoctor.yearsOfExperience || '0', 10),
        sendEmail: newDoctor.sendEmail,
      });

      if (response.success) {
        const savedPassword = response.data?.plainPassword ?? null;
        setCreatedPassword(savedPassword);
        toast.success(savedPassword ? 'Doctor created. Password stored in doctors table and visible in the list.' : 'Doctor created successfully');
        setNewDoctor({
          name: '',
          email: '',
          password: '',
          phone: '',
          city: '',
          timezone: 'UTC',
          specialization: '',
          yearsOfExperience: '',
          sendEmail: true,
        });
        fetchDoctorsList();
        setActiveTab('list');
      } else {
        toast.error(response.message || 'Failed to create doctor');
      }
    } catch (error: any) {
      toast.error(error.message || 'An unexpected error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  const openEdit = (doctor: any) => {
    setEditingDoctor(doctor);
    setEditForm({
      name: doctor.name,
      email: doctor.email,
      password: doctor.plainPassword ?? '',
      phone: doctor.phone ?? '',
      city: doctor.city ?? '',
      timezone: doctor.timezone ?? 'UTC',
      specialization: doctor.specialization ?? '',
      yearsOfExperience: String(doctor.yearsOfExperience ?? ''),
      isActive: doctor.isActive ?? true,
    });
    setEditOpen(true);
  };

  const handleEditSave = async () => {
    if (!editingDoctor) return;
    setIsSubmitting(true);
    try {
      const response = await adminDoctorApi.updateDoctor(editingDoctor.id, {
        name: editForm.name,
        email: editForm.email,
        password: editForm.password.trim() || undefined,
        phone: editForm.phone,
        city: editForm.city,
        timezone: editForm.timezone,
        specialization: editForm.specialization,
        yearsOfExperience: parseInt(editForm.yearsOfExperience || '0', 10),
        isActive: editForm.isActive,
      });
      if (response.success) {
        toast.success('Doctor updated');
        setEditOpen(false);
        setEditingDoctor(null);
        fetchDoctorsList();
      } else {
        toast.error(response.message || 'Update failed');
      }
    } catch (error: any) {
      toast.error(error.message || 'Update failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deleteTargetId) return;
    setIsSubmitting(true);
    try {
      const response = await adminDoctorApi.deleteDoctor(deleteTargetId);
      if (response.success) {
        toast.success('Doctor deleted');
        setDeleteTargetId(null);
        fetchDoctorsList();
      } else {
        toast.error(response.message || 'Delete failed');
      }
    } catch (error: any) {
      toast.error(error.message || 'Delete failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSendEmail = async (doctorId: string) => {
    try {
      const response = await adminDoctorApi.sendDoctorEmail(doctorId);
      if (response.success) {
        toast.success('Credentials email sent to doctor');
      } else {
        toast.error(response.message || 'Failed to send email');
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to send email');
    }
  };

  const handleBulkUpload = async () => {
    if (!bulkFile) {
      toast.error('Please select a CSV file');
      return;
    }

    setIsSubmitting(true);
    const formData = new FormData();
    formData.append('file', bulkFile);
    formData.append('sendEmail', bulkSendEmail.toString());

    try {
      const response = await adminDoctorApi.uploadDoctors(formData);
      if (response.success) {
        setUploadSummary(response.data);
        toast.success('Bulk upload processed');
        if (fileInputRef.current) fileInputRef.current.value = '';
        setBulkFile(null);
      } else {
        toast.error(response.message || 'Bulk upload failed');
      }
    } catch (error: any) {
      toast.error(error.message || 'An unexpected error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  const toggleDoctorStatus = (doctorId: string, isActive: boolean) => {
    updateDoctor(doctorId, { isActive });
  };

  return (
    <DashboardLayout navigation={adminNavigation} title="Doctors Management">
      <div className="space-y-6 animate-fade-in">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">Doctors Management</h1>
            <p className="text-muted-foreground mt-1">Manage healthcare providers</p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="list">Doctor List</TabsTrigger>
            <TabsTrigger value="add">Add Doctor</TabsTrigger>
            <TabsTrigger value="bulk">Bulk Upload</TabsTrigger>
          </TabsList>

          {/* Doctor List Tab */}
          <TabsContent value="list" className="space-y-6 mt-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: 'Total Doctors', value: listToDisplay.length, icon: Users, color: 'text-primary' },
                { label: 'Active Doctors', value: listToDisplay.filter(d => d.isActive).length, icon: UserCheck, color: 'text-success' },
                { label: 'Total Consultations', value: appointments.filter(a => a.doctorId).length, icon: Stethoscope, color: 'text-accent' },
                { label: 'Completed Today', value: appointments.filter(a => a.status === 'completed' && new Date(a.dateTime).toDateString() === new Date().toDateString()).length, icon: Calendar, color: 'text-warning' },
              ].map((stat) => (
                <Card key={stat.label} className="shadow-card border-0">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                        <stat.icon className={`h-5 w-5 ${stat.color}`} />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">{stat.label}</p>
                        <p className="text-xl font-bold">{stat.value}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name, email or specialization..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 max-w-md"
              />
            </div>

            <Card className="shadow-card border-0">
              <CardHeader>
                <CardTitle>All Doctors</CardTitle>
                <CardDescription>{listToDisplay.length} doctors registered</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Doctor</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Phone</TableHead>
                      <TableHead>Specialization</TableHead>
                      <TableHead>City</TableHead>
                      <TableHead>Years Exp.</TableHead>
                      <TableHead>Password</TableHead>
                      <TableHead>Live Status</TableHead>
                      <TableHead>Account Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoadingList ? (
                      <TableRow>
                        <TableCell colSpan={11} className="text-center py-10">Loading doctors...</TableCell>
                      </TableRow>
                    ) : listToDisplay.map((doctor) => {
                      return (
                        <TableRow key={doctor.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center">
                                <Stethoscope className="h-5 w-5 text-accent" />
                              </div>
                              <div>
                                <p className="font-medium">{doctor.name}</p>
                                <p className="text-xs text-muted-foreground">ID: {doctor.doctorUuid ? String(doctor.doctorUuid).slice(0, 8) : doctor.id?.slice(0, 8)}</p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1 text-sm">
                              <Mail className="h-3 w-3" /> {doctor.email}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1 text-sm">
                              <Phone className="h-3 w-3 text-muted-foreground" />
                              {doctor.phone || '—'}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary">{doctor.specialization}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <MapPin className="h-3 w-3 text-muted-foreground" />
                              <div className="flex flex-col">
                                <span>{doctor.city || '—'}</span>
                                <span className="text-[10px] text-accent font-bold uppercase">{doctor.timezone || 'UTC'}</span>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>{doctor.yearsOfExperience ?? '—'}</TableCell>
                          <TableCell>
                            <span className="font-mono text-xs bg-muted px-1.5 py-0.5 rounded">
                              {doctor.plainPassword || '—'}
                            </span>
                          </TableCell>
                          <TableCell>
                            {doctor.isOnline ? (
                              <Badge className="bg-success border-none text-white flex items-center gap-1 w-fit">
                                <div className="h-1.5 w-1.5 rounded-full bg-white animate-pulse" />
                                Online
                              </Badge>
                            ) : (
                              <Badge variant="secondary" className="opacity-50">Offline</Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <Badge variant={doctor.isActive ? 'default' : 'secondary'} className={doctor.isActive ? 'bg-success' : ''}>
                              {doctor.isActive ? 'Enabled' : 'Disabled'}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Switch
                              checked={doctor.isActive}
                              onCheckedChange={(checked) => toggleDoctorStatus(doctor.id, checked)}
                            />
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-1">
                              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(doctor)} title="Edit">
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeleteTargetId(doctor.id)} title="Delete">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleSendEmail(doctor.id)} title="Send credentials email">
                                <Send className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Add Doctor Tab */}
          <TabsContent value="add" className="mt-6">
            <Card className="max-w-2xl shadow-card border-0">
              <CardHeader>
                <CardTitle>Add New Doctor</CardTitle>
                <CardDescription>Enter doctor details. Password is stored in the doctors table; leave empty to auto-generate, or type your own. You can send it to the doctor by email.</CardDescription>
                <div className="mt-3 p-3 rounded-lg bg-muted/60 border border-border text-sm">
                  <p className="font-medium flex items-center gap-2">
                    <KeyRound className="h-4 w-4 text-muted-foreground" />
                    Password
                  </p>
                  <ul className="list-disc list-inside mt-1 text-muted-foreground space-y-0.5">
                    <li>Leave empty to auto-generate (8–12 chars); or type a password (editable).</li>
                    <li>Stored in the doctors table for admin view and &quot;Send email&quot;.</li>
                    <li>Check &quot;Send login credentials email&quot; to email the password when creating.</li>
                  </ul>
                </div>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAddDoctor} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name*</Label>
                      <Input
                        id="name"
                        placeholder="Dr. John Smith"
                        value={newDoctor.name}
                        onChange={(e) => setNewDoctor({ ...newDoctor, name: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address*</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="dr.smith@navala.health"
                        value={newDoctor.email}
                        onChange={(e) => setNewDoctor({ ...newDoctor, email: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        placeholder="+1-234-567-8900"
                        value={newDoctor.phone}
                        onChange={(e) => setNewDoctor({ ...newDoctor, phone: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="city">City</Label>
                      <Select value={newDoctor.city} onValueChange={(v) => setNewDoctor({ ...newDoctor, city: v })}>
                        <SelectTrigger id="city">
                          <SelectValue placeholder="Select city" />
                        </SelectTrigger>
                        <SelectContent>
                          {cities.map((city) => (
                            <SelectItem key={city} value={city}>{city}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="timezone">Timezone*</Label>
                      <Select value={newDoctor.timezone} onValueChange={(v) => setNewDoctor({ ...newDoctor, timezone: v })}>
                        <SelectTrigger id="timezone">
                          <SelectValue placeholder="Select timezone" />
                        </SelectTrigger>
                        <SelectContent className="max-h-[300px]">
                          {Object.values(countryTimezones).filter((v, i, a) => a.indexOf(v) === i).sort().map((tz) => (
                            <SelectItem key={tz} value={tz}>{tz}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="specialization">Specialization*</Label>
                      <Select value={newDoctor.specialization} onValueChange={(v) => setNewDoctor({ ...newDoctor, specialization: v })}>
                        <SelectTrigger id="specialization">
                          <SelectValue placeholder="Select specialization" />
                        </SelectTrigger>
                        <SelectContent>
                          {specializations.map((spec) => (
                            <SelectItem key={spec} value={spec}>{spec}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="experience">Years of Experience</Label>
                      <Input
                        id="experience"
                        type="number"
                        placeholder="5"
                        min="0"
                        value={newDoctor.yearsOfExperience}
                        onChange={(e) => setNewDoctor({ ...newDoctor, yearsOfExperience: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="password">Password (editable; leave empty to auto-generate)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="password"
                          type="text"
                          placeholder="Auto-generated if empty"
                          value={newDoctor.password}
                          onChange={(e) => setNewDoctor({ ...newDoctor, password: e.target.value })}
                          className="font-mono"
                        />
                        <Button type="button" variant="outline" onClick={() => setNewDoctor({ ...newDoctor, password: generateRandomPassword() })}>
                          Generate
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 py-2">
                    <Checkbox
                      id="sendEmail"
                      checked={newDoctor.sendEmail}
                      onCheckedChange={(checked) => setNewDoctor({ ...newDoctor, sendEmail: checked as boolean })}
                    />
                    <Label htmlFor="sendEmail" className="text-sm font-medium leading-none cursor-pointer">
                      Send login credentials email immediately
                    </Label>
                  </div>

                  <div className="pt-4">
                    <Button type="submit" className="w-full md:w-auto" disabled={isSubmitting}>
                      {isSubmitting ? 'Creating...' : 'Create Doctor Profile'}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Bulk Upload Tab */}
          <TabsContent value="bulk" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="shadow-card border-0">
                <CardHeader>
                  <CardTitle>Bulk Doctor Upload</CardTitle>
                  <CardDescription>Upload a CSV file with multiple doctor records. Each doctor gets an auto-generated password sent to their email if you enable it below.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted/50 rounded-lg border border-dashed border-muted-foreground/20">
                    <div className="text-sm space-y-2">
                      <p className="font-semibold">CSV Format Instructions:</p>
                      <code className="block p-2 bg-background rounded text-xs">
                        name,email,phone,city,specialization,years_of_experience
                      </code>
                      <p className="text-xs text-muted-foreground italic">
                        * Header row is mandatory. Each valid row will create a new doctor.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-4 pt-2">
                    <div className="space-y-2">
                      <Label htmlFor="csv-file">Select CSV File (.csv)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="csv-file"
                          type="file"
                          accept=".csv"
                          ref={fileInputRef}
                          onChange={(e) => setBulkFile(e.target.files?.[0] || null)}
                          className="cursor-pointer"
                        />
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="bulkSendEmail"
                        checked={bulkSendEmail}
                        onCheckedChange={(v) => setBulkSendEmail(v as boolean)}
                      />
                      <Label htmlFor="bulkSendEmail" className="text-sm cursor-pointer">
                        Send credentials email to all successfully added doctors
                      </Label>
                    </div>

                    <Button onClick={handleBulkUpload} disabled={isSubmitting || !bulkFile} className="w-full">
                      {isSubmitting ? 'Uploading...' : 'Start Bulk Upload'}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Upload Result Summary */}
              {uploadSummary && (
                <Card className="shadow-card border-0 animate-in fade-in slide-in-from-bottom-2">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CheckCircle2 className="h-5 w-5 text-success" />
                      Upload Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="p-2 bg-muted rounded">
                        <p className="text-muted-foreground text-[10px] uppercase font-bold">Total</p>
                        <p className="text-xl font-bold">{uploadSummary.total}</p>
                      </div>
                      <div className="p-2 bg-success/10 rounded">
                        <p className="text-success text-[10px] uppercase font-bold">Success</p>
                        <p className="text-xl font-bold text-success">{uploadSummary.success}</p>
                      </div>
                      <div className="p-2 bg-destructive/10 rounded">
                        <p className="text-destructive text-[10px] uppercase font-bold">Failed</p>
                        <p className="text-xl font-bold text-destructive">{uploadSummary.failed}</p>
                      </div>
                    </div>

                    {uploadSummary.errors && uploadSummary.errors.length > 0 && (
                      <div className="space-y-2">
                        <p className="text-sm font-semibold flex items-center gap-1">
                          <AlertCircle className="h-4 w-4 text-destructive" />
                          Errors ({uploadSummary.errors.length})
                        </p>
                        <div className="max-h-[200px] overflow-y-auto space-y-1 text-xs">
                          {uploadSummary.errors.map((err: any, idx: number) => (
                            <div key={idx} className="p-2 bg-destructive/5 border border-destructive/10 rounded">
                              <span className="font-bold text-destructive">Row {err.row}:</span> {err.message}
                              <p className="text-muted-foreground mt-0.5">{err.email}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>

        {/* Edit Doctor Dialog */}
        <Dialog open={editOpen} onOpenChange={setEditOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Doctor</DialogTitle>
              <DialogDescription>Update profile and password. Password is stored in the doctors table; use &quot;Send email&quot; to send credentials to the doctor.</DialogDescription>
            </DialogHeader>
            {editingDoctor && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
                <div className="space-y-2">
                  <Label>Full Name</Label>
                  <Input
                    value={editForm.name}
                    onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                    placeholder="Dr. John Smith"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input
                    type="email"
                    value={editForm.email}
                    onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                    placeholder="doctor@example.com"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Password (stored in doctors table)</Label>
                  <div className="flex gap-2">
                    <Input
                      type="text"
                      value={editForm.password}
                      onChange={(e) => setEditForm({ ...editForm, password: e.target.value })}
                      placeholder="Set or change password"
                      className="font-mono"
                    />
                    <Button type="button" variant="outline" size="sm" onClick={() => setEditForm({ ...editForm, password: generateRandomPassword() })}>
                      Generate
                    </Button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Phone</Label>
                  <Input
                    value={editForm.phone}
                    onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                    placeholder="+1-234-567-8900"
                  />
                </div>
                <div className="space-y-2">
                  <Label>City</Label>
                  <Select value={editForm.city} onValueChange={(v) => setEditForm({ ...editForm, city: v })}>
                    <SelectTrigger><SelectValue placeholder="Select city" /></SelectTrigger>
                    <SelectContent>
                      {cities.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Timezone</Label>
                  <Select value={editForm.timezone} onValueChange={(v) => setEditForm({ ...editForm, timezone: v })}>
                    <SelectTrigger><SelectValue placeholder="Select timezone" /></SelectTrigger>
                    <SelectContent className="max-h-[300px]">
                      {Object.values(countryTimezones).filter((v, i, a) => a.indexOf(v) === i).sort().map((tz) => (
                        <SelectItem key={tz} value={tz}>{tz}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Specialization</Label>
                  <Select value={editForm.specialization} onValueChange={(v) => setEditForm({ ...editForm, specialization: v })}>
                    <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                    <SelectContent>
                      {specializations.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Years of Experience</Label>
                  <Input
                    type="number"
                    min={0}
                    value={editForm.yearsOfExperience}
                    onChange={(e) => setEditForm({ ...editForm, yearsOfExperience: e.target.value })}
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={editForm.isActive}
                    onCheckedChange={(v) => setEditForm({ ...editForm, isActive: v })}
                  />
                  <Label>Active</Label>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditOpen(false)}>Cancel</Button>
              <Button onClick={handleEditSave} disabled={isSubmitting}>
                {isSubmitting ? 'Saving...' : 'Save'}
              </Button>
              {editingDoctor && (
                <Button
                  variant="secondary"
                  disabled={isSubmitting}
                  onClick={async () => {
                    const res = await adminDoctorApi.updateDoctor(editingDoctor.id, {
                      name: editForm.name,
                      email: editForm.email,
                      password: editForm.password.trim() || undefined,
                      phone: editForm.phone,
                      city: editForm.city,
                      specialization: editForm.specialization,
                      yearsOfExperience: parseInt(editForm.yearsOfExperience || '0', 10),
                      isActive: editForm.isActive,
                    });
                    if (res.success) {
                      setEditOpen(false);
                      setEditingDoctor(null);
                      fetchDoctorsList();
                      await handleSendEmail(editingDoctor.id);
                    } else {
                      toast.error(res.message || 'Update failed');
                    }
                  }}
                >
                  Save &amp; Send email
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete confirmation */}
        <AlertDialog open={!!deleteTargetId} onOpenChange={(open) => !open && setDeleteTargetId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete doctor?</AlertDialogTitle>
              <AlertDialogDescription>
                This will remove the doctor and their user account. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </DashboardLayout>
  );
}
