import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import {
  LayoutDashboard,
  Users,
  Calendar,
  CalendarCheck,
  CreditCard,
  FileText,
  BarChart3,
  Video,
  Phone,
  DollarSign,
  Loader2,
  User,
  Receipt,
  Globe,
} from 'lucide-react';
import { format } from 'date-fns';
import { adminPatientsApi, adminDoctorApi, adminApi, appointmentApi } from '@/services/api';
import { adminNavigation } from '@/config/adminNavigation';
import type { AdminPatient, AdminAppointmentRequest, AdminAppointment, TransactionStats, Transaction } from '@/services/api';
import { AppointmentRequestStatus } from '@/services/api';
import { toast } from 'sonner';

const requestStatusConfig: Record<AppointmentRequestStatus, { variant: 'pending' | 'assigned' | 'cancelled'; label: string }> = {
  PENDING: { variant: 'pending', label: 'Pending' },
  ASSIGNED: { variant: 'assigned', label: 'Assigned' },
  CANCELLED: { variant: 'cancelled', label: 'Cancelled' },
};

const appointmentStatusConfig: Record<string, { variant: 'default' | 'secondary' | 'outline'; label: string }> = {
  SCHEDULED: { variant: 'secondary', label: 'Scheduled' },
  COMPLETED: { variant: 'default', label: 'Completed' },
  CANCELLED: { variant: 'outline', label: 'Cancelled' },
};

export default function AdminDashboard() {
  const [loading, setLoading] = useState(true);
  const [patients, setPatients] = useState<AdminPatient[]>([]);
  const [doctors, setDoctors] = useState<any[]>([]);
  const [requests, setRequests] = useState<AdminAppointmentRequest[]>([]);
  const [appointments, setAppointments] = useState<AdminAppointment[]>([]);
  const [transactionStats, setTransactionStats] = useState<TransactionStats | null>(null);
  const [recentTransactions, setRecentTransactions] = useState<Transaction[]>([]);
  const [assigning, setAssigning] = useState<string | null>(null);

  const loadData = async () => {
    try {
      setLoading(true);
      const [
        patientsRes,
        doctorsRes,
        requestsRes,
        appointmentsRes,
        statsRes,
        transactionsRes,
      ] = await Promise.all([
        adminPatientsApi.getPatients(),
        adminDoctorApi.getDoctors(),
        appointmentApi.getAdminRequests({}),
        appointmentApi.getAdminAppointments(),
        adminApi.getTransactionStats(),
        adminApi.getTransactions({ limit: 5 }),
      ]);

      if (patientsRes.success && patientsRes.data?.patients) setPatients(patientsRes.data.patients);
      if (doctorsRes.success && doctorsRes.data) {
        setDoctors(
          doctorsRes.data.map((d: any) => ({
            ...d,
            doctorUuid: d.doctorUuid,
            name: d.name ?? (d.User ? `${d.User.firstName ?? ''} ${d.User.lastName ?? ''}`.trim() : 'Doctor'),
            isActive: d.isActive ?? d.User?.isActive ?? true,
          }))
        );
      }
      if (requestsRes.success && requestsRes.data) setRequests(requestsRes.data);
      if (appointmentsRes.success && appointmentsRes.data) setAppointments(appointmentsRes.data);
      if (statsRes.success && statsRes.data) setTransactionStats(statsRes.data);
      if (transactionsRes.success && transactionsRes.data?.payments) setRecentTransactions(transactionsRes.data.payments);
    } catch (e: any) {
      toast.error(e?.message || 'Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleAssignDoctor = async (requestUuid: string, doctorId: string) => {
    const doctor = doctors.find((d) => String(d.id) === String(doctorId));
    if (!doctor?.doctorUuid) {
      toast.error('Invalid doctor');
      return;
    }
    setAssigning(requestUuid);
    try {
      const res = await appointmentApi.assignDoctor({ requestUuid, doctorUuid: doctor.doctorUuid });
      if (!res.success) {
        toast.error(res.message || 'Failed to assign doctor');
        return;
      }
      toast.success('Doctor assigned');
      await loadData();
    } catch (e: any) {
      toast.error(e?.message || 'Failed to assign doctor');
    } finally {
      setAssigning(null);
    }
  };

  const [selectedCity, setSelectedCity] = useState('ALL');

  const cities = Array.from(new Set([
    ...patients.map(p => p.city).filter(Boolean),
    ...doctors.map(d => d.city).filter(Boolean),
    ...requests.map(r => r.city).filter(Boolean),
    ...appointments.map(a => a.city).filter(Boolean)
  ])).sort() as string[];

  const filteredPatients = selectedCity === 'ALL' ? patients : patients.filter(p => p.city === selectedCity);
  const filteredDoctors = selectedCity === 'ALL' ? doctors : doctors.filter(d => d.city === selectedCity);
  const filteredRequests = selectedCity === 'ALL' ? requests : requests.filter(r => r.city === selectedCity);
  const filteredAppointments = selectedCity === 'ALL' ? appointments : appointments.filter(a => a.city === selectedCity);

  const pendingRequests = filteredRequests.filter((r) => r.status === 'PENDING');
  const patientsWithPlan = filteredPatients.filter((p) => p.activePlan != null).length;
  const liveDoctors = filteredDoctors.filter(d => d.isOnline || d.is_online).length;

  if (loading) {
    return (
      <DashboardLayout navigation={adminNavigation} title="Admin Dashboard">
        <div className="flex items-center justify-center min-h-[320px]">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout navigation={adminNavigation} title="Admin Dashboard">
      <div className="space-y-8 animate-fade-in">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Administrator Command Center</h1>
            <p className="text-muted-foreground mt-1">Real-time health ecosystem monitoring</p>
          </div>
          <div className="flex items-center gap-2">
            <Globe className="h-4 w-4 text-muted-foreground" />
            <Select value={selectedCity} onValueChange={setSelectedCity}>
              <SelectTrigger className="w-[180px] rounded-full border-primary/20 bg-primary/5">
                <SelectValue placeholder="Global View" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">Global View (All)</SelectItem>
                {cities.map(city => (
                  <SelectItem key={city} value={city}>{city}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Platform Summary Card */}
        <Card className="border-none shadow-premium bg-gradient-to-br from-slate-900 to-slate-800 text-white overflow-hidden relative">
          <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
            <BarChart3 className="h-32 w-32" />
          </div>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Badge className="bg-primary/20 text-primary-foreground border-none">LIVE METRICS</Badge>
              <CardTitle className="text-xl">Platform Summary</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div className="space-y-1">
                <p className="text-slate-400 text-sm">Active Patients</p>
                <p className="text-4xl font-black text-white">{filteredPatients.length}</p>
                <div className="flex items-center gap-1 text-[10px] text-success">
                  <div className="h-1 w-1 rounded-full bg-success animate-pulse" />
                  {filteredPatients.filter(p => p.isActive).length} Verified Users
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-slate-400 text-sm">Online Doctors</p>
                <p className="text-4xl font-black text-primary">{liveDoctors}</p>
                <div className="flex items-center gap-1 text-[10px] text-primary">
                  <div className="h-1 w-1 rounded-full bg-primary animate-pulse" />
                  {filteredDoctors.length} Total in {selectedCity === 'ALL' ? 'Platform' : selectedCity}
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-slate-400 text-sm">Booked Appointments</p>
                <p className="text-4xl font-black text-accent">{filteredAppointments.length}</p>
                <div className="flex items-center gap-1 text-[10px] text-accent">
                  {filteredAppointments.filter(a => a.status === 'COMPLETED').length} Successfully Fulfilled
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-slate-400 text-sm">Active Plan Rev.</p>
                <p className="text-4xl font-black text-success">
                  {transactionStats != null
                    ? new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(transactionStats.thisMonthRevenue)
                    : '$0'}
                </p>
                <div className="flex items-center gap-1 text-[10px] text-success">
                  Estimated Current Month
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pending appointment requests – assign doctor */}
        <Card className="shadow-card border-0">
          <CardHeader>
            <CardTitle>Urgent {selectedCity !== 'ALL' ? selectedCity : ''} Requests</CardTitle>
            <CardDescription>Assign available doctors to incoming requests</CardDescription>
          </CardHeader>
          <CardContent>
            {pendingRequests.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4">No pending requests in {selectedCity === 'ALL' ? 'the selected region' : selectedCity}.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Patient</TableHead>
                    <TableHead>City</TableHead>
                    <TableHead>Service</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Requested</TableHead>
                    <TableHead>Assign doctor</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pendingRequests.slice(0, 8).map((req) => {
                    const patientName = req.patient ? `${req.patient.firstName} ${req.patient.lastName}` : '—';
                    return (
                      <TableRow key={req.requestUuid}>
                        <TableCell className="font-medium">{patientName}</TableCell>
                        <TableCell>{req.city ?? '—'}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            {req.serviceType === 'TELEHEALTH' ? <Video className="h-4 w-4 text-accent" /> : <Phone className="h-4 w-4 text-primary" />}
                            {req.serviceType === 'TELEHEALTH' ? 'Telehealth' : 'Emergency'}
                          </div>
                        </TableCell>
                        <TableCell><Badge variant="secondary">{req.plan?.name ?? '—'}</Badge></TableCell>
                        <TableCell className="text-muted-foreground text-sm">{format(new Date(req.createdAt), 'MMM d, HH:mm')}</TableCell>
                        <TableCell>
                          {assigning === req.requestUuid ? (
                            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                          ) : (
                            <Select onValueChange={(v) => handleAssignDoctor(req.requestUuid, v)}>
                              <SelectTrigger className="w-40 rounded-full">
                                <SelectValue placeholder="Assign doctor" />
                              </SelectTrigger>
                              <SelectContent>
                                {filteredDoctors.filter((d) => d.isActive).map((doc) => (
                                  <SelectItem key={doc.id} value={String(doc.id)}>{doc.name}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Recent appointments */}
          <Card className="shadow-card border-0">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Latest Appointments</CardTitle>
                <CardDescription>History for {selectedCity === 'ALL' ? 'Global' : selectedCity}</CardDescription>
              </div>
              <Button variant="outline" size="sm" asChild className="rounded-full">
                <Link to="/admin/appointments">View all</Link>
              </Button>
            </CardHeader>
            <CardContent>
              {filteredAppointments.length === 0 ? (
                <p className="text-sm text-muted-foreground py-4">No appointments yet.</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Patient</TableHead>
                      <TableHead>Doctor</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAppointments.slice(0, 6).map((apt) => {
                      const patientName = apt.patient ? `${apt.patient.firstName} ${apt.patient.lastName}` : '—';
                      const doctorName = apt.doctor?.name ?? '—';
                      const st = appointmentStatusConfig[apt.status] ?? { variant: 'outline', label: apt.status };
                      return (
                        <TableRow key={apt.appointmentUuid}>
                          <TableCell className="font-medium text-sm">{patientName}</TableCell>
                          <TableCell className="text-sm">{doctorName}</TableCell>
                          <TableCell><Badge variant={st.variant} className="text-[10px]">{st.label}</Badge></TableCell>
                          <TableCell className="text-muted-foreground text-[10px]">
                            {apt.appointmentDate ? format(new Date(apt.appointmentDate), 'MMM d, yyyy') : '—'}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          {/* Recent patients */}
          <Card className="shadow-card border-0">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>New Registrations</CardTitle>
                <CardDescription>Recent joins in {selectedCity === 'ALL' ? 'Platform' : selectedCity}</CardDescription>
              </div>
              <Button variant="outline" size="sm" asChild className="rounded-full">
                <Link to="/admin/patients">View all</Link>
              </Button>
            </CardHeader>
            <CardContent>
              {filteredPatients.length === 0 ? (
                <p className="text-sm text-muted-foreground py-4">No patients yet.</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Plan</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[...filteredPatients]
                      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                      .slice(0, 6)
                      .map((p) => (
                        <TableRow key={p.id}>
                          <TableCell className="font-medium">
                            <span className="flex items-center gap-1 text-sm">
                              <User className="h-3 w-3 text-muted-foreground" />
                              {p.firstName} {p.lastName}
                            </span>
                          </TableCell>
                          <TableCell>
                            {p.activePlan ? (
                              <Badge variant="secondary" className="text-[10px]">{p.activePlan.planName}</Badge>
                            ) : (
                              <span className="text-muted-foreground text-[10px]">No plan</span>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Revenue summary + recent transactions */}
        <Card className="shadow-card border-0">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Revenue & recent transactions</CardTitle>
              <CardDescription>Total revenue and latest payments</CardDescription>
            </div>
            <Button variant="outline" size="sm" asChild>
              <Link to="/admin/transactions">
                <Receipt className="mr-1 h-4 w-4" /> View all
              </Link>
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="rounded-lg border bg-muted/50 p-3">
                <p className="text-xs text-muted-foreground">Total revenue</p>
                <p className="text-lg font-semibold">
                  {transactionStats != null
                    ? new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(transactionStats.totalRevenue)
                    : '—'}
                </p>
              </div>
              <div className="rounded-lg border bg-muted/50 p-3">
                <p className="text-xs text-muted-foreground">This month</p>
                <p className="text-lg font-semibold">
                  {transactionStats != null
                    ? new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(transactionStats.thisMonthRevenue)
                    : '—'}
                </p>
              </div>
              <div className="rounded-lg border bg-muted/50 p-3">
                <p className="text-xs text-muted-foreground">Total transactions</p>
                <p className="text-lg font-semibold">{transactionStats?.totalTransactions ?? '—'}</p>
              </div>
              <div className="rounded-lg border bg-muted/50 p-3">
                <p className="text-xs text-muted-foreground">Refunded</p>
                <p className="text-lg font-semibold">
                  {transactionStats != null
                    ? new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(transactionStats.refundedAmount)
                    : '—'}
                </p>
              </div>
            </div>
            {recentTransactions.length > 0 && (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentTransactions.map((tx) => (
                    <TableRow key={tx.id}>
                      <TableCell>
                        {tx.User ? `${tx.User.firstName} ${tx.User.lastName}` : `User #${tx.userId}`}
                      </TableCell>
                      <TableCell>{tx.Plan?.name ?? '—'}</TableCell>
                      <TableCell>
                        {new Intl.NumberFormat('en-US', { style: 'currency', currency: (tx.currency || 'USD').toUpperCase() }).format((tx.amount ?? 0) / 100)}
                      </TableCell>
                      <TableCell><Badge variant={tx.status === 'SUCCESS' ? 'default' : 'secondary'}>{tx.status}</Badge></TableCell>
                      <TableCell className="text-muted-foreground text-sm">{format(new Date(tx.createdAt), 'MMM d, HH:mm')}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
