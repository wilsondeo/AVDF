import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Shield,
  Mail,
  UserX,
  FileText,
  ArrowLeft,
  Settings,
  Database,
  Clock
} from 'lucide-react';
import navalaLogo from '@/assets/navala.png';

export default function AccountDeletionPage() {
  return (
    <div className="min-h-screen gradient-hero pattern-medical">
      {/* Top bar */}
      <header className="sticky top-0 z-10 border-b border-border/60 bg-card/80 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/login" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
            <img src={navalaLogo} alt="Navala" className="h-8 w-auto" />
          </Link>
          <Link to="/login">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Login
            </Button>
          </Link>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8 pb-16">
        {/* Hero */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-destructive/10 text-destructive mb-6">
            <UserX className="h-7 w-7" strokeWidth={2} />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground tracking-tight mb-3">
            Account Deletion
          </h1>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            How to request the deletion of your Navala Travel Health account and associated data.
          </p>
        </div>

        <div className="space-y-8">
          {/* How to Delete */}
          <Card className="border-border/60 bg-card shadow-card overflow-hidden">
            <CardHeader className="pb-3 border-b border-border/60 bg-muted/30">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-primary/10 text-primary shrink-0">
                  <Settings className="h-5 w-5" strokeWidth={2} />
                </div>
                <CardTitle className="text-xl">How to Request Deletion</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="pt-6 prose prose-slate dark:prose-invert max-w-none">
              <p className="mb-4 text-foreground text-[15px] leading-relaxed">
                Users can request account deletion by following either of these steps:
              </p>
              <div className="flex flex-col gap-4 text-foreground">
                <div className="flex gap-4 p-4 rounded-lg bg-muted/50 border border-border">
                  <div className="flex items-center justify-center h-8 w-8 rounded-full bg-background border shadow-sm font-bold shrink-0">1</div>
                  <div>
                    <h3 className="font-semibold text-base mb-1">Via Account Settings</h3>
                    <p className="text-sm text-muted-foreground">Login to the app and navigate to your profile settings to initiate account deletion.</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 py-2 px-6">
                  <div className="flex-1 h-px bg-border"></div>
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">OR</span>
                  <div className="flex-1 h-px bg-border"></div>
                </div>
                <div className="flex gap-4 p-4 rounded-lg bg-muted/50 border border-border">
                  <div className="flex items-center justify-center h-8 w-8 rounded-full bg-background border shadow-sm font-bold shrink-0">2</div>
                  <div>
                    <h3 className="font-semibold text-base mb-1">Via Email Request</h3>
                    <p className="text-sm text-muted-foreground mb-2">Send a request email to <strong>info@navalaglobal.com</strong>.</p>
                    <p className="text-sm text-muted-foreground flex items-center gap-2">
                      <FileText className="h-4 w-4" /> Please include your <strong>Registered email / phone number</strong> in the email.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Data Deleted */}
          <Card className="border-border/60 bg-card shadow-card overflow-hidden">
            <CardHeader className="pb-3 border-b border-border/60 bg-muted/30">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-destructive/10 text-destructive shrink-0">
                  <Database className="h-5 w-5" strokeWidth={2} />
                </div>
                <CardTitle className="text-xl">Data That Will Be Deleted</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="pt-6 prose prose-slate dark:prose-invert max-w-none">
              <p className="mb-3 text-foreground text-[15px] leading-relaxed">
                Upon fulfilling your deletion request, the following information will be permanently removed:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                <li><strong className="text-foreground">Personal details:</strong> Name, contact information, and demographic data.</li>
                <li><strong className="text-foreground">Medical data:</strong> Health records, visit history, and prescribed medications.</li>
                <li><strong className="text-foreground">Account information:</strong> Login credentials, preferences, and linked profiles.</li>
              </ul>
            </CardContent>
          </Card>

          {/* Data Retention */}
          <Card className="border-border/60 bg-card shadow-card overflow-hidden">
            <CardHeader className="pb-3 border-b border-border/60 bg-muted/30">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-warning/10 text-warning shrink-0">
                  <Clock className="h-5 w-5" strokeWidth={2} />
                </div>
                <CardTitle className="text-xl">Data Retention</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="pt-6 prose prose-slate dark:prose-invert max-w-none">
              <div className="flex gap-4 items-start text-foreground text-[15px] leading-relaxed">
                <Shield className="h-6 w-6 text-warning shrink-0 mt-0.5" />
                <p>
                  Some data may be retained for legal, compliance, or security purposes for up to <strong>30 days</strong>. After this retention period, all remaining data will be securely and permanently deleted from our systems.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Footer CTA */}
        <div className="mt-14 text-center">
          <p className="text-muted-foreground text-sm mb-4 flex items-center justify-center gap-2">
            <Mail className="h-4 w-4" /> Need help? Contact us at info@navalaglobal.com
          </p>
          <Link to="/login">
            <Button variant="outline" size="lg" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Return to Login
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
