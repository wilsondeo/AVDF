import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Shield,
  Lock,
  Database,
  Mail,
  Globe,
  FileText,
  ArrowLeft,
  ChevronRight,
} from 'lucide-react';
import navalaLogo from '@/assets/navala.png';

const sections = [
  {
    id: 'intro',
    icon: FileText,
    title: 'Introduction',
    content: (
      <>
        <p className="mb-4">
          Navala Travel Health (&quot;we,&quot; &quot;our,&quot; or &quot;us&quot;) is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our platform, including our website, mobile experience, and healthcare services for travelers.
        </p>
        <p>
          By using Navala Travel Health, you agree to the collection and use of information in accordance with this policy. If you do not agree, please do not use our services.
        </p>
      </>
    ),
  },
  {
    id: 'collect',
    icon: Database,
    title: 'Information We Collect',
    content: (
      <>
        <p className="mb-3">We collect information that you provide directly and information that is collected automatically:</p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
          <li><strong className="text-foreground">Account & profile:</strong> Name, email, password, phone number, date of birth, address, and country.</li>
          <li><strong className="text-foreground">Health-related data:</strong> Medical history relevant to consultations, vitals you choose to log, medications, emergency contact details, and blood type when provided.</li>
          <li><strong className="text-foreground">Travel context:</strong> Travel dates and destination information when relevant to your care.</li>
          <li><strong className="text-foreground">Payment data:</strong> Payment is processed by Stripe. We do not store full card numbers; we receive only transaction identifiers and billing information necessary for records.</li>
          <li><strong className="text-foreground">Usage data:</strong> Device type, browser, IP address, and how you use our app (e.g., pages visited, features used) to improve our services.</li>
        </ul>
      </>
    ),
  },
  {
    id: 'use',
    icon: Shield,
    title: 'How We Use Your Information',
    content: (
      <>
        <p className="mb-3">We use the information we collect to:</p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
          <li>Provide, maintain, and improve our healthcare and travel health services.</li>
          <li>Authenticate your account and process your plan purchases and appointments.</li>
          <li>Enable telehealth and in-person consultations with healthcare professionals.</li>
          <li>Send you service-related communications (e.g., appointment reminders, plan activation).</li>
          <li>Comply with legal and regulatory obligations and protect our rights and your safety.</li>
          <li>Analyze usage in an aggregated, non-personally-identifying way to improve our product.</li>
        </ul>
      </>
    ),
  },
  {
    id: 'health',
    icon: Shield,
    title: 'Health Data & HIPAA',
    content: (
      <>
        <p className="mb-4">
          Health information you provide through Navala Travel Health is treated as protected health information (PHI) where applicable. We follow practices designed to meet or support compliance with the Health Insurance Portability and Accountability Act (HIPAA) and other applicable health privacy laws. Our healthcare providers and we use your health data only to deliver care, manage your account, and as required by law.
        </p>
        <p>
          We do not sell your health information. We share it only as described in this policy (e.g., with treating clinicians, payment processors as needed, or when required by law).
        </p>
      </>
    ),
  },
  {
    id: 'security',
    icon: Lock,
    title: 'Data Security',
    content: (
      <>
        <p className="mb-4">
          We implement technical and organizational measures to protect your data, including encryption in transit and at rest, access controls, and regular security assessments. Despite our efforts, no system can be 100% secure; we encourage you to use a strong password and keep your login details private.
        </p>
        <p>
          In the event of a data breach that affects your personal or health information, we will notify you and relevant authorities as required by applicable law.
        </p>
      </>
    ),
  },
  {
    id: 'third-parties',
    icon: Globe,
    title: 'Third-Party Services',
    content: (
      <>
        <p className="mb-4">
          We use trusted third parties to operate our service:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground mb-4">
          <li><strong className="text-foreground">Stripe</strong> — Payment processing. Their privacy policy applies to payment data they collect and process.</li>
          <li><strong className="text-foreground">Hosting & infrastructure</strong> — Our applications and data are hosted on secure, compliant infrastructure.</li>
          <li><strong className="text-foreground">Communication & analytics</strong> — We may use services for email, notifications, and aggregated analytics.</li>
        </ul>
        <p>
          We do not sell your personal or health information to third parties for marketing. We share data only as necessary to provide our services or as required by law.
        </p>
      </>
    ),
  },
  {
    id: 'cookies',
    icon: Lock,
    title: 'Cookies & Similar Technologies',
    content: (
      <>
        <p>
          We use cookies and similar technologies to keep you logged in, remember your preferences, and understand how our platform is used. You can control cookies through your browser settings. Disabling certain cookies may limit some features of our service.
        </p>
      </>
    ),
  },
  {
    id: 'rights',
    icon: Shield,
    title: 'Your Rights',
    content: (
      <>
        <p className="mb-4">Depending on your location, you may have the right to:</p>
        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
          <li>Access and receive a copy of your personal and health data we hold.</li>
          <li>Correct or update inaccurate information.</li>
          <li>Request deletion of your data, subject to legal and operational retention requirements.</li>
          <li>Object to or restrict certain processing of your data.</li>
          <li>Data portability — receive your data in a structured, machine-readable format.</li>
          <li>Withdraw consent where processing is based on consent.</li>
        </ul>
        <p className="mt-4">
          To exercise these rights, contact us using the details below. We will respond within the time required by applicable law. You also have the right to lodge a complaint with a supervisory authority.
        </p>
      </>
    ),
  },
  {
    id: 'international',
    icon: Globe,
    title: 'International Users & Children',
    content: (
      <>
        <p className="mb-4">
          Our services may be accessed from different countries. By using Navala Travel Health, you consent to the transfer and processing of your information in the jurisdictions where we operate, which may have different privacy laws than your country of residence.
        </p>
        <p>
          Our services are not directed to individuals under 18. We do not knowingly collect personal or health information from children. If you believe we have collected such information, please contact us so we can delete it.
        </p>
      </>
    ),
  },
  {
    id: 'contact',
    icon: Mail,
    title: 'Contact Us',
    content: (
      <>
        <p className="mb-4">
          For privacy-related questions, to exercise your rights, or to report a concern, please contact us:
        </p>
        <p className="text-muted-foreground">
          <strong className="text-foreground">Navala Travel Health</strong><br />
          Privacy / Data Protection<br />
          Email: info@navalaglobal.com
        </p>
        <p className="mt-4 text-sm text-muted-foreground">
          We will respond to your request as required by applicable law.
        </p>
      </>
    ),
  },
];

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen gradient-hero pattern-medical">
      {/* Top bar */}
      <header className="sticky top-0 z-10 border-b border-border/60 bg-card/80 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/login" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
            <img src={navalaLogo} alt="Navala" className="h-8 w-auto" />
          </Link>
          <Link to="/login">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Login
            </Button>
          </Link>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8 pb-16">
        {/* Hero */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-primary/10 text-primary mb-6">
            <Shield className="h-7 w-7" strokeWidth={2} />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground tracking-tight mb-3">
            Privacy Policy
          </h1>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            How Navala Travel Health collects, uses, and protects your information.
          </p>
          <p className="text-sm text-muted-foreground mt-4">
            Last updated: February 10, 2025
          </p>
        </div>

        {/* Table of contents - compact */}
        <Card className="mb-10 border-border/60 bg-card/50 shadow-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <ChevronRight className="h-4 w-4 text-accent" />
              On this page
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <nav className="flex flex-wrap gap-x-4 gap-y-1 text-sm">
              {sections.map((s) => (
                <a
                  key={s.id}
                  href={`#${s.id}`}
                  className="text-muted-foreground hover:text-accent transition-colors"
                >
                  {s.title}
                </a>
              ))}
            </nav>
          </CardContent>
        </Card>

        {/* Sections */}
        <div className="space-y-8">
          {sections.map((section) => {
            const Icon = section.icon;
            return (
              <Card
                key={section.id}
                id={section.id}
                className="border-border/60 bg-card shadow-card overflow-hidden scroll-mt-24"
              >
                <CardHeader className="pb-3 border-b border-border/60 bg-muted/30">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-primary/10 text-primary shrink-0">
                      <Icon className="h-5 w-5" strokeWidth={2} />
                    </div>
                    <CardTitle className="text-xl">{section.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 prose prose-slate dark:prose-invert max-w-none">
                  <div className="text-foreground text-[15px] leading-relaxed">
                    {section.content}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Footer CTA */}
        <div className="mt-14 text-center">
          <p className="text-muted-foreground text-sm mb-4">
            Questions? Contact us at info@navalaglobal.com
          </p>
          <Link to="/login">
            <Button variant="outline" size="lg" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Return to Login
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
