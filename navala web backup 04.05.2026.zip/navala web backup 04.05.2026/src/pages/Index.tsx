import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import navalaLogo from '@/assets/navala.png';
import {
  ArrowRight,
  ShieldCheck,
  Globe2,
  PhoneCall,
  Stethoscope,
  Download,
  Users,
  MapPin,
  Mail,
  Instagram,
  Linkedin,
  Twitter,
  Facebook,
  Pill,
  Calendar,
  CreditCard,
  Star,
  Video,
  Phone,
  CheckCircle2,
} from 'lucide-react';
import { PLAN_BENEFITS_AVAILABLE } from '@/config/patientPlan';
import { planApi, type Plan } from '@/services/api';

type LandingPlanCategory = 'INDIVIDUAL' | 'FAMILY_2' | 'FAMILY_3_4';
type LandingFilterKey = 'INDIVIDUAL' | 'FAMILY_2' | 'FAMILY_3_4';

const Index = () => {
  const [landingPlans, setLandingPlans] = useState<Plan[]>([]);
  const [landingFilter, setLandingFilter] = useState<LandingFilterKey>('INDIVIDUAL');
  const [landingLoading, setLandingLoading] = useState(false);

  useEffect(() => {
    const loadLandingPlans = async () => {
      try {
        setLandingLoading(true);
        const response = await planApi.getActivePlans();
        if (response.success && response.data) {
          const normalized = response.data.plans
            .map((plan) => ({
              ...plan,
              services: Array.isArray(plan.services)
                ? plan.services
                : (typeof plan.services === 'string' ? JSON.parse(plan.services) : []),
              features: Array.isArray(plan.features)
                ? plan.features
                : (typeof plan.features === 'string' ? JSON.parse(plan.features) : []),
              price: typeof plan.price === 'string' ? parseFloat(plan.price) : (plan.price || 0),
            }))
            .sort((a, b) => (a.price || 0) - (b.price || 0));
          setLandingPlans(normalized);
        }
      } finally {
        setLandingLoading(false);
      }
    };
    loadLandingPlans();
  }, []);

  const getLandingCategoryFromPlan = (plan: Plan): LandingFilterKey => {
    if (plan.maxPersons === 1) return 'INDIVIDUAL';
    if (plan.maxPersons === 2) return 'FAMILY_2';
    if (plan.maxPersons != null && plan.maxPersons >= 3) return 'FAMILY_3_4';
    const tab = (plan.planTabName || '').toLowerCase();
    if (tab.includes('family of 3-4')) return 'FAMILY_3_4';
    if (tab.includes('family of 2')) return 'FAMILY_2';
    if (tab.includes('individual')) return 'INDIVIDUAL';
    const name = (plan.name || '').toLowerCase();
    if (name.includes('family of 3-4')) return 'FAMILY_3_4';
    if (name.includes('family of 2')) return 'FAMILY_2';
    return 'INDIVIDUAL';
  };

  const landingFilteredPlans = landingPlans.filter(
    (p) => getLandingCategoryFromPlan(p) === landingFilter,
  );

  const renderLandingPlansContent = () => {
    if (landingLoading) {
      return (
        <p className="text-center text-sm text-slate-500">Loading plans…</p>
      );
    }

    if (landingFilteredPlans.length === 0) {
      return (
        <p className="text-center text-sm text-slate-500">No plans available.</p>
      );
    }

    return (
      <div className="grid gap-6 md:grid-cols-2">
        {landingFilteredPlans.map((plan, index) => (
          <Card
            key={plan.planId}
            className={`shadow-card border-0 relative overflow-hidden flex flex-col min-h-[360px] h-full w-full max-w-sm mx-auto transition-all duration-200 ease-out
              ${index === 1 && landingFilteredPlans.length > 1 ? 'ring-2 ring-accent' : ''}`}
          >
            <div className="h-1.5 shrink-0 gradient-primary" />
            {index === 1 && landingFilteredPlans.length > 1 && (
              <div className="absolute top-3 right-3">
                <Badge variant="info" className="flex items-center gap-1 text-[10px]">
                  <Star className="h-3 w-3" />
                  Most Popular
                </Badge>
              </div>
            )}
            <CardHeader className="text-center pt-6 shrink-0">
              <CardTitle className="text-lg">{plan.name}</CardTitle>
              <CardDescription>{plan.description || 'No description'}</CardDescription>
              <div className="mt-3">
                <span className="text-3xl font-bold text-foreground">
                  ${plan.price}
                </span>
                <span className="block text-xs text-muted-foreground mt-1">
                  Validity: {PLAN_BENEFITS_AVAILABLE.fromLabel} –{' '}
                  {PLAN_BENEFITS_AVAILABLE.toLabel}
                </span>
              </div>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col pt-0 min-h-0 pb-5">
              <div className="flex-1 flex flex-col min-h-[160px] space-y-3">
                <div className="shrink-0">
                  <p className="text-xs font-medium mb-1.5 uppercase tracking-wide text-slate-500">
                    Services Included
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {Array.isArray(plan.services) && plan.services.length > 0 ? (
                      plan.services.map((service) => (
                        <Badge
                          key={service}
                          variant="secondary"
                          className="flex items-center gap-1 text-[11px]"
                        >
                          {service === 'TELEHEALTH' && (
                            <Video className="h-3 w-3" />
                          )}
                          {service === 'EMERGENCY' && (
                            <Phone className="h-3 w-3" />
                          )}
                          {service === 'TELEHEALTH'
                            ? 'telehealth'
                            : service === 'EMERGENCY'
                            ? 'Emergency'
                            : service}
                        </Badge>
                      ))
                    ) : (
                      <Badge variant="secondary">No services</Badge>
                    )}
                  </div>
                </div>
                <ul className="space-y-2 flex-1 min-h-0 overflow-hidden list-none pl-0">
                  {Array.isArray(plan.features) && plan.features.length > 0 ? (
                    plan.features.slice(0, 4).map((feature, i) => (
                      <li key={i} className="flex items-center gap-2 text-xs">
                        <CheckCircle2 className="h-3.5 w-3.5 text-accent shrink-0" />
                        <span className="leading-snug text-slate-700">
                          {feature}
                        </span>
                      </li>
                    ))
                  ) : (
                    <li className="text-xs text-muted-foreground">
                      No features listed
                    </li>
                  )}
                </ul>
              </div>
              <div className="shrink-0 mt-4">
                <Button asChild className="w-full h-9 text-xs">
                  <Link to="/register">
                    <CreditCard className="h-3 w-3 mr-1.5" />
                    Get this plan
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Top Nav */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-sm">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 md:py-4 lg:px-8 xl:px-12">
          <div className="flex items-center gap-2">
            <img src={navalaLogo} alt="Navala Travel Health" className="h-8 w-auto md:h-9" />
            <div className="leading-tight">
              <p className="text-sm font-semibold tracking-wide uppercase text-slate-900">
                Navala Travel Health
              </p>
              <p className="text-xs text-slate-500 hidden sm:block">
                 World Cup 2026 Medical Access
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-600">
              <a href="#about" className="hover:text-blue-600 transition-colors">
                About
              </a>
              <a href="#plans" className="hover:text-blue-600 transition-colors">
                Plans
              </a>
              <a href="#how-it-works" className="hover:text-blue-600 transition-colors">
                How it works
              </a>
              <a href="#why-navala" className="hover:text-blue-600 transition-colors">
                Why Navala
              </a>
              <a href="#download" className="hover:text-blue-600 transition-colors">
                Download app
              </a>
            </nav>

            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                className="text-xs px-3 py-1 h-8 text-slate-700 hover:text-blue-700"
                asChild
              >
                <Link to="/login">Sign in</Link>
              </Button>
              <Button
                size="sm"
                className="text-xs px-3 py-1 h-8 bg-blue-600 hover:bg-blue-500 text-white font-semibold shadow-lg shadow-blue-500/30"
                asChild
              >
                <Link to="/register">
                  Sign up
                  <ArrowRight className="ml-1 h-3 w-3" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="min-w-0">
        {/* Hero Section - full bleed with background image */}
        <section
          className="relative min-h-[75vh] sm:min-h-[78vh] lg:min-h-[82vh] flex items-center overflow-hidden"
          aria-label="Hero"
        >
          {/* Background image - travel / stadium / world cup vibe */}
          <div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: `linear-gradient(105deg, rgba(255,255,255,0.97) 0%, rgba(255,255,255,0.92) 42%, rgba(255,255,255,0.75) 70%, rgba(241,245,249,0.5) 100%), url('https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=1920')`,
            }}
          />
          <div className="relative w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-12 py-12 sm:py-16 lg:py-20">
            <div className="grid gap-8 lg:gap-12 xl:gap-16 py-4 md:grid-cols-2 md:items-center animate-fade-in">
              <div className="space-y-5 sm:space-y-6 max-w-2xl">
                <Badge
                  variant="outline"
                  className="border-blue-500/40 bg-blue-50 text-blue-700 text-xs font-semibold"
                >
                  Built for the 2026  World Cup
                </Badge>
                <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-[2.75rem] font-bold tracking-tight text-slate-900">
                  World‑class soccer.{' '}
                  <span className="bg-gradient-to-r from-blue-700 via-sky-600 to-blue-500 bg-clip-text text-transparent">
                    World‑class medical access.
                  </span>
                </h1>
                <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                  Navala Travel Health was established for the discerning traveler—bringing seamless,
                  trusted healthcare access to every 2026  World Cup host city so fans can focus on
                  the match, not the medical system.
                </p>
                <div className="flex flex-wrap items-center gap-3">
                  <Button
                    size="default"
                    className="bg-blue-600 hover:bg-blue-500 text-white font-semibold shadow-lg shadow-blue-500/25"
                    asChild
                  >
                    <Link to="/register">
                      Get started now
                      <ArrowRight className="ml-1.5 h-4 w-4" />
                    </Link>
                  </Button>
                  <Button
                    size="default"
                    variant="outline"
                    className="border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
                    asChild
                  >
                    <a href="#plans">View World Cup plans</a>
                  </Button>
                </div>
                <div className="flex flex-wrap gap-4 sm:gap-6 pt-2 text-xs sm:text-sm text-slate-600">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="h-4 w-4 text-blue-600 shrink-0" />
                    <span>Locally credentialed clinicians</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Globe2 className="h-4 w-4 text-sky-500 shrink-0" />
                    <span>Every US host city</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <PhoneCall className="h-4 w-4 text-blue-500 shrink-0" />
                    <span>24/7 medical concierge</span>
                  </div>
                </div>
              </div>

              <div className="relative mt-6 md:mt-0">
                <div className="absolute -inset-4 rounded-3xl bg-gradient-to-tr from-blue-400/10 via-sky-300/10 to-transparent blur-2xl" />
                <div className="relative grid gap-4 rounded-3xl border border-slate-200/80 bg-white/95 p-5 sm:p-6 shadow-xl shadow-slate-200/50 backdrop-blur-sm">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs uppercase tracking-wide text-slate-500">
                        Host city coverage
                      </p>
                      <p className="mt-1 text-sm sm:text-base font-semibold text-slate-900">All 2026 World Cup US cities</p>
                    </div>
                    <Badge className="bg-blue-50 text-blue-700 border-blue-300 text-[10px]">
                      Verified Network
                    </Badge>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="rounded-2xl border border-slate-200 bg-slate-50/80 p-3 sm:p-4">
                      <p className="font-medium text-slate-900 mb-1 flex items-center gap-1.5 text-sm">
                        <Stethoscope className="h-4 w-4 text-blue-600 shrink-0" />
                        Telehealth first
                      </p>
                      <p className="text-slate-600 leading-relaxed text-[13px]">
                      get connected virtually  to credentialed local health care providers.
                      </p>
                    </div>
                    <div className="rounded-2xl border border-slate-200 bg-slate-50/80 p-3 sm:p-4">
                      <p className="font-medium text-slate-900 mb-1 flex items-center gap-1.5 text-sm">
                        <Globe2 className="h-4 w-4 text-sky-500 shrink-0" />
                        Medical concierge
                      </p>
                      <p className="text-slate-600 leading-relaxed text-[13px]">
                         A dedicated health concierge available 24/7 
                      </p>
                    </div>
                    <div className="sm:col-span-2 rounded-2xl border border-blue-200 bg-gradient-to-r from-blue-50 to-sky-50/80 p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                      <div>
                        <p className="font-semibold text-blue-900 text-sm">Built for global fans</p>
                        <p className="text-blue-800/90 text-[13px]">
                          One membership, complete medical clarity in the US.
                        </p>
                      </div>
                      <Badge variant="outline" className="border-blue-400/60 text-[10px] text-blue-700 bg-blue-50 w-fit">
                        2026 Tournament Ready
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-12 md:py-16 lg:py-20 border-t border-slate-200 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-12">
            <div className="grid gap-10 lg:gap-14 md:grid-cols-[minmax(0,1.4fr)_minmax(0,1.1fr)] items-start animate-fade-in">
              {/* Text column */}
              <div className="space-y-5">
                <h2 className="text-xl md:text-2xl lg:text-3xl font-semibold tracking-tight text-slate-900">
                  About Navala Travel Health
                </h2>
                <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                  Navala Travel Health was established and curated for the discerning traveler. In
                  2026, Navala’s focus is to bring unprecedented healthcare access to the 2026 
                  World Cup.
                </p>
                <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                  As the United States prepares to welcome millions of global fans for the 2026 
                  World Cup, Navala Travel Health exists to ensure that world‑class soccer is matched
                  with world‑class medical access.
                </p>
                <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                  For international visitors, the U.S. healthcare system can feel complex, unfamiliar,
                  and overwhelming. Navala Travel Health simplifies that experience. Our mission is to
                  provide seamless, trusted, and immediate access to high‑quality medical care—so
                  travelers can focus on the excitement of the tournament, not the stress of
                  navigating healthcare abroad.
                </p>
                <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                  Through our established network of locally credentialed, highly qualified doctors
                  and nurses in every World Cup host city, Navala members receive direct access to
                  vetted medical professionals. Each plan includes fully covered telehealth visits and
                  a dedicated medical concierge who assists with appointments, care coordination, and
                  prescriptions—delivering clarity, confidence, and peace of mind.
                </p>
                <p className="text-sm sm:text-base text-blue-700 font-medium leading-relaxed">
                  Navala Travel Health is redefining travel medical support: accessible, personalized,
                  and built for the global stage.
                </p>
              </div>

              {/* Visual / highlights column */}
              <div className="space-y-4">
                <div
                  className="relative overflow-hidden rounded-3xl border border-slate-200 bg-slate-100/70 shadow-sm"
                >
                  <div
                    className="h-32 sm:h-48 lg:h-64 xl:h-80 bg-cover bg-center"
                    style={{
                      backgroundImage:
                        "url('https://cdn.prod.website-files.com/66bd394eedeb9d6ee29898c6/682f5450a046c241920c1e6f_Three%20doctors%20standing%20side%20by%20side%2C%20crossing%20their%20arms.jpg')",
                    }}
                  />
                  <div className="p-5 sm:p-6">
                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                      Built for global fans
                    </p>
                    <p className="mt-2 text-sm text-slate-800">
                      A dedicated, travel‑ready care layer that connects international visitors with
                      local, credentialed clinicians in every host city.
                    </p>
                  </div>
                </div>

                <div className="grid gap-3 sm:grid-cols-3 text-sm">
                  <div className="rounded-2xl border border-slate-200 bg-slate-50 p-3">
                    <p className="text-xs font-semibold text-slate-500 uppercase mb-1">Clinicians</p>
                    <p className="text-sm font-semibold text-slate-900">Locally credentialed</p>
                    <p className="mt-1 text-[11px] text-slate-600">
                      US‑licensed doctors and nurses in every host city.
                    </p>
                  </div>
                  <div className="rounded-2xl border border-slate-200 bg-slate-50 p-3">
                    <p className="text-xs font-semibold text-slate-500 uppercase mb-1">Access</p>
                    <p className="text-sm font-semibold text-slate-900">Telehealth + in‑city</p>
                    <p className="mt-1 text-[11px] text-slate-600">
                      Unlimited virtual visits plus guided in‑person options.
                    </p>
                  </div>
                  <div className="rounded-2xl border border-slate-200 bg-slate-50 p-3">
                    <p className="text-xs font-semibold text-slate-500 uppercase mb-1">Support</p>
                    <p className="text-sm font-semibold text-slate-900">Concierge‑led</p>
                    <p className="mt-1 text-[11px] text-slate-600">
                      A medical concierge team coordinating every step of care.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Plans Section */}
        <section id="plans" className="py-12 md:py-16 lg:py-20 border-t border-slate-200 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-12">
            <div className="flex flex-col items-center text-center gap-3 animate-fade-in">
              <h2 className="text-xl md:text-2xl lg:text-3xl font-semibold tracking-tight">
                Choose a World Cup Health plan
              </h2>
              <p className="mt-1 text-sm md:text-base text-slate-600 max-w-2xl">
                Simple, event‑based coverage for individuals and families. Every plan includes
                telehealth visits and specialty care coordination during the{' '}
                {PLAN_BENEFITS_AVAILABLE.dateRange} window.
              </p>
            </div>

            {/* Tabbed plan summary – live from API (same as patient UI) */}
            <Tabs
              value={landingFilter}
              onValueChange={(v) => setLandingFilter(v as LandingFilterKey)}
              className="mt-8 w-full max-w-5xl mx-auto"
            >
              <div className="flex justify-center">
                <TabsList className="inline-flex h-9 items-center justify-center rounded-full bg-muted p-1 mb-4 gap-1">
                  <TabsTrigger
                    value="INDIVIDUAL"
                    className="px-4 text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground rounded-full"
                  >
                    Individual
                  </TabsTrigger>
                  <TabsTrigger
                    value="FAMILY_2"
                    className="px-4 text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground rounded-full"
                  >
                    Family of 2
                  </TabsTrigger>
                  <TabsTrigger
                    value="FAMILY_3_4"
                    className="px-4 text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground rounded-full"
                  >
                    Family of 3–4
                  </TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="INDIVIDUAL" className="mt-8">
                {renderLandingPlansContent()}
              </TabsContent>

              <TabsContent value="FAMILY_2" className="mt-8">
                {renderLandingPlansContent()}
              </TabsContent>
              <TabsContent value="FAMILY_3_4" className="mt-8">
                {renderLandingPlansContent()}
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* Who We Serve Section */}
        <section
          id="who-we-serve"
          className="py-12 md:py-16 lg:py-20 border-t border-slate-200 bg-white"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-12">
          <div className="flex flex-col gap-8 lg:gap-10 md:flex-row md:items-start md:justify-between animate-fade-in">
            <div className="max-w-md space-y-3">
              <h2 className="text-xl md:text-2xl font-semibold tracking-tight">
                Built for every kind of World Cup traveler
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                Whether you&apos;re following one team or chasing every knockout match, Navala
                Travel Health gives you a single, simple path to trusted care in the US.
              </p>
            </div>
            <div className="grid gap-4 md:grid-cols-3 w-full">
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <div className="mb-2 flex items-center gap-2">
                  <Users className="h-4 w-4 text-blue-600" />
                  <p className="text-xs font-semibold text-slate-900">Global fans & visitors</p>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Avoid the confusion of US healthcare with direct access to vetted doctors and clear
                  next steps when you need help.
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <div className="mb-2 flex items-center gap-2">
                  <Stethoscope className="h-4 w-4 text-blue-600" />
                  <p className="text-xs font-semibold text-slate-900">Families & supporter groups</p>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  One membership for your traveling party, with pediatric‑capable clinicians and a
                  concierge who understands group needs.
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <div className="mb-2 flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-blue-600" />
                  <p className="text-xs font-semibold text-slate-900">
                    Hospitality, partners & staff
                  </p>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Support VIP guests, staff, and partners with a clear, trusted channel into local
                  medical care in every host city.
                </p>
              </div>
            </div>
          </div>
          </div>
        </section>

        {/* How It Works */}
        <section id="how-it-works" className="py-12 md:py-16 lg:py-20 border-t border-slate-200 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-12 animate-fade-in">
          <h2 className="text-xl md:text-2xl lg:text-3xl font-semibold tracking-tight text-slate-900">
            How Navala works for traveling fans
          </h2>
          <div className="mt-8 grid gap-6 sm:gap-8 md:grid-cols-3">
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
              <p className="text-xs font-semibold text-blue-600 mb-1">Step 1</p>
              <h3 className="text-sm font-semibold mb-2">Choose your plan</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Before you travel, select the Navala plan that matches your World Cup itinerary and
                host cities, then create your secure profile.
              </p>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
              <p className="text-xs font-semibold text-blue-600 mb-1">Step 2</p>
              <h3 className="text-sm font-semibold mb-2">Access care instantly</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                If you feel unwell, open the app for a telehealth visit or message the concierge
                team for local, in‑city care options and next steps.
              </p>
            </div>
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
              <p className="text-xs font-semibold text-blue-600 mb-1">Step 3</p>
              <h3 className="text-sm font-semibold mb-2">Stay focused on the match</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Navala coordinates appointments, follow‑ups, and prescriptions so you stay focused
                on the world’s biggest stage—not the healthcare system.
              </p>
            </div>
          </div>
          </div>
        </section>

        {/* Why travelers trust Navala - standout section */}
        <section
          id="why-navala"
          className="py-14 md:py-20 lg:py-24 border-t border-slate-200 bg-gradient-to-b from-blue-600 to-blue-700 text-white"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-12 animate-fade-in">
            <div className="text-center max-w-3xl mx-auto mb-10 md:mb-14">
              <h2 className="text-2xl sm:text-4xl md:text-4xl lg:text-5xl xl:text-[2.75rem] font-bold tracking-tight">
                Why Navala Travel Health
              </h2>
              <p className="mt-4 text-sm sm:text-base text-blue-100 leading-relaxed">
              connects you directly to local providers for initial consultation at no other cost. Medications are covered up to the plan limit upfront. And a medical concierge gives you peace of mind - no worry about navigating a foreign healthcare system
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              <div className="rounded-2xl border border-white/20 bg-white/10 backdrop-blur-sm p-5 sm:p-6 text-center hover:bg-white/15 transition-colors">
                <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-white/20">
                  <MapPin className="h-6 w-6 text-white" />
                </div>
                <p className="text-xs font-semibold uppercase tracking-wider text-blue-100">Host cities</p>
                <p className="mt-1 text-lg sm:text-xl font-bold text-white">All US venues</p>
                <p className="mt-2 text-xs sm:text-sm text-blue-100 leading-relaxed">
                  Coverage in every US World Cup host city, with local expertise in each market.
                </p>
              </div>
              <div className="rounded-2xl border border-white/20 bg-white/10 backdrop-blur-sm p-5 sm:p-6 text-center hover:bg-white/15 transition-colors">
                <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-white/20">
                  <PhoneCall className="h-6 w-6 text-white" />
                </div>
                <p className="text-xs font-semibold uppercase tracking-wider text-blue-100">Access</p>
                <p className="mt-1 text-lg sm:text-xl font-bold text-white">Minutes, not hours</p>
                <p className="mt-2 text-xs sm:text-sm text-blue-100 leading-relaxed">
                  Telehealth and concierge routing get you answers fast—without waiting rooms.
                </p>
              </div>
              <div className="rounded-2xl border border-white/20 bg-white/10 backdrop-blur-sm p-5 sm:p-6 text-center hover:bg-white/15 transition-colors">
                <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-white/20">
                  <ShieldCheck className="h-6 w-6 text-white" />
                </div>
                <p className="text-xs font-semibold uppercase tracking-wider text-blue-100">Support</p>
                <p className="mt-1 text-lg sm:text-xl font-bold text-white">24/7 concierge</p>
                <p className="mt-2 text-xs sm:text-sm text-blue-100 leading-relaxed">
                  Always‑on medical guidance so you never navigate clinics or pharmacies alone.
                </p>
              </div>
              <div className="rounded-2xl border border-white/20 bg-white/10 backdrop-blur-sm p-5 sm:p-6 text-center hover:bg-white/15 transition-colors sm:col-span-2 lg:col-span-1">
                <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-white/20">
                  <Stethoscope className="h-6 w-6 text-white" />
                </div>
                <p className="text-xs font-semibold uppercase tracking-wider text-blue-100">Included</p>
                <p className="mt-1 text-lg sm:text-xl font-bold text-white">Telehealth visits</p>
                <p className="mt-2 text-xs sm:text-sm text-blue-100 leading-relaxed">
                  Fully covered virtual visits with US‑licensed clinicians in every Navala plan.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Download App Section */}
        <section id="download" className="py-12 md:py-16 lg:py-20 border-t border-slate-200 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-12">
          <div className="grid gap-8 lg:gap-12 md:grid-cols-2 items-center animate-fade-in">
            <div className="space-y-4">
              <h2 className="text-xl md:text-2xl font-semibold tracking-tight">
                Download the Navala Travel Health app
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed max-w-xl">
                Access your membership, connect with clinicians, and reach your medical concierge in
                just a few taps. Available on iOS and Android so you’re covered from airport gate to
                final whistle.
              </p>
              <div className="flex flex-wrap gap-3">
                <Button
                  size="sm"
                  className="flex items-center gap-2 rounded-xl bg-slate-900 text-slate-50 hover:bg-slate-800"
                >
                  <Download className="h-4 w-4" />
                  <div className="text-left leading-tight">
                    <div className="text-[9px] uppercase tracking-wide text-slate-300">
                      Download on the
                    </div>
                    <div className="text-[12px] font-semibold">App Store</div>
                  </div>
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="flex items-center gap-2 rounded-xl border-slate-300 bg-white text-slate-900 hover:bg-slate-50"
                >
                  <Download className="h-4 w-4" />
                  <div className="text-left leading-tight">
                    <div className="text-[9px] uppercase tracking-wide text-slate-500">
                      Get it on
                    </div>
                    <div className="text-[12px] font-semibold">Google Play</div>
                  </div>
                </Button>
              </div>
              <p className="text-[11px] text-slate-500">
                App store links coming as tournament approaches. Join today and be first to know
                when downloads go live.
              </p>
            </div>

            <div className="relative">
              <div className="absolute -inset-8 rounded-3xl bg-gradient-to-tr from-sky-400/15 via-blue-300/10 to-white/0 blur-3xl" />
              <div className="relative h-full rounded-3xl border border-slate-200 bg-slate-50 p-5 flex flex-col justify-between shadow-md shadow-blue-500/10">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-xs font-semibold text-slate-900">Navala Travel Health</p>
                    <p className="text-[11px] text-slate-600">Your 2026 World Cup medical home</p>
                  </div>
                  <Badge className="bg-blue-50 text-blue-700 border-blue-300 text-[10px]">
                    iOS & Android
                  </Badge>
                </div>
                <div className="space-y-3 text-[11px] text-slate-700">
                  <p>• One‑tap access to telehealth visits</p>
                  <p>• Real‑time chat with your concierge</p>
                  <p>• Digital plan details and host‑city guidance</p>
                </div>
                <div className="mt-5 flex flex-wrap items-center justify-between gap-3 text-[11px] text-slate-500">
                  <span>Secure, HIPAA‑aware infrastructure</span>
                  <span className="text-blue-700">Built for global travelers in 2026</span>
                </div>
              </div>
            </div>
            </div>
          </div>
        </section>

        {/* Contact / Get in touch */}
        <section
          id="contact"
          className="relative py-14 md:py-20 lg:py-24 border-t border-slate-200 overflow-hidden"
        >
          {/* Full-width background */}
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage:
                "linear-gradient(to right, rgba(15,23,42,0.82), rgba(15,23,42,0.88)), url('https://images.unsplash.com/photo-1525182008055-f88b95ff7980?w=1600')",
            }}
          />
          <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 animate-fade-in">
            <div className="grid gap-8 md:grid-cols-2 rounded-3xl border border-slate-900/60 bg-slate-900/80 text-slate-50 p-6 sm:p-8 lg:p-10 shadow-2xl shadow-slate-900/60 backdrop-blur-md">
              {/* Left: details */}
              <div className="space-y-5 text-sm">
                <div>
                  <h2 className="text-xl md:text-2xl font-semibold tracking-tight">Get in touch</h2>
                  <p className="mt-2 text-slate-200/90">
                    Do not hesitate to reach out. Fill in the contact form or use the details below
                    and we&apos;ll reply as fast as possible.
                  </p>
                </div>
                {/* <div className="space-y-3">
                  <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-300">
                    Our office
                  </h3>
                  <div className="space-y-2 text-[13px] leading-relaxed">
                    <p>
                      <span className="font-semibold">USA Office:</span> 27, Glen Riddle Road, Media,
                      PA 19063, USA 🇺🇸
                    </p>
                    <p>
                      <span className="font-semibold">South Africa Office:</span> 23A, 4th Avenue,
                      Houghton Estates, Johannesburg, South Africa 🇿🇦
                    </p>
                    <p>
                      <span className="font-semibold">Zimbabwe Office:</span> 21, Droitwich Avenue,
                      Mount Pleasant, Harare, Zimbabwe 🇿🇼
                    </p>
                  </div>
                </div> */}
                <div className="space-y-2 text-[13px]">
                  <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-300">
                    Message us
                  </h3>
                  <p className="flex items-center gap-2">
                    <Mail className="h-3.5 w-3.5 text-slate-200" />
                    <span>info@navalaglobal.com</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <PhoneCall className="h-3.5 w-3.5 text-slate-200" />
                    <span>+1 610 742 7763</span>
                  </p>
                </div>
                <div className="space-y-2 text-[13px]">
                  <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-300">
                    Follow us
                  </h3>
                  <div className="flex gap-3">
                    <button
                      type="button"
                      className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800/80 hover:bg-slate-700 transition-colors"
                    >
                      <Facebook className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800/80 hover:bg-slate-700 transition-colors"
                    >
                      <Instagram className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800/80 hover:bg-slate-700 transition-colors"
                    >
                      <Twitter className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800/80 hover:bg-slate-700 transition-colors"
                    >
                      <Linkedin className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Right: simple contact form */}
              <div className="space-y-4 text-sm">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-300">
                  Contact Navala
                </p>
                <div className="grid gap-3">
                  <div className="grid gap-1.5">
                    <label className="text-xs text-slate-200" htmlFor="contact-name">
                      Name
                    </label>
                    <input
                      id="contact-name"
                      className="h-9 rounded-md border border-slate-500/60 bg-slate-900/40 px-3 text-xs text-slate-50 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400/70"
                      placeholder="Your name"
                    />
                  </div>
                  <div className="grid gap-1.5">
                    <label className="text-xs text-slate-200" htmlFor="contact-email">
                      Email address
                    </label>
                    <input
                      id="contact-email"
                      type="email"
                      className="h-9 rounded-md border border-slate-500/60 bg-slate-900/40 px-3 text-xs text-slate-50 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400/70"
                      placeholder="you@example.com"
                    />
                  </div>
                  <div className="grid gap-1.5">
                    <label className="text-xs text-slate-200" htmlFor="contact-message">
                      Your query
                    </label>
                    <textarea
                      id="contact-message"
                      rows={4}
                      className="rounded-md border border-slate-500/60 bg-slate-900/40 px-3 py-2 text-xs text-slate-50 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400/70 resize-none"
                      placeholder="Tell us how we can help during your World Cup journey..."
                    />
                  </div>
                  <Button className="mt-1 h-9 bg-blue-500 hover:bg-blue-400 text-xs font-semibold self-start">
                    Submit form
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-6 border-t border-slate-200 text-[11px] sm:text-xs text-slate-500 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-12 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} Navala Travel Health. All rights reserved.</p>
          <div className="flex flex-wrap gap-3">
            <Link to="/account-deletion" className="hover:text-blue-600">
              Account Deletion
            </Link>
            <Link to="/privacy-policy" className="hover:text-blue-600">
              Privacy policy
            </Link>
            <Link to="/login" className="hover:text-blue-600">
              Sign in
            </Link>
            <Link to="/register" className="hover:text-blue-600">
              Sign up
            </Link>
          </div>
      </div>
        </footer>
      </main>
    </div>
  );
};

interface LandingPlanSummary {
  label: string;
  price: string;
  visits: { telehealth: string; inPerson: string };
  prescription: string;
  specialty: string;
  highlight?: boolean;
  delayMs?: number;
}

function LandingPlanCard({
  label,
  price,
  visits,
  prescription,
  specialty,
  highlight,
  delayMs,
}: LandingPlanSummary) {
  return (
    <Card
      className={`shadow-card border-0 relative overflow-hidden flex flex-col min-h-[420px] h-full w-full transition-all duration-200 ease-out animate-fade-in
        ${highlight ? 'ring-2 ring-accent md:scale-[1.02]' : ''}
        hover:shadow-xl hover:scale-[1.02] hover:ring-2 hover:ring-accent/40`}
      style={delayMs ? { animationDelay: `${delayMs}ms` } : undefined}
    >
      {/* Top strip */}
      <div
        className={`h-2 shrink-0 ${
          highlight ? 'bg-gradient-to-r from-blue-500 via-sky-400 to-cyan-400' : 'bg-slate-200'
        }`}
      />

      {/* Recommended badge */}
      {highlight && (
        <div className="absolute top-4 right-4">
          <Badge variant="info" className="flex items-center gap-1 text-[10px]">
            Recommended
          </Badge>
        </div>
      )}

      <CardHeader className="text-center pt-6 pb-3 shrink-0">
        <CardTitle className="text-lg">{label} Plan</CardTitle>
        <CardDescription className="text-xs">
          Telehealth‑first coverage with specialty care coordination.
        </CardDescription>
        <div className="mt-3">
          <span className="text-3xl font-bold text-foreground">{price}</span>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col pt-0 min-h-0 pb-5 text-sm">
        <div className="flex-1 flex flex-col min-h-[160px] space-y-3">
          <div className="grid grid-cols-2 gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3">
            <div className="space-y-1">
              <p className="flex items-center gap-1 text-xs text-slate-500">
                <Stethoscope className="h-3.5 w-3.5" />
                Telehealth visits
              </p>
              <p className="text-sm font-semibold text-slate-900">{visits.telehealth}</p>
            </div>
            <div className="space-y-1">
              <p className="flex items-center gap-1 text-xs text-slate-500">
                <Calendar className="h-3.5 w-3.5" />
                In‑person visits
              </p>
              <p className="text-sm font-semibold text-slate-900">{visits.inPerson}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="rounded-lg border border-slate-200 bg-white p-3 space-y-1">
              <p className="flex items-center gap-1 text-[11px] text-slate-500">
                <Pill className="h-3.5 w-3.5" />
                Prescription coverage
              </p>
              <p className="text-sm font-semibold text-slate-900">{prescription}</p>
            </div>
            <div className="rounded-lg border border-slate-200 bg-white p-3 space-y-1">
              <p className="flex items-center gap-1 text-[11px] text-slate-500">
                <CreditCard className="h-3.5 w-3.5" />
                Specialty care coordination
              </p>
              <p className="text-sm font-semibold text-slate-900">{specialty}</p>
            </div>
          </div>
        </div>

        <div className="shrink-0 h-11 flex items-end mt-3">
          <Button className="w-full h-10" variant={highlight ? 'accent' : 'default'} size="sm" asChild>
            <Link to="/login">Get Now</Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default Index;
