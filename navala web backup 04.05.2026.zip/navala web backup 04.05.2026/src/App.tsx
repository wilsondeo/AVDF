import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useAppStore } from "@/lib/store";

// Pages
import LoginPage from "./pages/auth/LoginPage";
import AdminLoginPage from "./pages/auth/AdminLoginPage";
import RegisterPage from "./pages/auth/RegisterPage";
import ForgotPasswordPage from "./pages/auth/ForgotPasswordPage";
import PrivacyPolicyPage from "./pages/PrivacyPolicyPage";
import TermsOfServicePage from "./pages/TermsOfServicePage";
import AccountDeletionPage from "./pages/AccountDeletionPage";
import NotFound from "./pages/NotFound";

// Patient Pages
import PatientDashboard from "./pages/patient/PatientDashboard";
import PatientPlansPage from "./pages/patient/PatientPlansPage";
import PatientNewPlansPage from "./pages/patient/PatientNewPlansPage";
import PatientAppointmentsPage from "./pages/patient/PatientAppointmentsPage";
import PatientPrescriptionsPage from "./pages/patient/PatientPrescriptionsPage";
import BookAppointmentPage from "./pages/patient/BookAppointmentPage";
import VideoCallPage from "./pages/patient/VideoCallPage";
import PatientProfilePage from "./pages/patient/PatientProfilePage";
import PatientContractsPage from "./pages/patient/PatientContractsPage";
import PlanConfirmationPage from "./pages/patient/PlanConfirmationPage";

// Doctor Pages
import DoctorDashboard from "./pages/doctor/DoctorDashboard";
import DoctorAppointmentsPage from "./pages/doctor/DoctorAppointmentsPage";
import DoctorPrescriptionsPage from "./pages/doctor/DoctorPrescriptionsPage";
import DoctorPatientsPage from "./pages/doctor/DoctorPatientsPage";
import DoctorConsultationPage from "./pages/doctor/DoctorConsultationPage";
import DoctorProfilePage from "./pages/doctor/DoctorProfilePage";

// Admin Pages
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminBookingsPage from "./pages/admin/AdminBookingsPage";
import AdminAppointmentsPage from "./pages/admin/AdminAppointmentsPage";
import AdminPatientsPage from "./pages/admin/AdminPatientsPage";
import AdminDoctorsPage from "./pages/admin/AdminDoctorsPage";
import AdminPlansPage from "./pages/admin/AdminPlansPage";
import AdminNewPlansPage from "./pages/admin/AdminNewPlansPage";
import AdminTransactionsPage from "./pages/admin/AdminTransactionsPage";
import AdminReportsPage from "./pages/admin/AdminReportsPage";
import AdminProfilePage from "./pages/admin/AdminProfilePage";
import AdminLocationsPage from "./pages/admin/AdminLocationsPage";
import AdminSettingsPage from "./pages/admin/AdminSettingsPage";
import Index from "./pages/Index";
import PrintPrescriptionPage from "./pages/shared/PrintPrescriptionPage";

const queryClient = new QueryClient();

// Protected Route Component
function ProtectedRoute({ children, allowedRoles }: { children: React.ReactNode; allowedRoles: string[] }) {
  const { isAuthenticated, currentUser } = useAppStore();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  if (currentUser && !allowedRoles.includes(currentUser.role)) {
    return <Navigate to={`/${currentUser.role}`} replace />;
  }
  
  return <>{children}</>;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Index />} />
          <Route path="/login" element={<LoginPage mode="patient" />} />
          <Route path="/doctor/login" element={<LoginPage mode="doctor" />} />
          <Route path="/admin/login" element={<AdminLoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
          <Route path="/terms-of-service" element={<TermsOfServicePage />} />
          <Route path="/account-deletion" element={<AccountDeletionPage />} />

          {/* Patient Routes */}
          <Route path="/patient" element={<ProtectedRoute allowedRoles={['patient', 'admin']}><PatientDashboard /></ProtectedRoute>} />
          <Route path="/patient/plans" element={<ProtectedRoute allowedRoles={['patient', 'admin']}><PatientPlansPage /></ProtectedRoute>} />
          <Route path="/patient/new-plans" element={<ProtectedRoute allowedRoles={['patient', 'admin']}><PatientNewPlansPage /></ProtectedRoute>} />
          <Route path="/patient/appointments" element={<ProtectedRoute allowedRoles={['patient', 'admin']}><PatientAppointmentsPage /></ProtectedRoute>} />
          <Route path="/patient/prescriptions" element={<ProtectedRoute allowedRoles={['patient', 'admin']}><PatientPrescriptionsPage /></ProtectedRoute>} />
          <Route path="/patient/contracts" element={<ProtectedRoute allowedRoles={['patient', 'admin']}><PatientContractsPage /></ProtectedRoute>} />
          <Route path="/patient/book" element={<ProtectedRoute allowedRoles={['patient', 'admin']}><BookAppointmentPage /></ProtectedRoute>} />
          <Route path="/patient/call/:appointmentId" element={<ProtectedRoute allowedRoles={['patient', 'admin']}><VideoCallPage /></ProtectedRoute>} />
          <Route path="/patient/profile" element={<ProtectedRoute allowedRoles={['patient', 'admin']}><PatientProfilePage /></ProtectedRoute>} />
          <Route path="/patient/plan-confirmation" element={<ProtectedRoute allowedRoles={['patient', 'admin']}><PlanConfirmationPage /></ProtectedRoute>} />

          {/* Doctor Routes */}
          <Route path="/doctor" element={<ProtectedRoute allowedRoles={['doctor']}><DoctorDashboard /></ProtectedRoute>} />
          <Route path="/doctor/appointments" element={<ProtectedRoute allowedRoles={['doctor']}><DoctorAppointmentsPage /></ProtectedRoute>} />
          <Route path="/doctor/prescriptions" element={<ProtectedRoute allowedRoles={['doctor']}><DoctorPrescriptionsPage /></ProtectedRoute>} />
          <Route path="/doctor/patients" element={<ProtectedRoute allowedRoles={['doctor']}><DoctorPatientsPage /></ProtectedRoute>} />
          <Route path="/doctor/consultation/:appointmentId" element={<ProtectedRoute allowedRoles={['doctor']}><DoctorConsultationPage /></ProtectedRoute>} />
          <Route path="/doctor/profile" element={<ProtectedRoute allowedRoles={['doctor']}><DoctorProfilePage /></ProtectedRoute>} />

          {/* Admin Routes */}
          <Route path="/admin" element={<ProtectedRoute allowedRoles={['admin']}><AdminDashboard /></ProtectedRoute>} />
          <Route path="/admin/bookings" element={<ProtectedRoute allowedRoles={['admin']}><AdminBookingsPage /></ProtectedRoute>} />
          <Route path="/admin/appointments" element={<ProtectedRoute allowedRoles={['admin']}><AdminAppointmentsPage /></ProtectedRoute>} />
          <Route path="/admin/patients" element={<ProtectedRoute allowedRoles={['admin']}><AdminPatientsPage /></ProtectedRoute>} />
          <Route path="/admin/doctors" element={<ProtectedRoute allowedRoles={['admin']}><AdminDoctorsPage /></ProtectedRoute>} />
          <Route path="/admin/plans" element={<ProtectedRoute allowedRoles={['admin']}><AdminPlansPage /></ProtectedRoute>} />
          <Route path="/admin/new-plans" element={<ProtectedRoute allowedRoles={['admin']}><AdminNewPlansPage /></ProtectedRoute>} />
          <Route path="/admin/transactions" element={<ProtectedRoute allowedRoles={['admin']}><AdminTransactionsPage /></ProtectedRoute>} />
          <Route path="/admin/locations" element={<ProtectedRoute allowedRoles={['admin']}><AdminLocationsPage /></ProtectedRoute>} />
          <Route path="/admin/profile" element={<ProtectedRoute allowedRoles={['admin']}><AdminProfilePage /></ProtectedRoute>} />
          <Route path="/admin/reports" element={<ProtectedRoute allowedRoles={['admin']}><AdminReportsPage /></ProtectedRoute>} />
          <Route path="/admin/settings" element={<ProtectedRoute allowedRoles={['admin']}><AdminSettingsPage /></ProtectedRoute>} />

          {/* Shared / Utility Routes */}
          <Route path="/print/prescription/:uuid" element={<ProtectedRoute allowedRoles={['doctor', 'patient', 'admin']}><PrintPrescriptionPage /></ProtectedRoute>} />

          {/* Catch-all */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
