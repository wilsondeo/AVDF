/**
 * API Service
 * Handles all API calls to the backend
 * Uses centralized API configuration
 */

import { API_ENDPOINTS, API_BASE_URL } from '@/config/api';

export interface ApiResponse<T = any> {
  success: boolean;
  message?: string;
  data?: T;
  error?: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone?: string;
  dateOfBirth?: string;
  streetAddress?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  country?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  emergencyContactRelationship?: string;
  bloodType?: string;
  gender?: string;
}

export interface AuthResponse {
  user: {
    id: number;
    userUuid?: string;
    email: string;
    firstName: string;
    lastName: string;
    role: 'ADMIN' | 'DOCTOR' | 'PATIENT';
    isActive: boolean;
  };
  accessToken: string;
  refreshToken: string;
}

/**
 * Generic API request handler
 */
async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  try {
    const response = await fetch(endpoint, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });

    const data = await response.json();

    if (!response.ok) {
      return {
        success: false,
        message: data.message || 'Request failed',
        error: data.message,
      };
    }

    return {
      success: true,
      ...data,
    };
  } catch (error) {
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Network error occurred',
      error: error instanceof Error ? error.message : 'Network error',
    };
  }
}

/**
 * Authentication API
 */
export const authApi = {
  /**
   * Patient login
   */
  async patientLogin(email: string, password: string): Promise<ApiResponse<AuthResponse>> {
    return apiRequest<AuthResponse>(API_ENDPOINTS.AUTH.LOGIN, {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  },

  /**
   * Patient registration
   */
  async patientRegister(data: RegisterRequest): Promise<ApiResponse<AuthResponse>> {
    return apiRequest<AuthResponse>(API_ENDPOINTS.AUTH.REGISTER, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  /**
   * Forgot password (patient): send OTP to email
   */
  async forgotPassword(email: string): Promise<ApiResponse<{ message?: string }>> {
    return apiRequest<{ message?: string }>(API_ENDPOINTS.AUTH.FORGOT_PASSWORD, {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  },

  /**
   * Reset password with OTP (patient)
   */
  async resetPassword(data: { email: string; otp: string; newPassword: string; confirmPassword: string }): Promise<ApiResponse<{ message?: string }>> {
    return apiRequest<{ message?: string }>(API_ENDPOINTS.AUTH.RESET_PASSWORD, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  /**
   * Admin login
   */
  async adminLogin(email: string, password: string): Promise<ApiResponse<AuthResponse>> {
    return apiRequest<AuthResponse>(API_ENDPOINTS.ADMIN.LOGIN, {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  },

  /**
   * Doctor login
   */
  async doctorLogin(email: string, password: string): Promise<ApiResponse<AuthResponse>> {
    return apiRequest<AuthResponse>(API_ENDPOINTS.DOCTOR.LOGIN, {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  },

  /**
   * Refresh access token
   */
  async refreshToken(refreshToken: string): Promise<ApiResponse<{ accessToken: string }>> {
    return apiRequest<{ accessToken: string }>(API_ENDPOINTS.AUTH.REFRESH, {
      method: 'POST',
      body: JSON.stringify({ refreshToken }),
    });
  },

  /**
   * Get dynamic consent content
   */
  async getConsent(): Promise<ApiResponse<{ sections: any[] }>> {
    return apiRequest<{ sections: any[] }>(API_ENDPOINTS.PUBLIC.CONSENT, {
      method: 'GET'
    });
  },
};

/**
 * Doctor Portal API
 */
export const doctorApi = {
  getProfile: (): Promise<ApiResponse<any>> => 
    apiRequest(`${API_ENDPOINTS.DOCTOR.PROFILE}`, {
      method: 'GET',
      headers: getAuthHeaders(),
    }),
  updateProfile: (data: { phone?: string; city?: string; specialization?: string; yearsOfExperience?: number; isOnline?: boolean; is_online?: boolean }): Promise<ApiResponse<any>> =>
    apiRequest(`${API_ENDPOINTS.DOCTOR.PROFILE}`, {
      method: 'PATCH',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),
};

/**
 * Payments API (Stripe PaymentIntent flow)
 */
export type PaymentType = 'PURCHASE' | 'UPGRADE';
export type PaymentStatus = 'PENDING' | 'SUCCESS' | 'FAILED';

export interface CreateIntentResponse {
  clientSecret: string;
  paymentIntentId: string;
  type: PaymentType;
  /** Amount in dollars to charge (e.g. for upgrade = difference only) */
  amountCharged?: number;
  amountChargedCents?: number;
}

export interface ActiveUserPlanResponse {
  activePlan: null | {
    id: number;
    userId: number;
    planId: number;
    startDate: string;
    endDate: string;
    status: 'ACTIVE' | 'EXPIRED';
    plan: any;
  };
}

export interface PaymentRecord {
  id: number;
  userId: number;
  planId: number;
  stripePaymentIntentId: string;
  amount: number;
  currency: string;
  status: PaymentStatus;
  type: PaymentType;
  createdAt: string;
}

export const paymentApi = {
  async createIntent(planId: string, taxAmount: number = 0): Promise<ApiResponse<CreateIntentResponse>> {
    return apiRequest<CreateIntentResponse>(API_ENDPOINTS.PAYMENTS.CREATE_INTENT, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ planId, taxAmount }),
    });
  },

  async getMyPayments(): Promise<ApiResponse<{ payments: PaymentRecord[]; count: number }>> {
    return apiRequest<{ payments: PaymentRecord[]; count: number }>(API_ENDPOINTS.PAYMENTS.MY_PAYMENTS, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  async getActiveUserPlan(): Promise<ApiResponse<ActiveUserPlanResponse>> {
    return apiRequest<ActiveUserPlanResponse>(API_ENDPOINTS.USER.ACTIVE_PLAN, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },
};

/** User profile (patient) */
export interface UserProfile {
  id: number;
  userUuid: string | null;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  isActive: boolean;
  phone?: string | null;
  dateOfBirth?: string | null;
  gender?: string | null;
  streetAddress?: string | null;
  city?: string | null;
  state?: string | null;
  zipCode?: string | null;
  country?: string | null;
  emergencyContactName?: string | null;
  emergencyContactPhone?: string | null;
  emergencyContactRelationship?: string | null;
  bloodType?: string | null;
  createdAt?: string;
  updatedAt?: string;
}

export interface UpdateProfileRequest {
  firstName?: string;
  lastName?: string;
  phone?: string;
  dateOfBirth?: string;
  gender?: string;
  streetAddress?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  country?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  emergencyContactRelationship?: string;
  bloodType?: string;
}

/** Family member (for family plans) */
export interface FamilyMember {
  id: number;
  userId: number;
  firstName: string;
  lastName: string;
  dateOfBirth?: string | null;
  gender?: string | null;
  relationship?: string | null;
  createdAt?: string;
  updatedAt?: string;
}

export interface FamilyMembersResponse {
  familyMembers: FamilyMember[];
  maxSlots: number;
}

export interface AdminFamilyMembersResponse {
  familyMembers: FamilyMember[];
}

export const userProfileApi = {
  getProfile: (): Promise<ApiResponse<UserProfile>> =>
    apiRequest<UserProfile>(API_ENDPOINTS.USER.PROFILE, {
      method: 'GET',
      headers: getAuthHeaders(),
      credentials: 'include',
    }),
  updateProfile: (data: UpdateProfileRequest): Promise<ApiResponse<UserProfile>> =>
    apiRequest<UserProfile>(API_ENDPOINTS.USER.PROFILE, {
      method: 'PATCH',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
      credentials: 'include',
    }),
};

export const familyMembersApi = {
  getList: (): Promise<ApiResponse<FamilyMembersResponse>> =>
    apiRequest<FamilyMembersResponse>(API_ENDPOINTS.USER.FAMILY_MEMBERS, {
      method: 'GET',
      headers: getAuthHeaders(),
      credentials: 'include',
    }),
  add: (data: {
    firstName: string;
    lastName: string;
    dateOfBirth?: string;
    gender?: string;
    relationship?: string;
  }): Promise<ApiResponse<FamilyMember>> =>
    apiRequest<FamilyMember>(API_ENDPOINTS.USER.FAMILY_MEMBERS, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
      credentials: 'include',
    }),
  update: (
    id: number,
    data: Partial<{
      firstName: string;
      lastName: string;
      dateOfBirth: string;
      gender: string;
      relationship: string;
    }>
  ): Promise<ApiResponse<FamilyMember>> =>
    apiRequest<FamilyMember>(API_ENDPOINTS.USER.FAMILY_MEMBER(id), {
      method: 'PATCH',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
      credentials: 'include',
    }),
  delete: (id: number): Promise<ApiResponse<unknown>> =>
    apiRequest<unknown>(API_ENDPOINTS.USER.FAMILY_MEMBER(id), {
      method: 'DELETE',
      headers: getAuthHeaders(),
      credentials: 'include',
    }),
};

export const adminFamilyMembersApi = {
  getForUser: (userId: number): Promise<ApiResponse<AdminFamilyMembersResponse>> => {
    // Build URL directly to avoid "not a function" errors in some build environments
    const url = `${API_BASE_URL}/admin/users/${userId}/family-members`;
    return apiRequest<AdminFamilyMembersResponse>(url, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },
};

/** Notification settings (admin and patient) – stored in database */
export interface NotificationSettingsData {
  emailAppointments: boolean;
  emailReminders: boolean;
  emailPromo: boolean;
  inAppEnabled: boolean;
}

export const notificationSettingsApi = {
  get: (): Promise<ApiResponse<NotificationSettingsData>> =>
    apiRequest<NotificationSettingsData>(API_ENDPOINTS.USER.NOTIFICATION_SETTINGS, {
      method: 'GET',
      headers: getAuthHeaders(),
      credentials: 'include',
    }),
  update: (data: Partial<NotificationSettingsData>): Promise<ApiResponse<NotificationSettingsData>> =>
    apiRequest<NotificationSettingsData>(API_ENDPOINTS.USER.NOTIFICATION_SETTINGS, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
      credentials: 'include',
    }),
};

/** Patient medication (today's list item with taken for today) */
export interface PatientMedicationItem {
  id: number;
  name: string;
  dosage: string;
  time: 'morning' | 'afternoon' | 'evening';
  taken: boolean;
}

/** Patient vitals reading */
export interface PatientVitalReading {
  id: number;
  heartRate: number | null;
  bloodPressureSystolic: number | null;
  bloodPressureDiastolic: number | null;
  temperature: number | null;
  oxygenLevel: number | null;
  recordedAt: string;
}

export const patientMedicationsApi = {
  getList: (): Promise<ApiResponse<PatientMedicationItem[]>> =>
    apiRequest<PatientMedicationItem[]>(API_ENDPOINTS.PATIENT.MEDICATIONS, {
      method: 'GET',
      headers: getAuthHeaders(),
    }),
  add: (data: { name: string; dosage: string; timeOfDay: 'morning' | 'afternoon' | 'evening' }): Promise<ApiResponse<PatientMedicationItem>> =>
    apiRequest<PatientMedicationItem>(API_ENDPOINTS.PATIENT.MEDICATIONS, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),
  update: (id: number, data: { name?: string; dosage?: string; timeOfDay?: 'morning' | 'afternoon' | 'evening' }): Promise<ApiResponse<PatientMedicationItem>> =>
    apiRequest<PatientMedicationItem>(API_ENDPOINTS.PATIENT.MEDICATION(id), {
      method: 'PATCH',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),
  setTaken: (id: number, taken: boolean): Promise<ApiResponse<{ taken: boolean }>> =>
    apiRequest<{ taken: boolean }>(`${API_ENDPOINTS.PATIENT.MEDICATION(id)}/taken`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ taken }),
    }),
};

export const patientVitalsApi = {
  getList: (limit = 10): Promise<ApiResponse<PatientVitalReading[]>> =>
    apiRequest<PatientVitalReading[]>(`${API_ENDPOINTS.PATIENT.VITALS}?limit=${limit}`, {
      method: 'GET',
      headers: getAuthHeaders(),
    }),
  add: (data: {
    heartRate?: number | null;
    bloodPressureSystolic?: number | null;
    bloodPressureDiastolic?: number | null;
    temperature?: number | null;
    oxygenLevel?: number | null;
    recordedAt?: string;
  }): Promise<ApiResponse<PatientVitalReading>> =>
    apiRequest<PatientVitalReading>(API_ENDPOINTS.PATIENT.VITALS, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),
  update: (id: number, data: Partial<PatientVitalReading>): Promise<ApiResponse<PatientVitalReading>> =>
    apiRequest<PatientVitalReading>(API_ENDPOINTS.PATIENT.VITAL(id), {
      method: 'PATCH',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    }),
};

/**
 * Helper to get auth token from localStorage
 */
export function getAuthToken(): string | null {
  return localStorage.getItem('accessToken');
}

/**
 * Helper to set auth token in localStorage
 */
export function setAuthToken(token: string): void {
  localStorage.setItem('accessToken', token);
}

/**
 * Helper to remove auth token from localStorage
 */
export function removeAuthToken(): void {
  localStorage.removeItem('accessToken');
  localStorage.removeItem('refreshToken');
}

/**
 * Helper to get auth headers with token
 */
export function getAuthHeaders(): HeadersInit {
  const token = getAuthToken();
  return {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
  };
}

/**
 * Plan API
 */
export interface Plan {
  id: number;
  planId: string;
  name: string;
  price: number;
  validityDays: number;
  description: string;
  services: string[];
  features: string[];
  isActive: boolean;
  planTabName?: string | null;
  maxPersons?: number | null;
  createdAt: string;
  updatedAt: string;
}

export interface CreatePlanRequest {
  name: string;
  price: number;
  validityDays: number;
  description?: string;
  services: string[];
  features?: string[];
  isActive?: boolean;
  planTabName?: string | null;
  maxPersons?: number;
}

export interface UpdatePlanRequest {
  name?: string;
  price?: number;
  validityDays?: number;
  description?: string;
  services?: string[];
  features?: string[];
  isActive?: boolean;
  planTabName?: string | null;
  maxPersons?: number;
}

export const planApi = {
  /**
   * Get all plans (Admin - includes inactive)
   */
  async getAllPlans(): Promise<ApiResponse<{ plans: Plan[]; count: number }>> {
    return apiRequest<{ plans: Plan[]; count: number }>(API_ENDPOINTS.ADMIN.PLANS, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  /**
   * Get active plans (Public)
   */
  async getActivePlans(): Promise<ApiResponse<{ plans: Plan[]; count: number }>> {
    return apiRequest<{ plans: Plan[]; count: number }>(API_ENDPOINTS.PUBLIC.PLANS, {
      method: 'GET',
    });
  },

  /**
   * Get plan by planId (Admin)
   */
  async getPlan(planId: string): Promise<ApiResponse<{ plan: Plan }>> {
    return apiRequest<{ plan: Plan }>(API_ENDPOINTS.ADMIN.PLAN(planId), {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  /**
   * Create plan (Admin)
   */
  async createPlan(data: CreatePlanRequest): Promise<ApiResponse<{ plan: Plan }>> {
    return apiRequest<{ plan: Plan }>(API_ENDPOINTS.ADMIN.PLANS, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    });
  },

  /**
   * Update plan (Admin)
   */
  async updatePlan(planId: string, data: UpdatePlanRequest): Promise<ApiResponse<{ plan: Plan }>> {
    return apiRequest<{ plan: Plan }>(API_ENDPOINTS.ADMIN.PLAN(planId), {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    });
  },

  /**
   * Delete plan (Admin - soft delete)
   */
  async deletePlan(planId: string): Promise<ApiResponse<void>> {
    return apiRequest<void>(API_ENDPOINTS.ADMIN.PLAN(planId), {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });
  },
};

/**
 * Admin API
 */
export interface Transaction {
  id: number;
  userId: number;
  planId: number;
  stripePaymentIntentId: string;
  amount: number;
  currency: string;
  status: PaymentStatus;
  type: PaymentType;
  createdAt: string;
  User?: {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    userUuid?: string;
  };
  Plan?: {
    id: number;
    name: string;
  };
}

export interface TransactionStats {
  totalRevenue: number;
  thisMonthRevenue: number;
  refundedAmount: number;
  totalTransactions: number;
}

export const adminApi = {
  async getTransactions(params: { limit?: number; offset?: number; search?: string; status?: string; liveOnly?: boolean; planId?: string; startDate?: string; endDate?: string } = {}): Promise<ApiResponse<{ payments: Transaction[]; count: number }>> {
    const queryParams = new URLSearchParams();
    if (params.limit) queryParams.append('limit', params.limit.toString());
    if (params.offset) queryParams.append('offset', params.offset.toString());
    if (params.search) queryParams.append('search', params.search);
    if (params.status && params.status !== 'all') queryParams.append('status', params.status);
    if (params.liveOnly !== undefined) queryParams.append('liveOnly', params.liveOnly.toString());
    if (params.planId && params.planId !== 'all') queryParams.append('planId', params.planId);
    if (params.startDate) queryParams.append('startDate', params.startDate);
    if (params.endDate) queryParams.append('endDate', params.endDate);

    return apiRequest<{ payments: Transaction[]; count: number }>(`${API_ENDPOINTS.ADMIN.BASE}/transactions?${queryParams.toString()}`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  getTransactionStats: async (params: { liveOnly?: boolean; planId?: string; startDate?: string; endDate?: string } = {}): Promise<ApiResponse<TransactionStats>> => {
    const queryParams = new URLSearchParams();
    if (params.liveOnly !== undefined) queryParams.append('liveOnly', params.liveOnly.toString());
    if (params.planId && params.planId !== 'all') queryParams.append('planId', params.planId);
    if (params.startDate) queryParams.append('startDate', params.startDate);
    if (params.endDate) queryParams.append('endDate', params.endDate);

    const qs = queryParams.toString();
    return apiRequest<TransactionStats>(`${API_ENDPOINTS.ADMIN.BASE}/transactions/stats${qs ? `?${qs}` : ''}`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  getReportsAnalytics: async (): Promise<ApiResponse<any>> => {
    return apiRequest<any>(`${API_ENDPOINTS.ADMIN.BASE}/reports/analytics`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },
};

export interface AdminPatientAppointment {
  appointmentUuid: string;
  appointmentDate: string | null;
  createdAt: string;
  status: string;
  serviceType: string;
  doctorName: string;
  familyMember?: { firstName: string; lastName: string; relationship?: string | null } | null;
}

export interface AdminPatientRequestDetails {
  age: number;
  gender: string;
  emergencyContact: string;
  notes: string | null;
  allergies: string | null;
  city: string | null;
}

export interface AdminPatient {
  id: number;
  userUuid: string | null;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  isActive: boolean;
  createdAt: string;
  updatedAt?: string;
  phone?: string | null;
  dateOfBirth?: string | null;
  streetAddress?: string | null;
  city?: string | null;
  state?: string | null;
  zipCode?: string | null;
  country?: string | null;
  emergencyContactName?: string | null;
  emergencyContactPhone?: string | null;
  emergencyContactRelationship?: string | null;
  bloodType?: string | null;
  gender?: string | null;
  activePlan: { planId: string; planName: string; endDate: string } | null;
  appointmentCount: number;
  completedCount: number;
  lastAppointmentAt: string | null;
  appointments?: AdminPatientAppointment[];
  latestRequestDetails?: AdminPatientRequestDetails | null;
}

export interface AdminUpdateUserPayload {
  firstName?: string;
  lastName?: string;
  phone?: string | null;
  dateOfBirth?: string | null;
  streetAddress?: string | null;
  city?: string | null;
  state?: string | null;
  zipCode?: string | null;
  country?: string | null;
  emergencyContactName?: string | null;
  emergencyContactPhone?: string | null;
  emergencyContactRelationship?: string | null;
  bloodType?: string | null;
  gender?: string | null;
  isActive?: boolean;
}

export const adminPatientsApi = {
  getPatients: async (): Promise<ApiResponse<{ patients: AdminPatient[]; count: number }>> => {
    return apiRequest<{ patients: AdminPatient[]; count: number }>(`${API_ENDPOINTS.ADMIN.PATIENTS}`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  /** Get single user by id (admin). */
  getUser: async (userId: number): Promise<ApiResponse<{ user: AdminPatient & { email: string } }>> => {
    return apiRequest<{ user: AdminPatient & { email: string } }>(`${API_ENDPOINTS.ADMIN.USERS(String(userId))}`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  /** Update user (admin). Profile fields + optional isActive. */
  updateUser: async (userId: number, data: AdminUpdateUserPayload): Promise<ApiResponse<{ user: AdminPatient }>> => {
    return apiRequest<{ user: AdminPatient }>(`${API_ENDPOINTS.ADMIN.USERS(String(userId))}`, {
      method: 'PATCH',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    });
  },

  /** Update user status only (admin). */
  updateUserStatus: async (userId: number, isActive: boolean): Promise<ApiResponse<{ user: AdminPatient }>> => {
    return apiRequest<{ user: AdminPatient }>(`${API_ENDPOINTS.ADMIN.USER_STATUS(String(userId))}`, {
      method: 'PATCH',
      headers: getAuthHeaders(),
      body: JSON.stringify({ isActive }),
    });
  },

  /** Grant a plan to a patient (admin). planId = plan business id from plans table. */
  grantPlan: async (userId: number, planId: string): Promise<ApiResponse<{ planId: string; planName: string; endDate: string }>> => {
    return apiRequest<{ planId: string; planName: string; endDate: string }>(
      `${API_ENDPOINTS.ADMIN.PATIENTS}/${userId}/plan`,
      {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ planId }),
      }
    );
  },
};

export const adminDoctorApi = {
  getDoctors: async (): Promise<ApiResponse<any[]>> => {
    return apiRequest<any[]>(`${API_ENDPOINTS.ADMIN.BASE}/doctors`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  getDoctor: async (id: string): Promise<ApiResponse<any>> => {
    return apiRequest(`${API_ENDPOINTS.ADMIN.BASE}/doctors/${id}`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  createDoctor: async (data: any): Promise<ApiResponse<any>> => {
    return apiRequest(`${API_ENDPOINTS.ADMIN.BASE}/doctors`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders(),
      },
      body: JSON.stringify(data),
    });
  },

  updateDoctor: async (id: string, data: any): Promise<ApiResponse<any>> => {
    return apiRequest(`${API_ENDPOINTS.ADMIN.BASE}/doctors/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders(),
      },
      body: JSON.stringify(data),
    });
  },

  deleteDoctor: async (id: string): Promise<ApiResponse<void>> => {
    return apiRequest(`${API_ENDPOINTS.ADMIN.BASE}/doctors/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });
  },

  sendDoctorEmail: async (id: string): Promise<ApiResponse<void>> => {
    return apiRequest(`${API_ENDPOINTS.ADMIN.BASE}/doctors/${id}/send-email`, {
      method: 'POST',
      headers: getAuthHeaders(),
    });
  },

  uploadDoctors: async (formData: FormData): Promise<ApiResponse<any>> => {
    const authHeaders = getAuthHeaders() as Record<string, string>;
    return apiRequest(`${API_ENDPOINTS.ADMIN.BASE}/doctors/upload`, {
      method: 'POST',
      headers: {
        'Authorization': authHeaders['Authorization'],
      },
      body: formData,
    });
  },
};

/**
 * Appointment Booking API
 *
 * Mirrors the backend booking system:
 *
 * PATIENT:
 * - POST /api/appointments/request
 * - GET  /api/appointments/my-requests
 *
 * ADMIN:
 * - GET  /api/admin/appointment-requests
 * - POST /api/admin/assign-doctor
 *
 * DOCTOR:
 * - GET /api/doctor/appointments
 */

export type AppointmentServiceType = 'TELEHEALTH' | 'EMERGENCY';
export type AppointmentRequestStatus = 'PENDING' | 'ASSIGNED' | 'CANCELLED';
export type AppointmentStatusApi = 'SCHEDULED' | 'COMPLETED' | 'CANCELLED';

export interface CreateAppointmentRequestPayload {
  country: string;
  state: string;
  city: string;
  age: number;
  gender: string;
  emergencyContact?: string;
  serviceType: AppointmentServiceType;
  notes?: string;
  allergies?: string;
  familyMemberId?: number;
  appointmentDate?: string;
  timezone?: string;
}

export interface VisitUsage {
  planName: string;
  telehealth: { limit: number; used: number; remaining: number };
  inPerson: { limit: number; used: number; remaining: number };
}

export interface AppointmentRequestSummary {
  requestUuid: string;
  serviceType: AppointmentServiceType;
  status: AppointmentRequestStatus;
  city: string;
  createdAt: string;
  preferredDate?: string;
  timezone?: string;
  visitUsage?: VisitUsage | null;
  /** Present when status is ASSIGNED */
  appointmentUuid?: string;
  assignedDoctor?: { name: string; specialization?: string | null; email?: string | null; phone?: string | null } | null;
  familyMember?: { firstName: string; lastName: string; relationship?: string | null } | null;
}

export interface PatientDetailsForRequest {
  age: number;
  gender: string;
  emergencyContact: string;
  notes: string | null;
  allergies: string | null;
  country: string | null;
  state: string | null;
  city: string | null;
}

export interface AdminAppointmentRequest extends AppointmentRequestSummary {
  patient: {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
  } | null;
  plan: {
    planId: string;
    name: string;
  } | null;
  assignedDoctor?: { name: string } | null;
  patientDetails?: PatientDetailsForRequest;
  familyMember?: { id?: number; firstName: string; lastName: string; relationship?: string | null } | null;
}

export interface AdminAppointment {
  appointmentUuid: string;
  status: AppointmentStatusApi;
  appointmentDate: string | null;
  serviceType: AppointmentServiceType;
  timezone?: string;
  createdAt: string;
  request: { requestUuid: string; city: string; timezone?: string; serviceType: string; familyMember?: { firstName: string; lastName: string; relationship?: string | null } | null } | null;
  patient: { id: number; firstName: string; lastName: string; email: string } | null;
  doctor: { name: string; email?: string; timezone?: string } | null;
}

export interface AssignDoctorPayload {
  requestUuid: string;
  doctorUuid: string;
  appointmentDate?: string; // ISO string
}

export interface DoctorAppointment {
  appointmentUuid: string;
  requestUuid?: string;
  city?: string | null;
  serviceType: AppointmentServiceType;
  status: AppointmentStatusApi;
  appointmentDate: string | null;
  patient: {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
  } | null;
  patientDetails?: PatientDetailsForRequest | null;
  familyMember?: { firstName: string; lastName: string; relationship?: string | null } | null;
  request?: { timezone?: string; city?: string } | null;
  doctorTimezone?: string;
}

export const appointmentApi = {
  /**
   * Patient: create an appointment request.
   * Backend derives plan_id from the active user_plan and ignores planId/status in payload.
   */
  async createRequest(payload: CreateAppointmentRequestPayload): Promise<ApiResponse<{ requestUuid: string }>> {
    return apiRequest<{ requestUuid: string }>(`${API_BASE_URL}/appointments/request`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload),
    });
  },

  /**
   * Patient: list own appointment requests.
   */
  async getMyRequests(): Promise<ApiResponse<AppointmentRequestSummary[]>> {
    return apiRequest<AppointmentRequestSummary[]>(`${API_BASE_URL}/appointments/my-requests`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  /**
   * Admin: list all appointment requests (optionally filter by status).
   */
  async getAdminRequests(params: { status?: AppointmentRequestStatus } = {}): Promise<ApiResponse<AdminAppointmentRequest[]>> {
    const query = new URLSearchParams();
    if (params.status) query.append('status', params.status);

    return apiRequest<AdminAppointmentRequest[]>(`${API_BASE_URL}/admin/appointment-requests?${query.toString()}`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  /**
   * Admin: assign doctor to a pending request.
   */
  async assignDoctor(payload: AssignDoctorPayload): Promise<ApiResponse<{ appointmentUuid: string; status: AppointmentStatusApi }>> {
    return apiRequest<{ appointmentUuid: string; status: AppointmentStatusApi }>(`${API_BASE_URL}/admin/assign-doctor`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload),
    });
  },
  /**
   * Admin: update appointment request status (PENDING, ASSIGNED, CANCELLED).
   */
  async updateRequestStatus(requestUuid: string, status: AppointmentRequestStatus): Promise<ApiResponse<{ requestUuid: string; status: AppointmentRequestStatus }>> {
    return apiRequest<{ requestUuid: string; status: AppointmentRequestStatus }>(
      `${API_BASE_URL}/admin/appointment-requests/${encodeURIComponent(requestUuid)}/status`,
      {
        method: 'PATCH',
        headers: getAuthHeaders(),
        body: JSON.stringify({ status }),
      }
    );
  },

  /**
   * Admin: permanently delete an appointment request.
   */
  async deleteRequest(requestUuid: string): Promise<ApiResponse<{ success: boolean }>> {
    return apiRequest<{ success: boolean }>(
      `${API_BASE_URL}/admin/appointment-requests/${encodeURIComponent(requestUuid)}`,
      {
        method: 'DELETE',
        headers: getAuthHeaders(),
      }
    );
  },

  /**
   * Doctor: list own appointments.
   */
  async getDoctorAppointments(): Promise<ApiResponse<DoctorAppointment[]>> {
    return apiRequest<DoctorAppointment[]>(`${API_BASE_URL}/doctor/appointments`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  /**
   * Admin: list all appointments (assigned doctor + patient + request details).
   */
  async getAdminAppointments(): Promise<ApiResponse<AdminAppointment[]>> {
    return apiRequest<AdminAppointment[]>(`${API_BASE_URL}/admin/appointments`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },
};

/** Location data from database */
export interface DBLocation {
  id: number;
  country: string;
  city: string;
  state: string;
  taxValue: number;
  taxType: 'FIXED' | 'PERCENTAGE';
  isTaxEnabled: boolean;
}

export interface SystemConfig {
  id: number;
  configKey: string;
  configValue: string;
}

export interface UserItineraryItem {
  id?: number;
  locationId: number;
  arrivalDate?: string;
  departureDate?: string;
  taxPaid?: number;
  visitOrder: number;
  location?: Partial<DBLocation>;
}

export const locationApi = {
  /** Get all available locations */
  async getAll(): Promise<ApiResponse<DBLocation[]>> {
    return apiRequest<DBLocation[]>(API_ENDPOINTS.LOCATIONS, {
      method: 'GET',
    });
  },
  
  /** Create location (Admin) */
  async create(data: Partial<DBLocation>): Promise<ApiResponse<DBLocation>> {
    return apiRequest<DBLocation>(API_ENDPOINTS.LOCATIONS, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    });
  },

  /** Update location (Admin) */
  async update(id: number, data: Partial<DBLocation>): Promise<ApiResponse<DBLocation>> {
    return apiRequest<DBLocation>(`${API_ENDPOINTS.LOCATIONS}/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    });
  },

  /** Delete location (Admin) */
  async delete(id: number): Promise<ApiResponse<void>> {
    return apiRequest<void>(`${API_ENDPOINTS.LOCATIONS}/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });
  },
};

export const systemConfigApi = {
  /** Get all configs */
  async getAll(): Promise<ApiResponse<SystemConfig[]>> {
    return apiRequest<SystemConfig[]>(API_ENDPOINTS.SYSTEM_CONFIGS, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  /** Get specific config */
  async get(key: string): Promise<ApiResponse<string>> {
    return apiRequest<string>(`${API_ENDPOINTS.SYSTEM_CONFIGS}/${key}`, {
      method: 'GET',
    });
  },

  /** Update specific config key */
  async update(key: string, value: string): Promise<ApiResponse<void>> {
    return apiRequest<void>(`${API_ENDPOINTS.SYSTEM_CONFIGS}/${key}`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ value }),
    });
  },

  /** Update tax settings */
  async updateTaxSettings(data: { is_location_tax_enabled: boolean; multi_city_tax_strategy: string }): Promise<ApiResponse<void>> {
    return apiRequest<void>(`${API_ENDPOINTS.SYSTEM_CONFIGS}/tax-settings`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    });
  },
};

export const itineraryApi = {
  /** Get user itineraries */
  async getMyItinerary(): Promise<ApiResponse<UserItineraryItem[]>> {
    return apiRequest<UserItineraryItem[]>(API_ENDPOINTS.ITINERARY, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  /** Get specifically by user ID (Admin) */
  async getForUser(userId: number): Promise<ApiResponse<UserItineraryItem[]>> {
    return apiRequest<UserItineraryItem[]>(`${API_ENDPOINTS.ITINERARY}/${userId}`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  /** Save itinerary */
  async save(destinations: UserItineraryItem[], paymentId?: number): Promise<ApiResponse<void>> {
    return apiRequest<void>(API_ENDPOINTS.ITINERARY, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ destinations, paymentId }),
    });
  },
};

export interface PrescriptionInput {
  appointmentUuid: string;
  diagnosis: string;
  generalAdvice?: string;
  restrictions?: string;
  notes?: string;
  status?: 'DRAFT' | 'ISSUED' | 'CANCELLED';
  medicines: Array<{
    name: string;
    dosage?: string;
    frequency?: string;
    duration?: string;
    foodInstructions?: string;
  }>;
}

export const prescriptionApi = {
  /** Search medicines from master store */
  async searchMedicines(query: string): Promise<ApiResponse<any[]>> {
    return apiRequest<any[]>(`${API_ENDPOINTS.PRESCRIPTION.BASE}/medicines/search?q=${encodeURIComponent(query)}`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  /** Create or Update prescription (Doctor only) */
  async save(data: PrescriptionInput): Promise<ApiResponse<any>> {
    return apiRequest<any>(API_ENDPOINTS.PRESCRIPTION.BASE, {
      method: 'PATCH',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    });
  },

  /** Get single prescription by ID or UUID */
  async getById(idOrUuid: string | number): Promise<ApiResponse<any>> {
    return apiRequest<any>(`${API_ENDPOINTS.PRESCRIPTION.BASE}/${idOrUuid}`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  /** Get single prescription by appointment UUID */
  async getByAppointmentUuid(appointmentUuid: string): Promise<ApiResponse<any>> {
    return apiRequest<any>(`${API_ENDPOINTS.PRESCRIPTION.BASE}/appointment/${appointmentUuid}`, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  /** Get prescriptions for logged-in patient */
  async getForPatient(): Promise<ApiResponse<any[]>> {
    return apiRequest<any[]>(API_ENDPOINTS.PRESCRIPTION.PATIENT, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },

  /** Get prescriptions written by logged-in doctor */
  async getForDoctor(): Promise<ApiResponse<any[]>> {
    return apiRequest<any[]>(API_ENDPOINTS.PRESCRIPTION.DOCTOR, {
      method: 'GET',
      headers: getAuthHeaders(),
    });
  },
};
