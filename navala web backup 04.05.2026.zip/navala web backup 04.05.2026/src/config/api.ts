/**
 * API Configuration
 * Centralized API base URL configuration using environment variables
 */

// Get API base URL – IP-based so it works on network (same host as frontend, port 3000)
// Vite uses VITE_ prefix for environment variables
const getApiBaseUrl = (): string => {
  // Explicit config (e.g. .env: VITE_API_BASE_URL=http://192.168.1.225:3000)
  if (import.meta.env.VITE_API_BASE_URL) {
    return import.meta.env.VITE_API_BASE_URL;
  }
  if (import.meta.env.VITE_BACKEND_URL) {
    return import.meta.env.VITE_BACKEND_URL;
  }
  if (import.meta.env.VITE_API_URL) {
    return import.meta.env.VITE_API_URL;
  }

  // In browser: use same host as the page, port 3000 (IP-based network)
  if (typeof window !== 'undefined' && window.location?.hostname) {
    const host = window.location.hostname;
    const protocol = window.location.protocol || 'http:';
    return `${protocol}//${host}:3000`;
  }

  // Fallback (SSR/build): use IP from env or default
  return import.meta.env.VITE_API_BASE_URL || 'http://192.168.1.225:3000';
};

// Get API prefix from environment variables
const getApiPrefix = (): string => {
  return import.meta.env.VITE_API_PREFIX || '/api';
};

/**
 * Full API base URL including prefix
 */
export const API_BASE_URL = `${getApiBaseUrl()}${getApiPrefix()}`;

/**
 * Base URL without prefix (for other uses)
 */
export const BACKEND_BASE_URL = getApiBaseUrl();

/**
 * API endpoints
 */
export const API_ENDPOINTS = {
  // Auth endpoints
  AUTH: {
    LOGIN: `${API_BASE_URL}/auth/login`,
    REGISTER: `${API_BASE_URL}/auth/register`,
    REFRESH: `${API_BASE_URL}/auth/refresh`,
    FORGOT_PASSWORD: `${API_BASE_URL}/auth/forgot-password`,
    RESET_PASSWORD: `${API_BASE_URL}/auth/reset-password`,
  },

  // Admin endpoints
  ADMIN: {
    // Base admin API path
    BASE: `${API_BASE_URL}/admin`,

    // Admin login (JSON API endpoint under /api prefix)
    // Using API_BASE_URL ensures this always hits the backend API and returns JSON,
    // avoiding cases where /admin/login might be served by the frontend (HTML).
    LOGIN: `${API_BASE_URL}/admin/login`,
    // API-prefixed admin endpoints (protected)
    DOCTORS: `${API_BASE_URL}/admin/doctors`, // This might conflict if I used it for something else. Let's check.
    // The existing DOCTORS endpoint likely gets list of doctors.
    // My new route is also /admin/doctors (POST).
    // If I use the same path, it is fine.
    PATIENTS: `${API_BASE_URL}/admin/patients`,
    USERS: (id?: string) => `${API_BASE_URL}/admin/users${id ? `/${id}` : ''}`,
    USER_STATUS: (id: string) => `${API_BASE_URL}/admin/users/${id}/status`,
    USER_FAMILY_MEMBERS: (id: number) => `${API_BASE_URL}/admin/users/${id}/family-members`,
    PLANS: `${API_BASE_URL}/admin/plans`,
    PLAN: (planId: string) => `${API_BASE_URL}/admin/plans/${planId}`,
  },

  // Public endpoints
  PUBLIC: {
    // Public plans endpoint (JSON API) under API prefix
    PLANS: `${API_BASE_URL}/plans`,
    CONSENT: `${API_BASE_URL}/consent`,
  },

  // Doctor endpoints
  DOCTOR: {
    LOGIN: `${API_BASE_URL}/doctor/login`,
    PROFILE: `${API_BASE_URL}/doctor/profile`,
  },

  // Payments / User Plan endpoints (also mounted under API_PREFIX for consistent routing)
  PAYMENTS: {
    CREATE_INTENT: `${API_BASE_URL}/payments/create-intent`,
    WEBHOOK: `${BACKEND_BASE_URL}/payments/webhook`,
    MY_PAYMENTS: `${API_BASE_URL}/payments/my`,
  },
  USER: {
    ACTIVE_PLAN: `${API_BASE_URL}/user/plan`,
    PROFILE: `${API_BASE_URL}/user/profile`,
    NOTIFICATION_SETTINGS: `${API_BASE_URL}/user/notification-settings`,
    FAMILY_MEMBERS: `${API_BASE_URL}/user/family-members`,
    FAMILY_MEMBER: (id: number) => `${API_BASE_URL}/user/family-members/${id}`,
  },

  PATIENT: {
    MEDICATIONS: `${API_BASE_URL}/patient/medications`,
    MEDICATION: (id: number) => `${API_BASE_URL}/patient/medications/${id}`,
    VITALS: `${API_BASE_URL}/patient/vitals`,
    VITAL: (id: number) => `${API_BASE_URL}/patient/vitals/${id}`,
  },
  LOCATIONS: `${API_BASE_URL}/locations`,
  SYSTEM_CONFIGS: `${API_BASE_URL}/system-configs`,
  ITINERARY: `${API_BASE_URL}/itinerary`,
  PRESCRIPTION: {
    PATIENT: `${API_BASE_URL}/prescription/patient`,
    DOCTOR: `${API_BASE_URL}/prescription/doctor`,
    BASE: `${API_BASE_URL}/prescription`,
  },
} as const;

/**
 * Helper function to build full API URL
 */
export const buildApiUrl = (endpoint: string): string => {
  // If endpoint already starts with http, return as is
  if (endpoint.startsWith('http://') || endpoint.startsWith('https://')) {
    return endpoint;
  }

  // If endpoint starts with /, append to base URL
  if (endpoint.startsWith('/')) {
    return `${BACKEND_BASE_URL}${endpoint}`;
  }

  // Otherwise, append to API base URL
  return `${API_BASE_URL}/${endpoint}`;
};

// Log API configuration in development
if (import.meta.env.DEV) {
  console.log('🔧 API Configuration:');
  console.log(`   Backend URL: ${BACKEND_BASE_URL}`);
  console.log(`   API Base URL: ${API_BASE_URL}`);
  console.log(`   Frontend URL: ${import.meta.env.VITE_FRONTEND_URL || window.location.origin}`);
}
