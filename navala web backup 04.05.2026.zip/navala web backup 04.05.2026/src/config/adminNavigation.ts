import {
  LayoutDashboard,
  Users,
  Calendar,
  CalendarCheck,
  CreditCard,
  BarChart3,
  Receipt,
  User,
  MapPin,
  Settings,
} from 'lucide-react';

/**
 * Shared admin sidebar navigation.
 * Used across all /admin pages so the menu is consistent.
 */
export const adminNavigation: {
  name: string;
  href: string;
  icon: typeof LayoutDashboard;
}[] = [
  { name: 'Dashboard', href: '/admin', icon: LayoutDashboard },
  { name: 'Bookings', href: '/admin/bookings', icon: Calendar },
  { name: 'Appointments', href: '/admin/appointments', icon: CalendarCheck },
  { name: 'Patients', href: '/admin/patients', icon: Users },
  { name: 'Doctors', href: '/admin/doctors', icon: Users },
  { name: 'Locations', href: '/admin/locations', icon: MapPin },
  { name: 'Plans', href: '/admin/plans', icon: CreditCard },
  // { name: 'New Plans', href: '/admin/new-plans', icon: CreditCard },
  { name: 'Transactions', href: '/admin/transactions', icon: Receipt },
  { name: 'Reports', href: '/admin/reports', icon: BarChart3 },
  { name: 'Settings', href: '/admin/settings', icon: Settings },
  { name: 'Profile', href: '/admin/profile', icon: User },
] as const;
