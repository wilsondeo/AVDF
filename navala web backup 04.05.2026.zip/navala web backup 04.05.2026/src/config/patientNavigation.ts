import { LayoutDashboard, Calendar, FileText, CreditCard, FileSignature } from 'lucide-react';

export const getPatientNavigation = (hasActivePlan: boolean = true) => [
  { name: 'Dashboard', href: '/patient', icon: LayoutDashboard },
  { name: 'My Appointments', href: '/patient/appointments', icon: Calendar, disabled: !hasActivePlan },
  { name: 'Prescriptions', href: '/patient/prescriptions', icon: FileText, disabled: !hasActivePlan },
  { name: 'Contracts', href: '/patient/contracts', icon: FileSignature },
  { name: 'My Plan', href: '/patient/plans', icon: CreditCard },
];
