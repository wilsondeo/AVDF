/**
 * Plan benefits availability window. All plans are active during this period only.
 * No per-plan validity; same window for every plan.
 */
/** Date range as shown in banners (no space after en-dash) */
const DATE_RANGE = 'June 9th–July 20th';

export const PLAN_BENEFITS_AVAILABLE = {
  /** Display label for start date */
  fromLabel: 'June 9',
  /** Display label for end date */
  toLabel: 'July 20',
  /** Date range for highlighting in UI */
  dateRange: DATE_RANGE,
  /** Full message for banners */
  message: `Your plan is active from ${DATE_RANGE}. Book appointments, prescriptions, and other benefits during this period.`,
  /** Short message for compact UI */
  shortMessage: `Plan active from ${DATE_RANGE}.`,
} as const;
