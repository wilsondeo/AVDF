import { loadStripe } from '@stripe/stripe-js';

/**
 * Stripe frontend configuration (TEST MODE supported)
 * Publishable key must come from Vite env vars.
 */

export const STRIPE_PUBLISHABLE_KEY = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY as string | undefined;

console.log('Stripe Key Loaded:', STRIPE_PUBLISHABLE_KEY ? STRIPE_PUBLISHABLE_KEY.substring(0, 10) + '...' : 'MISSING');

export function getStripePromise() {
  if (!STRIPE_PUBLISHABLE_KEY) {
    throw new Error('VITE_STRIPE_PUBLISHABLE_KEY is missing. Add it to your frontend .env file.');
  }
  return loadStripe(STRIPE_PUBLISHABLE_KEY);
}

