# cURL Examples – Patient Mobile API

Replace `BASE_URL` with your backend base (e.g. `http://localhost:3001`) and `ACCESS_TOKEN` with a valid JWT after login.

---

## Health

```bash
curl -s -X GET "${BASE_URL}/health"
```

---

## Auth

### Register

```bash
curl -s -X POST "${BASE_URL}/api/auth/register" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "patient@example.com",
    "password": "SecurePass8",
    "firstName": "John",
    "lastName": "Doe"
  }'
```

### Login

```bash
curl -s -X POST "${BASE_URL}/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "patient@example.com",
    "password": "SecurePass8"
  }'
```

### Refresh token

```bash
curl -s -X POST "${BASE_URL}/api/auth/refresh" \
  -H "Content-Type: application/json" \
  -d '{"refreshToken": "YOUR_REFRESH_TOKEN"}'
```

### Forgot password (send OTP)

```bash
curl -s -X POST "${BASE_URL}/api/auth/forgot-password" \
  -H "Content-Type: application/json" \
  -d '{"email": "patient@example.com"}'
```

### Reset password (with OTP)

```bash
curl -s -X POST "${BASE_URL}/api/auth/reset-password" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "patient@example.com",
    "otp": "123456",
    "newPassword": "NewSecurePass8",
    "confirmPassword": "NewSecurePass8"
  }'
```

---

## Public Content (no auth)

### Get consent categories

```bash
curl -s -X GET "${BASE_URL}/api/consent"
```

### Get available locations

```bash
curl -s -X GET "${BASE_URL}/api/locations"
```

---

## Plans (no auth)

### Get active plans

```bash
curl -s -X GET "${BASE_URL}/plans"
```

---

## User plan (auth required)

### Get my active plan

```bash
curl -s -X GET "${BASE_URL}/api/user/plan" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}"
```

---

## Payments (auth required)

### Create payment intent

```bash
curl -s -X POST "${BASE_URL}/api/payments/create-intent" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -d '{"planId": "plan_basic_001"}'
```

### Get my payments

```bash
curl -s -X GET "${BASE_URL}/api/payments/my?limit=10&offset=0" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}"
```

---

## Appointments (auth required)

### Create appointment request

```bash
curl -s -X POST "${BASE_URL}/api/appointments/request" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -d '{
    "city": "New York",
    "age": 35,
    "gender": "male",
    "emergencyContact": "+1234567890",
    "serviceType": "TELEHEALTH",
    "notes": "First consultation"
  }'
```

### Get my appointment requests

```bash
curl -s -X GET "${BASE_URL}/api/appointments/my-requests" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}"
```

---

## Family Management (auth required)

### List family members

```bash
curl -s -X GET "${BASE_URL}/api/user/family-members" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}"
```

### Add family member

```bash
curl -s -X POST "${BASE_URL}/api/user/family-members" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -d '{
    "firstName": "Jane",
    "lastName": "Doe",
    "relationship": "Spouse",
    "gender": "female",
    "dateOfBirth": "1990-05-15"
  }'
```

---

## Health Tracking (auth required)

### Get medications (today)

```bash
curl -s -X GET "${BASE_URL}/api/patient/medications" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}"
```

### Log medication taken

```bash
# Replace :id with medication id
curl -s -X POST "${BASE_URL}/api/patient/medications/:id/taken" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -d '{"taken": true}'
```

### Add vitals reading

```bash
curl -s -X POST "${BASE_URL}/api/patient/vitals" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -d '{
    "heartRate": 72,
    "bloodPressureSystolic": 120,
    "bloodPressureDiastolic": 80,
    "temperature": 98.6,
    "oxygenLevel": 98
  }'
```

---

## Notification Settings (auth required)

### Get settings

```bash
curl -s -X GET "${BASE_URL}/api/user/notification-settings" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}"
```

### Update settings

```bash
curl -s -X PUT "${BASE_URL}/api/user/notification-settings" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -d '{
    "emailAppointments": true,
    "emailReminders": true,
    "emailPromo": false,
    "inAppEnabled": true
  }'
```

---

## One-liner: login and save token (Unix)

```bash
# Save access token to ACCESS_TOKEN
ACCESS_TOKEN=$(curl -s -X POST "${BASE_URL}/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email":"patient@example.com","password":"SecurePass8"}' \
  | jq -r '.data.accessToken')
echo "Token: $ACCESS_TOKEN"
```

Then use in a protected call:

```bash
curl -s -X GET "${BASE_URL}/api/user/plan" -H "Authorization: Bearer $ACCESS_TOKEN"
```
