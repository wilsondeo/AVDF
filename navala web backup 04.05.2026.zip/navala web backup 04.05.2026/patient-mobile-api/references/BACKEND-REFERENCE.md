# Backend Reference – Patient Mobile API

This document points to the **source code** of the backend that implements the Patient Mobile API. Use it when debugging or when you need to align request/response with the server.

---

## Repository layout

The backend lives in the parent folder:

```
Navala Travel app/
├── backend/                    # Main backend (Express + Sequelize)
│   ├── server.js
│   ├── src/
│   │   ├── app.js              # Route mounting, CORS, middleware
│   │   ├── config/
│   │   ├── controllers/
│   │   ├── middlewares/
│   │   ├── models/
│   │   ├── routes/
│   │   └── services/
│   └── .env
└── patient-mobile-api/         # This folder (docs + config only)
```

---

## Patient-related backend files

| Purpose | Path |
|--------|------|
| Auth (login, register, refresh) | `backend/src/routes/auth.routes.js` |
| Auth logic | `backend/src/services/auth.service.js` |
| Auth controller | `backend/src/controllers/auth.controller.js` |
| Appointments (request, my-requests) | `backend/src/routes/appointment.routes.js` |
| Appointment logic | `backend/src/services/appointment.service.js` |
| Appointment controller | `backend/src/controllers/appointment.controller.js` |
| Payments (create-intent, user/plan, my) | `backend/src/routes/payment.routes.js` |
| User profile (GET/PATCH /user/profile) | Same router: `backend/src/routes/payment.routes.js`; controller: `backend/src/controllers/user.controller.js` (getProfile, updateProfile) |
| Payment logic | `backend/src/services/payment.service.js` |
| Payment controller | `backend/src/controllers/payment.controller.js` |
| Public plans (GET /plans) | `backend/src/routes/plan.routes.js` (getActivePlansController) |
| Consent content (GET /api/consent) | `backend/src/routes/consent.routes.js`; controller: `backend/src/controllers/consent.controller.js` |
| Health data (meds, vitals) | `backend/src/routes/patientData.routes.js`; controller: `backend/src/controllers/patientData.controller.js` |
| Notification settings (GET/PUT) | `backend/src/routes/user.routes.js`; controller: `backend/src/controllers/notificationSettings.controller.js` |
| Family members (CRUD) | `backend/src/routes/user.routes.js`; controller: `backend/src/controllers/familyMember.controller.js` |
| Locations (GET) | `backend/src/routes/location.routes.js`; controller: `backend/src/controllers/location.controller.js` |
| System Config (GET /api/system-configs) | `backend/src/routes/system-config.routes.js`; controller: `backend/src/controllers/systemConfigController.js` |
| User Itinerary (GET/POST /api/itinerary) | `backend/src/routes/itinerary.routes.js`; controller: `backend/src/controllers/itinerary.controller.js` |
| Prescriptions (GET array, GET specific) | `backend/src/routes/prescription.routes.js`; controller: `backend/src/controllers/prescription.controller.js` |
| Plan Confirmation Flow | **New Documentation**: `patient-mobile-api/references/plan-confirmation.md` |
| Forgot/Reset Password | `backend/src/app.js` (calls auth controller) |
| JWT (tokens, verify) | `backend/src/config/jwt.js` |
| Auth middleware (Bearer) | `backend/src/middlewares/auth.middleware.js` |
| Role (patientOnly) | `backend/src/middlewares/role.middleware.js` |

---

## How routes are mounted (app.js)

- `GET /health` – app root
- `GET /plans` – app root (public active plans)
- Payment routes mounted at **root** and at **API_PREFIX**:
  - `POST /payments/create-intent`, `GET /user/plan`, `GET /payments/my`
  - `POST /api/payments/create-intent`, `GET /api/user/plan`, `GET /api/payments/my`
- `API_PREFIX` = `/api` (default from env):
  - `/api/auth/*` – auth routes (login, register, refresh, forgot/reset)
  - `/api/appointments/*` – patient appointment routes
  - `/api/user/*` – user profile, plan, family members, notification settings
  - `/api/patient/*` – patient health data (medications, vitals)
  - `/api/locations` – public and admin locations management
  - `/api/system-configs` – global tax and strategy settings (GET public / POST admin)
  - `/api/itinerary` – patient trip itinerary segments (GET/POST/DELETE)
  - `/api/consent` – public consent categories
  - `/api/prescription` – medical prescriptions (GET /patient)

So the **patient mobile app** can use either:

- Base URL = `http://localhost:3001` and paths like `/api/auth/login`, `/api/user/plan`, `/plans`, etc., or  
- Same with a production host instead of localhost.

---

## Environment (backend)

Backend reads from `backend/.env`. Relevant for mobile:

- `PORT` – server port (default 3001)
- `API_PREFIX` – default `/api`
- `BASE_URL` – used in emails/links
- `JWT_SECRET`, `JWT_REFRESH_SECRET` – token signing
- `STRIPE_*` – payment (create-intent returns Stripe client secret)

The **mobile app** does not need these; it only needs the **base URL** (and optionally Stripe publishable key for the payment UI). See `patient-mobile-api/config/env.example`.

---

## Running the backend

From the project root:

```bash
cd backend
npm install
# Set .env (copy from .env.example if present)
node server.js
# or: npm start
```

Then use `http://localhost:3001` (or your `PORT`) as `BASE_URL` in the mobile app and in the cURL examples.

---

## Family Member Booking Logic

When an appointment is booked for a family member:
1.  **Selection**: The patient selects a family member from their profile (or 'Myself').
2.  **Request Creation**: A POST request is sent to `/api/appointments/request` with `familyMemberId` if a family member was selected.
3.  **Storage**: The `family_member_id` is stored in the `appointment_requests` table.
4.  **Admin Assignment**: When an admin assigns a doctor, an `Appointment` is created. This appointment links back to the `AppointmentRequest`.
5.  **Data Fetching**: 
    - The **Admin Panel** fetches requests and includes the `familyMember` model if `family_member_id` is present.
    - The **Doctor View** and **Prescriptions** traverse the associations (`Appointment` -> `AppointmentRequest` -> `FamilyMember`) to identify the correct patient to display.
6.  **Display**: If a `familyMember` is linked, the system displays the family member's name and details; otherwise, it defaults to the primary account holder's details.
