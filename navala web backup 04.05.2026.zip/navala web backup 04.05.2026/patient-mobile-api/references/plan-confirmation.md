# Plan Confirmation Flow – Mobile Development

This document explains how to implement the "Plan Confirmation" screen in the patient mobile application, mirroring the logic used in the web portal.

## Objective
To show the user a detailed receipt/confirmation of their active healthcare plan, including covered family members and the latest payment details.

## Logic Flow

To populate the confirmation screen, the mobile app should perform three parallel or sequential API calls:

### 1. Get Active Plan Details
**Endpoint**: `GET /api/user/plan`  
**Description**: Returns the user's currently active plan object.
- **Key Fields to Show**: `plan.name`, `plan.description`, `plan.features` (array), `plan.services` (array).
- **Coverage Period**: All plans currently follow the fixed World Cup window (June 9th to July 20th).

### 2. Get Covered family members
**Endpoint**: `GET /api/user/family-members`  
**Description**: Returns a list of family members added by the user.
- **Logic**: If the active plan (`maxPersons > 1`) is a family plan, display the primary member (the user) and the listed family members.
- **Visuals**: Show names and relationships.

### 3. Get Latest Payment Details
**Endpoint**: `GET /api/payments/my`  
**Description**: Returns the payment history for the user.
- **Logic**: Sort the returned `payments` array by `createdAt` (descending) and pick the first item. This represents the last transaction for the current plan.
- **Key Fields to Show**: `amount`, `stripePaymentIntentId` (as Transaction ID), `createdAt` (as Invoice Date).

## UI/UX Recommendation
- **Status Badge**: Display a prominent "ACTIVE" badge with a checkmark.
- **Document Aesthetic**: Style the screen or a specific section like a digital receipt/official certificate.
- **PDF Export**: If the mobile platform supports it, provide an option to "Share as PDF" or "Print" using the same data.

## Example Data Structure (for display)

```json
{
  "confirmationId": "NTH-CONF-000123",
  "planName": "Premium Health Plan - Diamond",
  "status": "ACTIVE",
  "member": "John Doe",
  "familyMembers": [
    {"name": "Jane Doe", "role": "Spouse"},
    {"name": "Junior Doe", "role": "Child"}
  ],
  "payment": {
    "amount": 299.00,
    "date": "2026-04-23",
    "transactionId": "pi_3P5..."
  }
}
```
# Patient API Endpoints & Logic Guide

This document explains how to implement the core features in the patient mobile application: **Plan Confirmation**, **Contracts**, and **Prescriptions**.

---

## 1. Plan Confirmation Flow
**Objective**: Show a detailed receipt of the user's active plan and payment.

### Logic Flow
Perform these API calls to populate the screen:

#### A. Get Active Plan
- **Endpoint**: `GET /api/user/plan`
- **Key Data**: `plan.name`, `plan.features` (array), `plan.services` (array).

#### B. Get Family Members
- **Endpoint**: `GET /api/user/family-members`
- **Logic**: If the plan allows multiple persons, list the user and their family members.

#### C. Get Payment Record
- **Endpoint**: `GET /api/payments/my`
- **Logic**: Sort by `createdAt` descending. The first item is the latest payment.
- **Display**: `amount` (formatted from cents), `stripePaymentIntentId` (Transaction ID), and `createdAt` (Invoice Date).

---

## 2. Service Contracts
**Objective**: Display the legally binding agreement between Navala and the Patient.

### Logic Flow
There is **no dedicated endpoint** for a contract PDF. The app should generate the contract view dynamically using:
1. **User Profile**: `GET /api/user/profile` (for name and address).
2. **Active Plan**: `GET /api/user/plan` (for plan name and coverage type).

### Key Contract Sections (to be hardcoded in UI):
- **Nature of Agreement**: Terms for delivery of healthcare during World Cup 2026.
- **Scope of Services**: 24/7 Telehealth and emergency coordination.
- **Coverage Period**: Strictly **June 9th to July 20th**.
- **Limitations**: Acknowledgment that Navala facilitates access to 3rd-party local hospitals.

---

## 3. Prescriptions
**Objective**: List all medical prescriptions issued by doctors.

### Logic Flow
#### A. List Prescriptions
- **Endpoint**: `GET /api/prescription/patient`
- **Description**: Returns all prescriptions for the logged-in user.
- **Response Structure**:
  ```json
  [
    {
      "id": 1,
      "prescriptionUuid": "...",
      "doctorName": "Dr. Smith",
      "diagnosis": "...",
      "medicines": [
        { "medicineName": "Amoxicillin", "dosage": "500mg", "frequency": "3x daily" }
      ],
      "createdAt": "2026-04-25T..."
    }
  ]
  ```

#### B. View/Print Prescription
- **Logic**: Each prescription should have a "View" button.
- **Printing**: The web portal uses a special print-friendly page. For mobile, you should generate a clean view with the Navala logo, doctor details, diagnosis, and the medicine list.

---

## 4. Common Data Mapping
- **Dates**: Always format dates in US format (`MM/DD/YYYY`) or full descriptive format (`Month Day, Year`) for clarity.
- **Currency**: All amounts from the API are in **USD**. Use `$XX.XX` format.
- **Role Verification**: Ensure the `role` in the user profile is `PATIENT`.
