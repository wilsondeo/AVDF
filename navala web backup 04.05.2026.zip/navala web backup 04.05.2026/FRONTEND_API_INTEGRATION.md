# Frontend API Integration Guide

## ✅ Completed Integration

The frontend has been fully integrated with the backend API using centralized configuration. No hardcoded URLs!

### Files Created/Updated

1. **`src/config/api.ts`** - Centralized API configuration
   - Reads from `VITE_API_BASE_URL` environment variable
   - Provides pre-configured endpoints
   - Automatically uses IP address or localhost based on `.env`

2. **`src/services/api.ts`** - API service layer
   - Handles all API calls
   - Manages authentication tokens
   - Provides type-safe API methods

3. **`src/pages/auth/RegisterPage.tsx`** - Patient registration page
   - ✅ Only allows patient registration (as per backend requirements)
   - ✅ Integrated with backend API
   - ✅ Uses centralized API configuration
   - ✅ Form validation
   - ✅ Error handling with toast notifications

4. **`src/pages/auth/LoginPage.tsx`** - Login page
   - ✅ Integrated with backend API for all roles
   - ✅ Separate endpoints for patient, doctor, and admin
   - ✅ Uses centralized API configuration
   - ✅ Token management

5. **`src/lib/store.ts`** - Updated store
   - Added `setUser` method for API integration
   - Updated `logout` to clear tokens

## How to Use

### 1. Configure Environment Variables

Create a `.env` file in the **root directory**:

```env
# Backend API URL (use IP address for network access)
VITE_API_BASE_URL=http://192.168.1.225:3000
VITE_API_PREFIX=/api
VITE_FRONTEND_URL=http://192.168.1.225:8080
```

**To switch from localhost to server:**
- Just change `VITE_API_BASE_URL` in `.env`
- No code changes needed!

### 2. Using API in Components

```typescript
import { authApi } from '@/services/api';
import { API_ENDPOINTS } from '@/config/api';

// Login example
const response = await authApi.patientLogin(email, password);
if (response.success && response.data) {
  // Handle success
  setAuthToken(response.data.accessToken);
}

// Registration example
const response = await authApi.patientRegister({
  email: 'patient@example.com',
  password: 'SecurePass123',
  firstName: 'John',
  lastName: 'Doe',
});
```

### 3. Available API Methods

**Authentication:**
- `authApi.patientLogin(email, password)`
- `authApi.patientRegister(data)`
- `authApi.doctorLogin(email, password)`
- `authApi.adminLogin(email, password)`
- `authApi.refreshToken(refreshToken)`

**Token Management:**
- `getAuthToken()` - Get stored access token
- `setAuthToken(token)` - Store access token
- `removeAuthToken()` - Clear tokens
- `getAuthHeaders()` - Get headers with auth token

**Patient profile (authenticated):**
- `userProfileApi.getProfile()` - GET current user profile (returns full UserProfile from users table)
- `userProfileApi.updateProfile(data)` - PATCH profile; `data` can include: `firstName`, `lastName`, `phone`, `dateOfBirth`, `streetAddress`, `city`, `state`, `zipCode`, `country`, `emergencyContactName`, `emergencyContactPhone`, `emergencyContactRelationship`, `bloodType` (all optional)

## Registration Flow

1. User fills registration form (first name, last name, email, password)
2. Form validates input (email format, password length, password match)
3. Calls `authApi.patientRegister()` with form data
4. On success:
   - Stores access token and refresh token
   - Updates user in store
   - Redirects to patient dashboard
5. On error:
   - Shows error message
   - Displays toast notification

## Login Flow

1. User selects role (patient/doctor/admin)
2. User enters email and password
3. Calls appropriate API endpoint:
   - Patient → `authApi.patientLogin()`
   - Doctor → `authApi.doctorLogin()`
   - Admin → `authApi.adminLogin()`
4. On success:
   - Stores tokens
   - Updates user in store
   - Redirects to appropriate dashboard
5. On error:
   - Shows error message
   - Displays toast notification

## Important Notes

### Patient Registration Only
- ✅ Only patients can self-register (as per backend requirements)
- ✅ Doctors and admins must be created by administrators
- ✅ Registration page only shows patient registration form

### Token Storage
- Access tokens stored in `localStorage` as `accessToken`
- Refresh tokens stored in `localStorage` as `refreshToken`
- Tokens are cleared on logout

### Error Handling
- All API calls include error handling
- User-friendly error messages displayed
- Toast notifications for success/error states

### Network Configuration
- Frontend listens on `0.0.0.0:8080` (accessible via IP)
- Backend CORS configured to accept frontend URL from environment
- Change URLs in `.env` files only - no code changes needed!

## Testing

1. **Start Backend:**
   ```bash
   cd backend
   npm run dev
   ```

2. **Start Frontend:**
   ```bash
   npm run dev
   ```

3. **Test Registration:**
   - Navigate to `/register`
   - Fill in patient details
   - Submit form
   - Should redirect to `/patient` on success

4. **Test Login:**
   - Navigate to `/login`
   - Select role (patient/doctor/admin)
   - Enter credentials
   - Should redirect to appropriate dashboard

## API Endpoints Used

- `POST /api/auth/register` - Patient registration (optional profile fields: phone, dateOfBirth, streetAddress, city, state, zipCode, country, emergencyContactName, emergencyContactPhone, emergencyContactRelationship, bloodType)
- `POST /api/auth/login` - Patient login
- `POST /api/admin/login` - Admin login
- `POST /api/doctor/login` - Doctor login
- `POST /api/auth/refresh` - Refresh access token
- `GET /user/profile` or `GET /api/user/profile` - Get current user profile (patient; requires auth)
- `PATCH /user/profile` or `PATCH /api/user/profile` - Update current user profile (patient; requires auth)

All endpoints use the centralized configuration from `src/config/api.ts`!
