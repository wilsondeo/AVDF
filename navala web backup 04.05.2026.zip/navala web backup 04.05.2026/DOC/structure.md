# Project Folder Structure

## Frontend (`/src`)
- `components/`: Reusable UI components (buttons, cards, layout).
- `config/`: Configuration files (API endpoints, plan constants).
- `lib/`: Shared logic and state management (Zustand store).
- `pages/`: Page components (Admin, Patient, Auth, Landing).
  - `admin/`: Admin-only pages (Plans, Patients, Dashboard).
  - `patient/`: Patient-only pages (Profile, Plans, Appointments).
- `services/`: API service layer (Axios wrappers).

## Backend (`/backend/src`)
- `config/`: Environment setup, database connection, Stripe, JWT.
- `controllers/`: Request handlers (logic for each endpoint).
- `middlewares/`: Auth and role-based access control.
- `models/`: Sequelize database models (User, Plan, FamilyMember).
- `routes/`: Express route definitions.
- `services/`: Business logic layer (Payment processing, Plan management).
- `utils/`: Helper functions (Validation, Date formatting).

## Documentation (`/DOC`)
- `database.md`: Database schema and table details.
- `api.md`: Endpoint list and descriptions.
- `flow.md`: Logical user and system flows.
- `structure.md`: This file.
