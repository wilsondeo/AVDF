# API Documentation

Base URL: `https://travelhealth.navalaglobal.com/api` (Production)
Local: `http://localhost:3000/api`

## Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/auth/login` | Patient login |
| POST | `/auth/register` | Patient registration |
| POST | `/admin/login` | Admin login (Note: `/admin/login` without `/api`) |

## User Profile & Family
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/user/profile` | Get current user profile |
| PATCH | `/user/profile` | Update profile (firstName, lastName, gender, etc.) |
| GET | `/user/family-members` | List family members & max slots |
| POST | `/user/family-members` | Add family member (locked after add) |
| GET | `/user/plan` | Get current active plan details |

## Admin Management
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/admin/patients` | List all patients with plan/appointment stats |
| GET | `/admin/users/:id/family-members` | View family for specific patient |
| PATCH | `/admin/users/:id` | Update patient profile/gender |
| GET | `/admin/plans` | List all plans (active & inactive) |
| POST | `/admin/plans` | Create new plan (Individual/Family) |
| POST | `/admin/patients/:id/plan` | Manually grant plan to patient |

## Public
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/plans` | Get all active plans for landing page |
