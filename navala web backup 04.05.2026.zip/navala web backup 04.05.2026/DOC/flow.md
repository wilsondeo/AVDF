# Application Flow Documentation

This document outlines the primary user flows in the Navala Travel Health application.

## 1. Patient Onboarding & Plan Purchase
1. **Landing Page**: User views plans (Individual, Family of 2, Family of 3-4).
2. **Registration**: User clicks "Get this plan" and registers an account.
3. **Plan Selection**: User selects a plan from the `PatientPlansPage`.
4. **Stripe Checkout**: User pays via Stripe.
5. **Activation**: Stripe Webhook notifies the backend; `UserPlan` is created as `ACTIVE`.

## 2. Profile & Family Management
1. **Profile Setup**: Patient enters personal info (Gender, DOB, Address).
2. **Age Calculation**: System automatically shows age based on DOB.
3. **Family Addition**: 
   - If on a Family Plan, user sees "Add Family Member".
   - User enters details and clicks Save.
   - **Confirmation**: A popup warns that details cannot be changed later.
   - **Locking**: After saving, "Edit" and "Remove" buttons are disabled.
4. **Coverage View**: `PatientPlansPage` shows a unified banner with all covered members.

## 3. Admin Patient Management
1. **Dashboard**: Admin views total patients and active plans.
2. **Patient List**: Admin searches/filters patients by plan or status.
3. **Patient Details**: 
   - Admin clicks "View".
   - System automatically loads patient profile and **Family Members**.
   - Admin can manually grant a plan or update patient status.

## 4. Appointment Flow (Conceptual)
1. **Booking**: Patient picks a slot -> Adds symptoms -> Selects covered member.
2. **Doctor View**: Doctor sees appointment with symptoms and patient history.
3. **Consultation**: Telehealth or In-person visit occurs.
