import express from 'express';
import { authMiddleware } from '../middlewares/auth.middleware.js';
import { adminOnly } from '../middlewares/role.middleware.js';
import {
  createPlanController,
  updatePlanController,
  deletePlanController,
  getAllPlansController,
  getPlanByPlanIdController,
} from '../controllers/plan.controller.js';

const router = express.Router();

/**
 * Admin Plan Routes
 * Base path: /api/admin/plans
 * All routes require authentication and admin role
 */

router.use(authMiddleware);
router.use(adminOnly);

// Create plan
router.post('/', createPlanController);

// Get all plans (admin view - includes inactive)
router.get('/', getAllPlansController);

// Get plan by planId
router.get('/:planId', getPlanByPlanIdController);

// Update plan
router.put('/:planId', updatePlanController);

// Delete plan (soft delete)
router.delete('/:planId', deletePlanController);

export default router;
