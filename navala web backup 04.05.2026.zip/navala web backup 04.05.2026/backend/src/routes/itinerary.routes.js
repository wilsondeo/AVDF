import { Router } from 'express';
import { getUserItineraries, saveUserItinerary, clearUserItinerary } from '../controllers/itinerary.controller.js';

const router = Router();

/**
 * @route GET /api/itinerary
 * @desc Get user itineraries
 */
router.get('/', getUserItineraries);

/**
 * @route GET /api/itinerary/:userId
 * @desc Get specifically by user ID (Admin)
 */
router.get('/:userId', getUserItineraries);

/**
 * @route POST /api/itinerary
 * @desc Save itinerary
 */
router.post('/', saveUserItinerary);

/**
 * @route DELETE /api/itinerary
 * @desc Clear itinerary
 */
router.delete('/', clearUserItinerary);

export default router;
