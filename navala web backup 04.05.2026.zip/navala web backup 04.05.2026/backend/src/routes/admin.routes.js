import express from 'express';
import { authMiddleware } from '../middlewares/auth.middleware.js';
import { adminOnly } from '../middlewares/role.middleware.js';
import {
  adminLogin,
  createDoctor,
  getAllDoctors,
  getAllPatients,
  grantPlanToPatient,
  getUser,
  updateUserStatusEndpoint,
  updateUserEndpoint,
  getTransactions,
  getTransactionStats,
  getReportsAnalytics,
} from '../controllers/admin.controller.js';
import { getFamilyMembersForUser } from '../controllers/familyMember.controller.js';

const router = express.Router();

/**
 * Admin Routes
 * Base path: /api/admin
 */

// Public route - Admin login (no authentication required)
router.post('/login', adminLogin);

// Protected routes - All require authentication and admin role
router.use(authMiddleware);
router.use(adminOnly);

// Patient management
router.get('/patients', getAllPatients);
router.post('/patients/:userId/plan', grantPlanToPatient);
router.get('/users/:id/family-members', getFamilyMembersForUser);

// User management
router.get('/users/:id', getUser);
router.patch('/users/:id', updateUserEndpoint);
router.patch('/users/:id/status', updateUserStatusEndpoint);

// Transaction management
router.get('/transactions', getTransactions);
router.get('/transactions/stats', getTransactionStats);
router.get('/reports/analytics', getReportsAnalytics);

export default router;
