import express from 'express';
import { authMiddleware } from '../middlewares/auth.middleware.js';
import { patientOnly } from '../middlewares/role.middleware.js';
import {
  createAppointmentRequestController,
  getMyAppointmentRequestsController,
} from '../controllers/appointment.controller.js';

/**
 * Patient Appointment Routes
 * Base path: /api/appointments
 */

const router = express.Router();

// All routes require authenticated PATIENT
router.use(authMiddleware, patientOnly);

// POST /api/appointments/request
router.post('/request', createAppointmentRequestController);

// GET /api/appointments/my-requests
router.get('/my-requests', getMyAppointmentRequestsController);

export default router;

