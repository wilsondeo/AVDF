import { Router } from 'express';
import { getAllConfigs, updateTaxSettings, getSetting } from '../controllers/systemConfigController.js';

const router = Router();

/**
 * @route GET /api/system-configs
 * @desc Get all configs
 * @access Admin
 */
router.get('/', getAllConfigs);

/**
 * @route GET /api/system-configs/:key
 * @desc Get specific config
 * @access Public
 */
router.get('/:key', getSetting);

/**
 * @route POST /api/system-configs/tax-settings
 * @desc Update tax settings
 * @access Admin
 */
router.post('/tax-settings', updateTaxSettings);

export default router;
