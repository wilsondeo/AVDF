import express from 'express';
import { getConsentController } from '../controllers/consent.controller.js';

const router = express.Router();

/**
 * Public routes for consent categories
 * GET /api/consent
 */
router.get('/', getConsentController);

export default router;
