import express from 'express';
import { authMiddleware } from '../middlewares/auth.middleware.js';
import { patientOnly } from '../middlewares/role.middleware.js';
import {
  getMedications,
  addMedication,
  updateMedication,
  setMedicationTaken,
  getVitals,
  addVitals,
  updateVitals,
} from '../controllers/patientData.controller.js';

const router = express.Router();

router.use(authMiddleware, patientOnly);

router.get('/medications', getMedications);
router.post('/medications', addMedication);
router.patch('/medications/:id', updateMedication);
router.post('/medications/:id/taken', setMedicationTaken);

router.get('/vitals', getVitals);
router.post('/vitals', addVitals);
router.patch('/vitals/:id', updateVitals);

export default router;
