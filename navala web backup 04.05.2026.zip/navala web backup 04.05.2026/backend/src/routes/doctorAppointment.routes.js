import express from 'express';
import { authMiddleware } from '../middlewares/auth.middleware.js';
import { doctorOnly } from '../middlewares/role.middleware.js';
import { getDoctorAppointmentsController } from '../controllers/doctorAppointment.controller.js';

/**
 * Doctor Appointment Routes
 * Base path: /api/doctor
 *
 * Required endpoint:
 * - GET /api/doctor/appointments
 */

const router = express.Router();

router.use(authMiddleware, doctorOnly);

router.get('/appointments', getDoctorAppointmentsController);

export default router;

