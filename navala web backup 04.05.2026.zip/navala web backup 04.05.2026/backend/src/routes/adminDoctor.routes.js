import express from 'express';
import {
  getAllDoctorsController,
  getDoctorController,
  createDoctorController,
  updateDoctorController,
  deleteDoctorController,
  sendDoctorEmailController,
  uploadDoctorsController,
} from '../controllers/adminDoctor.controller.js';
import { adminOnly } from '../middlewares/role.middleware.js';
import { authMiddleware } from '../middlewares/auth.middleware.js';
import multer from 'multer';

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

router.use(authMiddleware, adminOnly);

router.get('/', getAllDoctorsController);
router.post('/', createDoctorController);
router.post('/upload', upload.single('file'), uploadDoctorsController);
router.get('/:id', getDoctorController);
router.put('/:id', updateDoctorController);
router.delete('/:id', deleteDoctorController);
router.post('/:id/send-email', sendDoctorEmailController);

export default router;
