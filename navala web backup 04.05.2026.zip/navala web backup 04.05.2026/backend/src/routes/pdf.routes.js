import express from 'express';
import { getPrescriptionPDF, getContractPDF, getConfirmationPDF } from '../controllers/pdf.controller.js';
import { authMiddleware } from '../middlewares/auth.middleware.js';

const router = express.Router();

/**
 * PDF Routes
 * These endpoints return actual PDF files that the mobile app can download/view.
 */

// We don't strictly need auth for public-facing UUIDs (like prescriptions), 
// but it's safer to keep them protected for sensitive documents.
router.get('/prescription/:uuid', authMiddleware, getPrescriptionPDF);
router.get('/contract/:userId', authMiddleware, getContractPDF);
router.get('/confirmation/:paymentId', authMiddleware, getConfirmationPDF);

export default router;
