import express from 'express';
import { adminLogin } from '../controllers/admin.controller.js';

const router = express.Router();

/**
 * Standalone Admin Login Route
 * Base path: /admin/login (no API prefix)
 * This is a separate URL for admin login
 */

router.post('/login', adminLogin);

export default router;
