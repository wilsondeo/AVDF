import express from 'express';
import { authMiddleware } from '../middlewares/auth.middleware.js';
import { doctorOnly } from '../middlewares/role.middleware.js';
import { doctorLogin, getDoctorProfile } from '../controllers/doctor.controller.js';
import { updateProfile } from '../controllers/user.controller.js';

const router = express.Router();

/**
 * Doctor Routes
 * Base path: /api/doctor
 */

// Public route - Doctor login (no authentication required)
router.post('/login', doctorLogin);

// Protected routes - All require authentication and doctor role
router.use(authMiddleware);
router.use(doctorOnly);

// Doctor profile
router.get('/profile', getDoctorProfile);
router.patch('/profile', updateProfile);

export default router;
