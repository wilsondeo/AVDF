import express from 'express';
import { getPrescriptionView, getConfirmationView, getContractView } from '../controllers/shared.controller.js';
import { authMiddleware } from '../middlewares/auth.middleware.js';

const router = express.Router();

/**
 * Shared View Routes
 * These routes return high-fidelity HTML for mobile PDF generation.
 */

// Prescription view (using UUID)
router.get('/prescription/:uuid/view', authMiddleware, getPrescriptionView);

// Plan Confirmation / Receipt view (using userUuid or ID)
router.get('/confirmation/:userUuid/view', authMiddleware, getConfirmationView);

// Service Contract view (using userUuid or ID)
router.get('/contract/:userUuid/view', authMiddleware, getContractView);

export default router;
