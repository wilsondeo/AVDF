import express from 'express';
import { patientLogin, patientRegister, refreshToken, forgotPassword, resetPassword } from '../controllers/auth.controller.js';

const router = express.Router();

/**
 * Patient Authentication Routes
 * Base path: /api/auth
 */

// Patient login
router.post('/login', patientLogin);

// Patient registration
router.post('/register', patientRegister);

// Refresh access token
router.post('/refresh', refreshToken);

// Forgot password: send OTP to email (patient only)
router.post('/forgot-password', forgotPassword);

// Reset password with OTP (patient only)
router.post('/reset-password', resetPassword);

export default router;
