import express from 'express';
import { authMiddleware } from '../middlewares/auth.middleware.js';
import { getProfile, updateProfile } from '../controllers/user.controller.js';
import { getNotificationSettings, updateNotificationSettings } from '../controllers/notificationSettings.controller.js';
import { getUserPlanController } from '../controllers/payment.controller.js';
import {
  getFamilyMembers,
  postFamilyMember,
  patchFamilyMember,
  deleteFamilyMemberController,
} from '../controllers/familyMember.controller.js';

const router = express.Router();

// All /api/user/* routes require auth
router.use(authMiddleware);

router.get('/plan', getUserPlanController);
router.get('/profile', getProfile);
router.patch('/profile', updateProfile);
router.get('/notification-settings', getNotificationSettings);
router.put('/notification-settings', updateNotificationSettings);

router.get('/family-members', getFamilyMembers);
router.post('/family-members', postFamilyMember);
router.patch('/family-members/:id', patchFamilyMember);
router.delete('/family-members/:id', deleteFamilyMemberController);

export default router;
