import express from 'express';
import { authMiddleware } from '../middlewares/auth.middleware.js';
import {
  createIntentController,
  webhookController,
  getUserPlanController,
  getMyPaymentsController,
} from '../controllers/payment.controller.js';
import { getProfile, updateProfile } from '../controllers/user.controller.js';
import { getNotificationSettings, updateNotificationSettings } from '../controllers/notificationSettings.controller.js';
import { forgotPassword, resetPassword } from '../controllers/auth.controller.js';

const router = express.Router();

// Auth: forgot/reset password (when this router is mounted at /api, path is /auth/forgot-password)
router.post('/auth/forgot-password', forgotPassword);
router.post('/auth/reset-password', resetPassword);

/**
 * Required endpoints:
 * - POST /payments/create-intent (auth)
 * - POST /payments/webhook (no auth)
 * - GET  /user/plan (auth)
 *
 * We mount this router at "/" so paths match exactly.
 */

// Stripe webhook MUST be public (no auth)
router.post('/payments/webhook', webhookController);

// Authenticated endpoints
router.post('/payments/create-intent', authMiddleware, createIntentController);
router.get('/user/plan', authMiddleware, getUserPlanController);
router.get('/user/profile', authMiddleware, getProfile);
router.patch('/user/profile', authMiddleware, updateProfile);
router.get('/user/notification-settings', authMiddleware, getNotificationSettings);
router.put('/user/notification-settings', authMiddleware, updateNotificationSettings);
router.get('/payments/my', authMiddleware, getMyPaymentsController);

export default router;

