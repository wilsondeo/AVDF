import express from 'express';
import { authMiddleware } from '../middlewares/auth.middleware.js';
import { adminOnly } from '../middlewares/role.middleware.js';
import {
  getAllAppointmentRequestsController,
  assignDoctorController,
  updateRequestStatusController,
  getAllAppointmentsController,
  deleteAppointmentRequestController,
} from '../controllers/adminAppointment.controller.js';

/**
 * Admin Appointment Routes
 * Base path: /api/admin
 *
 * - GET    /api/admin/appointment-requests
 * - POST   /api/admin/assign-doctor
 * - GET    /api/admin/appointments
 * - DELETE /api/admin/appointment-requests/:requestUuid
 */

const router = express.Router();

// All routes require authenticated ADMIN
router.use(authMiddleware, adminOnly);

router.get('/appointment-requests', getAllAppointmentRequestsController);
router.patch('/appointment-requests/:requestUuid/status', updateRequestStatusController);
router.post('/assign-doctor', assignDoctorController);
router.get('/appointments', getAllAppointmentsController);
router.delete('/appointment-requests/:requestUuid', deleteAppointmentRequestController);

export default router;
