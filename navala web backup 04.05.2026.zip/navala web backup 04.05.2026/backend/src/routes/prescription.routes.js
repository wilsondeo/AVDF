import express from 'express';
import { authMiddleware } from '../middlewares/auth.middleware.js';
import { doctorOnly } from '../middlewares/role.middleware.js';
import { createOrUpdatePrescription, getPatientPrescriptions, getDoctorPrescriptions, getPrescriptionByAppointmentUuid, getPrescriptionById, searchMedicines } from '../controllers/prescription.controller.js';

const router = express.Router();

/**
 * Prescription Routes
 * Base path: /api/prescriptions
 */

router.use(authMiddleware);

// Patient routes
router.get('/patient', getPatientPrescriptions);

// Doctor routes
router.patch('/', doctorOnly, createOrUpdatePrescription); // Using PATCH to handle both save as draft and final create/update
router.get('/doctor', doctorOnly, getDoctorPrescriptions);
router.get('/medicines/search', searchMedicines); // Needs to be before :idOrUuid or it will be catched as ID
router.get('/appointment/:appointmentUuid', getPrescriptionByAppointmentUuid);
router.get('/:idOrUuid', getPrescriptionById);

export default router;
