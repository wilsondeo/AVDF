import { Router } from 'express';
import { 
  getAllLocationsController, 
  createLocationController, 
  updateLocationController, 
  deleteLocationController 
} from '../controllers/location.controller.js';

const router = Router();

/**
 * @route GET /api/locations
 * @desc Get all available locations
 * @access Public
 */
router.get('/', getAllLocationsController);

/**
 * @route POST /api/locations
 * @desc Create a new location (Admin)
 * @access Private/Admin
 */
router.post('/', createLocationController);

/**
 * @route PUT /api/locations/:id
 * @desc Update a location (Admin)
 * @access Private/Admin
 */
router.put('/:id', updateLocationController);

/**
 * @route DELETE /api/locations/:id
 * @desc Delete a location (Admin)
 * @access Private/Admin
 */
router.delete('/:id', deleteLocationController);

export default router;
