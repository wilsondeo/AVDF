import { randomUUID } from 'crypto';

/**
 * Generate a unique UUID v4
 * @returns {string} UUID string
 */
export function generateUuid() {
    return randomUUID();
}
