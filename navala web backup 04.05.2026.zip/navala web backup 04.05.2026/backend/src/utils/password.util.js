/**
 * Generate a secure random password
 * Meets requirements: 8-12 chars, Uppercase, Lowercase, Number, Symbol
 * @param {number} minLength - Minimum length (default: 8)
 * @param {number} maxLength - Maximum length (default: 12)
 * @returns {string} Random password
 */
export function generateRandomPassword(minLength = 8, maxLength = 12) {
    const length = Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;

    const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lower = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';
    const symbols = '!@#$%^&*';
    const all = upper + lower + numbers + symbols;

    let password = '';

    // Ensure at least one of each type
    password += upper[Math.floor(Math.random() * upper.length)];
    password += lower[Math.floor(Math.random() * lower.length)];
    password += numbers[Math.floor(Math.random() * numbers.length)];
    password += symbols[Math.floor(Math.random() * symbols.length)];

    // Fill the rest randomly
    for (let i = password.length; i < length; i++) {
        password += all[Math.floor(Math.random() * all.length)];
    }

    // Shuffle the password
    return password.split('').sort(() => Math.random() - 0.5).join('');
}
