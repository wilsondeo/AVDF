/**
 * Validate date of birth: must be a valid date, not in the future, and person must be 13+ years old.
 * @param {string} dateOfBirth - Date string (e.g. YYYY-MM-DD)
 * @returns {{ valid: boolean, message?: string }}
 */
export function validateDateOfBirth(dateOfBirth) {
  if (!dateOfBirth || typeof dateOfBirth !== 'string' || !dateOfBirth.trim()) {
    return { valid: true }; // optional field
  }
  const d = new Date(dateOfBirth);
  if (Number.isNaN(d.getTime())) {
    return { valid: false, message: 'Please enter a valid date of birth.' };
  }
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (d > today) {
    return { valid: false, message: 'Please enter a valid date of birth.' };
  }
  const age = (today.getTime() - d.getTime()) / (365.25 * 24 * 60 * 60 * 1000);
  if (age < 13) {
    return { valid: false, message: 'You must be 13 years or older.' };
  }
  return { valid: true };
}
