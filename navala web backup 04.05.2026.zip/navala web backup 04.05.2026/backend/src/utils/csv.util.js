/**
 * Parse CSV buffer into JSON array
 * @param {Buffer|string} buffer - CSV file buffer or string
 * @returns {Promise<Array<Object>>} Array of objects where keys are headers
 */
export async function parseCsv(buffer) {
    const content = buffer.toString().trim();
    const lines = content.split(/\r?\n/);

    if (lines.length < 2) {
        throw new Error('CSV file is empty or missing data');
    }

    const headers = lines[0].split(',').map(h => h.trim());
    const results = [];

    for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        // Handle CSV quoting if simple split is not enough? 
        // Requirement implies simple CSV: name,email,phone,city,specialization,years_of_experience
        // We will assume simple comma separation for now as per requirement example.
        const values = line.split(',').map(v => v.trim());

        if (values.length !== headers.length) {
            // Skip malformed lines or handle partials?
            // We will try to map what we have
        }

        const row = {};
        headers.forEach((header, index) => {
            row[header] = values[index] || '';
        });

        // Add row number for error reporting (1-based, considering header is 1)
        row._rowNumber = i + 1;

        results.push(row);
    }

    return results;
}
