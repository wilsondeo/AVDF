import express from 'express';
import cors from 'cors';
import { env } from './config/env.js';
import { initializeSequelize, testConnection, syncDatabase } from './config/database.js';
import { verifyEmailConfig } from './config/mail.js';
import './models/User.js'; // Import model to register it
import './models/Plan.js'; // Import model to register it
import './models/Payment.js'; // Import model to register it
import './models/UserPlan.js'; // Import model to register it
import './models/Doctor.js'; // For admin patients/appointments
import './models/AppointmentRequest.js'; // For admin appointment-requests
import './models/Appointment.js'; // For admin patients/appointments
import './models/PasswordResetOtp.js'; // For forgot-password OTP
import './models/PlanUpgrade.js'; // For upgrade audit (storage only)
import './models/PatientMedication.js';
import './models/MedicationTaken.js';
import './models/PatientVital.js';
import './models/NotificationSetting.js';
import './models/FamilyMember.js';
import './models/Location.js';
import './models/SystemConfig.js';
import './models/UserItinerary.js';
import './models/Prescription.js';
import './models/PrescriptionMedicine.js';
import './models/Medicine.js';
import { backfillUserUuids } from './models/User.js';

// Import routes
import authRoutes from './routes/auth.routes.js';
import adminRoutes from './routes/admin.routes.js';
import adminDoctorRoutes from './routes/adminDoctor.routes.js';
import appointmentRoutes from './routes/appointment.routes.js';
import adminAppointmentRoutes from './routes/adminAppointment.routes.js';
import doctorAppointmentRoutes from './routes/doctorAppointment.routes.js';
import adminLoginRoute from './routes/admin-login.routes.js';
import doctorRoutes from './routes/doctor.routes.js';
import planRoutes from './routes/plan.routes.js';
import { getActivePlansController } from './controllers/plan.controller.js';
import paymentRoutes from './routes/payment.routes.js';
import userRoutes from './routes/user.routes.js';
import patientDataRoutes from './routes/patientData.routes.js';
import locationRoutes from './routes/location.routes.js';
import consentRoutes from './routes/consent.routes.js';
import systemConfigRoutes from './routes/system-config.routes.js';
import itineraryRoutes from './routes/itinerary.routes.js';
import prescriptionRoutes from './routes/prescription.routes.js';
import pdfRoutes from './routes/pdf.routes.js';
import sharedRoutes from './routes/shared.routes.js';

/**
 * Express Application Setup
 * Centralized application configuration
 */

const app = express();

// Middleware - CORS configuration (IP-based; set FRONTEND_URL/CORS_ORIGIN in .env)
const allowedOrigins = [
  env.CORS_ORIGIN,
  env.FRONTEND_URL,
  'http://192.168.1.225:8080',
  'http://192.168.1.225:5173',
].filter(Boolean); // Remove undefined values

app.use(cors({
  origin: (origin, callback) => {
    // Allow requests with no origin (like mobile apps, Postman, curl)
    if (!origin) {
      return callback(null, true);
    }

    // Check if origin is in allowed list
    if (allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      // In development, allow any origin (for flexibility)
      if (env.NODE_ENV === 'development') {
        callback(null, true);
      } else {
        callback(new Error('Not allowed by CORS'));
      }
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// IMPORTANT: Stripe webhook signature verification requires raw body.
// Capture raw body for both /payments/webhook and /api/payments/webhook while
// still using JSON parsing for other routes.
app.use(express.json({
  verify: (req, _res, buf) => {
    if (
      req.originalUrl === '/payments/webhook' ||
      req.originalUrl === `${env.API_PREFIX}/payments/webhook` ||
      req.originalUrl.endsWith('/payments/webhook')
    ) {
      req.rawBody = buf;
    }
  },
}));
app.use(express.urlencoded({ extended: true }));

// Request logging middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    success: true,
    message: 'Server is running',
    timestamp: new Date().toISOString(),
  });
});

// Standalone Admin Login Route (separate URL without API prefix)
app.use('/admin', adminLoginRoute);

// Public routes (no authentication required)
// Public plans endpoint available both at root and under API prefix for consistency
app.get('/plans', getActivePlansController);

// Forgot/reset password – MUST be before app.use(API_PREFIX, ...) or that router catches all /api/*
app.post('/api/auth/forgot-password', (req, res) => {
  import('./controllers/auth.controller.js').then(({ forgotPassword }) => forgotPassword(req, res)).catch((err) => {
    console.error('forgot-password', err);
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  });
});
app.post('/api/auth/reset-password', (req, res) => {
  import('./controllers/auth.controller.js').then(({ resetPassword: doReset }) => doReset(req, res)).catch((err) => {
    console.error('reset-password', err);
    res.status(500).json({ success: false, message: err.message || 'Server error' });
  });
});

// Payments routes (Stripe)
// Mounted at root so paths match exactly: /payments/* and /user/plan
app.use('/', paymentRoutes);
// Optional aliases under API prefix for convenience
app.use(env.API_PREFIX, paymentRoutes);

// API routes
const apiPrefix = env.API_PREFIX;
// Public plans endpoint under API prefix (JSON API)
app.get(`${apiPrefix}/plans`, getActivePlansController);
app.use(apiPrefix + '/user', userRoutes);
app.use(apiPrefix + '/auth', authRoutes);
app.use(`${apiPrefix}/admin/doctors`, adminDoctorRoutes); // More specific first
app.use(`${apiPrefix}/admin`, adminRoutes);
app.use(`${apiPrefix}/admin/plans`, planRoutes);
app.use(`${apiPrefix}/appointments`, appointmentRoutes);
app.use(`${apiPrefix}/admin`, adminAppointmentRoutes);
app.use(`${apiPrefix}/doctor`, doctorRoutes);
app.use(`${apiPrefix}/doctor`, doctorAppointmentRoutes);
app.use(`${apiPrefix}/patient`, patientDataRoutes);
app.use(`${apiPrefix}/locations`, locationRoutes);
app.use(`${apiPrefix}/consent`, consentRoutes);
app.use(`${apiPrefix}/system-configs`, systemConfigRoutes);
app.use(`${apiPrefix}/itinerary`, itineraryRoutes);
app.use(`${apiPrefix}/prescription`, prescriptionRoutes);
app.use(`${apiPrefix}/pdf`, pdfRoutes);
app.use(`${apiPrefix}/shared`, sharedRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Route not found',
    path: req.path,
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);

  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal server error',
    ...(env.NODE_ENV === 'development' && { stack: err.stack }),
  });
});

/**
 * Initialize application
 * Sets up database connection and tables
 */
export async function initializeApp() {
  try {
    // Initialize Sequelize (this registers models)
    initializeSequelize();

    // Test database connection
    await testConnection();

    // Sync database models (creates tables if they don't exist)
    // Control schema sync behavior via env vars only (no code changes for deployment):
    // - DB_SYNC_ALTER=true  -> safe-ish development alters
    // - DB_SYNC_FORCE=true  -> DROPS & recreates tables (DANGEROUS!)
    await syncDatabase({ alter: env.DB_SYNC_ALTER, force: env.DB_SYNC_FORCE });

    // Backfill user_uuid for existing databases (safe migration helper)
    await backfillUserUuids();

    // Verify email configuration (non-blocking)
    await verifyEmailConfig();

    console.log('✅ Application initialized successfully');
  } catch (error) {
    console.error('❌ Application initialization failed:', error);
    throw error;
  }
}

export default app;
