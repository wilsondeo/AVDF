import jwt from 'jsonwebtoken';
import { env } from './env.js';

/**
 * JWT Token Configuration and Utilities
 * Centralized token creation and verification
 */

/**
 * Generate access token
 * @param {Object} payload - Token payload (userId, role)
 * @returns {string} JWT access token
 */
export function generateAccessToken(payload) {
  return jwt.sign(
    {
      userId: payload.userId,
      role: payload.role,
      ...(payload.userUuid ? { userUuid: payload.userUuid } : {}),
      type: 'access',
    },
    env.JWT_SECRET,
    {
      expiresIn: env.JWT_ACCESS_EXPIRY,
    }
  );
}

/**
 * Generate refresh token
 * @param {Object} payload - Token payload (userId, role)
 * @returns {string} JWT refresh token
 */
export function generateRefreshToken(payload) {
  return jwt.sign(
    {
      userId: payload.userId,
      role: payload.role,
      ...(payload.userUuid ? { userUuid: payload.userUuid } : {}),
      type: 'refresh',
    },
    env.JWT_REFRESH_SECRET,
    {
      expiresIn: env.JWT_REFRESH_EXPIRY,
    }
  );
}

/**
 * Generate both access and refresh tokens
 * @param {Object} payload - Token payload (userId, role)
 * @returns {Object} Object containing accessToken and refreshToken
 */
export function generateTokenPair(payload) {
  return {
    accessToken: generateAccessToken(payload),
    refreshToken: generateRefreshToken(payload),
  };
}

/**
 * Verify access token
 * @param {string} token - JWT access token
 * @returns {Object} Decoded token payload
 * @throws {Error} If token is invalid or expired
 */
export function verifyAccessToken(token) {
  try {
    return jwt.verify(token, env.JWT_SECRET);
  } catch (error) {
    throw new Error('Invalid or expired access token');
  }
}

/**
 * Verify refresh token
 * @param {string} token - JWT refresh token
 * @returns {Object} Decoded token payload
 * @throws {Error} If token is invalid or expired
 */
export function verifyRefreshToken(token) {
  try {
    return jwt.verify(token, env.JWT_REFRESH_SECRET);
  } catch (error) {
    throw new Error('Invalid or expired refresh token');
  }
}

/**
 * Decode token without verification (for debugging)
 * @param {string} token - JWT token
 * @returns {Object} Decoded token payload
 */
export function decodeToken(token) {
  return jwt.decode(token);
}
