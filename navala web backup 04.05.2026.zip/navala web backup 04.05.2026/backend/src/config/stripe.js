import Stripe from 'stripe';
import { env } from './env.js';

/**
 * Stripe configuration (TEST MODE)
 * All secrets come from environment variables.
 */

export function getStripeClient() {
  if (!env.STRIPE_SECRET_KEY) {
    throw new Error('STRIPE_SECRET_KEY is missing. Set it in backend/.env');
  }

  return new Stripe(env.STRIPE_SECRET_KEY, {
    // Keep default API version chosen by installed stripe SDK
    // You can pin an apiVersion here if desired.
    typescript: false,
  });
}

export function getStripeWebhookSecret() {
  if (!env.STRIPE_WEBHOOK_SECRET) {
    throw new Error('STRIPE_WEBHOOK_SECRET is missing. Set it in backend/.env');
  }
  return env.STRIPE_WEBHOOK_SECRET;
}

