import { Sequelize } from 'sequelize';
import { env } from './env.js';

/**
 * Database Configuration using Sequelize ORM
 * Centralized database connection management
 */

let sequelize = null;

/**
 * Initialize Sequelize connection
 * @returns {Sequelize} Sequelize instance
 */
export function initializeSequelize() {
  if (sequelize) {
    return sequelize;
  }

  sequelize = new Sequelize(env.DB_NAME, env.DB_USER, env.DB_PASSWORD, {
    host: env.DB_HOST,
    port: env.DB_PORT,
    dialect: 'mysql',
    logging: env.NODE_ENV === 'development' ? console.log : false,
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000,
    },
    define: {
      timestamps: true,
      underscored: false,
      freezeTableName: true,
    },
  });

  return sequelize;
}

/**
 * Get Sequelize instance
 * @returns {Sequelize} Sequelize instance
 */
export function getSequelize() {
  if (!sequelize) {
    return initializeSequelize();
  }
  return sequelize;
}

/**
 * Test database connection
 * @returns {Promise<boolean>} True if connection successful
 */
export async function testConnection() {
  try {
    const db = getSequelize();
    await db.authenticate();
    console.log('✅ Database connected successfully');
    return true;
  } catch (error) {
    console.error('❌ Database connection failed:', error.message);
    throw error;
  }
}

/**
 * Sync database models
 * @param {Object} options - Sync options
 * @returns {Promise<void>}
 */
export async function syncDatabase(options = {}) {
  const db = getSequelize();
  const syncOptions = {
    alter: false,
    force: false,
    ...options,
  };
  
  await db.sync(syncOptions);
  console.log('✅ Database models synchronized');
}

/**
 * Close database connection
 * @returns {Promise<void>}
 */
export async function closeConnection() {
  if (sequelize) {
    await sequelize.close();
    sequelize = null;
    console.log('Database connection closed');
  }
}
