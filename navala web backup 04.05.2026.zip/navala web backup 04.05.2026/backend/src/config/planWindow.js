/**
 * Fixed plan benefits window. All plans are active during this period only.
 * No per-plan validity; same window for every plan.
 */
const PLAN_WINDOW = {
  startMonth: 5,   // June (0-indexed)
  startDay: 9,
  endMonth: 6,    // July (0-indexed)
  endDay: 20,
};

/**
 * Get start and end dates for the plan window in a given year.
 * @param {number} [year] - Defaults to current year
 * @returns {{ startDate: Date, endDate: Date }}
 */
export function getPlanWindowDates(year = new Date().getFullYear()) {
  const startDate = new Date(year, PLAN_WINDOW.startMonth, PLAN_WINDOW.startDay);
  const endDate = new Date(year, PLAN_WINDOW.endMonth, PLAN_WINDOW.endDay);
  return { startDate, endDate };
}

/**
 * Get the active plan window (if today is past July 20, returns next year's window).
 * @returns {{ startDate: Date, endDate: Date }}
 */
export function getActivePlanWindow() {
  const now = new Date();
  let year = now.getFullYear();
  const { endDate } = getPlanWindowDates(year);
  if (now > endDate) {
    year += 1;
  }
  return getPlanWindowDates(year);
}

export default getPlanWindowDates;
