import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

/**
 * Centralized environment configuration
 * All environment variables are loaded here and exported
 */
export const env = {
  // Server Configuration (HOST=0.0.0.0 to listen on all interfaces for IP access)
  NODE_ENV: process.env.NODE_ENV || 'development',
  PORT: process.env.PORT || 3000,
  HOST: process.env.HOST || '0.0.0.0',
  BASE_URL: process.env.BASE_URL || 'http://0.0.0.0:3000',
  API_PREFIX: process.env.API_PREFIX || '/api',

  // Frontend Configuration (use your machine IP for network access)
  FRONTEND_URL: process.env.FRONTEND_URL || 'http://0.0.0.0:8080',
  CORS_ORIGIN: process.env.CORS_ORIGIN || process.env.FRONTEND_URL || 'http://0.0.0.0:8080',

  // Database Configuration (127.0.0.1 or DB server IP)
  DB_HOST: process.env.DB_HOST || '127.0.0.1',
  DB_PORT: process.env.DB_PORT || 3306,
  DB_USER: process.env.DB_USER || 'root',
  DB_PASSWORD: process.env.DB_PASSWORD || '',
  DB_NAME: process.env.DB_NAME || 'navala_travelapp',
  // In development, default to alter=true to avoid crashes when models evolve.
  // In production, keep it false unless explicitly enabled.
  DB_SYNC_ALTER: process.env.DB_SYNC_ALTER !== undefined
    ? process.env.DB_SYNC_ALTER === 'true'
    : ((process.env.NODE_ENV || 'development') === 'development'),
  DB_SYNC_FORCE: process.env.DB_SYNC_FORCE === 'true',

  // JWT Configuration
  JWT_SECRET: process.env.JWT_SECRET || 'your-secret-key-change-in-production',
  JWT_REFRESH_SECRET: process.env.JWT_REFRESH_SECRET || 'your-refresh-secret-key-change-in-production',
  JWT_ACCESS_EXPIRY: process.env.JWT_ACCESS_EXPIRY || '24h',
  JWT_REFRESH_EXPIRY: process.env.JWT_REFRESH_EXPIRY || '7d',

  // Stripe Configuration (TEST MODE supported)
  STRIPE_SECRET_KEY: process.env.STRIPE_SECRET_KEY || '',
  STRIPE_WEBHOOK_SECRET: process.env.STRIPE_WEBHOOK_SECRET || '',
  STRIPE_CURRENCY: process.env.STRIPE_CURRENCY || 'usd',

  // SMTP Configuration
  SMTP_HOST: process.env.SMTP_HOST || 'smtp.gmail.com',
  SMTP_PORT: process.env.SMTP_PORT || 587,
  SMTP_SECURE: process.env.SMTP_SECURE === 'true',
  SMTP_USER: process.env.SMTP_USER || '',
  SMTP_PASSWORD: process.env.SMTP_PASSWORD || '',
  SMTP_FROM_EMAIL: process.env.SMTP_FROM_EMAIL || '',
  SMTP_FROM_NAME: process.env.SMTP_FROM_NAME || 'Navala Travel',

  // Security
  BCRYPT_ROUNDS: parseInt(process.env.BCRYPT_ROUNDS || '10', 10),
};

/**
 * Validate required environment variables
 */
export function validateEnv() {
  const required = [
    'JWT_SECRET',
    'JWT_REFRESH_SECRET',
    'DB_NAME',
  ];

  const missing = required.filter(key => !process.env[key] || process.env[key] === '');

  if (missing.length > 0 && env.NODE_ENV === 'production') {
    throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
  }
}

// Validate on import in production
if (env.NODE_ENV === 'production') {
  validateEnv();
}
