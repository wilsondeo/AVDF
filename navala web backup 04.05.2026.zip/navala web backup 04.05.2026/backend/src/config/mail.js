import nodemailer from 'nodemailer';
import { env } from './env.js';

/**
 * Email Configuration
 * Centralized SMTP configuration for NodeMailer
 */

let transporter = null;

/**
 * Create and configure email transporter
 * @returns {nodemailer.Transporter} Configured email transporter
 */
export function createTransporter() {
  if (transporter) {
    return transporter;
  }

  transporter = nodemailer.createTransport({
    host: env.SMTP_HOST,
    port: parseInt(env.SMTP_PORT, 10),
    secure: env.SMTP_SECURE,
    auth: {
      user: env.SMTP_USER,
      pass: env.SMTP_PASSWORD,
    },
  });

  return transporter;
}

/**
 * Get email transporter
 * @returns {nodemailer.Transporter} Email transporter
 */
export function getTransporter() {
  if (!transporter) {
    return createTransporter();
  }
  return transporter;
}

/**
 * Verify email configuration
 * @returns {Promise<boolean>} True if configuration is valid
 */
export async function verifyEmailConfig() {
  try {
    const transporter = getTransporter();
    await transporter.verify();
    console.log('✅ Email server is ready to send messages');
    return true;
  } catch (error) {
    console.warn('⚠️ Email configuration verification failed:', error.message);
    return false;
  }
}

/**
 * Get default email options
 * @returns {Object} Default email options
 */
export function getDefaultEmailOptions() {
  return {
    from: {
      name: env.SMTP_FROM_NAME,
      address: env.SMTP_FROM_EMAIL,
    },
  };
}
