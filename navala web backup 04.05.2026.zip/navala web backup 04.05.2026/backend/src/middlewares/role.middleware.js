import { UserRoles } from '../models/User.js';

/**
 * Role-based Access Control Middleware
 * Restricts access based on user roles
 */

/**
 * Middleware to check if user has required role(s)
 * @param {string|string[]} allowedRoles - Single role or array of allowed roles
 * @returns {Function} Express middleware function
 */
export function roleMiddleware(allowedRoles) {
  // Normalize to array
  const roles = Array.isArray(allowedRoles) ? allowedRoles : [allowedRoles];
  
  return (req, res, next) => {
    // Check if user is authenticated (should be set by authMiddleware)
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required',
      });
    }
    
    // Check if user has required role
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: 'Insufficient permissions. Required role: ' + roles.join(' or '),
      });
    }
    
    next();
  };
}

/**
 * Middleware to restrict access to Admin only
 */
export const adminOnly = roleMiddleware(UserRoles.ADMIN);

/**
 * Middleware to restrict access to Doctor only
 */
export const doctorOnly = roleMiddleware(UserRoles.DOCTOR);

/**
 * Middleware to restrict access to Patient only
 */
export const patientOnly = roleMiddleware(UserRoles.PATIENT);

/**
 * Middleware to restrict access to Admin or Doctor
 */
export const adminOrDoctor = roleMiddleware([UserRoles.ADMIN, UserRoles.DOCTOR]);

/**
 * Middleware to restrict access to Admin or Patient
 */
export const adminOrPatient = roleMiddleware([UserRoles.ADMIN, UserRoles.PATIENT]);
