/**
 * Seed the 6 World Cup plans (Individual/Family of 2/Family of 3-4 × Basic/Premium).
 * Safe to run multiple times: skips creation if a plan with the same name already exists.
 *
 * Usage (from backend folder): node src/scripts/seed-world-cup-plans.js
 * Or: npm run seed:plans  (if script is added to package.json)
 */

import { testConnection, syncDatabase, closeConnection, initializeSequelize } from '../config/database.js';
import Plan from '../models/Plan.js';
import { createPlanService } from '../services/plan.service.js';

const WORLD_CUP_PLANS = [
  {
    name: 'Individual - Basic',
    price: 100,
    validityDays: 42,
    description: 'Individual plan. 2 telehealth visits, prescription coverage $150, specialty care coordination. June 9–July 20.',
    services: ['TELEHEALTH', 'EMERGENCY'],
    features: ['2 telehealth visits', 'Prescription coverage $150', 'Specialty care coordination'],
    isActive: true,
  },
  {
    name: 'Individual - Premium',
    price: 130,
    validityDays: 42,
    description: 'Individual plan. 4 telehealth + 2 in-person visits, prescription $250, specialty coordination. June 9–July 20.',
    services: ['TELEHEALTH', 'EMERGENCY'],
    features: ['4 telehealth visits', '2 in-person visits', 'Prescription coverage $250', 'Specialty care coordination'],
    isActive: true,
  },
  {
    name: 'Family of 2 - Basic',
    price: 150,
    validityDays: 42,
    description: 'Family of 2. 4 telehealth + 2 in-person, prescription $250, specialty coordination. June 9–July 20.',
    services: ['TELEHEALTH', 'EMERGENCY'],
    features: ['4 telehealth visits', '2 in-person visits', 'Prescription coverage $250', 'Specialty care coordination'],
    isActive: true,
  },
  {
    name: 'Family of 2 - Premium',
    price: 200,
    validityDays: 42,
    description: 'Family of 2. Unlimited telehealth, 4 in-person, prescription $350, specialty coordination. June 9–July 20.',
    services: ['TELEHEALTH', 'EMERGENCY'],
    features: ['Unlimited telehealth visits', '4 in-person visits', 'Prescription coverage $350', 'Specialty care coordination'],
    isActive: true,
  },
  {
    name: 'Family of 3-4 - Basic',
    price: 250,
    validityDays: 42,
    description: 'Family of 3–4. 5 telehealth + 4 in-person, prescription $375, specialty coordination. June 9–July 20.',
    services: ['TELEHEALTH', 'EMERGENCY'],
    features: ['5 telehealth visits', '4 in-person visits', 'Prescription coverage $375', 'Specialty care coordination'],
    isActive: true,
  },
  {
    name: 'Family of 3-4 - Premium',
    price: 325,
    validityDays: 42,
    description: 'Family of 3–4. Unlimited telehealth, 6 in-person, prescription $500, specialty coordination. June 9–July 20.',
    services: ['TELEHEALTH', 'EMERGENCY'],
    features: ['Unlimited telehealth visits', '6 in-person visits', 'Prescription coverage $500', 'Specialty care coordination'],
    isActive: true,
  },
];

async function seedWorldCupPlans() {
  try {
    console.log('🌱 Seeding World Cup plans...');
    initializeSequelize();
    await testConnection();
    await syncDatabase({ alter: false });

    for (const planData of WORLD_CUP_PLANS) {
      const exists = await Plan.findOne({ where: { name: planData.name } });
      if (exists) {
        console.log(`⏭️  Plan "${planData.name}" already exists. Skipping.`);
        continue;
      }
      const plan = await createPlanService(planData);
      console.log(`✅ Created: ${planData.name} (planId: ${plan.planId})`);
    }

    await closeConnection();
    console.log('✅ World Cup plans seed completed.');
  } catch (error) {
    console.error('❌ Seed failed:', error);
    await closeConnection();
    process.exit(1);
  }
}

seedWorldCupPlans();
