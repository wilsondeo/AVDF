import { testConnection, syncDatabase, closeConnection, initializeSequelize } from '../config/database.js';
import { createUser, emailExists, UserRoles } from '../models/User.js';
import '../models/User.js'; // Import to register model with Sequelize

/**
 * Database Seed Script
 * Creates admin user for initial setup
 * 
 * Usage: npm run seed
 */

async function seedDatabase() {
  try {
    console.log('🌱 Starting database seed...');
    
    // Initialize Sequelize (this registers models)
    initializeSequelize();
    
    // Test database connection
    await testConnection();
    
    // Sync database models (creates tables if they don't exist)
    await syncDatabase({ alter: false });
    
    // Check if admin already exists
    const adminEmail = process.env.ADMIN_EMAIL || 'admin@navala.com';
    
    if (await emailExists(adminEmail)) {
      console.log('⚠️  Admin user already exists. Skipping seed.');
      await closeConnection();
      return;
    }
    
    // Default admin credentials (should be changed after first login)
    const adminPassword = process.env.ADMIN_PASSWORD || 'Admin@123';
    const adminFirstName = process.env.ADMIN_FIRST_NAME || 'Admin';
    const adminLastName = process.env.ADMIN_LAST_NAME || 'User';
    
    // Create admin user
    const admin = await createUser({
      email: adminEmail,
      password: adminPassword,
      firstName: adminFirstName,
      lastName: adminLastName,
      role: UserRoles.ADMIN,
      isActive: true,
    });
    
    console.log('✅ Admin user created successfully!');
    console.log('\n📋 Admin Credentials:');
    console.log(`   Email: ${adminEmail}`);
    console.log(`   Password: ${adminPassword}`);
    console.log('\n⚠️  IMPORTANT: Change the admin password after first login!');
    console.log('   You can set custom credentials using environment variables:');
    console.log('   ADMIN_EMAIL, ADMIN_PASSWORD, ADMIN_FIRST_NAME, ADMIN_LAST_NAME');
    
    await closeConnection();
    console.log('\n✅ Database seed completed successfully!');
  } catch (error) {
    console.error('❌ Database seed failed:', error);
    await closeConnection();
    process.exit(1);
  }
}

// Run seed
seedDatabase();
