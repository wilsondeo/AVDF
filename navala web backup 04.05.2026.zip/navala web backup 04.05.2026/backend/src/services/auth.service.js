import { getUserByEmail, comparePassword, createUser, emailExists, updateUserPassword } from '../models/User.js';
import { generateTokenPair, verifyRefreshToken, generateAccessToken } from '../config/jwt.js';
import { UserRoles } from '../models/User.js';
import PasswordResetOtp from '../models/PasswordResetOtp.js';
import { sendPasswordResetOtp } from './mail.service.js';

/**
 * Authentication Service
 * Handles authentication business logic
 */

/**
 * Authenticate user with email and password
 * @param {string} email - User email
 * @param {string} password - Plain text password
 * @param {string} expectedRole - Expected user role (optional, for role-specific login)
 * @returns {Promise<Object>} User object and tokens
 * @throws {Error} If authentication fails
 */
export async function authenticateUser(email, password, expectedRole = null) {
  // Get user with password
  const user = await getUserByEmail(email, true);
  
  if (!user) {
    throw new Error('Invalid email or password');
  }
  
  // Check if user is active
  if (!user.isActive) {
    throw new Error('Account is deactivated. Please contact administrator.');
  }
  
  // Verify role if expected role is provided
  if (expectedRole && user.role !== expectedRole) {
    throw new Error('Invalid email or password');
  }
  
  // Verify password
  const isPasswordValid = await comparePassword(password, user.password);
  if (!isPasswordValid) {
    throw new Error('Invalid email or password');
  }
  
  // Remove password from user object
  delete user.password;
  
  // Generate tokens
  const tokens = generateTokenPair({
    userId: user.id,
    role: user.role,
    userUuid: user.userUuid,
  });
  
  return {
    user,
    ...tokens,
  };
}

/**
 * Register a new patient
 * @param {Object} userData - Patient registration data
 * @param {string} userData.email - Patient email
 * @param {string} userData.password - Plain text password
 * @param {string} userData.firstName - Patient first name
 * @param {string} userData.lastName - Patient last name
 * @returns {Promise<Object>} Created user and tokens
 * @throws {Error} If registration fails
 */
export async function registerPatient(userData) {
  // Check if email already exists
  if (await emailExists(userData.email)) {
    throw new Error('Email already registered');
  }
  
  // Create patient user
  const user = await createUser({
    ...userData,
    role: UserRoles.PATIENT,
  });
  
  // Generate tokens
  const tokens = generateTokenPair({
    userId: user.id,
    role: user.role,
    userUuid: user.userUuid,
  });
  
  return {
    user,
    ...tokens,
  };
}

/**
 * Refresh access token using refresh token
 * @param {string} refreshToken - Refresh token
 * @returns {Promise<Object>} New access token
 * @throws {Error} If refresh token is invalid
 */
export async function refreshAccessToken(refreshToken) {
  // Verify refresh token
  const decoded = verifyRefreshToken(refreshToken);
  
  // Generate new access token
  const accessToken = generateAccessToken({
    userId: decoded.userId,
    role: decoded.role,
  });
  
  return {
    accessToken,
  };
}

/**
 * Validate user role
 * @param {string} role - Role to validate
 * @returns {boolean} True if role is valid
 */
export function isValidRole(role) {
  return Object.values(UserRoles).includes(role);
}

const OTP_EXPIRY_MINUTES = 10;
const OTP_LENGTH = 6;

function generateOtp() {
  let otp = '';
  for (let i = 0; i < OTP_LENGTH; i++) {
    otp += Math.floor(Math.random() * 10).toString();
  }
  return otp;
}

/**
 * Request password reset: validate patient email, generate OTP, store it, send email.
 * @param {string} email - Patient email
 * @throws {Error} If email not found or not a patient
 */
export async function requestPasswordReset(email) {
  const user = await getUserByEmail(email, false);
  if (!user) {
    throw new Error('No account found with this email');
  }
  if (user.role !== UserRoles.PATIENT) {
    throw new Error('Password reset is only available for patient accounts');
  }
  const otp = generateOtp();
  const expiresAt = new Date(Date.now() + OTP_EXPIRY_MINUTES * 60 * 1000);
  await PasswordResetOtp.upsert(
    { email: email.toLowerCase().trim(), otp, expiresAt },
    { fields: ['otp', 'expiresAt', 'updatedAt'] }
  );
  await sendPasswordResetOtp(email, otp);
}

/**
 * Reset password using OTP: validate OTP, then update password.
 * @param {string} email - Patient email
 * @param {string} otp - OTP sent to email
 * @param {string} newPassword - New password
 * @throws {Error} If OTP invalid/expired or validation fails
 */
export async function resetPasswordWithOtp(email, otp, newPassword) {
  const row = await PasswordResetOtp.findOne({
    where: { email: email.toLowerCase().trim() },
  });
  if (!row) {
    throw new Error('Invalid or expired OTP. Please request a new one.');
  }
  if (new Date() > new Date(row.expiresAt)) {
    await row.destroy();
    throw new Error('OTP has expired. Please request a new one.');
  }
  if (row.otp !== String(otp).trim()) {
    throw new Error('Invalid OTP.');
  }
  const user = await getUserByEmail(email, false);
  if (!user || user.role !== UserRoles.PATIENT) {
    throw new Error('Invalid request');
  }
  if (newPassword.length < 8) {
    throw new Error('Password must be at least 8 characters long');
  }
  await updateUserPassword(user.id, newPassword);
  await row.destroy();
}
