import { getSequelize } from '../config/database.js';
import AppointmentRequest, {
  AppointmentRequestStatus,
  AppointmentRequestServiceTypes,
} from '../models/AppointmentRequest.js';
import Appointment, { AppointmentStatus } from '../models/Appointment.js';
import UserPlan, { UserPlanStatus } from '../models/UserPlan.js';
import Plan, { ServiceTypes as PlanServiceTypes } from '../models/Plan.js';
import Doctor from '../models/Doctor.js';
import User, { UserRoles } from '../models/User.js';
import FamilyMember from '../models/FamilyMember.js';
import { generateUuid } from '../utils/uuid.util.js';
import { sendAppointmentConfirmation } from './mail.service.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { Op } from 'sequelize';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load country timezone mapping
let countryTimezones = {};
try {
  const countryTimezonesPath = path.join(__dirname, '../data/country-timezones.json');
  countryTimezones = JSON.parse(fs.readFileSync(countryTimezonesPath, 'utf8'));
} catch (error) {
  console.error('Failed to load country-timezones.json:', error.message);
}

/**
 * Appointment Service
 * Contains all business logic for:
 * - creating appointment requests as a patient
 * - listing patient requests
 * - admin review & doctor assignment
 * - doctor appointments listing
 */

const sequelize = getSequelize();

/**
 * Get active user plan with plan details.
 * Reads from user_plans and plans.
 */
async function getActivePlanWithDetails(userId) {
  const userPlan = await UserPlan.findOne({
    where: { userId, status: UserPlanStatus.ACTIVE },
    order: [['endDate', 'DESC']],
  });

  if (!userPlan) return null;

  const plan = await Plan.findByPk(userPlan.planId);
  if (!plan) return null;

  const upJson = userPlan.toJSON();
  let planJson = plan.toJSON();

  if (typeof planJson.services === 'string') {
    planJson.services = JSON.parse(planJson.services);
  }

  // Fetch visit usage for this patient
  const usage = await getVisitUsage(userId);

  return {
    ...upJson,
    plan: planJson,
    visitUsage: usage,
  };
}

/**
 * Validate that a given service type is allowed by the plan.
 */
function ensureServiceAllowed(plan, requestedServiceType) {
  const services = Array.isArray(plan.services) ? plan.services : [];
  const normalized = services.map((s) => String(s).toUpperCase());

  if (requestedServiceType === AppointmentRequestServiceTypes.TELEHEALTH) {
    if (!normalized.includes(PlanServiceTypes.TELEHEALTH)) {
      throw Object.assign(new Error('Telehealth service is not included in active plan'), { status: 403 });
    }
  } else if (requestedServiceType === AppointmentRequestServiceTypes.EMERGENCY) {
    if (!normalized.includes(PlanServiceTypes.EMERGENCY)) {
      throw Object.assign(new Error('Emergency service is not included in active plan'), { status: 403 });
    }
  } else {
    throw Object.assign(new Error('Invalid service type'), { status: 400 });
  }
}

/**
 * Helper to parse plan features and extract visit limits.
 */
export function parsePlanVisits(features) {
  const limits = { telehealthLimit: 0, inPersonLimit: 0 };
  if (!Array.isArray(features)) return limits;

  features.forEach((feature) => {
    const text = feature.toLowerCase();
    
    if (text.includes('telehealth')) {
      if (text.includes('unlimited')) {
        limits.telehealthLimit = Infinity;
      } else {
        const match = text.match(/(\d+)/);
        if (match) limits.telehealthLimit = parseInt(match[1], 10);
      }
    }
    
    if (text.includes('in-person') || text.includes('emergency')) {
      if (text.includes('unlimited')) {
        limits.inPersonLimit = Infinity;
      } else {
        const match = text.match(/(\d+)/);
        if (match) limits.inPersonLimit = parseInt(match[1], 10);
      }
    }
  });

  return limits;
}

/**
 * Calculate visit usage for a patient under their active plan.
 */
export async function getVisitUsage(userId) {
  const userPlan = await UserPlan.findOne({
    where: { userId, status: UserPlanStatus.ACTIVE },
    order: [['endDate', 'DESC']],
  });
  if (!userPlan) return null;

  const plan = await Plan.findByPk(userPlan.planId);
  if (!plan) return null;

  let features = plan.features;
  if (typeof features === 'string') {
    try { features = JSON.parse(features); } catch (e) { features = []; }
  }

  const limits = parsePlanVisits(features);

  const appointments = await Appointment.findAll({
    where: {
      patientId: userId,
      status: { [Op.ne]: 'CANCELLED' },
      createdAt: {
        [Op.between]: [userPlan.startDate, userPlan.endDate]
      }
    }
  });

  const used = { telehealthUsed: 0, inPersonUsed: 0 };
  appointments.forEach((apt) => {
    if (apt.serviceType === 'TELEHEALTH') used.telehealthUsed++;
    if (apt.serviceType === 'EMERGENCY') used.inPersonUsed++;
  });

  return {
    planName: plan.name,
    telehealth: { 
      limit: limits.telehealthLimit, 
      used: used.telehealthUsed, 
      remaining: limits.telehealthLimit === Infinity ? Infinity : Math.max(0, limits.telehealthLimit - used.telehealthUsed) 
    },
    inPerson: { 
      limit: limits.inPersonLimit, 
      used: used.inPersonUsed, 
      remaining: limits.inPersonLimit === Infinity ? Infinity : Math.max(0, limits.inPersonLimit - used.inPersonUsed) 
    }
  };
}

/**
 * Create appointment request for a patient.
 * - Ensures ACTIVE plan exists.
 * - Ensures requested service is allowed by plan.
 * - Stores plan_id from user_plans, not from frontend.
 */
export async function createAppointmentRequestForPatient(patientId, payload) {
  const {
    country,
    state,
    city,
    age,
    gender,
    emergencyContact,
    serviceType,
    notes,
    allergies,
    familyMemberId,
    appointmentDate,
  } = payload;

  if (!country || !state || !city || !age || !gender || !serviceType) {
    throw Object.assign(new Error('Missing required fields'), { status: 400 });
  }

  const activePlan = await getActivePlanWithDetails(patientId);
  if (!activePlan) {
    throw Object.assign(new Error('No active plan found for patient'), { status: 403 });
  }

  ensureServiceAllowed(activePlan.plan, String(serviceType).toUpperCase());

  const requestUuid = generateUuid();

  const request = await AppointmentRequest.create({
    requestUuid,
    patientId,
    planId: activePlan.planId,
    country,
    state,
    city,
    age,
    gender,
    emergencyContact: emergencyContact || null,
    serviceType: String(serviceType).toUpperCase(),
    notes: notes || null,
    allergies: allergies || null,
    familyMemberId: familyMemberId || null,
    preferredDate: appointmentDate ? new Date(appointmentDate) : null,
    timezone: payload.timezone || countryTimezones[country] || countryTimezones[country.trim()] || null,
    status: AppointmentRequestStatus.PENDING,
  });

  return request.toJSON();
}

/**
 * Get appointment requests for a specific patient.
 * For ASSIGNED requests, includes appointmentUuid and assignedDoctor so the patient sees when a doctor was assigned.
 */
export async function getAppointmentRequestsForPatient(patientId) {
  const requests = await AppointmentRequest.findAll({
    where: { patientId },
    order: [['created_at', 'DESC']],
    include: [
      { model: FamilyMember, as: 'familyMember', attributes: ['id', 'firstName', 'lastName', 'relationship'] }
    ]
  });

  const list = requests.map((r) => r.toJSON());
  const assignedIds = list.filter((r) => r.status === AppointmentRequestStatus.ASSIGNED).map((r) => r.id);
  if (assignedIds.length === 0) {
    return list;
  }

  const appointments = await Appointment.findAll({
    where: { requestId: assignedIds },
    include: [
      {
        model: Doctor,
        as: 'doctor',
        required: true,
        attributes: ['specialization', 'phone'],
        include: [{ model: User, attributes: ['firstName', 'lastName', 'email'] }],
      },
    ],
  });
  const requestIdToInfo = {};
  for (const a of appointments) {
    const doc = a.doctor;
    const user = doc?.User || doc?.user;
    const name = user ? `${user.firstName || ''} ${user.lastName || ''}`.trim() : 'Doctor';
    requestIdToInfo[a.requestId] = {
      appointmentUuid: a.appointmentUuid,
      doctorName: name,
      specialization: doc?.specialization || null,
      email: user?.email || null,
      phone: doc?.phone || null,
    };
  }

  return list.map((r) => {
    const out = { ...r };
    if (r.status === AppointmentRequestStatus.ASSIGNED && requestIdToInfo[r.id]) {
      const info = requestIdToInfo[r.id];
      out.appointmentUuid = info.appointmentUuid;
      out.assignedDoctor = {
        name: info.doctorName,
        specialization: info.specialization,
        email: info.email,
        phone: info.phone,
      };
    }
    return out;
  });
}

/**
 * Admin: list all appointment requests (optionally filter by status).
 * For ASSIGNED requests, includes assigned doctor name via appointments table.
 */
export async function getAllAppointmentRequests({ status } = {}) {
  const where = {};
  if (status) {
    where.status = status;
  }

  const requests = await AppointmentRequest.findAll({
    where,
    attributes: [
      'id',
      'requestUuid',
      'patientId',
      'planId',
      'country',
      'state',
      'city',
      'timezone',
      'age',
      'gender',
      'emergencyContact',
      'serviceType',
      'notes',
      'status',
      'preferredDate',
      'allergies',
      'createdAt',
      'updatedAt',
    ],
    order: [['createdAt', 'DESC']],
    include: [
      { model: User, as: 'patient', attributes: ['id', 'firstName', 'lastName', 'email'] },
      { model: Plan, as: 'plan', attributes: ['id', 'planId', 'name', 'services'] },
      { model: FamilyMember, as: 'familyMember', attributes: ['id', 'firstName', 'lastName', 'relationship'] },
    ],
  });

  const list = requests.map((r) => {
    const j = r.toJSON();
    // Fetch visit usage for this patient (async in map is slow but for now keeping it simple)
    // In production, we'd optimize this with a single query or cache.
    return {
      ...j,
      visitUsage: null, // Will be populated in the next step
      patientDetails: {
        age: j.age,
        gender: j.gender,
        emergencyContact: j.emergencyContact,
        notes: j.notes,
        allergies: j.allergies,
        country: j.country,
        state: j.state,
        city: j.city,
        timezone: j.timezone,
      }
    };
  });

  // Populate visitUsage for each row (parallelizing)
  const listWithUsage = await Promise.all(list.map(async (item) => {
    try {
      item.visitUsage = await getVisitUsage(item.patientId);
    } catch (err) {
      console.error(`Failed to fetch visit usage for patient ${item.patientId}:`, err.message);
    }
    return item;
  }));

  const assignedIds = listWithUsage.filter((r) => r.status === AppointmentRequestStatus.ASSIGNED).map((r) => r.id);
  if (assignedIds.length === 0) {
    return listWithUsage;
  }

  const appointments = await Appointment.findAll({
    where: { requestId: assignedIds },
    attributes: ['id', 'requestId', 'patientId', 'doctorId', 'appointmentUuid', 'appointmentDate', 'serviceType', 'status', 'createdAt'],
    include: [
      { model: Doctor, as: 'doctor', required: true, include: [{ model: User, attributes: ['firstName', 'lastName'] }] },
    ],
  });
  const requestIdToDoctorName = {};
  for (const a of appointments) {
    const doc = a.doctor;
    const user = doc?.User || doc?.user;
    const name = user ? `${user.firstName || ''} ${user.lastName || ''}`.trim() : 'Doctor';
    requestIdToDoctorName[a.requestId] = name;
  }

  return listWithUsage.map((r) => {
    const out = { ...r };
    if (r.status === AppointmentRequestStatus.ASSIGNED && requestIdToDoctorName[r.id]) {
      out.assignedDoctor = { name: requestIdToDoctorName[r.id] };
    }
    return out;
  });
}

/**
 * Admin: assign doctor to a request and create appointment in a transaction.
 */
export async function assignDoctorToRequest({ requestUuid, doctorUuid, appointmentDate }) {
  if (!requestUuid || !doctorUuid) {
    throw Object.assign(new Error('requestUuid and doctorUuid are required'), { status: 400 });
  }

  const t = await sequelize.transaction();

  try {
    const request = await AppointmentRequest.findOne({
      where: { requestUuid },
      transaction: t,
      lock: t.LOCK.UPDATE,
    });

    if (!request) {
      throw Object.assign(new Error('Request not found'), { status: 404 });
    }

    if (request.status !== AppointmentRequestStatus.PENDING) {
      throw Object.assign(new Error('Only PENDING requests can be assigned'), { status: 400 });
    }

    // Find doctor by doctor_uuid and ensure its User is DOCTOR
    const doctor = await Doctor.findOne({
      where: { doctorUuid: doctorUuid },
      transaction: t,
      lock: t.LOCK.UPDATE,
    });
    if (!doctor) {
      throw Object.assign(new Error('Doctor not found'), { status: 404 });
    }

    const doctorUser = await User.findByPk(doctor.userId, { transaction: t });
    if (!doctorUser || doctorUser.role !== UserRoles.DOCTOR) {
      throw Object.assign(new Error('Linked user for doctor is invalid'), { status: 400 });
    }

    const appointmentUuid = generateUuid();

    const appointment = await Appointment.create({
      appointmentUuid,
      requestId: request.id,
      patientId: request.patientId,
      doctorId: doctor.id,
      serviceType: request.serviceType,
      timezone: request.timezone,
      appointmentDate: appointmentDate ? new Date(appointmentDate) : (request.preferredDate || null),
      status: AppointmentStatus.SCHEDULED,
    }, { transaction: t });

    await request.update(
      { status: AppointmentRequestStatus.ASSIGNED },
      { transaction: t },
    );

    await t.commit();

    // Send appointment confirmation email to patient (non-blocking)
    const patientUser = await User.findByPk(request.patientId, {
      attributes: ['email', 'firstName'],
    });
    if (patientUser) {
      const doctorName = `${doctorUser.firstName} ${doctorUser.lastName}`.trim() || 'Your doctor';
      sendAppointmentConfirmation({
        patientEmail: patientUser.email,
        patientFirstName: patientUser.firstName,
        doctorName,
        serviceType: request.serviceType,
        appointmentDate: appointment.appointmentDate,
        appointmentUuid,
      }).catch((err) => console.error('Appointment confirmation email failed:', err.message));
    }

    return appointment.toJSON();
  } catch (err) {
    await t.rollback();
    throw err;
  }
}

/**
 * Admin: update appointment request status (PENDING, ASSIGNED, CANCELLED).
 */
export async function updateRequestStatus({ requestUuid, status }) {
  const allowed = [AppointmentRequestStatus.PENDING, AppointmentRequestStatus.ASSIGNED, AppointmentRequestStatus.CANCELLED];
  if (!requestUuid || !status || !allowed.includes(status)) {
    throw Object.assign(new Error('requestUuid and status (PENDING, ASSIGNED, CANCELLED) are required'), { status: 400 });
  }

  const request = await AppointmentRequest.findOne({ where: { requestUuid } });
  if (!request) {
    throw Object.assign(new Error('Request not found'), { status: 404 });
  }

  await request.update({ status });
  return request.toJSON();
}

/**
 * Doctor: get appointments assigned to the current doctor.
 */
export async function getAppointmentsForDoctor(doctorUserId) {
  // Find doctor row for this user
  const doctor = await Doctor.findOne({ where: { userId: doctorUserId } });
  if (!doctor) return [];

  const appointments = await Appointment.findAll({
    where: { doctorId: doctor.id },
    order: [['appointmentDate', 'DESC']],
    include: [
      { 
        model: AppointmentRequest, 
        as: 'request',
        include: [{ model: FamilyMember, as: 'familyMember', attributes: ['firstName', 'lastName', 'relationship'] }]
      },
      { model: User, as: 'patient', attributes: ['id', 'firstName', 'lastName', 'email'] },
    ],
  });

  return appointments.map((a) => {
    const j = a.toJSON();
    return {
      ...j,
      doctorTimezone: doctor.timezone,
    };
  });
}

/**
 * Admin: get all appointments with patient, doctor, and request details.
 */
export async function getAllAppointmentsForAdmin() {
  const appointments = await Appointment.findAll({
    order: [['createdAt', 'DESC']],
    include: [
      { 
        model: AppointmentRequest, 
        as: 'request', 
        attributes: ['requestUuid', 'country', 'state', 'city', 'timezone', 'preferredDate', 'serviceType', 'status'],
        include: [{ model: FamilyMember, as: 'familyMember', attributes: ['firstName', 'lastName'] }]
      },
      { model: User, as: 'patient', attributes: ['id', 'firstName', 'lastName', 'email'] },
      { model: Doctor, as: 'doctor', include: [{ model: User, attributes: ['firstName', 'lastName', 'email'] }] },
    ],
  });

  return appointments.map((a) => {
    const j = a.toJSON();
    const doctorUser = j.doctor?.User || j.doctor?.user;
    return {
      appointmentUuid: j.appointmentUuid,
      status: j.status,
      appointmentDate: j.appointmentDate,
      serviceType: j.serviceType,
      timezone: j.timezone,
      createdAt: j.createdAt ?? j.created_at,
      request: j.request ? { 
        requestUuid: j.request.requestUuid, 
        country: j.request.country, 
        state: j.request.state, 
        city: j.request.city, 
        timezone: j.request.timezone,
        serviceType: j.request.serviceType,
        familyMember: j.request.familyMember
      } : null,
      patient: j.patient ? { id: j.patient.id, firstName: j.patient.firstName, lastName: j.patient.lastName, email: j.patient.email } : null,
      doctor: j.doctor ? { name: doctorUser ? `${doctorUser.firstName || ''} ${doctorUser.lastName || ''}`.trim() : 'Doctor', email: doctorUser?.email, timezone: j.doctor.timezone } : null,
    };
  });
}

