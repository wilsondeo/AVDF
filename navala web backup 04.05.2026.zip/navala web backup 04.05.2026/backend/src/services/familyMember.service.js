import FamilyMember from '../models/FamilyMember.js';
import UserPlan from '../models/UserPlan.js';
import Plan from '../models/Plan.js';
import { UserPlanStatus } from '../models/UserPlan.js';

/**
 * Get max number of family member slots allowed for the user based on their active plan.
 * Individual (maxPersons 1) => 0, Family of 2 (maxPersons 2) => 1, Family of 3-4 (maxPersons 3 or 4) => 2 or 3.
 * @param {number} userId
 * @returns {Promise<number>} Max family members allowed (0, 1, or up to 3)
 */
export async function getMaxFamilySlots(userId) {
  const active = await UserPlan.findOne({
    where: { userId, status: UserPlanStatus.ACTIVE },
    include: [{ model: Plan, attributes: ['maxPersons'] }],
    order: [['endDate', 'DESC']],
  });
  if (!active) return 0;
  const plan = active.Plan || active.plan;
  const maxPersons = plan?.maxPersons != null ? parseInt(plan.maxPersons, 10) : 1;
  return Math.max(0, maxPersons - 1); // subtract account holder
}

/**
 * List family members for a user.
 * @param {number} userId
 * @returns {Promise<Array>}
 */
export async function listFamilyMembers(userId) {
  const list = await FamilyMember.findAll({
    where: { userId },
    order: [['createdAt', 'ASC']],
  });
  return list.map((m) => m.toJSON());
}

/**
 * Create a family member. Enforces slot limit from plan.
 * @param {number} userId
 * @param {{ firstName: string, lastName: string, dateOfBirth?: string, gender?: string, relationship?: string }} data
 * @returns {Promise<Object>}
 */
export async function createFamilyMember(userId, data) {
  const maxSlots = await getMaxFamilySlots(userId);
  if (maxSlots <= 0) {
    throw new Error('Your plan does not include family members. Upgrade to a family plan to add members.');
  }
  const current = await FamilyMember.count({ where: { userId } });
  if (current >= maxSlots) {
    throw new Error(`You can add up to ${maxSlots} family member(s) on your current plan.`);
  }
  const member = await FamilyMember.create({
    userId,
    firstName: (data.firstName || '').trim(),
    lastName: (data.lastName || '').trim(),
    dateOfBirth: data.dateOfBirth || null,
    gender: data.gender || null,
    relationship: data.relationship || null,
  });
  return member.toJSON();
}

/**
 * Update a family member. Only the owner can update.
 * @param {number} userId
 * @param {number} memberId
 * @param {{ firstName?: string, lastName?: string, dateOfBirth?: string, gender?: string, relationship?: string }} data
 * @returns {Promise<Object|null>}
 */
export async function updateFamilyMember(userId, memberId, data) {
  const member = await FamilyMember.findOne({ where: { id: memberId, userId } });
  if (!member) return null;
  const updates = {};
  if (data.firstName !== undefined) updates.firstName = (data.firstName || '').trim();
  if (data.lastName !== undefined) updates.lastName = (data.lastName || '').trim();
  if (data.dateOfBirth !== undefined) updates.dateOfBirth = data.dateOfBirth || null;
  if (data.gender !== undefined) updates.gender = data.gender || null;
  if (data.relationship !== undefined) updates.relationship = data.relationship || null;
  if (Object.keys(updates).length > 0) {
    await member.update(updates);
  }
  return member.toJSON();
}

/**
 * Delete a family member. Only the owner can delete.
 * @param {number} userId
 * @param {number} memberId
 * @returns {Promise<boolean>}
 */
export async function deleteFamilyMember(userId, memberId) {
  const deleted = await FamilyMember.destroy({
    where: { id: memberId, userId },
  });
  return deleted > 0;
}
