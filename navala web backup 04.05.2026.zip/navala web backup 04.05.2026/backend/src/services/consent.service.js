import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Get consent sections from JSON file
 * @returns {Promise<Array>} Array of consent sections
 */
export async function getConsentSections() {
  try {
    const filePath = path.join(__dirname, '../data/consent.json');
    const data = await fs.readFile(filePath, 'utf8');
    const consentData = JSON.parse(data);
    
    // The data structure in consent.json is { success: true, data: { sections: [...] } }
    return consentData.data.sections;
  } catch (error) {
    console.error('Error in getConsentSections service:', error);
    throw new Error('Failed to load consent content from data source');
  }
}
