import { Op } from 'sequelize';
import { env } from '../config/env.js';
import { getSequelize } from '../config/database.js';
import { getStripeClient } from '../config/stripe.js';
import { getActivePlanWindow } from '../config/planWindow.js';
import Plan from '../models/Plan.js';
import Payment, { PaymentStatus, PaymentType } from '../models/Payment.js';
import UserPlan, { UserPlanStatus } from '../models/UserPlan.js';
import PlanUpgrade from '../models/PlanUpgrade.js';
import Appointment from '../models/Appointment.js';
import User from '../models/User.js';

/**
 * Payment Service
 * - Contains all Stripe + DB logic
 * - Trusts ONLY Stripe webhook for success
 */

function toCents(amount) {
  const n = typeof amount === 'string' ? parseFloat(amount) : Number(amount);
  if (!Number.isFinite(n) || n < 0) throw new Error('Invalid plan price');
  return Math.round(n * 100);
}


export async function getActiveUserPlan(userId, transaction) {
  const where = { userId, status: UserPlanStatus.ACTIVE };
  const opts = { where, order: [['endDate', 'DESC']] };
  if (transaction) opts.transaction = transaction;

  const active = await UserPlan.findOne(opts);
  return active ? active.toJSON() : null;
}

export async function createPaymentIntentForPlan({ userId, planBusinessId, taxAmount = 0 }) {
  const plan = await Plan.findOne({ where: { planId: planBusinessId, isActive: true } });
  if (!plan) throw new Error('Plan not found or inactive');

  const planJson = plan.toJSON();
  const basePriceCents = toCents(planJson.price);
  const taxCents = toCents(taxAmount);
  const totalNewPriceCents = basePriceCents + taxCents;
  const currency = env.STRIPE_CURRENCY;

  const existingActive = await UserPlan.findOne({ where: { userId, status: UserPlanStatus.ACTIVE } });
  const type = existingActive ? PaymentType.UPGRADE : PaymentType.PURCHASE;

  let amount = totalNewPriceCents;
  if (type === PaymentType.UPGRADE) {
    const oldPlan = await Plan.findByPk(existingActive.planId);
    if (!oldPlan) throw new Error('Current plan not found');
    const oldPlanJson = oldPlan.toJSON();
    const oldPriceCents = toCents(oldPlanJson.price);
    // For upgrades, we usually just charge the difference in plan prices.
    // However, if tax is also involved, we add it.
    const differenceCents = basePriceCents - oldPriceCents;
    if (differenceCents <= 0) {
      throw new Error('Select a higher-tier plan to upgrade. Your current plan is the same price or higher.');
    }
    // New total for upgrade = difference + tax
    amount = differenceCents + taxCents;
    
    // Stripe minimum for USD is 50 cents
    amount = Math.max(amount, 50);
  }

  const stripe = getStripeClient();

  const paymentIntent = await stripe.paymentIntents.create({
    amount,
    currency,
    automatic_payment_methods: { enabled: true },
    metadata: {
      userId: String(userId),
      planBusinessId: String(planBusinessId),
      paymentType: type,
      taxCents: String(taxCents),
    },
  });

  await Payment.create({
    userId,
    planId: planJson.id,
    stripePaymentIntentId: paymentIntent.id,
    amount,
    currency,
    status: PaymentStatus.PENDING,
    type,
    createdAt: new Date(),
  });

  return {
    clientSecret: paymentIntent.client_secret,
    paymentIntentId: paymentIntent.id,
    type,
    amountChargedCents: amount,
  };
}

export async function markPaymentFailed(stripePaymentIntentId) {
  await Payment.update(
    { status: PaymentStatus.FAILED },
    { where: { stripePaymentIntentId } }
  );
}

/**
 * Handle Stripe payment_intent.succeeded
 * - Verify payment exists and is pending
 * - Update payment to SUCCESS
 * - Activate/upgrade user plan
 * - Transactional consistency is mandatory
 */
export async function handlePaymentIntentSucceeded({ stripePaymentIntentId }) {
  const sequelize = getSequelize();

  return sequelize.transaction(async (t) => {
    const payment = await Payment.findOne({
      where: { stripePaymentIntentId },
      transaction: t,
      lock: t.LOCK.UPDATE,
    });

    if (!payment) {
      // If you want, you can create a record here, but requirement says we save PENDING on intent creation
      throw new Error('Payment record not found for this PaymentIntent');
    }

    if (payment.status === PaymentStatus.SUCCESS) {
      // Idempotency: webhook can be delivered multiple times
      return { ok: true, alreadyProcessed: true };
    }

    // Update payment status
    await payment.update({ status: PaymentStatus.SUCCESS }, { transaction: t });

    // Fetch plan (read-only)
    const plan = await Plan.findByPk(payment.planId, { transaction: t, lock: t.LOCK.UPDATE });
    if (!plan) throw new Error('Plan not found for payment');

    const planJson = plan.toJSON();
    const now = new Date();
    const { startDate: windowStart, endDate } = getActivePlanWindow();

    // Enforce only ONE ACTIVE plan
    const activePlans = await UserPlan.findAll({
      where: { userId: payment.userId, status: UserPlanStatus.ACTIVE },
      transaction: t,
      lock: t.LOCK.UPDATE,
    });

    if (payment.type === PaymentType.PURCHASE) {
      if (activePlans.length > 0) {
        // Defensive: if an active exists, we still expire it to maintain invariant
        await UserPlan.update(
          { status: UserPlanStatus.EXPIRED, endDate: now },
          { where: { userId: payment.userId, status: UserPlanStatus.ACTIVE }, transaction: t }
        );
      }
    }

    if (payment.type === PaymentType.UPGRADE) {
      // Expire existing active plan(s) immediately
      if (activePlans.length > 0) {
        await UserPlan.update(
          { status: UserPlanStatus.EXPIRED, endDate: now },
          { where: { userId: payment.userId, status: UserPlanStatus.ACTIVE }, transaction: t }
        );
      }
    }

    // Create new ACTIVE plan record (fixed window June 9 – July 20, no per-plan validity)
    await UserPlan.create({
      userId: payment.userId,
      planId: payment.planId,
      startDate: windowStart,
      endDate,
      status: UserPlanStatus.ACTIVE,
    }, { transaction: t });

    // Record upgrade in plan_upgrades (storage only, not for display)
    if (payment.type === PaymentType.UPGRADE && activePlans.length > 0) {
      const oldPlanId = activePlans[0].planId;
      const oldPlan = await Plan.findByPk(oldPlanId, { transaction: t });
      const oldPlanJson = oldPlan ? oldPlan.toJSON() : null;
      const oldPriceCents = oldPlanJson ? toCents(oldPlanJson.price) : 0;
      const newPriceCents = toCents(planJson.price);
      await PlanUpgrade.create({
        userId: payment.userId,
        oldPlanId,
        newPlanId: payment.planId,
        oldPriceCents,
        newPriceCents,
        amountChargedCents: payment.amount,
        paymentId: payment.id,
        createdAt: now,
      }, { transaction: t });
    }

    return { ok: true, alreadyProcessed: false };
  });
}

export async function getUserActivePlanWithDetails(userId) {
  const active = await UserPlan.findOne({
    where: { userId, status: UserPlanStatus.ACTIVE },
    include: [{ model: Plan }],
    order: [['endDate', 'DESC']],
  });

  if (!active) return null;

  const json = active.toJSON();
  // Normalize embedded plan JSON/DECIMAL fields if needed
  const plan = json.Plan || json.plan || null;
  if (plan) {
    if (typeof plan.services === 'string') {
      plan.services = JSON.parse(plan.services);
    }
    if (typeof plan.features === 'string') {
      plan.features = JSON.parse(plan.features);
    }
    if (typeof plan.price === 'string') {
      plan.price = parseFloat(plan.price);
    }
  }
  // All plans use fixed window June 9 – July 20 (no per-plan validity); always return window dates
  const { startDate: windowStart, endDate: windowEnd } = getActivePlanWindow();
  return {
    id: json.id,
    userId: json.userId,
    planId: json.planId,
    startDate: windowStart,
    endDate: windowEnd,
    status: json.status,
    plan,
  };
}

export async function getUserPayments(userId, { limit = 20, offset = 0 } = {}) {
  const payments = await Payment.findAll({
    where: { userId },
    order: [['createdAt', 'DESC']],
    limit,
    offset,
  });
  return payments.map((p) => p.toJSON());
}

export async function getAllPayments({ limit = 20, offset = 0, search = '', status = '', liveOnly = true, planId = 'all', startDate = null, endDate = null } = {}) {
  const where = {};

  if (status && status !== 'all') {
    where.status = status.toUpperCase();
  }

  if (search) {
    where[Op.or] = [
      { stripePaymentIntentId: { [Op.like]: `%${search}%` } },
    ];
  }

  // Live only filter (exclude pi_test_ prefix)
  if (liveOnly) {
    where.stripePaymentIntentId = { [Op.notLike]: 'pi_test_%' };
  }

  if (planId && planId !== 'all') {
    where.planId = planId;
  }

  if (startDate) {
    where.createdAt = { [Op.gte]: new Date(startDate) };
  }

  if (endDate) {
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);
    where.createdAt = { ...where.createdAt, [Op.lte]: end };
  }

  const { count, rows } = await Payment.findAndCountAll({
    where,
    include: [
      {
        model: getSequelize().models.User,
        attributes: ['id', 'firstName', 'lastName', 'email', 'userUuid']
      },
      {
        model: Plan,
        attributes: ['id', 'name']
      }
    ],
    order: [['createdAt', 'DESC']],
    limit,
    offset,
  });

  return {
    payments: rows.map(p => p.toJSON()),
    count,
  };
}

export async function getPaymentStats({ liveOnly = true, planId = 'all', startDate = null, endDate = null } = {}) {
  const sequelize = getSequelize();
  const whereBase = { status: PaymentStatus.SUCCESS };

  if (liveOnly) {
    whereBase.stripePaymentIntentId = { [Op.notLike]: 'pi_test_%' };
  }

  if (planId && planId !== 'all') {
    whereBase.planId = planId;
  }

  if (startDate) {
    whereBase.createdAt = { [Op.gte]: new Date(startDate) };
  }

  if (endDate) {
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);
    whereBase.createdAt = { ...whereBase.createdAt, [Op.lte]: end };
  }

  // Total Revenue (only SUCCESS and filtered)
  const totalRevenue = await Payment.sum('amount', {
    where: whereBase
  }) || 0;

  // This Month Revenue
  const startOfMonth = new Date();
  startOfMonth.setDate(1);
  startOfMonth.setHours(0, 0, 0, 0);

  const thisMonthRevenue = await Payment.sum('amount', {
    where: {
      ...whereBase,
      createdAt: { [Op.gte]: startOfMonth }
    }
  }) || 0;

  // Refunded Amount (placeholder)
  const refundedAmount = 0;

  // Total Successful Transactions count (User specifically requested only SUCCESS in stats)
  const totalTransactions = await Payment.count({
    where: whereBase
  });

  return {
    totalRevenue: totalRevenue / 100, 
    thisMonthRevenue: thisMonthRevenue / 100,
    refundedAmount: refundedAmount / 100,
    totalTransactions,
  };
}

export async function getAnalyticsData() {
  const sequelize = getSequelize();
  const now = new Date();
  
  // 1. Revenue Trend (last 6 months)
  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(now.getMonth() - 5);
  sixMonthsAgo.setDate(1);
  sixMonthsAgo.setHours(0, 0, 0, 0);

  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  
  // Create a map of the last 6 months with 0 revenue as default
  const trendDataMap = {};
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(now.getMonth() - i);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    trendDataMap[key] = {
      month: monthNames[d.getMonth()],
      revenue: 0
    };
  }

  const revenueByMonth = await Payment.findAll({
    where: {
      status: PaymentStatus.SUCCESS,
      createdAt: { [Op.gte]: sixMonthsAgo },
      stripePaymentIntentId: { [Op.notLike]: 'pi_test_%' }
    },
    attributes: [
      [sequelize.fn('date_format', sequelize.col('created_at'), '%Y-%m'), 'month'],
      [sequelize.fn('sum', sequelize.col('amount')), 'revenue']
    ],
    group: ['month']
  });

  revenueByMonth.forEach(r => {
    const key = r.get('month');
    if (trendDataMap[key]) {
      trendDataMap[key].revenue = parseFloat(r.get('revenue')) / 100;
    }
  });

  const revenueTrend = Object.values(trendDataMap);

  // 2. Service Distribution (Telehealth vs Emergency)
  const serviceDistributionRows = await Appointment.findAll({
    attributes: [
      'serviceType',
      [sequelize.fn('count', sequelize.col('id')), 'count']
    ],
    group: ['serviceType']
  });

  const serviceDistribution = serviceDistributionRows.map(r => ({
    name: r.serviceType === 'TELEHEALTH' ? 'Telehealth' : 'Emergency',
    value: parseInt(r.get('count'), 10)
  }));

  // 3. Appointment Trend (Last 4 weeks)
  const fourWeeksAgo = new Date();
  fourWeeksAgo.setDate(now.getDate() - 28);
  
  const appointmentTrendRows = await Appointment.findAll({
    where: {
      createdAt: { [Op.gte]: fourWeeksAgo }
    },
    attributes: [
      [sequelize.fn('week', sequelize.col('created_at')), 'weekNum'],
      'status',
      [sequelize.fn('count', sequelize.col('id')), 'count']
    ],
    group: ['weekNum', 'status']
  });

  // Group by week
  const trendMap = {};
  appointmentTrendRows.forEach(r => {
    const week = `Week ${r.get('weekNum')}`;
    if (!trendMap[week]) trendMap[week] = { week, completed: 0, pending: 0 };
    if (r.status === 'COMPLETED') trendMap[week].completed += parseInt(r.get('count'), 10);
    if (r.status === 'SCHEDULED') trendMap[week].pending += parseInt(r.get('count'), 10);
  });
  
  const appointmentTrend = Object.values(trendMap).slice(-4);

  // 4. Plan Distribution
  const planDistributionRows = await UserPlan.findAll({
    where: { status: UserPlanStatus.ACTIVE },
    include: [{ model: Plan, attributes: ['name'] }],
    attributes: [
      [sequelize.fn('count', sequelize.col('UserPlan.id')), 'subscribers']
    ],
    group: ['Plan.name']
  });

  const planDistribution = planDistributionRows.map(r => ({
    name: r.Plan?.name || 'Unknown',
    subscribers: parseInt(r.get('subscribers'), 10)
  }));

  // 5. Key Metrics
  const telehealthCount = await Appointment.count({ where: { serviceType: 'TELEHEALTH' } });
  const emergencyCount = await Appointment.count({ where: { serviceType: 'EMERGENCY' } });
  const patientCount = await User.count({ where: { role: 'patient' } });
  const activeDoctors = await User.count({ where: { role: 'doctor', isActive: true } });
  const totalAppointments = await Appointment.count();

  return {
    revenueTrend,
    serviceDistribution,
    appointmentTrend,
    planDistribution,
    metrics: {
      telehealthCount,
      emergencyCount,
      patientCount,
      activeDoctors,
      totalAppointments
    }
  };
}
