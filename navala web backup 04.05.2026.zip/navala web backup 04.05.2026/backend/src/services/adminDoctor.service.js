import { getSequelize } from '../config/database.js';
import User, { UserRoles } from '../models/User.js';
import Doctor from '../models/Doctor.js';
import { generateRandomPassword } from '../utils/password.util.js';
import { generateUuid } from '../utils/uuid.util.js';
import { sendDoctorCredentials } from './mail.service.js';
import bcrypt from 'bcrypt';
import { env } from '../config/env.js';

/**
 * Admin Doctor Service
 * Handles business logic for managing doctors
 */

/**
 * Create a new doctor
 * @param {Object} data - Doctor data
 * @param {string} data.name - Full name
 * @param {string} data.email - Email address
 * @param {string} [data.password] - Optional password (auto-generated if not provided)
 * @param {string} data.phone - Phone number
 * @param {string} data.city - City
 * @param {string} data.specialization - Specialization
 * @param {number} data.yearsOfExperience - Years of experience
 * @param {boolean} [sendEmail=false] - Whether to send login email
 * @returns {Promise<Object>} Created doctor object (includes plainPassword for admin)
 */
export async function createDoctor(data, sendEmail = false) {
    const sequelize = getSequelize();
    const t = await sequelize.transaction();

    try {
        const splitName = data.name.trim().split(' ');
        const firstName = splitName[0];
        const lastName = splitName.slice(1).join(' ') || '';

        const password = (data.password && String(data.password).trim()) ? String(data.password).trim() : generateRandomPassword();

        const user = await User.create({
            email: data.email,
            password,
            firstName,
            lastName,
            role: UserRoles.DOCTOR,
            isActive: true,
        }, { transaction: t });

        const doctorUuid = generateUuid();
        const doctor = await Doctor.create({
            userId: user.id,
            doctorUuid,
            phone: data.phone,
            city: data.city,
            specialization: data.specialization,
            yearsOfExperience: data.yearsOfExperience,
            plainPassword: password,
        }, { transaction: t });

        await t.commit();

        if (sendEmail) {
            sendDoctorCredentials({
                email: user.email,
                firstName: user.firstName,
                password,
            }).catch(err => console.error(`Failed to send email to ${user.email}:`, err));
        }

        return {
            id: doctor.id,
            doctorUuid: doctor.doctorUuid,
            name: `${user.firstName} ${user.lastName}`,
            email: user.email,
            specialization: doctor.specialization,
            city: doctor.city,
            plainPassword: password,
        };
    } catch (error) {
        await t.rollback();
        if (error.name === 'SequelizeUniqueConstraintError' && error.fields?.email) {
            throw new Error(`Email ${data.email} already exists.`);
        }
        throw error;
    }
}

/**
 * List all doctors with their profiles (includes plainPassword for admin display)
 * @returns {Promise<Array<Object>>} List of doctors
 */
export async function listDoctors() {
    return await Doctor.findAll({
        include: [{
            model: User,
            attributes: ['id', 'firstName', 'lastName', 'email', 'isActive'],
        }],
        order: [['created_at', 'DESC']],
    });
}

/**
 * Get one doctor by id
 * @param {number} doctorId - Doctor id
 * @returns {Promise<Object|null>} Doctor with User or null
 */
export async function getDoctorById(doctorId) {
    const doctor = await Doctor.findByPk(doctorId, {
        include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'email', 'isActive'] }],
    });
    return doctor ? doctor.toJSON() : null;
}

/**
 * Update a doctor (profile and optionally password)
 * @param {number} doctorId - Doctor id
 * @param {Object} data - Fields to update (name, email, phone, city, specialization, yearsOfExperience, password)
 * @returns {Promise<Object>} Updated doctor
 */
export async function updateDoctor(doctorId, data) {
    const doctor = await Doctor.findByPk(doctorId, { include: [{ model: User }] });
    if (!doctor) throw new Error('Doctor not found');

    const user = doctor.User;
    if (!user) throw new Error('User not found for doctor');

    const updates = {};
    if (data.phone !== undefined) updates.phone = data.phone;
    if (data.city !== undefined) updates.city = data.city;
    if (data.specialization !== undefined) updates.specialization = data.specialization;
    if (data.yearsOfExperience !== undefined) updates.yearsOfExperience = parseInt(data.yearsOfExperience, 10) || 0;

    if (data.password !== undefined && data.password !== null && String(data.password).trim()) {
        const newPassword = String(data.password).trim();
        user.password = newPassword;
        await user.save();
        updates.plainPassword = newPassword;
    }

    if (data.name !== undefined && data.name.trim()) {
        const parts = data.name.trim().split(' ');
        user.firstName = parts[0];
        user.lastName = parts.slice(1).join(' ') || '';
        await user.save();
    }
    if (data.email !== undefined && data.email.trim()) {
        user.email = data.email.trim();
        await user.save();
    }
    if (data.isActive !== undefined) {
        user.isActive = !!data.isActive;
        await user.save();
    }

    if (Object.keys(updates).length) {
        await doctor.update(updates);
    }

    const refreshed = await Doctor.findByPk(doctorId, {
        include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'email', 'isActive'] }],
    });
    return refreshed.toJSON();
}

/**
 * Delete a doctor and their user account
 * @param {number} doctorId - Doctor id
 */
export async function deleteDoctor(doctorId) {
    const doctor = await Doctor.findByPk(doctorId);
    if (!doctor) throw new Error('Doctor not found');
    const userId = doctor.userId;
    await doctor.destroy();
    await User.destroy({ where: { id: userId } });
}

/**
 * Send credentials email to doctor using stored plain password
 * @param {number} doctorId - Doctor id
 */
export async function sendDoctorCredentialsById(doctorId) {
    const doctor = await Doctor.findByPk(doctorId, { include: [{ model: User }] });
    if (!doctor) throw new Error('Doctor not found');
    const user = doctor.User;
    if (!user) throw new Error('User not found for doctor');
    const password = doctor.plainPassword;
    if (!password) throw new Error('No password stored for this doctor. Set a password in Edit first, then send email.');
    await sendDoctorCredentials({
        email: user.email,
        firstName: user.firstName,
        password,
    });
}

/**
 * Bulk upload doctors from parsed CSV data
 * @param {Array<Object>} rows - Parsed CSV rows
 * @param {boolean} [sendEmail=false] - Whether to send emails
 * @returns {Promise<Object>} Summary of upload
 */
export async function bulkUploadDoctors(rows, sendEmail = false) {
    const results = {
        total: rows.length,
        success: 0,
        failed: 0,
        errors: [],
    };

    for (const row of rows) {
        try {
            // Validate required fields
            if (!row.name || !row.email || !row.specialization) {
                throw new Error('Missing required fields (name, email, specialization)');
            }

            await createDoctor({
                name: row.name,
                email: row.email,
                phone: row.phone,
                city: row.city,
                specialization: row.specialization,
                yearsOfExperience: parseInt(row.years_of_experience || '0', 10),
            }, sendEmail);

            results.success++;
        } catch (error) {
            results.failed++;
            results.errors.push({
                row: row._rowNumber || '?', // Row number from CSV util
                email: row.email || 'Unknown',
                message: error.message,
            });
        }
    }

    return results;
}
