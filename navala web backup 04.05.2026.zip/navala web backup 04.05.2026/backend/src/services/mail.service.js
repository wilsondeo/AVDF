import { getTransporter, getDefaultEmailOptions } from '../config/mail.js';
import { env } from '../config/env.js';

/**
 * Mail Service
 * Handles email sending with templates
 */

/**
 * Send doctor credentials email
 * @param {Object} options - Email options
 * @param {string} options.email - Doctor email
 * @param {string} options.firstName - Doctor first name
 * @param {string} options.password - Temporary password
 * @returns {Promise<Object>} Email send result
 */
export async function sendDoctorCredentials({ email, firstName, password }) {
  const transporter = getTransporter();
  const defaultOptions = getDefaultEmailOptions();
  
  const mailOptions = {
    ...defaultOptions,
    to: email,
    subject: 'Your Navala Travel Doctor Account Credentials',
    html: getDoctorCredentialsTemplate({ firstName, email, password }),
    text: getDoctorCredentialsTextTemplate({ firstName, email, password }),
  };
  
  try {
    const info = await transporter.sendMail(mailOptions);
    console.log(`✅ Doctor credentials email sent to ${email}`);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error(`❌ Failed to send email to ${email}:`, error.message);
    throw new Error('Failed to send email. Please check email configuration.');
  }
}

/**
 * Get doctor credentials email HTML template
 * @param {Object} data - Template data
 * @returns {string} HTML email template
 */
function getDoctorCredentialsTemplate({ firstName, email, password }) {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Doctor Account Credentials</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="background-color: #f4f4f4; padding: 20px; border-radius: 5px;">
        <h2 style="color: #2c3e50;">Welcome to Navala Travel Healthcare Platform</h2>
        
        <p>Dear Dr. ${firstName},</p>
        
        <p>Your doctor account has been created successfully. Please use the following credentials to log in:</p>
        
        <div style="background-color: #ffffff; padding: 15px; border-left: 4px solid #3498db; margin: 20px 0;">
          <p style="margin: 5px 0;"><strong>Email:</strong> ${email}</p>
          <p style="margin: 5px 0;"><strong>Temporary Password:</strong> <code style="background-color: #f4f4f4; padding: 2px 6px; border-radius: 3px;">${password}</code></p>
        </div>
        
        <p><strong>Important:</strong> Please change your password after your first login for security purposes.</p>
        
        <p>You can log in at: <a href="${env.BASE_URL}/doctor/login" style="color: #3498db;">${env.BASE_URL}/doctor/login</a></p>
        
        <p style="margin-top: 30px;">If you have any questions, please contact the administrator info@navalaglobal.com.</p>
        
        <p style="margin-top: 20px;">
          Best regards,<br>
          Navala Travel Team
        </p>
      </div>
    </body>
    </html>
  `;
}

/**
 * Get doctor credentials email plain text template
 * @param {Object} data - Template data
 * @returns {string} Plain text email template
 */
function getDoctorCredentialsTextTemplate({ firstName, email, password }) {
  return `
Welcome to Navala Travel Healthcare Platform

Dear Dr. ${firstName},

Your doctor account has been created successfully. Please use the following credentials to log in:

Email: ${email}
Temporary Password: ${password}

Important: Please change your password after your first login for security purposes.

You can log in at: ${env.BASE_URL}/doctor/login

If you have any questions, please contact the administrator.

Best regards,
Navala Travel Team
  `.trim();
}

/**
 * Generate a secure random password
 * @param {number} length - Password length (default: 12)
 * @returns {string} Random password
 */
export function generateTemporaryPassword(length = 12) {
  const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
  let password = '';
  
  // Ensure at least one of each type
  password += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[Math.floor(Math.random() * 26)]; // Uppercase
  password += 'abcdefghijklmnopqrstuvwxyz'[Math.floor(Math.random() * 26)]; // Lowercase
  password += '0123456789'[Math.floor(Math.random() * 10)]; // Number
  password += '!@#$%^&*'[Math.floor(Math.random() * 8)]; // Special char
  
  // Fill the rest randomly
  for (let i = password.length; i < length; i++) {
    password += charset[Math.floor(Math.random() * charset.length)];
  }
  
  // Shuffle the password
  return password.split('').sort(() => Math.random() - 0.5).join('');
}

/**
 * Send appointment confirmation email to patient after admin assigns a doctor
 * @param {Object} options
 * @param {string} options.patientEmail - Patient email
 * @param {string} options.patientFirstName - Patient first name
 * @param {string} options.doctorName - Doctor full name
 * @param {string} options.serviceType - TELEHEALTH | EMERGENCY
 * @param {string|null} options.appointmentDate - ISO date string or null
 * @param {string} options.appointmentUuid - Public appointment id
 */
export async function sendAppointmentConfirmation({
  patientEmail,
  patientFirstName,
  doctorName,
  serviceType,
  appointmentDate,
  appointmentUuid,
}) {
  const transporter = getTransporter();
  const defaultOptions = getDefaultEmailOptions();
  const serviceLabel = serviceType === 'TELEHEALTH' ? 'Telehealth Consultation' : 'Emergency Service';
  const dateStr = appointmentDate
    ? new Date(appointmentDate).toLocaleString('en-US', { dateStyle: 'full', timeStyle: 'short' })
    : 'To be confirmed';

  const mailOptions = {
    ...defaultOptions,
    to: patientEmail,
    subject: 'Appointment Confirmed – Navala Travel',
    html: `
    <!DOCTYPE html>
    <html>
    <head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Appointment Confirmed</title></head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="background-color: #f4f4f4; padding: 20px; border-radius: 5px;">
        <h2 style="color: #2c3e50;">Appointment Confirmed</h2>
        <p>Dear ${patientFirstName},</p> 
        <p>Your appointment has been confirmed. A doctor has been assigned to your request.</p>
        <div style="background-color: #ffffff; padding: 15px; border-left: 4px solid #3498db; margin: 20px 0;">
          <p style="margin: 5px 0;"><strong>Service:</strong> ${serviceLabel}</p>
          <p style="margin: 5px 0;"><strong>Doctor:</strong> ${doctorName}</p>
          <p style="margin: 5px 0;"><strong>Date & time:</strong> ${dateStr}</p>
          <p style="margin: 5px 0;"><strong>Appointment ID:</strong> <code>${appointmentUuid}</code></p> 
        </div>
        <p>You can log in to your patient dashboard to view and manage your appointments.</p>
        <p style="margin-top: 20px;">Best regards,<br>Navala Travel Team</p>
      </div>
    </body>
    </html>
    `,
    text: `Appointment Confirmed\n\nDear ${patientFirstName},\n\nYour appointment has been confirmed.\n\nService: ${serviceLabel}\nDoctor: ${doctorName}\nDate & time: ${dateStr}\nAppointment ID: ${appointmentUuid}\n\nBest regards,\nNavala Travel Team`,
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log(`✅ Appointment confirmation email sent to ${patientEmail}`);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error(`❌ Failed to send appointment confirmation to ${patientEmail}:`, error.message);
    throw new Error('Failed to send appointment confirmation email.');
  }
}

/**
 * Send password reset OTP to patient email
 * @param {string} email - Patient email
 * @param {string} otp - 6-digit OTP
 */
export async function sendPasswordResetOtp(email, otp) {
  const transporter = getTransporter();
  const defaultOptions = getDefaultEmailOptions();
  const mailOptions = {
    ...defaultOptions,
    to: email,
    subject: 'Reset your password – Navala Travel',
    html: `
    <!DOCTYPE html>
    <html>
    <head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Reset Password</title></head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="background-color: #f4f4f4; padding: 20px; border-radius: 5px;">
        <h2 style="color: #2c3e50;">Reset your password</h2>
        <p>You requested a password reset for your Navala Travel patient account.</p>
        <p>Your one-time password (OTP) is:</p>
        <div style="background-color: #ffffff; padding: 15px; border-left: 4px solid #3498db; margin: 20px 0; font-size: 24px; letter-spacing: 4px; font-weight: bold;">
          ${otp}
        </div>
        <p>This OTP is valid for 10 minutes. Do not share it with anyone.</p>
        <p>If you did not request this, please ignore this email.</p>
        <p style="margin-top: 20px;">Best regards,<br>Navala Travel Team</p>
      </div>
    </body>
    </html>
    `,
    text: `Reset your password\n\nYour OTP is: ${otp}\n\nValid for 10 minutes. Do not share.\n\nNavala Travel Team`,
  };
  try {
    const info = await transporter.sendMail(mailOptions);
    console.log(`✅ Password reset OTP sent to ${email}`);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error(`❌ Failed to send OTP to ${email}:`, error.message);
    throw new Error('Failed to send OTP email. Please try again.');
  }
}