import {
  createPlan,
  getPlanByPlanId,
  getPlanById,
  getAllPlans,
  getActivePlans,
  updatePlan,
  softDeletePlan,
  planIdExists,
} from '../models/Plan.js';
import { ServiceTypes } from '../models/Plan.js';

/**
 * Plan Service
 * Handles business logic for plans
 */

/**
 * Create a new plan
 * @param {Object} planData - Plan data
 * @returns {Promise<Object>} Created plan
 * @throws {Error} If validation fails
 */
export async function createPlanService(planData) {
  // Validate required fields
  if (!planData.name || !planData.price || !planData.validityDays) {
    throw new Error('Name, price, and validityDays are required');
  }
  
  // Validate price
  if (typeof planData.price !== 'number' || planData.price < 0) {
    throw new Error('Price must be a positive number');
  }
  
  // Validate validityDays
  if (typeof planData.validityDays !== 'number' || planData.validityDays < 1) {
    throw new Error('Validity days must be at least 1');
  }
  
  // Validate services
  if (!Array.isArray(planData.services) || planData.services.length === 0) {
    throw new Error('At least one service type is required');
  }
  
  // Validate service types
  const validServices = Object.values(ServiceTypes);
  for (const service of planData.services) {
    if (!validServices.includes(service)) {
      throw new Error(`Invalid service type: ${service}. Must be one of: ${validServices.join(', ')}`);
    }
  }
  
  // Validate features
  if (!Array.isArray(planData.features)) {
    throw new Error('Features must be an array');
  }
  
  // Create plan (planId is auto-generated)
  return createPlan({
    name: planData.name,
    price: parseFloat(planData.price),
    validityDays: parseInt(planData.validityDays, 10),
    description: planData.description || '',
    services: planData.services,
    features: planData.features || [],
    isActive: planData.isActive !== undefined ? planData.isActive : true,
    planTabName: planData.planTabName || null,
    maxPersons: planData.maxPersons != null ? parseInt(planData.maxPersons, 10) || 1 : 1,
  });
}

/**
 * Update plan
 * @param {string} planId - Plan business identifier
 * @param {Object} updates - Plan updates
 * @returns {Promise<Object>} Updated plan
 * @throws {Error} If plan not found or validation fails
 */
export async function updatePlanService(planId, updates) {
  // Check if plan exists
  const existingPlan = await getPlanByPlanId(planId, true);
  if (!existingPlan) {
    throw new Error('Plan not found');
  }
  
  // Validate price if provided
  if (updates.price !== undefined) {
    if (typeof updates.price !== 'number' || updates.price < 0) {
      throw new Error('Price must be a positive number');
    }
    updates.price = parseFloat(updates.price);
  }
  
  // Validate validityDays if provided
  if (updates.validityDays !== undefined) {
    if (typeof updates.validityDays !== 'number' || updates.validityDays < 1) {
      throw new Error('Validity days must be at least 1');
    }
    updates.validityDays = parseInt(updates.validityDays, 10);
  }
  
  // Validate services if provided
  if (updates.services !== undefined) {
    if (!Array.isArray(updates.services) || updates.services.length === 0) {
      throw new Error('At least one service type is required');
    }
    
    const validServices = Object.values(ServiceTypes);
    for (const service of updates.services) {
      if (!validServices.includes(service)) {
        throw new Error(`Invalid service type: ${service}`);
      }
    }
  }
  
  // Validate features if provided
  if (updates.features !== undefined && !Array.isArray(updates.features)) {
    throw new Error('Features must be an array');
  }

  if (updates.maxPersons !== undefined) {
    const mp = parseInt(updates.maxPersons, 10);
    if (Number.isNaN(mp) || mp < 1) {
      throw new Error('maxPersons must be a positive integer');
    }
    updates.maxPersons = mp;
  }
  
  return updatePlan(planId, updates);
}

/**
 * Delete plan (soft delete)
 * @param {string} planId - Plan business identifier
 * @returns {Promise<boolean>} True if deleted successfully
 * @throws {Error} If plan not found
 */
export async function deletePlanService(planId) {
  const plan = await getPlanByPlanId(planId, true);
  if (!plan) {
    throw new Error('Plan not found');
  }
  
  return softDeletePlan(planId);
}

/**
 * Get all plans (admin view - includes inactive)
 * @param {Object} options - Query options
 * @returns {Promise<Array>} Array of plans
 */
export async function getAllPlansService(options = {}) {
  return getAllPlans({
    includeInactive: true, // Admin can see all plans
    ...options,
  });
}

/**
 * Get active plans (public view)
 * @returns {Promise<Array>} Array of active plans
 */
export async function getActivePlansService() {
  return getActivePlans();
}

/**
 * Get plan by planId
 * @param {string} planId - Plan business identifier
 * @param {boolean} includeInactive - Include inactive plans
 * @returns {Promise<Object>} Plan object
 * @throws {Error} If plan not found
 */
export async function getPlanByPlanIdService(planId, includeInactive = false) {
  const plan = await getPlanByPlanId(planId, includeInactive);
  if (!plan) {
    throw new Error('Plan not found');
  }
  return plan;
}
