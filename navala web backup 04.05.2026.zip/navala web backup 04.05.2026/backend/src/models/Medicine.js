import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';

const sequelize = getSequelize();

const Medicine = sequelize.define('Medicine', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  name: {
    type: DataTypes.STRING(255),
    allowNull: false,
    unique: true,
  },
  category: {
    type: DataTypes.STRING(100),
    allowNull: false,
    defaultValue: 'General',
  },
  isActive: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    field: 'is_active',
  },
  createdByRecordType: {
    type: DataTypes.ENUM('DOCTOR', 'ADMIN', 'SYSTEM'),
    allowNull: false,
    defaultValue: 'SYSTEM',
    field: 'created_by_type',
  },
  createdById: {
    type: DataTypes.INTEGER,
    allowNull: true,
    field: 'created_by_id',
  },
}, {
  tableName: 'medicines',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
  underscored: true,
});

export default Medicine;
