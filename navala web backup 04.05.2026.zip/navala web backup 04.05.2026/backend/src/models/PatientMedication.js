import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';
import User from './User.js';

const sequelize = getSequelize();

export const TimeOfDay = {
  MORNING: 'morning',
  AFTERNOON: 'afternoon',
  EVENING: 'evening',
};

const PatientMedication = sequelize.define('PatientMedication', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  userId: { type: DataTypes.INTEGER, allowNull: false, field: 'user_id' },
  name: { type: DataTypes.STRING(255), allowNull: false },
  dosage: { type: DataTypes.STRING(100), allowNull: false },
  timeOfDay: {
    type: DataTypes.ENUM('morning', 'afternoon', 'evening'),
    allowNull: false,
    field: 'time_of_day',
  },
  sortOrder: { type: DataTypes.INTEGER, allowNull: true, defaultValue: 0, field: 'sort_order' },
}, {
  tableName: 'patient_medications',
  timestamps: true,
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  indexes: [{ fields: ['user_id'] }],
});

PatientMedication.belongsTo(User, { foreignKey: 'userId' });

export default PatientMedication;
