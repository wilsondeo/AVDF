import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';
import User from './User.js';

/**
 * Doctor Model
 * Stores profile information for users with DOCTOR role
 */

const sequelize = getSequelize();

const Doctor = sequelize.define('Doctor', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    doctorUuid: {
        type: DataTypes.STRING(36),
        allowNull: false,
        unique: true,
        field: 'doctor_uuid',
        comment: 'Unique public identifier for doctor profile',
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'user_id',
        references: {
            model: 'users',
            key: 'id',
        },
        unique: true, // One user can be one doctor
    },
    phone: {
        type: DataTypes.STRING(20),
        allowNull: true,
    },
    city: {
        type: DataTypes.STRING(100),
        allowNull: true,
    },
    timezone: {
        type: DataTypes.STRING(50),
        allowNull: false,
        defaultValue: 'UTC',
        comment: 'Default timezone for the doctor',
    },
    specialization: {
        type: DataTypes.STRING(100),
        allowNull: false,
    },
    yearsOfExperience: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'years_of_experience',
        defaultValue: 0,
    },
    plainPassword: {
        type: DataTypes.STRING(128),
        allowNull: true,
        field: 'plain_password',
        comment: 'Stored for admin display and resending credentials email; login uses hashed password in users table.',
    },
    isOnline: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'is_online',
    },
}, {
    tableName: 'doctors',
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    indexes: [
        { fields: ['doctor_uuid'], unique: true },
        { fields: ['user_id'], unique: true },
        { fields: ['specialization'] },
        { fields: ['city'] },
    ],
});

// Define Association
Doctor.belongsTo(User, { foreignKey: 'userId' });
User.hasOne(Doctor, { foreignKey: 'userId' });

export default Doctor;
