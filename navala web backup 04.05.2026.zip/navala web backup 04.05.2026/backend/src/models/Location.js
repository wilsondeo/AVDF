import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';

/**
 * Location Model using Sequelize
 * Handles location data (Country, City, State)
 */

const sequelize = getSequelize();

const Location = sequelize.define('Location', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  country: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  city: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  state: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  taxValue: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    defaultValue: 0.00,
    field: 'tax_value',
  },
  taxType: {
    type: DataTypes.ENUM('FIXED', 'PERCENTAGE'),
    allowNull: false,
    defaultValue: 'FIXED',
    field: 'tax_type',
  },
  isTaxEnabled: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    field: 'is_tax_enabled',
  },
}, {
  tableName: 'locations',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
  underscored: true,
});

/**
 * Get all locations from database
 * @returns {Promise<Array>} Array of location objects
 */
export async function getAllLocations() {
  const locations = await Location.findAll({
    order: [
      ['country', 'ASC'],
      ['city', 'ASC'],
    ],
  });
  return locations.map(loc => loc.toJSON());
}

export default Location;
