import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';
import Plan from './Plan.js';

/**
 * user_plans table (assumed to exist)
 *
 * Columns:
 * - id
 * - user_id
 * - plan_id
 * - start_date
 * - end_date
 * - status (ACTIVE, EXPIRED)
 */

const sequelize = getSequelize();

export const UserPlanStatus = {
  ACTIVE: 'ACTIVE',
  EXPIRED: 'EXPIRED',
};

const UserPlan = sequelize.define('UserPlan', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },

  userId: { type: DataTypes.INTEGER, allowNull: false, field: 'user_id' },
  planId: { type: DataTypes.INTEGER, allowNull: false, field: 'plan_id' },

  startDate: { type: DataTypes.DATE, allowNull: false, field: 'start_date' },
  endDate: { type: DataTypes.DATE, allowNull: false, field: 'end_date' },

  status: {
    type: DataTypes.ENUM('ACTIVE', 'EXPIRED'),
    allowNull: false,
    defaultValue: 'ACTIVE',
  },
}, {
  tableName: 'user_plans',
  timestamps: false,
  indexes: [
    { fields: ['user_id'] },
    { fields: ['plan_id'] },
    { fields: ['status'] },
    { fields: ['start_date'] },
    { fields: ['end_date'] },
  ],
});

// Associations (optional but helpful)
UserPlan.belongsTo(Plan, { foreignKey: 'planId', targetKey: 'id' });

export default UserPlan;

