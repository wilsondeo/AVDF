import { DataTypes } from 'sequelize';
import bcrypt from 'bcrypt';
import { randomUUID } from 'crypto';
import { getSequelize } from '../config/database.js';
import { env } from '../config/env.js';

/**
 * User Model using Sequelize
 * Handles all database operations for users
 */

const sequelize = getSequelize();

export const UserRoles = {
  ADMIN: 'ADMIN',
  DOCTOR: 'DOCTOR',
  PATIENT: 'PATIENT',
};

/**
 * User Model Definition
 */
const User = sequelize.define('User', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  userUuid: {
    type: DataTypes.STRING(36),
    allowNull: true,
    // unique: true, // Temporarily disabled to fix ER_TOO_MANY_KEYS
    field: 'user_uuid',
    comment: 'Public/user-facing UUID (do not expose auto-increment id in UI)',
  },
  email: {
    type: DataTypes.STRING(255),
    allowNull: false,
    // unique: true, // Temporarily disabled to fix ER_TOO_MANY_KEYS
    validate: {
      isEmail: true,
    },
  },
  password: {
    type: DataTypes.STRING(255),
    allowNull: false,
  },
  firstName: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  lastName: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  role: {
    type: DataTypes.ENUM('ADMIN', 'DOCTOR', 'PATIENT'),
    allowNull: false,
    defaultValue: 'PATIENT',
  },
  isActive: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
  },
  // Patient profile (optional; also used for display)
  phone: { type: DataTypes.STRING(20), allowNull: true },
  dateOfBirth: { type: DataTypes.DATEONLY, allowNull: true, field: 'date_of_birth' },
  streetAddress: { type: DataTypes.STRING(255), allowNull: true, field: 'street_address' },
  city: { type: DataTypes.STRING(100), allowNull: true },
  state: { type: DataTypes.STRING(100), allowNull: true },
  zipCode: { type: DataTypes.STRING(20), allowNull: true, field: 'zip_code' },
  country: { type: DataTypes.STRING(100), allowNull: true },
  emergencyContactName: { type: DataTypes.STRING(100), allowNull: true, field: 'emergency_contact_name' },
  emergencyContactPhone: { type: DataTypes.STRING(50), allowNull: true, field: 'emergency_contact_phone' },
  emergencyContactRelationship: { type: DataTypes.STRING(50), allowNull: true, field: 'emergency_contact_relationship' },
  bloodType: { type: DataTypes.STRING(10), allowNull: true, field: 'blood_type' },
  gender: { type: DataTypes.STRING(20), allowNull: true },
}, {
  tableName: 'users',
  timestamps: true,
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  indexes: [
    // Unique constraints are already handles in field definitions:
    // email: { unique: true }
    // userUuid: { unique: true }
  ],
  hooks: {
    beforeCreate: async (user) => {
      if (!user.userUuid) {
        user.userUuid = randomUUID();
      }
      if (user.password) {
        user.password = await bcrypt.hash(user.password, env.BCRYPT_ROUNDS);
      }
    },
    beforeUpdate: async (user) => {
      if (user.changed('password')) {
        user.password = await bcrypt.hash(user.password, env.BCRYPT_ROUNDS);
      }
    },
  },
});

/**
 * Hash password using bcrypt
 * @param {string} password - Plain text password
 * @returns {Promise<string>} Hashed password
 */
export async function hashPassword(password) {
  return bcrypt.hash(password, env.BCRYPT_ROUNDS);
}

/**
 * Compare password with hash
 * @param {string} password - Plain text password
 * @param {string} hash - Hashed password
 * @returns {Promise<boolean>} True if password matches
 */
export async function comparePassword(password, hash) {
  return bcrypt.compare(password, hash);
}

/**
 * Create a new user
 * @param {Object} userData - User data
 * @param {string} userData.email - User email
 * @param {string} userData.password - Plain text password (will be hashed automatically)
 * @param {string} userData.firstName - User first name
 * @param {string} userData.lastName - User last name
 * @param {string} userData.role - User role (ADMIN, DOCTOR, PATIENT)
 * @returns {Promise<Object>} Created user (without password)
 */
const PROFILE_FIELDS = [
  'phone', 'dateOfBirth', 'gender', 'streetAddress', 'city', 'state', 'zipCode', 'country',
  'emergencyContactName', 'emergencyContactPhone', 'emergencyContactRelationship', 'bloodType',
];

export async function createUser(userData) {
  const base = {
    email: userData.email,
    password: userData.password, // Will be hashed by hook
    firstName: userData.firstName,
    lastName: userData.lastName,
    role: userData.role,
    isActive: userData.isActive !== undefined ? userData.isActive : true,
  };
  PROFILE_FIELDS.forEach((key) => {
    if (userData[key] !== undefined && userData[key] !== null && userData[key] !== '') {
      base[key] = userData[key];
    }
  });
  const user = await User.create(base);

  // Return user without password
  const userJson = user.toJSON();
  delete userJson.password;
  return userJson;
}

/**
 * Get user by ID
 * @param {number} userId - User ID
 * @returns {Promise<Object|null>} User object (without password) or null
 */
export async function getUserById(userId) {
  const user = await User.findByPk(userId, {
    attributes: { exclude: ['password'] },
    include: [{ model: getSequelize().models.Doctor }],
  });

  return user ? user.toJSON() : null;
}

/**
 * Get user by email
 * @param {string} email - User email
 * @param {boolean} includePassword - Whether to include password in result
 * @returns {Promise<Object|null>} User object or null
 */
export async function getUserByEmail(email, includePassword = false) {
  const attributes = includePassword
    ? undefined // Include all attributes including password
    : { exclude: ['password'] };

  const user = await User.findOne({
    where: { email },
    attributes,
  });

  return user ? user.toJSON() : null;
}

/**
 * Get all users by role
 * @param {string} role - User role
 * @returns {Promise<Array>} Array of users
 */
export async function getUsersByRole(role) {
  const users = await User.findAll({
    where: { role },
    attributes: { exclude: ['password'] },
    order: [['createdAt', 'DESC']],
  });

  return users.map(user => user.toJSON());
}

/**
 * Update user password
 * @param {number} userId - User ID
 * @param {string} newPassword - New plain text password (will be hashed automatically)
 * @returns {Promise<boolean>} True if updated successfully
 */
export async function updateUserPassword(userId, newPassword) {
  const user = await User.findByPk(userId);

  if (!user) {
    return false;
  }

  user.password = newPassword; // Will be hashed by hook
  await user.save();

  return true;
}

/**
 * Update user status
 * @param {number} userId - User ID
 * @param {boolean} isActive - Active status
 * @returns {Promise<boolean>} True if updated successfully
 */
export async function updateUserStatus(userId, isActive) {
  const [affectedRows] = await User.update(
    { isActive },
    { where: { id: userId } }
  );

  return affectedRows > 0;
}

/**
 * Update user profile (patient profile fields)
 * @param {number} userId - User ID
 * @param {Object} profile - Fields to update (phone, dateOfBirth, streetAddress, city, state, zipCode, country, emergencyContactName, emergencyContactPhone, emergencyContactRelationship, bloodType; firstName, lastName allowed)
 * @returns {Promise<Object|null>} Updated user (without password) or null
 */
export async function updateUserProfile(userId, profile) {
  const allowed = ['firstName', 'lastName', ...PROFILE_FIELDS];
  const updates = {};
  allowed.forEach((key) => {
    if (profile[key] !== undefined) {
      updates[key] = profile[key] === '' ? null : profile[key];
    }
  });
  if (Object.keys(updates).length === 0) return getUserById(userId);
  await User.update(updates, { where: { id: userId } });
  return getUserById(userId);
}

/**
 * Check if email exists
 * @param {string} email - Email to check
 * @returns {Promise<boolean>} True if email exists
 */
export async function emailExists(email) {
  const count = await User.count({ where: { email } });
  return count > 0;
}

/**
 * Backfill user UUIDs for existing rows (safe migration helper).
 * This keeps production deployments code-change-free while allowing schema evolution.
 */
export async function backfillUserUuids() {
  // MySQL UUID() generates a v1-ish UUID string; good enough as a stable public identifier.
  // We also handle empty string (from previous failed migrations).
  await sequelize.query(
    "UPDATE users SET user_uuid = UUID() WHERE user_uuid IS NULL OR user_uuid = ''"
  );
}

export default User;
