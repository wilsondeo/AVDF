import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';
import User from './User.js';
import Doctor from './Doctor.js';
import AppointmentRequest from './AppointmentRequest.js';

/**
 * Appointment Model
 * Represents a confirmed appointment between patient and doctor.
 *
 * - appointmentUuid is the public identifier.
 * - requestId links back to the original AppointmentRequest.
 */

const sequelize = getSequelize();

export const AppointmentStatus = {
  SCHEDULED: 'SCHEDULED',
  COMPLETED: 'COMPLETED',
  CANCELLED: 'CANCELLED',
};

const Appointment = sequelize.define('Appointment', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  appointmentUuid: {
    type: DataTypes.STRING(36),
    allowNull: false,
    unique: true,
    field: 'appointment_uuid',
    comment: 'Public identifier for the appointment',
  },
  requestId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'request_id',
    references: {
      model: 'appointment_requests',
      key: 'id',
    },
  },
  patientId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'patient_id',
    references: {
      model: 'users',
      key: 'id',
    },
  },
  doctorId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'doctor_id',
    references: {
      model: 'doctors',
      key: 'id',
    },
  },
  serviceType: {
    type: DataTypes.ENUM('TELEHEALTH', 'EMERGENCY'),
    allowNull: false,
    field: 'service_type',
  },
  city: {
    type: DataTypes.STRING(100),
    allowNull: true,
  },
  state: {
    type: DataTypes.STRING(100),
    allowNull: true,
  },
  country: {
    type: DataTypes.STRING(100),
    allowNull: true,
  },
  timezone: {
    type: DataTypes.STRING(50),
    allowNull: true,
    comment: 'Timezone of the appointment location',
  },
  appointmentDate: {
    type: DataTypes.DATE,
    allowNull: true,
    field: 'appointment_date',
  },
  status: {
    type: DataTypes.ENUM('SCHEDULED', 'COMPLETED', 'CANCELLED'),
    allowNull: false,
    defaultValue: 'SCHEDULED',
  },
  createdAt: {
    type: DataTypes.DATE,
    allowNull: true,
    field: 'created_at',
  },
  updatedAt: {
    type: DataTypes.DATE,
    allowNull: true,
    field: 'updated_at',
  },
}, {
  tableName: 'appointments',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
  indexes: [
    { fields: ['appointment_uuid'], unique: true },
    { fields: ['request_id'] },
    { fields: ['patient_id'] },
    { fields: ['doctor_id'] },
    { fields: ['status'] },
  ],
});

Appointment.belongsTo(AppointmentRequest, { foreignKey: 'requestId', as: 'request' });
Appointment.belongsTo(User, { foreignKey: 'patientId', as: 'patient' });
Appointment.belongsTo(Doctor, { foreignKey: 'doctorId', as: 'doctor' });

export default Appointment;

