import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';
import Prescription from './Prescription.js';

const sequelize = getSequelize();

const PrescriptionMedicine = sequelize.define('PrescriptionMedicine', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    prescriptionId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'prescription_id',
        references: {
            model: 'prescriptions',
            key: 'id',
        },
        onDelete: 'CASCADE',
    },
    name: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    dosage: {
        type: DataTypes.STRING(100),
        allowNull: true,
    },
    frequency: {
        type: DataTypes.STRING(100),
        allowNull: true,
    },
    duration: {
        type: DataTypes.STRING(100),
        allowNull: true,
    },
    foodInstructions: {
        type: DataTypes.STRING(255),
        allowNull: true,
        field: 'food_instructions',
    },
}, {
    tableName: 'prescription_medicines',
    timestamps: false,
    indexes: [
        { fields: ['prescription_id'] },
    ],
});

// Associations
PrescriptionMedicine.belongsTo(Prescription, { foreignKey: 'prescriptionId' });
Prescription.hasMany(PrescriptionMedicine, { as: 'medicines', foreignKey: 'prescriptionId', onDelete: 'CASCADE' });

export default PrescriptionMedicine;
