import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';
import User from './User.js';

const sequelize = getSequelize();

const PatientVital = sequelize.define('PatientVital', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  userId: { type: DataTypes.INTEGER, allowNull: false, field: 'user_id' },
  heartRate: { type: DataTypes.INTEGER, allowNull: true, field: 'heart_rate' },
  bloodPressureSystolic: { type: DataTypes.INTEGER, allowNull: true, field: 'blood_pressure_systolic' },
  bloodPressureDiastolic: { type: DataTypes.INTEGER, allowNull: true, field: 'blood_pressure_diastolic' },
  temperature: { type: DataTypes.DECIMAL(4, 1), allowNull: true },
  oxygenLevel: { type: DataTypes.INTEGER, allowNull: true, field: 'oxygen_level' },
  recordedAt: { type: DataTypes.DATE, allowNull: false, field: 'recorded_at' },
}, {
  tableName: 'patient_vitals',
  timestamps: true,
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  indexes: [
    { fields: ['user_id'] },
    { fields: ['user_id', 'recorded_at'] },
  ],
});

PatientVital.belongsTo(User, { foreignKey: 'userId' });

export default PatientVital;
