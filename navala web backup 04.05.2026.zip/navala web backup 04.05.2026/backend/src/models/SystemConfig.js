import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';

const sequelize = getSequelize();

const SystemConfig = sequelize.define('SystemConfig', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  configKey: {
    type: DataTypes.STRING(100),
    allowNull: false,
    unique: true,
    field: 'config_key',
  },
  configValue: {
    type: DataTypes.STRING(255),
    allowNull: false,
    field: 'config_value',
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
}, {
  tableName: 'system_configs',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
  underscored: true,
});

/**
 * Get config value by key
 * @param {string} key 
 * @returns {Promise<string|null>}
 */
export async function getConfig(key) {
  const config = await SystemConfig.findOne({ where: { configKey: key } });
  return config ? config.configValue : null;
}

/**
 * Set or update config value
 * @param {string} key 
 * @param {string} value 
 */
export async function setConfig(key, value) {
  const [config, created] = await SystemConfig.findOrCreate({
    where: { configKey: key },
    defaults: { configValue: value }
  });
  
  if (!created) {
    config.configValue = value;
    await config.save();
  }
  return config;
}

export default SystemConfig;
