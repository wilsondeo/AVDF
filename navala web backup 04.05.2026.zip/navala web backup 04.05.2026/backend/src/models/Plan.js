import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';

/**
 * Plan Model using Sequelize
 * Handles all database operations for healthcare plans
 */

const sequelize = getSequelize();

export const ServiceTypes = {
  TELEHEALTH: 'TELEHEALTH',
  EMERGENCY: 'EMERGENCY',
};

/**
 * Plan Model Definition
 */
const Plan = sequelize.define('Plan', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  planId: {
    type: DataTypes.STRING(50),
    allowNull: false,
    unique: true,
    comment: 'Unique business identifier for the plan',
  },
  name: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    validate: {
      min: 0,
    },
  },
  validityDays: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1,
    },
    comment: 'Number of days the plan is valid',
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  services: {
    type: DataTypes.JSON,
    allowNull: false,
    defaultValue: [],
    comment: 'Array of service types: TELEHEALTH, EMERGENCY',
    validate: {
      isValidServices(value) {
        if (!Array.isArray(value)) {
          throw new Error('Services must be an array');
        }
        const validServices = Object.values(ServiceTypes);
        for (const service of value) {
          if (!validServices.includes(service)) {
            throw new Error(`Invalid service type: ${service}`);
          }
        }
      },
    },
  },
  features: {
    type: DataTypes.JSON,
    allowNull: false,
    defaultValue: [],
    comment: 'Array of feature strings',
    validate: {
      isArray(value) {
        if (!Array.isArray(value)) {
          throw new Error('Features must be an array');
        }
      },
    },
  },
  planTabName: {
    type: DataTypes.STRING(50),
    allowNull: true,
    comment: 'Display name used for grouping plans in tabs (e.g. Individual, Family of 2)',
  },
  maxPersons: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 1,
    comment: 'How many people this plan covers (1 = individual, 2 = family of 2, 3-4 = family 3-4)',
    validate: {
      min: 1,
    },
  },
  isActive: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    comment: 'Soft delete support',
  },
}, {
  tableName: 'plans',
  timestamps: true,
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  indexes: [
    { fields: ['planId'], unique: true },
    { fields: ['isActive'] },
    { fields: ['name'] },
  ],
});

/**
 * Generate unique planId
 * Format: PLAN-{timestamp}-{random}
 * @returns {string} Unique plan identifier
 */
export function generatePlanId() {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `PLAN-${timestamp}-${random}`;
}

/**
 * Create a new plan
 * @param {Object} planData - Plan data
 * @returns {Promise<Object>} Created plan
 */
export async function createPlan(planData) {
  // Generate unique planId
  let planId = generatePlanId();
  
  // Ensure planId is unique (retry if collision)
  let attempts = 0;
  while (await Plan.findOne({ where: { planId } }) && attempts < 10) {
    planId = generatePlanId();
    attempts++;
  }
  
  if (attempts >= 10) {
    throw new Error('Failed to generate unique planId');
  }
  
  const plan = await Plan.create({
    ...planData,
    planId,
  });
  
  const planJson = plan.toJSON();
  // Ensure services and features are arrays
  if (typeof planJson.services === 'string') {
    planJson.services = JSON.parse(planJson.services);
  }
  if (typeof planJson.features === 'string') {
    planJson.features = JSON.parse(planJson.features);
  }
  // Ensure price is a number
  if (typeof planJson.price === 'string') {
    planJson.price = parseFloat(planJson.price);
  }
  return planJson;
}

/**
 * Get plan by planId
 * @param {string} planId - Plan business identifier
 * @param {boolean} includeInactive - Include inactive plans
 * @returns {Promise<Object|null>} Plan object or null
 */
export async function getPlanByPlanId(planId, includeInactive = false) {
  const where = { planId };
  if (!includeInactive) {
    where.isActive = true;
  }
  
  const plan = await Plan.findOne({ where });
  if (!plan) return null;
  
  const planJson = plan.toJSON();
  // Ensure services and features are arrays
  if (typeof planJson.services === 'string') {
    planJson.services = JSON.parse(planJson.services);
  }
  if (typeof planJson.features === 'string') {
    planJson.features = JSON.parse(planJson.features);
  }
  // Ensure price is a number
  if (typeof planJson.price === 'string') {
    planJson.price = parseFloat(planJson.price);
  }
  return planJson;
}

/**
 * Get plan by ID
 * @param {number} id - Plan database ID
 * @param {boolean} includeInactive - Include inactive plans
 * @returns {Promise<Object|null>} Plan object or null
 */
export async function getPlanById(id, includeInactive = false) {
  const where = { id };
  if (!includeInactive) {
    where.isActive = true;
  }
  
  const plan = await Plan.findByPk(id, { where });
  if (!plan) return null;
  
  const planJson = plan.toJSON();
  // Ensure services and features are arrays
  if (typeof planJson.services === 'string') {
    planJson.services = JSON.parse(planJson.services);
  }
  if (typeof planJson.features === 'string') {
    planJson.features = JSON.parse(planJson.features);
  }
  // Ensure price is a number
  if (typeof planJson.price === 'string') {
    planJson.price = parseFloat(planJson.price);
  }
  return planJson;
}

/**
 * Get all plans
 * @param {Object} options - Query options
 * @param {boolean} options.includeInactive - Include inactive plans
 * @param {number} options.limit - Limit results
 * @param {number} options.offset - Offset for pagination
 * @returns {Promise<Array>} Array of plans
 */
export async function getAllPlans(options = {}) {
  const {
    includeInactive = false,
    limit,
    offset,
  } = options;
  
  const where = {};
  if (!includeInactive) {
    where.isActive = true;
  }
  
  const queryOptions = {
    where,
    order: [['createdAt', 'DESC']],
    raw: false, // Get Sequelize instances to properly parse JSON
  };
  
  if (limit) queryOptions.limit = limit;
  if (offset) queryOptions.offset = offset;
  
  const plans = await Plan.findAll(queryOptions);
  return plans.map(plan => {
    const planJson = plan.toJSON();
    // Ensure services and features are arrays
    if (typeof planJson.services === 'string') {
      planJson.services = JSON.parse(planJson.services);
    }
    if (typeof planJson.features === 'string') {
      planJson.features = JSON.parse(planJson.features);
    }
    // Ensure price is a number
    if (typeof planJson.price === 'string') {
      planJson.price = parseFloat(planJson.price);
    }
    return planJson;
  });
}

/**
 * Get active plans (public)
 * @returns {Promise<Array>} Array of active plans
 */
export async function getActivePlans() {
  const plans = await getAllPlans({ includeInactive: false });
  // Normalize is already done in getAllPlans
  return plans;
}

/**
 * Update plan
 * @param {string} planId - Plan business identifier
 * @param {Object} updates - Plan updates
 * @returns {Promise<Object|null>} Updated plan or null
 */
export async function updatePlan(planId, updates) {
  const plan = await Plan.findOne({ where: { planId } });
  
  if (!plan) {
    return null;
  }
  
  // Don't allow updating planId
  const { planId: _, ...safeUpdates } = updates;
  
  await plan.update(safeUpdates);
  const planJson = plan.toJSON();
  // Ensure services and features are arrays
  if (typeof planJson.services === 'string') {
    planJson.services = JSON.parse(planJson.services);
  }
  if (typeof planJson.features === 'string') {
    planJson.features = JSON.parse(planJson.features);
  }
  // Ensure price is a number
  if (typeof planJson.price === 'string') {
    planJson.price = parseFloat(planJson.price);
  }
  return planJson;
}

/**
 * Soft delete plan (set isActive to false)
 * @param {string} planId - Plan business identifier
 * @returns {Promise<boolean>} True if updated successfully
 */
export async function softDeletePlan(planId) {
  const [affectedRows] = await Plan.update(
    { isActive: false },
    { where: { planId } }
  );
  
  return affectedRows > 0;
}

/**
 * Check if planId exists
 * @param {string} planId - Plan business identifier
 * @returns {Promise<boolean>} True if planId exists
 */
export async function planIdExists(planId) {
  const count = await Plan.count({ where: { planId } });
  return count > 0;
}

export default Plan;
