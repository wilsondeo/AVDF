import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';
import User from './User.js';
import PatientMedication from './PatientMedication.js';

const sequelize = getSequelize();

const MedicationTaken = sequelize.define('MedicationTaken', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  userId: { type: DataTypes.INTEGER, allowNull: false, field: 'user_id' },
  medicationId: { type: DataTypes.INTEGER, allowNull: false, field: 'medication_id' },
  date: { type: DataTypes.DATEONLY, allowNull: false },
  taken: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
}, {
  tableName: 'medication_taken',
  timestamps: true,
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  indexes: [
    { fields: ['user_id', 'medication_id', 'date'], unique: true },
    { fields: ['user_id'] },
  ],
});

MedicationTaken.belongsTo(User, { foreignKey: 'userId' });
MedicationTaken.belongsTo(PatientMedication, { foreignKey: 'medicationId' });

export default MedicationTaken;
