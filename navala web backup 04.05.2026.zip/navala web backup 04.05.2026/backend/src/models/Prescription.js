import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';
import Appointment from './Appointment.js';
import Doctor from './Doctor.js';
import User from './User.js';

const sequelize = getSequelize();

const Prescription = sequelize.define('Prescription', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    prescriptionUuid: {
        type: DataTypes.STRING(36),
        allowNull: false,
        unique: true,
        field: 'prescription_uuid',
    },
    appointmentId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'appointment_id',
        references: {
            model: 'appointments',
            key: 'id',
        },
    },
    doctorId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'doctor_id',
        references: {
            model: 'doctors',
            key: 'id',
        },
    },
    patientId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'patient_id',
        references: {
            model: 'users',
            key: 'id',
        },
    },
    diagnosis: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    generalAdvice: {
        type: DataTypes.TEXT,
        allowNull: true,
        field: 'general_advice',
    },
    restrictions: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    notes: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM('DRAFT', 'ISSUED', 'CANCELLED'),
        allowNull: false,
        defaultValue: 'ISSUED',
    },
}, {
    tableName: 'prescriptions',
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    indexes: [
        { fields: ['prescription_uuid'], unique: true },
        { fields: ['appointment_id'] },
        { fields: ['doctor_id'] },
        { fields: ['patient_id'] },
        { fields: ['status'] },
    ],
});

// Associations
Prescription.belongsTo(Appointment, { foreignKey: 'appointmentId' });
Appointment.hasMany(Prescription, { foreignKey: 'appointmentId' });

Prescription.belongsTo(Doctor, { foreignKey: 'doctorId' });
Doctor.hasMany(Prescription, { foreignKey: 'doctorId' });

Prescription.belongsTo(User, { as: 'patient', foreignKey: 'patientId' });
User.hasMany(Prescription, { as: 'prescriptions', foreignKey: 'patientId' });

export default Prescription;
