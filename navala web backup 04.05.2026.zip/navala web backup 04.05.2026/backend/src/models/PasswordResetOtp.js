import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';

const sequelize = getSequelize();

/**
 * Stores OTP for patient forgot-password flow.
 * One row per email; updated when a new OTP is requested.
 */
const PasswordResetOtp = sequelize.define('PasswordResetOtp', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  email: {
    type: DataTypes.STRING(255),
    allowNull: false,
    unique: true,
  },
  otp: {
    type: DataTypes.STRING(10),
    allowNull: false,
  },
  expiresAt: {
    type: DataTypes.DATE,
    allowNull: false,
    field: 'expires_at',
  },
}, {
  tableName: 'password_reset_otps',
  timestamps: true,
  createdAt: true,
  updatedAt: true,
  // No extra indexes: email has unique:true above; expires_at uses field name so index would need column name
});

export default PasswordResetOtp;
