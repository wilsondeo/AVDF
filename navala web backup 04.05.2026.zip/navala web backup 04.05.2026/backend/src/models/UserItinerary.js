import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';
import User from './User.js';
import Location from './Location.js';
import Payment from './Payment.js';

const sequelize = getSequelize();

const UserItinerary = sequelize.define('UserItinerary', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'user_id',
    references: {
      model: 'users',
      key: 'id',
    },
  },
  paymentId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    field: 'payment_id',
    references: {
      model: 'payments',
      key: 'id',
    },
  },
  locationId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'location_id',
    references: {
      model: 'locations',
      key: 'id',
    },
  },
  arrivalDate: {
    type: DataTypes.DATEONLY,
    allowNull: true,
    field: 'arrival_date',
  },
  departureDate: {
    type: DataTypes.DATEONLY,
    allowNull: true,
    field: 'departure_date',
  },
  taxPaid: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    defaultValue: 0.00,
    field: 'tax_paid',
  },
  visitOrder: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 1,
    field: 'visit_order',
  },
}, {
  tableName: 'user_itineraries',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
  underscored: true,
});

// Associations
UserItinerary.belongsTo(User, { foreignKey: 'userId', as: 'user' });
UserItinerary.belongsTo(Location, { foreignKey: 'locationId', as: 'location' });
UserItinerary.belongsTo(Payment, { foreignKey: 'paymentId', as: 'payment' });

export default UserItinerary;
