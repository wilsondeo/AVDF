import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';
import User from './User.js';
import Plan from './Plan.js';
import Payment from './Payment.js';

/**
 * plan_upgrades table – audit log for plan upgrades (storage only, not for display).
 * Records: user, old plan, new plan, prices, amount charged, payment reference.
 */
const sequelize = getSequelize();

const PlanUpgrade = sequelize.define('PlanUpgrade', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },

  userId: { type: DataTypes.INTEGER, allowNull: false, field: 'user_id' },
  oldPlanId: { type: DataTypes.INTEGER, allowNull: false, field: 'old_plan_id' },
  newPlanId: { type: DataTypes.INTEGER, allowNull: false, field: 'new_plan_id' },

  oldPriceCents: { type: DataTypes.INTEGER, allowNull: false, field: 'old_price_cents' },
  newPriceCents: { type: DataTypes.INTEGER, allowNull: false, field: 'new_price_cents' },
  amountChargedCents: { type: DataTypes.INTEGER, allowNull: false, field: 'amount_charged_cents' },

  paymentId: { type: DataTypes.INTEGER, allowNull: false, field: 'payment_id' },

  createdAt: { type: DataTypes.DATE, allowNull: false, field: 'created_at', defaultValue: DataTypes.NOW },
}, {
  tableName: 'plan_upgrades',
  timestamps: false,
  indexes: [
    { fields: ['user_id'] },
    { fields: ['payment_id'], unique: true },
    { fields: ['created_at'] },
  ],
});

PlanUpgrade.belongsTo(User, { foreignKey: 'userId' });
PlanUpgrade.belongsTo(Plan, { foreignKey: 'oldPlanId', targetKey: 'id' });
PlanUpgrade.belongsTo(Plan, { foreignKey: 'newPlanId', targetKey: 'id' });
PlanUpgrade.belongsTo(Payment, { foreignKey: 'paymentId' });

export default PlanUpgrade;
