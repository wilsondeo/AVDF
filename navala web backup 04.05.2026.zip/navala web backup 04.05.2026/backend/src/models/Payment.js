import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';
import User from './User.js';
import Plan from './Plan.js';

/**
 * payments table (assumed to exist)
 *
 * Columns:
 * - id
 * - user_id
 * - plan_id
 * - stripe_payment_intent_id
 * - amount
 * - currency
 * - status (PENDING, SUCCESS, FAILED)
 * - type (PURCHASE, UPGRADE)
 * - created_at
 */

const sequelize = getSequelize();

export const PaymentStatus = {
  PENDING: 'PENDING',
  SUCCESS: 'SUCCESS',
  FAILED: 'FAILED',
};

export const PaymentType = {
  PURCHASE: 'PURCHASE',
  UPGRADE: 'UPGRADE',
};

const Payment = sequelize.define('Payment', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },

  userId: { type: DataTypes.INTEGER, allowNull: false, field: 'user_id' },
  planId: { type: DataTypes.INTEGER, allowNull: false, field: 'plan_id' },

  stripePaymentIntentId: {
    type: DataTypes.STRING(255),
    allowNull: false,
    field: 'stripe_payment_intent_id',
  },

  // Store amount in the smallest currency unit (e.g. cents)
  amount: { type: DataTypes.INTEGER, allowNull: false },
  currency: { type: DataTypes.STRING(10), allowNull: false },

  status: {
    type: DataTypes.ENUM('PENDING', 'SUCCESS', 'FAILED'),
    allowNull: false,
    defaultValue: 'PENDING',
  },

  type: {
    type: DataTypes.ENUM('PURCHASE', 'UPGRADE'),
    allowNull: false,
  },

  createdAt: { type: DataTypes.DATE, allowNull: false, field: 'created_at', defaultValue: DataTypes.NOW },
}, {
  tableName: 'payments',
  timestamps: false,
  indexes: [
    { fields: ['user_id'] },
    { fields: ['plan_id'] },
    { fields: ['stripe_payment_intent_id'], unique: true },
    { fields: ['status'] },
    { fields: ['type'] },
    { fields: ['created_at'] },
  ],
});

// Define associations
Payment.belongsTo(User, { foreignKey: 'userId' });
Payment.belongsTo(Plan, { foreignKey: 'planId' });
User.hasMany(Payment, { foreignKey: 'userId' });
Plan.hasMany(Payment, { foreignKey: 'planId' });

export default Payment;

