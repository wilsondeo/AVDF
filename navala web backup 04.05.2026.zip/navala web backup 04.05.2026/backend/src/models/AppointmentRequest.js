import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';
import User from './User.js';
import Plan from './Plan.js';
import FamilyMember from './FamilyMember.js';

/**
 * AppointmentRequest Model
 * Stores raw booking requests from patients before a doctor is assigned.
 *
 * IMPORTANT:
 * - requestUuid is the public identifier exposed via APIs.
 * - planId is derived from user_plans (active plan) on the backend.
 */

const sequelize = getSequelize();

export const AppointmentRequestStatus = {
  PENDING: 'PENDING',
  ASSIGNED: 'ASSIGNED',
  CANCELLED: 'CANCELLED',
};

export const AppointmentRequestServiceTypes = {
  TELEHEALTH: 'TELEHEALTH',
  EMERGENCY: 'EMERGENCY',
};

const AppointmentRequest = sequelize.define('AppointmentRequest', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  requestUuid: {
    type: DataTypes.STRING(36),
    allowNull: false,
    unique: true,
    field: 'request_uuid',
    comment: 'Public identifier for the appointment request',
  },
  patientId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'patient_id',
    references: {
      model: 'users',
      key: 'id',
    },
  },
  planId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'plan_id',
    references: {
      model: 'plans',
      key: 'id',
    },
    comment: 'FK to plans.id for the active plan at the time of request',
  },
  city: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  state: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  country: {
    type: DataTypes.STRING(100),
    allowNull: false,
  },
  timezone: {
    type: DataTypes.STRING(50),
    allowNull: true,
    comment: 'Timezone of the destination/location for the appointment',
  },
  preferredDate: {
    type: DataTypes.DATE,
    allowNull: true,
    field: 'preferred_date',
  },
  familyMemberId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    field: 'family_member_id',
    references: {
      model: 'family_members',
      key: 'id',
    },
  },
  age: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  gender: {
    type: DataTypes.STRING(20),
    allowNull: false,
  },
  emergencyContact: {
    type: DataTypes.STRING(50),
    allowNull: true,
    field: 'emergency_contact',
  },
  serviceType: {
    type: DataTypes.ENUM('TELEHEALTH', 'EMERGENCY'),
    allowNull: false,
    field: 'service_type',
  },
  notes: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  allergies: {
    type: DataTypes.TEXT,
    allowNull: true,
    comment: 'Known allergies or cause / reason for visit for reliable communication with admin and doctor',
  },
  status: {
    type: DataTypes.ENUM('PENDING', 'ASSIGNED', 'CANCELLED'),
    allowNull: false,
    defaultValue: 'PENDING',
  },
  createdAt: {
    type: DataTypes.DATE,
    allowNull: true,
    field: 'created_at',
  },
  updatedAt: {
    type: DataTypes.DATE,
    allowNull: true,
    field: 'updated_at',
  },
}, {
  tableName: 'appointment_requests',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
  indexes: [
    { fields: ['request_uuid'], unique: true },
    { fields: ['patient_id'] },
    { fields: ['plan_id'] },
    { fields: ['status'] },
    { fields: ['service_type'] },
  ],
});

AppointmentRequest.belongsTo(User, { foreignKey: 'patientId', as: 'patient' });
AppointmentRequest.belongsTo(Plan, { foreignKey: 'planId', as: 'plan' });
AppointmentRequest.belongsTo(FamilyMember, { foreignKey: 'familyMemberId', as: 'familyMember' });

export default AppointmentRequest;

