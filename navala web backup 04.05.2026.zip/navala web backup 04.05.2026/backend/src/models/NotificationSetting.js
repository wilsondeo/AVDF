import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/database.js';
import User from './User.js';

const sequelize = getSequelize();

/**
 * Per-user notification preferences (admin and patient).
 * One row per user; created on first get/update.
 */
const NotificationSetting = sequelize.define('NotificationSetting', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    unique: true,
    field: 'user_id',
  },
  emailAppointments: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    field: 'email_appointments',
  },
  emailReminders: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    field: 'email_reminders',
  },
  emailPromo: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: false,
    field: 'email_promo',
  },
  inAppEnabled: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: true,
    field: 'in_app_enabled',
  },
}, {
  tableName: 'notification_settings',
  timestamps: true,
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  indexes: [{ unique: true, fields: ['user_id'] }],
});

NotificationSetting.belongsTo(User, { foreignKey: 'userId' });

export default NotificationSetting;
