import NotificationSetting from '../models/NotificationSetting.js';

const DEFAULTS = {
  emailAppointments: true,
  emailReminders: true,
  emailPromo: false,
  inAppEnabled: true,
};

/**
 * GET /user/notification-settings
 * Returns current user's notification preferences (admin or patient). Creates default row if none.
 */
export async function getNotificationSettings(req, res) {
  try {
    const userId = req.user?.id ?? req.userId;
    if (!userId) {
      return res.status(401).json({ success: false, message: 'Unauthorized' });
    }
    let row = await NotificationSetting.findOne({ where: { userId: Number(userId) } });
    if (!row) {
      row = await NotificationSetting.create({ userId: Number(userId), ...DEFAULTS });
    }
    const data = row.toJSON();
    res.json({
      success: true,
      message: 'Notification settings retrieved',
      data: {
        emailAppointments: !!data.emailAppointments,
        emailReminders: !!data.emailReminders,
        emailPromo: !!data.emailPromo,
        inAppEnabled: !!data.inAppEnabled,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error?.message || 'Failed to get notification settings',
    });
  }
}

/**
 * PUT /user/notification-settings
 * Body: { emailAppointments?, emailReminders?, emailPromo?, inAppEnabled? }
 */
export async function updateNotificationSettings(req, res) {
  try {
    const userId = req.user?.id ?? req.userId;
    if (!userId) {
      return res.status(401).json({ success: false, message: 'Unauthorized' });
    }
    const payload = req.body || {};
    const updates = {};
    if (typeof payload.emailAppointments === 'boolean') updates.emailAppointments = payload.emailAppointments;
    if (typeof payload.emailReminders === 'boolean') updates.emailReminders = payload.emailReminders;
    if (typeof payload.emailPromo === 'boolean') updates.emailPromo = payload.emailPromo;
    if (typeof payload.inAppEnabled === 'boolean') updates.inAppEnabled = payload.inAppEnabled;

    let row = await NotificationSetting.findOne({ where: { userId: Number(userId) } });
    if (!row) {
      row = await NotificationSetting.create({ userId: Number(userId), ...DEFAULTS, ...updates });
    } else if (Object.keys(updates).length > 0) {
      await row.update(updates);
    }
    const data = row.toJSON();
    res.json({
      success: true,
      message: 'Notification settings updated',
      data: {
        emailAppointments: !!data.emailAppointments,
        emailReminders: !!data.emailReminders,
        emailPromo: !!data.emailPromo,
        inAppEnabled: !!data.inAppEnabled,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error?.message || 'Failed to update notification settings',
    });
  }
}
