import { authenticateUser, registerPatient, refreshAccessToken, requestPasswordReset, resetPasswordWithOtp } from '../services/auth.service.js';
import { UserRoles } from '../models/User.js';
import { validateDateOfBirth } from '../utils/validation.util.js';

/**
 * Authentication Controller
 * Handles patient authentication endpoints
 */

/**
 * Patient login
 * POST /api/auth/login
 */
export async function patientLogin(req, res) {
  try {
    const { email, password } = req.body;
    
    // Validate input
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required',
      });
    }
    
    // Authenticate patient
    const result = await authenticateUser(email, password, UserRoles.PATIENT);
    
    res.json({
      success: true,
      message: 'Login successful',
      data: result,
    });
  } catch (error) {
    res.status(401).json({
      success: false,
      message: error.message || 'Login failed',
    });
  }
}

/**
 * Patient registration
 * POST /api/auth/register
 */
export async function patientRegister(req, res) {
  try {
    const {
      email,
      password,
      firstName,
      lastName,
      phone,
      dateOfBirth,
      streetAddress,
      city,
      state,
      zipCode,
      country,
      emergencyContactName,
      emergencyContactPhone,
      emergencyContactRelationship,
      bloodType,
      gender,
    } = req.body;
    
    // Validate input
    if (!email || !password || !firstName || !lastName) {
      return res.status(400).json({
        success: false,
        message: 'Email, password, firstName, and lastName are required',
      });
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid email format',
      });
    }
    
    if (password.length < 8) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 8 characters long',
      });
    }

    if (dateOfBirth) {
      const dobCheck = validateDateOfBirth(dateOfBirth);
      if (!dobCheck.valid) {
        return res.status(400).json({
          success: false,
          message: dobCheck.message || 'Invalid date of birth',
        });
      }
    }

    const result = await registerPatient({
      email,
      password,
      firstName,
      lastName,
      phone: phone || null,
      dateOfBirth: dateOfBirth || null,
      streetAddress: streetAddress || null,
      city: city || null,
      state: state || null,
      zipCode: zipCode || null,
      country: country || null,
      emergencyContactName: emergencyContactName || null,
      emergencyContactPhone: emergencyContactPhone || null,
      emergencyContactRelationship: emergencyContactRelationship || null,
      bloodType: bloodType || null,
      gender: gender || null,
    });
    
    res.status(201).json({
      success: true,
      message: 'Registration successful',
      data: result,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message || 'Registration failed',
    });
  }
}

/**
 * Refresh access token
 * POST /api/auth/refresh
 */
export async function refreshToken(req, res) {
  try {
    const { refreshToken } = req.body;
    
    if (!refreshToken) {
      return res.status(400).json({
        success: false,
        message: 'Refresh token is required',
      });
    }
    
    const result = await refreshAccessToken(refreshToken);
    
    
    res.json({
      success: true,
      message: 'Token refreshed successfully',
      data: result,
    });
  } catch (error) {
    res.status(401).json({
      success: false,
      message: error.message || 'Token refresh failed',
    });
  }
}

/**
 * Forgot password (patient only): send OTP to email
 * POST /api/auth/forgot-password
 */
export async function forgotPassword(req, res) {
  try {
    const { email } = req.body;
    if (!email || typeof email !== 'string') {
      return res.status(400).json({
        success: false,
        message: 'Email is required',
      });
    }
    await requestPasswordReset(email.trim());
    res.json({
      success: true,
      message: 'OTP sent to your email. Check your inbox.',
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message || 'Failed to send OTP',
    });
  }
}

/**
 * Reset password with OTP (patient only)
 * POST /api/auth/reset-password
 * Body: { email, otp, newPassword, confirmPassword }
 */
export async function resetPassword(req, res) {
  try {
    const { email, otp, newPassword, confirmPassword } = req.body;
    if (!email || !otp || !newPassword || !confirmPassword) {
      return res.status(400).json({
        success: false,
        message: 'Email, OTP, new password and confirm password are required',
      });
    }
    if (newPassword !== confirmPassword) {
      return res.status(400).json({
        success: false,
        message: 'New password and confirm password do not match',
      });
    }
    await resetPasswordWithOtp(email.trim(), otp, newPassword);
    res.json({
      success: true,
      message: 'Password reset successfully. You can now log in.',
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message || 'Failed to reset password',
    });
  }
}
