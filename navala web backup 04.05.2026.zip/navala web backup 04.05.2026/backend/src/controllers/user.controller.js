import { getUserById, updateUserProfile } from '../models/User.js';
import { validateDateOfBirth } from '../utils/validation.util.js';

/**
 * GET /api/user/profile
 * Returns the current user's profile (no password).
 */
export async function getProfile(req, res) {
  try {
    const userId = req.userId ?? req.user?.id ?? req.token?.userId;
    if (!userId) {
      return res.status(401).json({ success: false, message: 'Unauthorized' });
    }
    const user = await getUserById(Number(userId));
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    res.json({
      success: true,
      message: 'Profile retrieved',
      data: user,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error?.message || 'Failed to get profile',
    });
  }
}

/**
 * PATCH /api/user/profile
 * Body: { firstName, lastName, phone, dateOfBirth, streetAddress, city, state, zipCode, country, emergencyContactName, emergencyContactPhone, emergencyContactRelationship, bloodType }
 */
export async function updateProfile(req, res) {
  try {
    const userId = req.userId ?? req.user?.id ?? req.token?.userId;
    if (!userId) {
      return res.status(401).json({ success: false, message: 'Unauthorized' });
    }
    const body = req.body || {};
    if (body.dateOfBirth != null && body.dateOfBirth !== '') {
      const dobCheck = validateDateOfBirth(body.dateOfBirth);
      if (!dobCheck.valid) {
        return res.status(400).json({
          success: false,
          message: dobCheck.message || 'Invalid date of birth',
        });
      }
    }
    const updated = await updateUserProfile(Number(userId), body);
    if (!updated) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    // If user is a doctor, also update doctor-specific fields
    if (updated.role === 'DOCTOR') {
      const doctorUpdates = {};
      if (body.phone !== undefined) doctorUpdates.phone = body.phone;
      if (body.city !== undefined) doctorUpdates.city = body.city;
      if (body.specialization !== undefined) doctorUpdates.specialization = body.specialization;
      if (body.yearsOfExperience !== undefined) doctorUpdates.yearsOfExperience = body.yearsOfExperience;
      if (body.isOnline !== undefined) doctorUpdates.isOnline = body.isOnline;
      if (body.is_online !== undefined) doctorUpdates.isOnline = body.is_online;

      if (Object.keys(doctorUpdates).length > 0) {
        const Doctor = (await import('../models/Doctor.js')).default;
        await Doctor.update(doctorUpdates, { where: { userId: updated.id } });
      }
    }

    res.json({
      success: true,
      message: 'Profile updated',
      data: updated,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error?.message || 'Failed to update profile',
    });
  }
}
