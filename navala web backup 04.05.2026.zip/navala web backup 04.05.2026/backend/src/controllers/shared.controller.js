import Prescription from '../models/Prescription.js';
import User from '../models/User.js';
import Doctor from '../models/Doctor.js';
import Appointment from '../models/Appointment.js';
import Payment from '../models/Payment.js';
import Plan from '../models/Plan.js';
import { Op } from 'sequelize';

/**
 * Shared Controller
 * Serves HTML templates for PDF generation on mobile.
 */

// Helper to wrap HTML in a professional container
const wrapInDocument = (content, title = 'Document') => `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&family=Playfair+Display:ital,wght@1,800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        .font-serif { font-family: 'Playfair Display', serif; }
        @page { size: A4; margin: 0; }
        @media print {
            .no-print { display: none; }
            body { padding: 0; margin: 0; }
        }
    </style>
</head>
<body class="bg-gray-50 text-slate-800 p-8">
    <div class="max-w-3xl mx-auto bg-white p-12 shadow-sm border border-gray-100 min-h-[1050px] relative">
        ${content}
    </div>
</body>
</html>
`;

export const getPrescriptionView = async (req, res) => {
    try {
        const { uuid } = req.params;
        const prescription = await Prescription.findOne({
            where: { prescriptionUuid: uuid },
            include: [
                { 
                    model: Doctor, 
                    include: [{ model: User, attributes: ['firstName', 'lastName'] }] 
                },
                { 
                    model: Appointment,
                    include: ['request']
                },
                { model: User, as: 'patient' }
            ]
        });

        if (!prescription) {
            return res.status(404).send('<h1>Prescription Not Found</h1>');
        }

        const data = prescription.toJSON();
        const doctorName = data.Doctor?.User ? `Dr. ${data.Doctor.User.firstName} ${data.Doctor.User.lastName}` : 'Medical Provider';
        const dateStr = new Date(data.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

        const html = `
            <div class="flex justify-between items-center border-b-2 border-blue-500/20 pb-8 mb-8">
                <div>
                    <div class="flex items-center gap-2 mb-1">
                        <div class="w-8 h-8 bg-blue-600 rounded flex items-center justify-center text-white font-bold">N</div>
                        <h1 class="text-xl font-extrabold tracking-tight">Navala Travel Health</h1>
                    </div>
                    <p class="text-[10px] text-blue-600 font-bold uppercase tracking-widest">Global Telemedicine</p>
                </div>
                <div class="text-right text-[10px] text-slate-400 leading-relaxed">
                    <p>+1 (800) 555-0199</p>
                    <p>care@navala.health</p>
                    <p>New York, NY</p>
                </div>
            </div>

            <div class="flex justify-between items-start mb-12">
                <div>
                    <h2 class="text-5xl font-serif italic text-slate-200 font-black mb-2">Rx</h2>
                    <h3 class="text-2xl font-bold text-slate-900">Medical Prescription</h3>
                    <p class="text-xs font-bold text-slate-400">ID: ${data.prescriptionUuid}</p>
                </div>
                <div class="bg-slate-50 p-4 rounded-xl border border-slate-100 text-right">
                    <p class="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1">Date Issued</p>
                    <p class="text-sm font-bold">${dateStr}</p>
                    <p class="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-4 mb-1">Provider</p>
                    <p class="text-sm font-bold">${doctorName}</p>
                </div>
            </div>

            <div class="bg-blue-50 border border-blue-100 rounded-2xl p-6 mb-10 flex justify-between items-center">
                <div>
                    <p class="text-[10px] font-bold text-blue-600 uppercase tracking-widest mb-1">Patient Name</p>
                    <p class="text-xl font-extrabold text-slate-900">${data.patient?.firstName} ${data.patient?.lastName}</p>
                </div>
                <div class="text-right">
                    <p class="text-[10px] font-bold text-blue-600 uppercase tracking-widest mb-1">Gender / DOB</p>
                    <p class="text-sm font-semibold">${data.patient?.gender || '--'} / ${data.patient?.dateOfBirth || '--'}</p>
                </div>
            </div>

            <div class="mb-10">
                <h4 class="text-sm font-bold text-slate-400 uppercase tracking-widest border-b pb-2 mb-4">Diagnosis</h4>
                <p class="text-lg font-medium text-slate-800">${data.diagnosis}</p>
            </div>

            <div class="mb-10">
                <h4 class="text-sm font-bold text-slate-400 uppercase tracking-widest border-b pb-2 mb-6">Medication Schedule</h4>
                <div class="space-y-8">
                    ${data.medicines?.map((med, i) => `
                        <div class="flex gap-6">
                            <span class="text-xl font-bold text-slate-200">${i + 1}</span>
                            <div class="flex-1">
                                <p class="text-lg font-bold text-slate-900">${med.name}</p>
                                <div class="grid grid-cols-3 gap-8 mt-2">
                                    <div>
                                        <p class="text-[10px] font-bold text-slate-400 uppercase">Dosage</p>
                                        <p class="text-sm font-semibold">${med.dosage}</p>
                                    </div>
                                    <div>
                                        <p class="text-[10px] font-bold text-slate-400 uppercase">Frequency</p>
                                        <p class="text-sm font-semibold">${med.frequency}</p>
                                    </div>
                                    <div>
                                        <p class="text-[10px] font-bold text-slate-400 uppercase">Duration</p>
                                        <p class="text-sm font-semibold">${med.duration}</p>
                                    </div>
                                </div>
                                ${med.foodInstructions ? `<p class="mt-2 text-xs font-bold text-amber-600 bg-amber-50 px-2 py-1 rounded inline-block">Instruction: ${med.foodInstructions}</p>` : ''}
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>

            <div class="grid grid-cols-2 gap-12 mt-12 mb-20">
                ${data.generalAdvice ? `
                    <div>
                        <p class="text-[10px] font-bold text-slate-400 uppercase mb-2">Advice</p>
                        <p class="text-xs text-slate-600 leading-relaxed">${data.generalAdvice}</p>
                    </div>
                ` : ''}
                ${data.restrictions ? `
                    <div>
                        <p class="text-[10px] font-bold text-red-400 uppercase mb-2">Restrictions</p>
                        <p class="text-xs text-red-600 font-bold leading-relaxed">${data.restrictions}</p>
                    </div>
                ` : ''}
            </div>

            <div class="absolute bottom-12 left-12 right-12 flex justify-between items-end border-t border-slate-100 pt-8">
                <p class="text-[9px] text-slate-400">Digitally verified medical document. Valid with provider credentials.</p>
                <div class="text-center w-40">
                    <p class="font-serif italic text-xl text-slate-800 border-b border-slate-800 mb-2">${doctorName.replace('Dr. ', '')}</p>
                    <p class="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Authorized Signature</p>
                </div>
            </div>
        `;

        res.send(wrapInDocument(html, `Prescription_${data.prescriptionUuid.slice(-8)}`));
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};

export const getConfirmationView = async (req, res) => {
    try {
        const { userUuid } = req.params;
        
        // Find user by userUuid OR auto-increment id
        const user = await User.findOne({
            where: {
                [Op.or]: [
                    { userUuid: userUuid },
                    { id: isNaN(userUuid) ? -1 : userUuid }
                ]
            }
        });

        if (!user) return res.status(404).send('User not found');

        const payment = await Payment.findOne({
            where: { userId: user.id, status: 'SUCCESS' },
            include: [Plan],
            order: [['created_at', 'DESC']]
        });

        const dateStr = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
        const plan = payment?.Plan || { name: 'Active Healthcare Plan', amount: 0 };
        const amountStr = payment ? `$${(payment.amount / 100).toFixed(2)}` : 'N/A';

        const html = `
            <div class="flex justify-between items-center mb-12">
                <div class="flex items-center gap-3">
                    <div class="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center text-white font-black text-2xl">N</div>
                    <div>
                        <h1 class="text-2xl font-black tracking-tighter">Navala Travel Health</h1>
                        <p class="text-[10px] font-bold text-blue-600 tracking-[0.2em] uppercase">Premium Confirmation</p>
                    </div>
                </div>
                <div class="text-right">
                    <span class="bg-green-100 text-green-700 text-[10px] font-black px-3 py-1 rounded-full border border-green-200">PAYMENT SUCCESSFUL</span>
                </div>
            </div>

            <div class="border-y border-slate-100 py-8 mb-12 flex justify-between items-center">
                <div>
                    <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Transaction ID</p>
                    <p class="text-sm font-mono font-bold text-slate-800">${payment?.stripePaymentIntentId || 'NTH-TEST-INTENT'}</p>
                </div>
                <div class="text-right">
                    <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Invoice Date</p>
                    <p class="text-sm font-bold text-slate-800">${dateStr}</p>
                </div>
            </div>

            <h3 class="text-xl font-extrabold text-slate-900 mb-6">Plan Summary</h3>
            <div class="bg-slate-50 rounded-2xl p-8 border border-slate-100 mb-8">
                <div class="flex justify-between items-center mb-6">
                    <div>
                        <p class="text-2xl font-black text-blue-600">${plan.name}</p>
                        <p class="text-sm text-slate-500 font-medium">Annual Travel Coverage</p>
                    </div>
                    <div class="text-right">
                        <p class="text-2xl font-black text-slate-900">${amountStr}</p>
                        <p class="text-xs text-slate-400 font-bold uppercase">Total Paid</p>
                    </div>
                </div>
                
                <div class="space-y-4 pt-6 border-t border-slate-200">
                    <div class="flex justify-between items-center">
                        <p class="text-sm font-bold text-slate-700">Account Holder</p>
                        <p class="text-sm font-medium text-slate-900">${user.firstName} ${user.lastName}</p>
                    </div>
                    <div class="flex justify-between items-center">
                        <p class="text-sm font-bold text-slate-700">Membership UUID</p>
                        <p class="text-sm font-mono text-slate-500">${user.userUuid || 'N/A'}</p>
                    </div>
                </div>
            </div>

            <div class="mt-12">
                <h4 class="text-xs font-black text-slate-400 uppercase tracking-widest mb-4">Included Services</h4>
                <div class="grid grid-cols-2 gap-4">
                    <div class="flex items-center gap-3 bg-white border border-slate-100 p-4 rounded-xl">
                        <div class="w-2 h-2 bg-blue-500 rounded-full"></div>
                        <p class="text-xs font-bold text-slate-700">24/7 Virtual Care</p>
                    </div>
                    <div class="flex items-center gap-3 bg-white border border-slate-100 p-4 rounded-xl">
                        <div class="w-2 h-2 bg-blue-500 rounded-full"></div>
                        <p class="text-xs font-bold text-slate-700">Global Coverage</p>
                    </div>
                    <div class="flex items-center gap-3 bg-white border border-slate-100 p-4 rounded-xl">
                        <div class="w-2 h-2 bg-blue-500 rounded-full"></div>
                        <p class="text-xs font-bold text-slate-700">Specialist Referrals</p>
                    </div>
                    <div class="flex items-center gap-3 bg-white border border-slate-100 p-4 rounded-xl">
                        <div class="w-2 h-2 bg-blue-500 rounded-full"></div>
                        <p class="text-xs font-bold text-slate-700">Prescription Savings</p>
                    </div>
                </div>
            </div>

            <div class="mt-20 p-8 border-2 border-dashed border-slate-100 rounded-3xl text-center">
                <p class="text-slate-400 text-xs mb-2">Thank you for choosing Navala Travel Health</p>
                <p class="text-slate-800 font-extrabold">Your coverage is now active.</p>
            </div>
        `;

        res.send(wrapInDocument(html, 'Plan_Confirmation'));
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};

export const getContractView = async (req, res) => {
    try {
        const { userUuid } = req.params;
        const user = await User.findOne({
            where: {
                [Op.or]: [
                    { userUuid: userUuid },
                    { id: isNaN(userUuid) ? -1 : userUuid }
                ]
            }
        });

        if (!user) return res.status(404).send('User not found');

        const dateStr = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

        const html = `
            <div class="flex justify-between items-start mb-16">
                <div>
                    <h1 class="text-3xl font-black tracking-tight mb-1">Service Contract</h1>
                    <p class="text-sm font-bold text-blue-600 uppercase tracking-widest">Legal Agreement</p>
                </div>
                <div class="text-right">
                    <p class="text-[10px] font-bold text-slate-400 uppercase">Effective Date</p>
                    <p class="text-sm font-bold text-slate-900">${dateStr}</p>
                </div>
            </div>

            <div class="prose prose-slate max-w-none text-xs leading-relaxed text-slate-700 space-y-6">
                <p>This Medical Services Agreement ("Agreement") is entered into between **Navala Travel Health LLC** ("Provider") and **${user.firstName} ${user.lastName}** ("Member").</p>
                
                <h4 class="text-sm font-black text-slate-900 uppercase">1. Scope of Services</h4>
                <p>Provider agrees to facilitate access to healthcare services, including but not limited to telemedicine consultations, prescription management, and medical coordination during Member's international travel. These services are provided through a network of licensed medical professionals.</p>

                <h4 class="text-sm font-black text-slate-900 uppercase">2. Member Responsibilities</h4>
                <p>Member agrees to provide accurate medical history, current medications, and travel itinerary information. Member understands that telemedicine has limitations and agrees to seek local emergency care if a life-threatening situation arises.</p>

                <h4 class="text-sm font-black text-slate-900 uppercase">3. Privacy and Data</h4>
                <p>Provider handles Member's medical information in accordance with HIPAA-compliant standards (or equivalent international privacy laws). Data is encrypted and only shared with necessary medical personnel involved in Member's care.</p>

                <h4 class="text-sm font-black text-slate-900 uppercase">4. Liability Limitation</h4>
                <p>Provider acts as a facilitator of care. While Provider ensures high standards for its network, Provider is not liable for outcomes related to the clinical judgment of independent medical practitioners or third-party facilities.</p>

                <h4 class="text-sm font-black text-slate-900 uppercase">5. Term and Termination</h4>
                <p>This agreement remains in effect for the duration of the Member's active subscription plan. Either party may terminate the agreement with written notice, subject to the terms of the specific plan purchased.</p>
            </div>

            <div class="mt-20 pt-12 border-t border-slate-100 flex justify-between">
                <div class="w-56">
                    <div class="border-b border-slate-900 pb-2 mb-2 min-h-[40px]"></div>
                    <p class="text-[9px] font-bold text-slate-400 uppercase">Navala Travel Health Authorized Signatory</p>
                </div>
                <div class="w-56 text-right">
                    <p class="font-serif italic text-lg text-slate-800 border-b border-slate-900 pb-2 mb-2 min-h-[40px] text-right">${user.firstName} ${user.lastName}</p>
                    <p class="text-[9px] font-bold text-slate-400 uppercase">Member Digital Signature</p>
                    <p class="text-[8px] text-slate-300 mt-1">ID: ${user.userUuid || user.id}</p>
                </div>
            </div>
        `;

        res.send(wrapInDocument(html, 'Service_Contract'));
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};
