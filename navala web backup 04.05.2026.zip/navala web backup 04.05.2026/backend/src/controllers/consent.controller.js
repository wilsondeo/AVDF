import { getConsentSections } from '../services/consent.service.js';

/**
 * Consent Controller
 * Handles requests for legal and telehealth consent content
 */

/**
 * Get all consent sections
 * @param {import('express').Request} req
 * @param {import('express').Response} res
 */
export async function getConsentController(req, res) {
  try {
    const sections = await getConsentSections();
    
    res.json({
      success: true,
      message: 'Consent content retrieved successfully',
      data: {
        sections
      },
    });
  } catch (error) {
    console.error('Error fetching consent content:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to fetch consent content',
      error: error.message,
    });
  }
}
