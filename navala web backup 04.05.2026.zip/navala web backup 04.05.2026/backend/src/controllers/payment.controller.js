import { getStripeClient, getStripeWebhookSecret } from '../config/stripe.js';
import {
  createPaymentIntentForPlan,
  handlePaymentIntentSucceeded,
  markPaymentFailed,
  getUserActivePlanWithDetails,
  getUserPayments,
} from '../services/payment.service.js';

/**
 * Payment Controller
 * - No business logic here
 * - Delegates to services
 */

export async function createIntentController(req, res) {
  try {
    const { planId, taxAmount } = req.body;

    if (!planId) {
      return res.status(400).json({ success: false, message: 'planId is required' });
    }

    const result = await createPaymentIntentForPlan({
      userId: req.user.id,
      planBusinessId: planId,
      taxAmount: taxAmount || 0,
    });

    return res.status(201).json({
      success: true,
      message: 'Payment intent created',
      data: {
        ...result,
        amountCharged: result.amountChargedCents != null ? result.amountChargedCents / 100 : undefined,
      },
    });
  } catch (error) {
    return res.status(400).json({
      success: false,
      message: error.message || 'Failed to create payment intent',
    });
  }
}

/**
 * Stripe webhook handler
 * - MUST verify signature
 * - Trust only webhook for success
 */
export async function webhookController(req, res) {
  const stripe = getStripeClient();
  const webhookSecret = getStripeWebhookSecret();

  const signature = req.headers['stripe-signature'];
  if (!signature) {
    return res.status(400).send('Missing Stripe signature');
  }

  // raw body is required for constructEvent
  const rawBody = req.rawBody;
  if (!rawBody) {
    return res.status(400).send('Missing raw request body');
  }

  let event;
  try {
    event = stripe.webhooks.constructEvent(rawBody, signature, webhookSecret);
  } catch (err) {
    return res.status(400).send(`Webhook signature verification failed: ${err.message}`);
  }

  try {
    switch (event.type) {
      case 'payment_intent.succeeded': {
        const intent = event.data.object;
        await handlePaymentIntentSucceeded({ stripePaymentIntentId: intent.id });
        break;
      }
      case 'payment_intent.payment_failed': {
        const intent = event.data.object;
        await markPaymentFailed(intent.id);
        break;
      }
      default:
        // Ignore other events
        break;
    }

    return res.json({ received: true });
  } catch (error) {
    // Return 200 to avoid Stripe retries for internal errors? In prod you may prefer 500.
    // Here we return 500 so Stripe retries and we keep consistency guarantees.
    return res.status(500).json({ success: false, message: error.message || 'Webhook handler failed' });
  }
}

/**
 * Get user's active plan
 * GET /user/plan
 */
export async function getUserPlanController(req, res) {
  try {
    const activePlan = await getUserActivePlanWithDetails(req.user.id);

    return res.json({
      success: true,
      message: 'User plan fetched',
      data: { activePlan },
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to fetch user plan',
    });
  }
}

/**
 * Get user's payment history (latest first)
 * GET /payments/my
 */
export async function getMyPaymentsController(req, res) {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit, 10) : 20;
    const offset = req.query.offset ? parseInt(req.query.offset, 10) : 0;

    const payments = await getUserPayments(req.user.id, { limit, offset });

    return res.json({
      success: true,
      message: 'Payments retrieved successfully',
      data: { payments, count: payments.length },
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to fetch payments',
    });
  }
}
