import SystemConfig from '../models/SystemConfig.js';

/**
 * Get all system configurations
 */
export const getAllConfigs = async (req, res) => {
  try {
    const configs = await SystemConfig.findAll();
    res.json({ success: true, data: configs });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/**
 * Update clinical settings (Global Tax Toggle and Strategy)
 */
export const updateTaxSettings = async (req, res) => {
  const { is_location_tax_enabled, multi_city_tax_strategy } = req.body;
  
  try {
    if (is_location_tax_enabled !== undefined) {
      await SystemConfig.upsert({
        configKey: 'is_location_tax_enabled',
        configValue: String(is_location_tax_enabled)
      });
    }
    
    if (multi_city_tax_strategy !== undefined) {
      await SystemConfig.upsert({
        configKey: 'multi_city_tax_strategy',
        configValue: multi_city_tax_strategy
      });
    }
    
    res.json({ success: true, message: 'Tax settings updated successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/**
 * Get specific setting by key
 */
export const getSetting = async (req, res) => {
  const { key } = req.params;
  try {
    const config = await SystemConfig.findOne({ where: { configKey: key } });
    if (!config) {
      return res.status(404).json({ success: false, message: 'Setting not found' });
    }
    res.json({ success: true, data: config.configValue });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
