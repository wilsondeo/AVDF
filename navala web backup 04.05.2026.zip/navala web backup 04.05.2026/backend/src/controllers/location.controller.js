import Location, { getAllLocations } from '../models/Location.js';

/**
 * Location Controller
 * Handles requests related to locations
 */

/**
 * Get all locations
 */
export async function getAllLocationsController(req, res) {
  try {
    const locations = await getAllLocations();
    res.json({
      success: true,
      data: locations,
    });
  } catch (error) {
    console.error('Error fetching locations:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch locations',
      error: error.message,
    });
  }
}

/**
 * Create a new location (Admin)
 */
export async function createLocationController(req, res) {
  const { country, city, state, taxValue, taxType, isTaxEnabled } = req.body;
  try {
    const location = await Location.create({
      country,
      city,
      state,
      taxValue,
      taxType: taxType || 'FIXED',
      isTaxEnabled
    });
    res.json({ success: true, data: location });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to create location', error: error.message });
  }
}

/**
 * Update a location (Admin)
 */
export async function updateLocationController(req, res) {
  const { id } = req.params;
  const { country, city, state, taxValue, taxType, isTaxEnabled } = req.body;
  try {
    const location = await Location.findByPk(id);
    if (!location) {
      return res.status(404).json({ success: false, message: 'Location not found' });
    }

    await location.update({ country, city, state, taxValue, taxType, isTaxEnabled });
    res.json({ success: true, data: location });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to update location', error: error.message });
  }
}

/**
 * Delete a location (Admin)
 */
export async function deleteLocationController(req, res) {
  const { id } = req.params;
  try {
    const location = await Location.findByPk(id);
    if (!location) {
      return res.status(404).json({ success: false, message: 'Location not found' });
    }

    await location.destroy();
    res.json({ success: true, message: 'Location deleted successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to delete location', error: error.message });
  }
}
