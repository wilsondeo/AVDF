import {
  getAllAppointmentRequests,
  assignDoctorToRequest,
  updateRequestStatus,
  getAllAppointmentsForAdmin,
} from '../services/appointment.service.js';
import AppointmentRequest from '../models/AppointmentRequest.js';
import Appointment from '../models/Appointment.js';
import Prescription from '../models/Prescription.js';

/**
 * Admin-facing appointment controllers
 */

export async function getAllAppointmentRequestsController(req, res) {
  try {
    const { status } = req.query;
    const requests = await getAllAppointmentRequests({ status });
    const list = Array.isArray(requests) ? requests : [];

    return res.json({
      success: true,
      message: 'Appointment requests fetched',
      data: list.map((r) => {
        const patient = r.patient;
        const plan = r.plan;
        return {
          requestUuid: r.requestUuid,
          status: r.status,
          serviceType: r.serviceType,
          country: r.country ?? null,
          state: r.state ?? null,
          city: r.city,
          preferredDate: r.preferredDate ?? null,
          patient: patient
            ? {
                id: patient.id,
                firstName: patient.firstName,
                lastName: patient.lastName,
                email: patient.email,
              }
            : null,
          familyMember: r.familyMember 
            ? {
                id: r.familyMember.id,
                firstName: r.familyMember.firstName,
                lastName: r.familyMember.lastName,
                relationship: r.familyMember.relationship
              }
            : null,
          plan: plan ? { planId: plan.planId, name: plan.name } : null,
          createdAt: r.createdAt ?? r.created_at,
          assignedDoctor: r.assignedDoctor || null,
          patientDetails: {
            age: r.age,
            gender: r.gender,
            emergencyContact: r.emergencyContact,
            notes: r.notes ?? null,
            allergies: r.allergies ?? null,
            country: r.country ?? null,
            state: r.state ?? null,
            city: r.city ?? null,
          },
        };
      }),
    });
  } catch (error) {
    const message = error?.message || 'Failed to fetch appointment requests';
    console.error('[getAllAppointmentRequests]', message, error?.stack || error);
    return res.status(500).json({
      success: false,
      message,
    });
  }
}

export async function assignDoctorController(req, res) {
  try {
    const { requestUuid, doctorUuid, appointmentDate } = req.body || {};

    if (!requestUuid || !doctorUuid) {
      return res.status(400).json({
        success: false,
        message: 'requestUuid and doctorUuid are required',
      });
    }

    const appointment = await assignDoctorToRequest({ requestUuid, doctorUuid, appointmentDate });

    return res.status(201).json({
      success: true,
      message: 'Doctor assigned and appointment created',
      data: {
        appointmentUuid: appointment.appointmentUuid,
        status: appointment.status,
      },
    });
  } catch (error) {
    return res.status(error.status || 400).json({
      success: false,
      message: error.message || 'Failed to assign doctor',
    });
  }
}

/**
 * Admin: update appointment request status.
 * PATCH /api/admin/appointment-requests/:requestUuid/status
 * Body: { status: 'PENDING' | 'ASSIGNED' | 'CANCELLED' }
 */
export async function updateRequestStatusController(req, res) {
  try {
    const { requestUuid } = req.params;
    const { status } = req.body || {};
    if (!requestUuid) {
      return res.status(400).json({ success: false, message: 'requestUuid is required' });
    }
    const updated = await updateRequestStatus({ requestUuid, status });
    return res.json({
      success: true,
      message: 'Status updated',
      data: { requestUuid: updated.requestUuid, status: updated.status },
    });
  } catch (error) {
    return res.status(error.status || 500).json({
      success: false,
      message: error.message || 'Failed to update status',
    });
  }
}

/**
 * Admin: get all appointments (confirmed bookings with assigned doctors).
 */
export async function getAllAppointmentsController(req, res) {
  try {
    const appointments = await getAllAppointmentsForAdmin();
    return res.json({
      success: true,
      message: 'Appointments fetched',
      data: appointments,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to fetch appointments',
    });
  }
}
/**
 * Admin: permanently delete an appointment request from the database.
 * DELETE /api/admin/appointment-requests/:requestUuid
 */
export async function deleteAppointmentRequestController(req, res) {
  try {
    const { requestUuid } = req.params;
    if (!requestUuid) {
      return res.status(400).json({ success: false, message: 'requestUuid is required' });
    }

    const request = await AppointmentRequest.findOne({ where: { requestUuid } });
    if (!request) {
      return res.status(404).json({ success: false, message: 'Booking request not found' });
    }

    const appointments = await Appointment.findAll({ where: { requestId: request.id } });
    for (const apt of appointments) {
      // Delete prescriptions (medicines will cascade from prescription)
      await Prescription.destroy({ where: { appointmentId: apt.id } });
      // Delete the appointment itself
      await apt.destroy();
    }

    await request.destroy();

    return res.json({
      success: true,
      message: 'Booking request permanently deleted',
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to delete booking request',
    });
  }
}
