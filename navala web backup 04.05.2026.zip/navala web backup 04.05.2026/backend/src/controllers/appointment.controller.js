import {
  createAppointmentRequestForPatient,
  getAppointmentRequestsForPatient,
} from '../services/appointment.service.js';

/**
 * Patient-facing appointment controllers
 */

export async function createAppointmentRequestController(req, res) {
  try {
    const patientId = req.user.id;
    const { country, state, city, age, gender, emergencyContact, serviceType, notes, allergies, familyMemberId, appointmentDate } = req.body || {};

    const request = await createAppointmentRequestForPatient(patientId, {
      country,
      state,
      city,
      age,
      gender,
      emergencyContact,
      serviceType,
      notes,
      allergies,
      familyMemberId,
      appointmentDate,
    });

    return res.status(201).json({
      success: true,
      message: 'Appointment request created',
      data: {
        requestUuid: request.requestUuid,
      },
    });
  } catch (error) {
    return res.status(error.status || 400).json({
      success: false,
      message: error.message || 'Failed to create appointment request',
    });
  }
}

export async function getMyAppointmentRequestsController(req, res) {
  try {
    const patientId = req.user.id;
    const requests = await getAppointmentRequestsForPatient(patientId);

    return res.json({
      success: true,
      message: 'Appointment requests fetched',
      data: requests.map((r) => ({
        requestUuid: r.requestUuid,
        serviceType: r.serviceType,
        status: r.status,
        city: r.city,
        createdAt: r.created_at,
        preferredDate: r.preferredDate,
        familyMember: r.familyMember ? {
          firstName: r.familyMember.firstName,
          lastName: r.familyMember.lastName,
          relationship: r.familyMember.relationship
        } : null,
        ...(r.status === 'ASSIGNED' && r.appointmentUuid && { appointmentUuid: r.appointmentUuid }),
        ...(r.status === 'ASSIGNED' && r.assignedDoctor && { assignedDoctor: r.assignedDoctor }),
      })),
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to fetch appointment requests',
    });
  }
}

