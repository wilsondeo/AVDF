import { createDoctor, bulkUploadDoctors, listDoctors, getDoctorById, updateDoctor, deleteDoctor, sendDoctorCredentialsById } from '../services/adminDoctor.service.js';
import { parseCsv } from '../utils/csv.util.js';

export async function getAllDoctorsController(req, res) {
    try {
        const doctors = await listDoctors();
        res.json({
            success: true,
            data: doctors.map(d => d.toJSON ? d.toJSON() : d),
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
}

export async function getDoctorController(req, res) {
    try {
        const doctorId = parseInt(req.params.id, 10);
        if (isNaN(doctorId)) {
            return res.status(400).json({ success: false, message: 'Invalid doctor id' });
        }
        const doctor = await getDoctorById(doctorId);
        if (!doctor) {
            return res.status(404).json({ success: false, message: 'Doctor not found' });
        }
        res.json({ success: true, data: doctor });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

export async function createDoctorController(req, res) {
    try {
        const { name, email, password, phone, city, specialization, yearsOfExperience, sendEmail } = req.body;

        if (!name || !email || !specialization) {
            return res.status(400).json({
                success: false,
                message: 'Name, Email, and Specialization are required.',
            });
        }

        const doctor = await createDoctor({
            name,
            email,
            password: password || undefined,
            phone,
            city,
            specialization,
            yearsOfExperience: parseInt(yearsOfExperience, 10) || 0,
        }, sendEmail === true || sendEmail === 'true');

        res.status(201).json({
            success: true,
            message: 'Doctor created successfully',
            data: doctor,
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: error.message,
        });
    }
}

export async function updateDoctorController(req, res) {
    try {
        const doctorId = parseInt(req.params.id, 10);
        if (isNaN(doctorId)) {
            return res.status(400).json({ success: false, message: 'Invalid doctor id' });
        }
        const { name, email, phone, city, specialization, yearsOfExperience, password, isActive } = req.body;
        const doctor = await updateDoctor(doctorId, {
            name,
            email,
            phone,
            city,
            specialization,
            yearsOfExperience,
            password,
            isActive,
        });
        res.json({ success: true, message: 'Doctor updated', data: doctor });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
}

export async function deleteDoctorController(req, res) {
    try {
        const doctorId = parseInt(req.params.id, 10);
        if (isNaN(doctorId)) {
            return res.status(400).json({ success: false, message: 'Invalid doctor id' });
        }
        await deleteDoctor(doctorId);
        res.json({ success: true, message: 'Doctor deleted' });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
}

export async function sendDoctorEmailController(req, res) {
    try {
        const doctorId = parseInt(req.params.id, 10);
        if (isNaN(doctorId)) {
            return res.status(400).json({ success: false, message: 'Invalid doctor id' });
        }
        await sendDoctorCredentialsById(doctorId);
        res.json({ success: true, message: 'Credentials email sent to doctor' });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
}

export async function uploadDoctorsController(req, res) {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: 'No file uploaded',
            });
        }

        const sendEmail = req.body.sendEmail === 'true' || req.body.sendEmail === true;

        // Parse CSV
        const rows = await parseCsv(req.file.buffer);

        if (rows.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'CSV file is empty',
            });
        }

        const summary = await bulkUploadDoctors(rows, sendEmail);

        res.json({
            success: true,
            message: 'Bulk upload processed',
            data: summary,
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message || 'Failed to process CSV',
        });
    }
}
