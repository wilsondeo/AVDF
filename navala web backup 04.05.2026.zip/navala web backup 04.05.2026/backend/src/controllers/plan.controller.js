import {
  createPlanService,
  updatePlanService,
  deletePlanService,
  getAllPlansService,
  getActivePlansService,
  getPlanByPlanIdService,
} from '../services/plan.service.js';

/**
 * Plan Controller
 * Handles HTTP requests for plan endpoints
 */

/**
 * Create a new plan (Admin only)
 * POST /admin/plans
 */
export async function createPlanController(req, res) {
  try {
    const planData = req.body;
    
    // Validate required fields
    if (!planData.name || planData.price === undefined || !planData.validityDays) {
      return res.status(400).json({
        success: false,
        message: 'Name, price, and validityDays are required',
      });
    }
    
    const plan = await createPlanService(planData);
    
    res.status(201).json({
      success: true,
      message: 'Plan created successfully',
      data: { plan },
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message || 'Failed to create plan',
    });
  }
}

/**
 * Update plan (Admin only)
 * PUT /admin/plans/:planId
 */
export async function updatePlanController(req, res) {
  try {
    const { planId } = req.params;
    const updates = req.body;
    
    const plan = await updatePlanService(planId, updates);
    
    res.json({
      success: true,
      message: 'Plan updated successfully',
      data: { plan },
    });
  } catch (error) {
    const statusCode = error.message === 'Plan not found' ? 404 : 400;
    res.status(statusCode).json({
      success: false,
      message: error.message || 'Failed to update plan',
    });
  }
}

/**
 * Delete plan (Admin only - soft delete)
 * DELETE /admin/plans/:planId
 */
export async function deletePlanController(req, res) {
  try {
    const { planId } = req.params;
    
    await deletePlanService(planId);
    
    res.json({
      success: true,
      message: 'Plan deleted successfully',
    });
  } catch (error) {
    const statusCode = error.message === 'Plan not found' ? 404 : 400;
    res.status(statusCode).json({
      success: false,
      message: error.message || 'Failed to delete plan',
    });
  }
}

/**
 * Get all plans (Admin only - includes inactive)
 * GET /admin/plans
 */
export async function getAllPlansController(req, res) {
  try {
    const { limit, offset } = req.query;
    
    const options = {};
    if (limit) options.limit = parseInt(limit, 10);
    if (offset) options.offset = parseInt(offset, 10);
    
    const plans = await getAllPlansService(options);
    
    res.json({
      success: true,
      message: 'Plans retrieved successfully',
      data: {
        plans,
        count: plans.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to retrieve plans',
    });
  }
}

/**
 * Get active plans (Public)
 * GET /plans
 */
export async function getActivePlansController(req, res) {
  try {
    const plans = await getActivePlansService();
    
    res.json({
      success: true,
      message: 'Active plans retrieved successfully',
      data: {
        plans,
        count: plans.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to retrieve plans',
    });
  }
}

/**
 * Get plan by planId (Admin only)
 * GET /admin/plans/:planId
 */
export async function getPlanByPlanIdController(req, res) {
  try {
    const { planId } = req.params;
    
    const plan = await getPlanByPlanIdService(planId, true); // Admin can see inactive
    
    res.json({
      success: true,
      message: 'Plan retrieved successfully',
      data: { plan },
    });
  } catch (error) {
    res.status(404).json({
      success: false,
      message: error.message || 'Plan not found',
    });
  }
}
