import UserItinerary from '../models/UserItinerary.js';
import Location from '../models/Location.js';

/**
 * Get user itineraries
 */
export const getUserItineraries = async (req, res) => {
  const userId = req.user?.id || req.params.userId;
  try {
    const itineraries = await UserItinerary.findAll({
      where: { userId },
      include: [
        {
          model: Location,
          as: 'location',
          attributes: ['city', 'state', 'country', 'taxValue']
        }
      ],
      order: [['visitOrder', 'ASC']]
    });
    res.json({ success: true, data: itineraries });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch itineraries', error: error.message });
  }
};

/**
 * Save user itinerary (typically after purchase or during checkout simulation)
 */
export const saveUserItinerary = async (req, res) => {
  const userId = req.user.id;
  const { destinations, paymentId } = req.body; // destinations is an array of {locationId, arrivalDate, departureDate, taxPaid}
  
  try {
    // Delete existing itinerary items for this trip if paymentId is the same or if restarting
    // (In a real scenario, you'd match by trip/payment)
    
    const itineraryItems = destinations.map((dest, index) => ({
      userId,
      paymentId,
      locationId: dest.locationId,
      arrivalDate: dest.arrivalDate,
      departureDate: dest.departureDate,
      taxPaid: dest.taxPaid || 0,
      visitOrder: index + 1
    }));
    
    await UserItinerary.bulkCreate(itineraryItems);
    res.json({ success: true, message: 'Itinerary saved successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to save itinerary', error: error.message });
  }
};

/**
 * Clear user itinerary
 */
export const clearUserItinerary = async (req, res) => {
  const userId = req.user.id;
  try {
    await UserItinerary.destroy({ where: { userId, paymentId: null } }); // Clear pending/unsaved
    res.json({ success: true, message: 'Itinerary cleared' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to clear itinerary', error: error.message });
  }
};
