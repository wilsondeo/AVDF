import PatientMedication from '../models/PatientMedication.js';
import MedicationTaken from '../models/MedicationTaken.js';
import PatientVital from '../models/PatientVital.js';

const today = () => new Date().toISOString().slice(0, 10);

// ---------- Medications ----------

export async function getMedications(req, res) {
  try {
    const userId = req.user.id;
    const meds = await PatientMedication.findAll({
      where: { userId },
      order: [['timeOfDay', 'ASC'], ['sortOrder', 'ASC'], ['id', 'ASC']],
    });
    const todayDate = today();
    const takenRows = await MedicationTaken.findAll({
      where: { userId, date: todayDate },
    });
    const takenByMedId = Object.fromEntries(takenRows.map((t) => [t.medicationId, t.taken]));
    const list = meds.map((m) => {
      const j = m.toJSON();
      return {
        id: j.id,
        name: j.name,
        dosage: j.dosage,
        time: j.timeOfDay,
        taken: !!takenByMedId[j.id],
      };
    });
    return res.json({ success: true, data: list });
  } catch (e) {
    return res.status(500).json({ success: false, message: e.message || 'Failed to get medications' });
  }
}

export async function addMedication(req, res) {
  try {
    const userId = req.user.id;
    const { name, dosage, timeOfDay } = req.body;
    if (!name || !dosage || !timeOfDay) {
      return res.status(400).json({ success: false, message: 'name, dosage, and timeOfDay are required' });
    }
    const validTimes = ['morning', 'afternoon', 'evening'];
    if (!validTimes.includes(timeOfDay)) {
      return res.status(400).json({ success: false, message: 'timeOfDay must be morning, afternoon, or evening' });
    }
    const med = await PatientMedication.create({
      userId,
      name: String(name).trim(),
      dosage: String(dosage).trim(),
      timeOfDay,
    });
    const j = med.toJSON();
    return res.status(201).json({
      success: true,
      data: { id: j.id, name: j.name, dosage: j.dosage, time: j.timeOfDay, taken: false },
    });
  } catch (e) {
    return res.status(500).json({ success: false, message: e.message || 'Failed to add medication' });
  }
}

export async function updateMedication(req, res) {
  try {
    const userId = req.user.id;
    const id = parseInt(req.params.id, 10);
    const { name, dosage, timeOfDay } = req.body;
    const med = await PatientMedication.findOne({ where: { id, userId } });
    if (!med) return res.status(404).json({ success: false, message: 'Medication not found' });
    if (name !== undefined) med.name = String(name).trim();
    if (dosage !== undefined) med.dosage = String(dosage).trim();
    if (timeOfDay !== undefined) {
      const validTimes = ['morning', 'afternoon', 'evening'];
      if (!validTimes.includes(timeOfDay)) {
        return res.status(400).json({ success: false, message: 'timeOfDay must be morning, afternoon, or evening' });
      }
      med.timeOfDay = timeOfDay;
    }
    await med.save();
    const j = med.toJSON();
    const todayDate = today();
    const takenRow = await MedicationTaken.findOne({
      where: { userId, medicationId: id, date: todayDate },
    });
    return res.json({
      success: true,
      data: {
        id: j.id,
        name: j.name,
        dosage: j.dosage,
        time: j.timeOfDay,
        taken: !!takenRow?.taken,
      },
    });
  } catch (e) {
    return res.status(500).json({ success: false, message: e.message || 'Failed to update medication' });
  }
}

export async function setMedicationTaken(req, res) {
  try {
    const userId = req.user.id;
    const id = parseInt(req.params.id, 10);
    const { taken } = req.body;
    const med = await PatientMedication.findOne({ where: { id, userId } });
    if (!med) return res.status(404).json({ success: false, message: 'Medication not found' });
    const todayDate = today();
    let row = await MedicationTaken.findOne({
      where: { userId, medicationId: id, date: todayDate },
    });
    if (row) {
      row.taken = !!taken;
      await row.save();
    } else {
      row = await MedicationTaken.create({
        userId,
        medicationId: id,
        date: todayDate,
        taken: !!taken,
      });
    }
    return res.json({ success: true, data: { taken: !!row.taken } });
  } catch (e) {
    return res.status(500).json({ success: false, message: e.message || 'Failed to set taken' });
  }
}

// ---------- Vitals ----------

export async function getVitals(req, res) {
  try {
    const userId = req.user.id;
    const limit = Math.min(parseInt(req.query.limit, 10) || 1, 50);
    const vitals = await PatientVital.findAll({
      where: { userId },
      order: [['recordedAt', 'DESC']],
      limit,
    });
    const list = vitals.map((v) => {
      const j = v.toJSON();
      return {
        id: j.id,
        heartRate: j.heartRate,
        bloodPressureSystolic: j.bloodPressureSystolic,
        bloodPressureDiastolic: j.bloodPressureDiastolic,
        temperature: j.temperature != null ? parseFloat(j.temperature) : null,
        oxygenLevel: j.oxygenLevel,
        recordedAt: j.recordedAt,
      };
    });
    return res.json({ success: true, data: list });
  } catch (e) {
    return res.status(500).json({ success: false, message: e.message || 'Failed to get vitals' });
  }
}

export async function addVitals(req, res) {
  try {
    const userId = req.user.id;
    const { heartRate, bloodPressureSystolic, bloodPressureDiastolic, temperature, oxygenLevel } = req.body;
    const recordedAt = req.body.recordedAt ? new Date(req.body.recordedAt) : new Date();
    const vital = await PatientVital.create({
      userId,
      heartRate: heartRate != null ? parseInt(heartRate, 10) : null,
      bloodPressureSystolic: bloodPressureSystolic != null ? parseInt(bloodPressureSystolic, 10) : null,
      bloodPressureDiastolic: bloodPressureDiastolic != null ? parseInt(bloodPressureDiastolic, 10) : null,
      temperature: temperature != null && temperature !== '' ? parseFloat(temperature) : null,
      oxygenLevel: oxygenLevel != null ? parseInt(oxygenLevel, 10) : null,
      recordedAt,
    });
    const j = vital.toJSON();
    return res.status(201).json({
      success: true,
      data: {
        id: j.id,
        heartRate: j.heartRate,
        bloodPressureSystolic: j.bloodPressureSystolic,
        bloodPressureDiastolic: j.bloodPressureDiastolic,
        temperature: j.temperature != null ? parseFloat(j.temperature) : null,
        oxygenLevel: j.oxygenLevel,
        recordedAt: j.recordedAt,
      },
    });
  } catch (e) {
    return res.status(500).json({ success: false, message: e.message || 'Failed to add vitals' });
  }
}

export async function updateVitals(req, res) {
  try {
    const userId = req.user.id;
    const id = parseInt(req.params.id, 10);
    const vital = await PatientVital.findOne({ where: { id, userId } });
    if (!vital) return res.status(404).json({ success: false, message: 'Vital record not found' });
    const { heartRate, bloodPressureSystolic, bloodPressureDiastolic, temperature, oxygenLevel, recordedAt } = req.body;
    if (heartRate !== undefined) vital.heartRate = heartRate == null ? null : parseInt(heartRate, 10);
    if (bloodPressureSystolic !== undefined) vital.bloodPressureSystolic = bloodPressureSystolic == null ? null : parseInt(bloodPressureSystolic, 10);
    if (bloodPressureDiastolic !== undefined) vital.bloodPressureDiastolic = bloodPressureDiastolic == null ? null : parseInt(bloodPressureDiastolic, 10);
    if (temperature !== undefined) vital.temperature = temperature === '' || temperature == null ? null : parseFloat(temperature);
    if (oxygenLevel !== undefined) vital.oxygenLevel = oxygenLevel == null ? null : parseInt(oxygenLevel, 10);
    if (recordedAt !== undefined) vital.recordedAt = new Date(recordedAt);
    await vital.save();
    const j = vital.toJSON();
    return res.json({
      success: true,
      data: {
        id: j.id,
        heartRate: j.heartRate,
        bloodPressureSystolic: j.bloodPressureSystolic,
        bloodPressureDiastolic: j.bloodPressureDiastolic,
        temperature: j.temperature != null ? parseFloat(j.temperature) : null,
        oxygenLevel: j.oxygenLevel,
        recordedAt: j.recordedAt,
      },
    });
  } catch (e) {
    return res.status(500).json({ success: false, message: e.message || 'Failed to update vitals' });
  }
}
