import { getAppointmentsForDoctor } from '../services/appointment.service.js';

/**
 * Doctor-facing appointment controllers
 */

export async function getDoctorAppointmentsController(req, res) {
  try {
    const doctorUserId = req.user.id;
    const appointments = await getAppointmentsForDoctor(doctorUserId);

    return res.json({
      success: true,
      message: 'Appointments fetched',
      data: appointments.map((a) => ({
        appointmentUuid: a.appointmentUuid,
        requestUuid: a.request?.requestUuid,
        city: a.request?.city ?? null,
        serviceType: a.serviceType,
        status: a.status,
        appointmentDate: a.appointmentDate,
        patient: a.patient ? {
          id: a.patient.id,
          firstName: a.patient.firstName,
          lastName: a.patient.lastName,
          email: a.patient.email,
        } : null,
        familyMember: a.request?.familyMember ? {
          firstName: a.request.familyMember.firstName,
          lastName: a.request.familyMember.lastName,
          relationship: a.request.familyMember.relationship || null,
        } : null,
        patientDetails: a.request ? {
          age: a.request.age,
          gender: a.request.gender,
          emergencyContact: a.request.emergencyContact,
          notes: a.request.notes || null,
          allergies: a.request.allergies || null,
        } : null,
      })),
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to fetch doctor appointments',
    });
  }
}

