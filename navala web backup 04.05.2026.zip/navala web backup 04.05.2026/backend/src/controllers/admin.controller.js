import { authenticateUser } from '../services/auth.service.js';
import { createUser, emailExists, getUsersByRole, getUserById, updateUserStatus, updateUserProfile } from '../models/User.js';
import { sendDoctorCredentials, generateTemporaryPassword } from '../services/mail.service.js';
import { Utils } from 'sequelize'; // Check if needed, otherwise ignore.
import { getAllPayments, getPaymentStats, getAnalyticsData } from '../services/payment.service.js';
import { UserRoles } from '../models/User.js';
import UserPlan, { UserPlanStatus } from '../models/UserPlan.js';
import Plan, { getPlanByPlanId } from '../models/Plan.js';
import { getActivePlanWindow } from '../config/planWindow.js';
import Appointment from '../models/Appointment.js';
import Doctor from '../models/Doctor.js';
import User from '../models/User.js';
import AppointmentRequest from '../models/AppointmentRequest.js';
import FamilyMember from '../models/FamilyMember.js';
import { validateDateOfBirth } from '../utils/validation.util.js';

/**
 * Admin Controller
 * Handles admin-specific endpoints
 */

/**
 * Admin login
 * POST /api/admin/login
 */
export async function adminLogin(req, res) {
  try {
    const { email, password } = req.body;

    // Validate input
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required',
      });
    }

    // Authenticate admin
    const result = await authenticateUser(email, password, UserRoles.ADMIN);

    res.json({
      success: true,
      message: 'Login successful',
      data: result,
    });
  } catch (error) {
    res.status(401).json({
      success: false,
      message: error.message || 'Login failed',
    });
  }
}

/**
 * Create a new doctor
 * POST /api/admin/doctors
 */
export async function createDoctor(req, res) {
  try {
    const { email, firstName, lastName } = req.body;

    // Validate input
    if (!email || !firstName || !lastName) {
      return res.status(400).json({
        success: false,
        message: 'Email, firstName, and lastName are required',
      });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid email format',
      });
    }

    // Check if email already exists
    if (await emailExists(email)) {
      return res.status(400).json({
        success: false,
        message: 'Email already registered',
      });
    }

    // Generate temporary password
    const temporaryPassword = generateTemporaryPassword();

    // Create doctor user
    const doctor = await createUser({
      email,
      password: temporaryPassword,
      firstName,
      lastName,
      role: UserRoles.DOCTOR,
    });

    // Send credentials via email
    try {
      await sendDoctorCredentials({
        email: doctor.email,
        firstName: doctor.firstName,
        password: temporaryPassword,
      });
    } catch (emailError) {
      // Log error but don't fail the request
      console.error('Failed to send email:', emailError);
      // You might want to handle this differently based on your requirements
    }

    res.status(201).json({
      success: true,
      message: 'Doctor created successfully. Credentials sent via email.',
      data: {
        doctor: {
          id: doctor.id,
          email: doctor.email,
          firstName: doctor.firstName,
          lastName: doctor.lastName,
          role: doctor.role,
        },
      },
    });
  } catch (error) {
    console.error('Error creating doctor:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to create doctor',
    });
  }
}

/**
 * Get all doctors
 * GET /api/admin/doctors
 */
export async function getAllDoctors(req, res) {
  try {
    const doctors = await getUsersByRole(UserRoles.DOCTOR);

    res.json({
      success: true,
      message: 'Doctors retrieved successfully',
      data: {
        doctors,
        count: doctors.length,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to retrieve doctors',
    });
  }
}

/**
 * Get all patients with active plan and appointment stats
 * GET /api/admin/patients
 */
export async function getAllPatients(req, res) {
  try {
    const users = await getUsersByRole(UserRoles.PATIENT);

    const enriched = await Promise.all(
      users.map(async (user) => {
        const activePlan = await UserPlan.findOne({
          where: { userId: user.id, status: UserPlanStatus.ACTIVE },
          order: [['endDate', 'DESC']],
          include: [{ model: Plan, attributes: ['id', 'planId', 'name'] }],
        });
        let planJson = null;
        if (activePlan) {
          const includedPlan = activePlan.Plan ?? activePlan.get?.('Plan');
          planJson = includedPlan ? (typeof includedPlan.toJSON === 'function' ? includedPlan.toJSON() : includedPlan) : null;
          if (!planJson && activePlan.planId) {
            const planRow = await Plan.findByPk(activePlan.planId, { attributes: ['id', 'planId', 'name'] });
            planJson = planRow ? planRow.toJSON() : null;
          }
        }
        const appointments = await Appointment.findAll({
          where: { patientId: user.id },
          attributes: ['appointmentUuid', 'appointmentDate', 'createdAt', 'status', 'serviceType'],
          order: [['createdAt', 'DESC']],
          include: [
            { model: Doctor, as: 'doctor', attributes: [], include: [{ model: User, attributes: ['firstName', 'lastName'] }] },
            { 
              model: AppointmentRequest, 
              as: 'request', 
              include: [{ model: FamilyMember, as: 'familyMember', attributes: ['firstName', 'lastName', 'relationship'] }] 
            },
          ],
        });
        const lastAppointment = appointments[0];
        const appointmentList = appointments.map((a) => {
          const doc = a.doctor;
          const u = doc?.User || doc?.user;
          const doctorName = u ? `${u.firstName || ''} ${u.lastName || ''}`.trim() : null;
          return {
            appointmentUuid: a.appointmentUuid,
            appointmentDate: a.appointmentDate,
            createdAt: a.createdAt,
            status: a.status,
            serviceType: a.serviceType,
            doctorName: doctorName || '—',
            familyMember: a.request?.familyMember ? {
              firstName: a.request.familyMember.firstName,
              lastName: a.request.familyMember.lastName,
              relationship: a.request.familyMember.relationship
            } : null,
          };
        });
        const latestRequest = await AppointmentRequest.findOne({
          where: { patientId: user.id },
          order: [['createdAt', 'DESC']],
          attributes: ['age', 'gender', 'emergencyContact', 'notes', 'city', 'allergies'],
          include: [{ model: FamilyMember, as: 'familyMember', attributes: ['firstName', 'lastName', 'relationship'] }]
        });
        const requestJson = latestRequest ? latestRequest.toJSON() : null;
        const { endDate: windowEnd } = getActivePlanWindow();
        const endDate = activePlan != null ? (windowEnd instanceof Date ? windowEnd.toISOString() : windowEnd) : null;
        const activePlanPayload = activePlan
          ? {
              planId: planJson?.planId ?? String(activePlan.planId),
              planName: planJson?.name ?? 'Unknown',
              endDate,
            }
          : null;

        return {
          id: user.id,
          userUuid: user.userUuid,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
          isActive: user.isActive,
          createdAt: user.createdAt,
          updatedAt: user.updatedAt,
          phone: user.phone ?? null,
          dateOfBirth: user.dateOfBirth ?? null,
          streetAddress: user.streetAddress ?? null,
          city: user.city ?? null,
          state: user.state ?? null,
          zipCode: user.zipCode ?? null,
          country: user.country ?? null,
          emergencyContactName: user.emergencyContactName ?? null,
          emergencyContactPhone: user.emergencyContactPhone ?? null,
          emergencyContactRelationship: user.emergencyContactRelationship ?? null,
          bloodType: user.bloodType ?? null,
          gender: user.gender ?? null,
          activePlan: activePlanPayload,
          appointmentCount: appointments.length,
          completedCount: appointments.filter((a) => a.status === 'COMPLETED').length,
          lastAppointmentAt: lastAppointment ? (lastAppointment.appointmentDate || lastAppointment.createdAt) : null,
          appointments: appointmentList,
          latestRequestDetails: requestJson
            ? {
                age: requestJson.age,
                gender: requestJson.gender,
                emergencyContact: requestJson.emergencyContact,
                notes: requestJson.notes || null,
                allergies: requestJson.allergies || null,
                city: requestJson.city || null,
                familyMember: requestJson.familyMember ? {
                  firstName: requestJson.familyMember.firstName,
                  lastName: requestJson.familyMember.lastName,
                  relationship: requestJson.familyMember.relationship
                } : null,
              }
            : null,
        };
      })
    );

    res.json({
      success: true,
      message: 'Patients retrieved successfully',
      data: {
        patients: enriched,
        count: enriched.length,
      },
    });
  } catch (error) {
    const message = error?.message || 'Failed to retrieve patients';
    console.error('[getAllPatients]', message, error?.stack || error);
    res.status(500).json({
      success: false,
      message,
    });
  }
}

/**
 * Grant (assign) a plan to a patient (admin).
 * POST /api/admin/patients/:userId/plan
 * Body: { planId: string } - plan business id from plans table
 */
export async function grantPlanToPatient(req, res) {
  try {
    const userId = parseInt(req.params.userId, 10);
    const { planId: planBusinessId } = req.body;
    if (!planBusinessId || typeof planBusinessId !== 'string') {
      return res.status(400).json({
        success: false,
        message: 'planId (plan business id) is required',
      });
    }

    const user = await getUserById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }
    if (user.role !== UserRoles.PATIENT) {
      return res.status(400).json({
        success: false,
        message: 'User is not a patient',
      });
    }

    const plan = await getPlanByPlanId(planBusinessId.trim(), true);
    if (!plan) {
      return res.status(404).json({
        success: false,
        message: 'Plan not found',
      });
    }

    const now = new Date();
    const { startDate: windowStart, endDate } = getActivePlanWindow();

    await UserPlan.update(
      { status: UserPlanStatus.EXPIRED, endDate: now },
      { where: { userId, status: UserPlanStatus.ACTIVE } }
    );

    await UserPlan.create({
      userId,
      planId: plan.id,
      startDate: windowStart,
      endDate,
      status: UserPlanStatus.ACTIVE,
    });

    res.json({
      success: true,
      message: 'Plan granted successfully',
      data: {
        planId: plan.planId,
        planName: plan.name,
        endDate: endDate.toISOString(),
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to grant plan',
    });
  }
}

/**
 * Get user by ID
 * GET /api/admin/users/:id
 */
export async function getUser(req, res) {
  try {
    const { id } = req.params;
    const user = await getUserById(parseInt(id, 10));

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    res.json({
      success: true,
      message: 'User retrieved successfully',
      data: { user },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to retrieve user',
    });
  }
}

/**
 * Update user status
 * PATCH /api/admin/users/:id/status
 */
export async function updateUserStatusEndpoint(req, res) {
  try {
    const { id } = req.params;
    const { isActive } = req.body;

    if (typeof isActive !== 'boolean') {
      return res.status(400).json({
        success: false,
        message: 'isActive must be a boolean value',
      });
    }

    const updated = await updateUserStatus(parseInt(id, 10), isActive);

    if (!updated) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    const user = await getUserById(parseInt(id, 10));

    res.json({
      success: true,
      message: `User ${isActive ? 'activated' : 'deactivated'} successfully`,
      data: { user },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to update user status',
    });
  }
}

/**
 * Update user (profile and optional status)
 * PATCH /api/admin/users/:id
 * Body: { firstName?, lastName?, phone?, dateOfBirth?, streetAddress?, city?, state?, zipCode?, country?, emergencyContactName?, emergencyContactPhone?, emergencyContactRelationship?, bloodType?, isActive? }
 */
export async function updateUserEndpoint(req, res) {
  try {
    const userId = parseInt(req.params.id, 10);
    const body = req.body || {};

    const user = await getUserById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    if (body.isActive !== undefined && typeof body.isActive === 'boolean') {
      await updateUserStatus(userId, body.isActive);
    }

    if (body.dateOfBirth != null && body.dateOfBirth !== '') {
      const dobCheck = validateDateOfBirth(body.dateOfBirth);
      if (!dobCheck.valid) {
        return res.status(400).json({
          success: false,
          message: dobCheck.message || 'Invalid date of birth',
        });
      }
    }

    const profilePayload = { ...body };
    delete profilePayload.isActive;
    const updated = await updateUserProfile(userId, profilePayload);

    res.json({
      success: true,
      message: 'User updated successfully',
      data: { user: updated },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to update user',
    });
  }
}

/**
 * Get all transactions
 * GET /api/admin/transactions
 */
export async function getTransactions(req, res) {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit, 10) : 20;
    const offset = req.query.offset ? parseInt(req.query.offset, 10) : 0;
    const search = req.query.search || '';
    const status = req.query.status || '';
    const liveOnly = req.query.liveOnly === 'true' || req.query.liveOnly === undefined; // default to true
    const planId = req.query.planId || 'all';
    const startDate = req.query.startDate || null;
    const endDate = req.query.endDate || null;

    const result = await getAllPayments({ limit, offset, search, status, liveOnly, planId, startDate, endDate });

    res.json({
      success: true,
      message: 'Transactions retrieved successfully',
      data: result,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to retrieve transactions',
    });
  }
}

/**
 * Get transaction stats
 * GET /api/admin/transactions/stats
 */
export async function getTransactionStats(req, res) {
  try {
    const liveOnly = req.query.liveOnly === 'true' || req.query.liveOnly === undefined; // default to true
    const planId = req.query.planId || 'all';
    const startDate = req.query.startDate || null;
    const endDate = req.query.endDate || null;

    const stats = await getPaymentStats({ liveOnly, planId, startDate, endDate });

    res.json({
      success: true,
      message: 'Transaction stats retrieved successfully',
      data: stats,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to retrieve transaction stats',
    });
  }
}

/**
 * Get Reports & Analytics
 * GET /api/admin/reports/analytics
 */
export async function getReportsAnalytics(req, res) {
  try {
    const analytics = await getAnalyticsData();

    res.json({
      success: true,
      message: 'Analytics retrieved successfully',
      data: analytics,
    });
  } catch (error) {
    console.error('[getReportsAnalytics] Error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to retrieve analytics',
    });
  }
}
