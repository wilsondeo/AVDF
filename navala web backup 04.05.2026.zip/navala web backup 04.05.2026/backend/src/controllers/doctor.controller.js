import { authenticateUser } from '../services/auth.service.js';
import { UserRoles } from '../models/User.js';

/**
 * Doctor Controller
 * Handles doctor-specific endpoints
 */

/**
 * Doctor login
 * POST /api/doctor/login
 */
export async function doctorLogin(req, res) {
  try {
    const { email, password } = req.body;
    
    // Validate input
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required',
      });
    }
    
    // Authenticate doctor
    const result = await authenticateUser(email, password, UserRoles.DOCTOR);
    
    res.json({
      success: true,
      message: 'Login successful',
      data: result,
    });
  } catch (error) {
    res.status(401).json({
      success: false,
      message: error.message || 'Login failed',
    });
  }
}

/**
 * Get doctor profile
 * GET /api/doctor/profile
 */
export async function getDoctorProfile(req, res) {
  try {
    // User is attached to request by authMiddleware
    res.json({
      success: true,
      message: 'Profile retrieved successfully',
      data: {
        user: {
          ...req.user,
          doctor: req.user.Doctor ? req.user.Doctor.toJSON() : null
        },
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to retrieve profile',
    });
  }
}
