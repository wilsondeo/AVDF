import Prescription from '../models/Prescription.js';
import PrescriptionMedicine from '../models/PrescriptionMedicine.js';
import Medicine from '../models/Medicine.js';
import Appointment from '../models/Appointment.js';
import User, { UserRoles } from '../models/User.js';
import Doctor from '../models/Doctor.js';
import AppointmentRequest from '../models/AppointmentRequest.js';
import FamilyMember from '../models/FamilyMember.js';
import { generateUuid } from '../utils/uuid.util.js';
import { getSequelize } from '../config/database.js';
import { Op } from 'sequelize';

/**
 * Doctor: Create or Update a prescription
 */
export async function createOrUpdatePrescription(req, res) {
    const sequelize = getSequelize();
    const t = await sequelize.transaction();

    try {
        const { appointmentId } = req.body; // Passed as uuid or ID, usually frontend has appointmentUuid currently. Let's assume appointmentUuid
        const { appointmentUuid, diagnosis, generalAdvice, restrictions, notes, status, medicines } = req.body;

        // Ensure user is doctor
        if (req.user.role !== UserRoles.DOCTOR) {
            return res.status(403).json({ success: false, message: 'Only doctors can write prescriptions' });
        }

        const doctor = await Doctor.findOne({ where: { userId: req.user.id } });
        if (!doctor) {
            return res.status(404).json({ success: false, message: 'Doctor profile not found' });
        }

        const appointment = await Appointment.findOne({ where: { appointmentUuid } });
        if (!appointment) {
            return res.status(404).json({ success: false, message: 'Appointment not found' });
        }

        // Check if an issued prescription already exists for this appointment
        let prescription = await Prescription.findOne({
            where: { appointmentId: appointment.id },
            include: [{ model: PrescriptionMedicine, as: 'medicines' }]
        });

        if (prescription) {
            if (prescription.status === 'ISSUED') {
                await t.rollback();
                return res.status(403).json({ success: false, message: 'Cannot edit an already issued prescription' });
            }

            // Update existing DRAFT
            await prescription.update({
                diagnosis,
                generalAdvice,
                restrictions,
                notes,
                status: status || 'DRAFT'
            }, { transaction: t });

            // Clear old medicines and add new ones
            await PrescriptionMedicine.destroy({ where: { prescriptionId: prescription.id }, transaction: t });
            
            if (medicines && medicines.length > 0) {
                // Auto-populate medicine store
                for (const m of medicines) {
                    if (m.name) {
                        await Medicine.findOrCreate({
                            where: { name: m.name.trim() },
                            defaults: {
                                name: m.name.trim(),
                                createdByRecordType: 'DOCTOR',
                                createdById: doctor.id
                            },
                            transaction: t
                        });
                    }
                }

                const medData = medicines.map(m => ({
                    prescriptionId: prescription.id,
                    name: m.name,
                    dosage: m.dosage,
                    frequency: m.frequency,
                    duration: m.duration,
                    foodInstructions: m.foodInstructions
                }));
                await PrescriptionMedicine.bulkCreate(medData, { transaction: t });
            }

        } else {
            // Create new
            prescription = await Prescription.create({
                prescriptionUuid: generateUuid(),
                appointmentId: appointment.id,
                doctorId: doctor.id,
                patientId: appointment.patientId,
                diagnosis,
                generalAdvice,
                restrictions,
                notes,
                status: status || 'DRAFT'
            }, { transaction: t });

            if (medicines && medicines.length > 0) {
                // Auto-populate medicine store
                for (const m of medicines) {
                    if (m.name) {
                        await Medicine.findOrCreate({
                            where: { name: m.name.trim() },
                            defaults: {
                                name: m.name.trim(),
                                createdByRecordType: 'DOCTOR',
                                createdById: doctor.id
                            },
                            transaction: t
                        });
                    }
                }

                const medData = medicines.map(m => ({
                    prescriptionId: prescription.id,
                    name: m.name,
                    dosage: m.dosage,
                    frequency: m.frequency,
                    duration: m.duration,
                    foodInstructions: m.foodInstructions || m.food_instructions
                }));
                await PrescriptionMedicine.bulkCreate(medData, { transaction: t });
            }
        }

        await t.commit();
        
        // If issued, mark the appointment as COMPLETED
        if (status === 'ISSUED' || prescription.status === 'ISSUED') {
            await Appointment.update(
                { status: 'COMPLETED' },
                { where: { id: appointment.id } }
            );
        }
        
        // Fetch full related object
        const finalPrescription = await Prescription.findByPk(prescription.id, {
            include: [{ model: PrescriptionMedicine, as: 'medicines' }]
        });

        res.status(200).json({ success: true, data: finalPrescription });

    } catch (error) {
        await t.rollback();
        res.status(500).json({ success: false, message: error.message });
    }
}

/**
 * Get prescriptions for the logged-in patient
 */
export async function getPatientPrescriptions(req, res) {
    try {
        const userId = req.user.id;
        
        const prescriptions = await Prescription.findAll({
            where: { patientId: userId, status: 'ISSUED' }, // Patients shouldn't see DRAFTS
            include: [
                { model: PrescriptionMedicine, as: 'medicines' },
                { 
                    model: Doctor, 
                    include: [{ model: User, attributes: ['firstName', 'lastName'] }]
                },
                { 
                    model: Appointment, 
                    attributes: ['appointmentDate', 'serviceType'],
                    include: [{
                        model: AppointmentRequest,
                        as: 'request',
                        include: [{ model: FamilyMember, as: 'familyMember', attributes: ['firstName', 'lastName', 'relationship'] }]
                    }]
                }
            ],
            order: [['created_at', 'DESC']]
        });
        
        res.status(200).json({ success: true, data: prescriptions });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

/**
 * Get prescriptions written by the logged-in doctor
 */
export async function getDoctorPrescriptions(req, res) {
    try {
        const doctor = await Doctor.findOne({ where: { userId: req.user.id } });
        if (!doctor) {
            return res.status(404).json({ success: false, message: 'Doctor profile not found' });
        }
        
        const prescriptions = await Prescription.findAll({
            where: { doctorId: doctor.id },
            include: [
                { model: PrescriptionMedicine, as: 'medicines' },
                { model: User, as: 'patient', attributes: ['firstName', 'lastName'] },
                { 
                    model: Appointment, 
                    attributes: ['appointmentDate', 'serviceType'],
                    include: [{
                        model: AppointmentRequest,
                        as: 'request',
                        include: [{ model: FamilyMember, as: 'familyMember', attributes: ['firstName', 'lastName', 'relationship'] }]
                    }]
                }
            ],
            order: [['updated_at', 'DESC']]
        });
        
        res.status(200).json({ success: true, data: prescriptions });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

/**
 * Get single prescription by appointment UUID for Doctor Cockpit
 */
export async function getPrescriptionByAppointmentUuid(req, res) {
    try {
        const { appointmentUuid } = req.params;
        const appointment = await Appointment.findOne({ where: { appointmentUuid } });
        
        if (!appointment) {
            return res.status(404).json({ success: false, message: 'Appointment not found' });
        }

        const prescription = await Prescription.findOne({
            where: { appointmentId: appointment.id },
            include: [
                { model: PrescriptionMedicine, as: 'medicines' },
                { 
                    model: Appointment, 
                    attributes: ['appointmentDate', 'serviceType'],
                    include: [{
                        model: AppointmentRequest,
                        as: 'request',
                        include: [{ model: FamilyMember, as: 'familyMember', attributes: ['firstName', 'lastName', 'relationship'] }]
                    }]
                }
            ]
        });

        if (!prescription) {
            return res.status(404).json({ success: false, message: 'Prescription not found mapping to this appointment' });
        }

        res.status(200).json({ success: true, data: prescription });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

/**
 * Get generic prescription by ID or UUID.
 */
export async function getPrescriptionById(req, res) {
    try {
        const { idOrUuid } = req.params;
        let whereClause = {};

        // If it's a number, assume it's the integer ID, otherwise UUID
        if (!isNaN(idOrUuid)) {
            whereClause.id = parseInt(idOrUuid);
        } else {
            whereClause.prescriptionUuid = idOrUuid;
        }

        const prescription = await Prescription.findOne({
            where: whereClause,
            include: [
                { model: PrescriptionMedicine, as: 'medicines' },
                { 
                    model: Doctor, 
                    include: [{ model: User, attributes: ['firstName', 'lastName'] }]
                },
                { 
                   model: User, as: 'patient', attributes: ['firstName', 'lastName', 'dateOfBirth', 'gender'] 
                },
                { 
                    model: Appointment, 
                    attributes: ['appointmentDate', 'serviceType'],
                    include: [{
                        model: AppointmentRequest,
                        as: 'request',
                        include: [{ model: FamilyMember, as: 'familyMember', attributes: ['firstName', 'lastName', 'relationship', 'gender', 'dateOfBirth'] }]
                    }]
                }
            ]
        });

        if (!prescription) {
            return res.status(404).json({ success: false, message: 'Prescription not found' });
        }

        // Verify authorization: only the patient or the prescribing doctor can view it. Admin could view too if needed, but keeping it simple.
        if (req.user.role === 'patient' && prescription.patientId !== req.user.id) {
           return res.status(403).json({ success: false, message: 'Unauthorized' });
        }
        if (req.user.role === 'doctor') {
           const doctor = await Doctor.findOne({ where: { userId: req.user.id } });
           if (!doctor || doctor.id !== prescription.doctorId) {
               return res.status(403).json({ success: false, message: 'Unauthorized' });
           }
        }

        res.status(200).json({ success: true, data: prescription });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

/**
 * Search medicines from the master store
 */
export async function searchMedicines(req, res) {
    try {
        const { q } = req.query;
        if (!q) {
            return res.status(200).json({ success: true, data: [] });
        }

        const medicines = await Medicine.findAll({
            where: {
                name: { [Op.like]: `%${q}%` },
                isActive: true
            },
            limit: 20,
            order: [['name', 'ASC']]
        });

        res.status(200).json({ success: true, data: medicines });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

