import {
  listFamilyMembers,
  createFamilyMember,
  updateFamilyMember,
  deleteFamilyMember,
  getMaxFamilySlots,
} from '../services/familyMember.service.js';
import { validateDateOfBirth } from '../utils/validation.util.js';

function getUserId(req) {
  return req.userId ?? req.user?.id;
}

/**
 * GET /api/user/family-members
 */
export async function getFamilyMembers(req, res) {
  try {
    const userId = getUserId(req);
    if (!userId) {
      return res.status(401).json({ success: false, message: 'Unauthorized' });
    }
    const list = await listFamilyMembers(Number(userId));
    const maxSlots = await getMaxFamilySlots(Number(userId));
    return res.json({
      success: true,
      message: 'Family members retrieved',
      data: { familyMembers: list, maxSlots },
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error?.message || 'Failed to get family members',
    });
  }
}

/**
 * Admin: GET /api/admin/users/:id/family-members
 * Returns family members for a specific user (no slot info needed for admin view).
 */
export async function getFamilyMembersForUser(req, res) {
  try {
    const userId = parseInt(req.params.id, 10);
    if (Number.isNaN(userId)) {
      return res.status(400).json({ success: false, message: 'Invalid user id' });
    }
    const list = await listFamilyMembers(userId);
    return res.json({
      success: true,
      message: 'Family members retrieved',
      data: { familyMembers: list },
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error?.message || 'Failed to get family members',
    });
  }
}

/**
 * POST /api/user/family-members
 * Body: { firstName, lastName, dateOfBirth?, gender?, relationship? }
 */
export async function postFamilyMember(req, res) {
  try {
    const userId = getUserId(req);
    if (!userId) {
      return res.status(401).json({ success: false, message: 'Unauthorized' });
    }
    const body = req.body || {};
    const firstName = (body.firstName ?? '').trim();
    const lastName = (body.lastName ?? '').trim();
    if (!firstName || !lastName) {
      return res.status(400).json({
        success: false,
        message: 'First name and last name are required.',
      });
    }
    if (body.dateOfBirth != null && body.dateOfBirth !== '') {
      const dobCheck = validateDateOfBirth(body.dateOfBirth);
      if (!dobCheck.valid) {
        return res.status(400).json({
          success: false,
          message: dobCheck.message || 'Invalid date of birth',
        });
      }
    }
    const member = await createFamilyMember(Number(userId), {
      firstName,
      lastName,
      dateOfBirth: body.dateOfBirth || null,
      gender: body.gender || null,
      relationship: body.relationship || null,
    });
    return res.status(201).json({
      success: true,
      message: 'Family member added',
      data: member,
    });
  } catch (error) {
    const status = error.message?.includes('plan') ? 400 : 500;
    return res.status(status).json({
      success: false,
      message: error?.message || 'Failed to add family member',
    });
  }
}

/**
 * PATCH /api/user/family-members/:id
 */
export async function patchFamilyMember(req, res) {
  try {
    const userId = getUserId(req);
    if (!userId) {
      return res.status(401).json({ success: false, message: 'Unauthorized' });
    }
    const memberId = parseInt(req.params.id, 10);
    if (Number.isNaN(memberId)) {
      return res.status(400).json({ success: false, message: 'Invalid member id' });
    }
    const body = req.body || {};
    if (body.dateOfBirth != null && body.dateOfBirth !== '') {
      const dobCheck = validateDateOfBirth(body.dateOfBirth);
      if (!dobCheck.valid) {
        return res.status(400).json({
          success: false,
          message: dobCheck.message || 'Invalid date of birth',
        });
      }
    }
    const member = await updateFamilyMember(Number(userId), memberId, {
      firstName: body.firstName,
      lastName: body.lastName,
      dateOfBirth: body.dateOfBirth,
      gender: body.gender,
      relationship: body.relationship,
    });
    if (!member) {
      return res.status(404).json({ success: false, message: 'Family member not found' });
    }
    return res.json({
      success: true,
      message: 'Family member updated',
      data: member,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error?.message || 'Failed to update family member',
    });
  }
}

/**
 * DELETE /api/user/family-members/:id
 */
export async function deleteFamilyMemberController(req, res) {
  try {
    const userId = getUserId(req);
    if (!userId) {
      return res.status(401).json({ success: false, message: 'Unauthorized' });
    }
    const memberId = parseInt(req.params.id, 10);
    if (Number.isNaN(memberId)) {
      return res.status(400).json({ success: false, message: 'Invalid member id' });
    }
    const deleted = await deleteFamilyMember(Number(userId), memberId);
    if (!deleted) {
      return res.status(404).json({ success: false, message: 'Family member not found' });
    }
    return res.json({
      success: true,
      message: 'Family member removed',
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error?.message || 'Failed to remove family member',
    });
  }
}
