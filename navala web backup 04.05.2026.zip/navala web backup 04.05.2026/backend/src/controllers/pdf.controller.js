import puppeteer from 'puppeteer';
import dotenv from 'dotenv';

dotenv.config();

/**
 * PDF Controller
 * Uses Puppeteer to render the exact Web Version of documents into PDFs for the mobile app.
 */

const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:5173';

const generatePDF = async (url) => {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  const page = await browser.newPage();
  
  // Set screen size to ensure proper rendering
  await page.setViewport({ width: 1200, height: 1600 });
  
  // Visit the page
  await page.goto(url, { waitUntil: 'networkidle0' });
  
  // Generate PDF
  const pdfBuffer = await page.pdf({
    format: 'A4',
    printBackground: true,
    margin: { top: '0px', right: '0px', bottom: '0px', left: '0px' },
    preferCSSPageSize: true
  });

  await browser.close();
  return pdfBuffer;
};

export const getPrescriptionPDF = async (req, res) => {
  try {
    const { uuid } = req.params;
    // We point to the public print route in the frontend
    const url = `${FRONTEND_URL}/print/prescription/${uuid}`;
    
    const pdf = await generatePDF(url);
    
    res.contentType("application/pdf");
    res.send(pdf);
  } catch (error) {
    console.error('PDF Generation Error:', error);
    res.status(500).json({ success: false, message: 'Failed to generate PDF', error: error.message });
  }
};

export const getContractPDF = async (req, res) => {
  try {
    // Note: Contract page usually needs a logged in user. 
    // For the mobile API, we might need a special "public-view" or token-based route.
    // For now, we assume the frontend has a route /print/contract/:userId
    const { userId } = req.params;
    const url = `${FRONTEND_URL}/patient/contracts?print=true&userId=${userId}`;
    
    const pdf = await generatePDF(url);
    
    res.contentType("application/pdf");
    res.send(pdf);
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to generate PDF' });
  }
};

export const getConfirmationPDF = async (req, res) => {
  try {
    const { paymentId } = req.params;
    const url = `${FRONTEND_URL}/patient/plan-confirmation?print=true&paymentId=${paymentId}`;
    
    const pdf = await generatePDF(url);
    
    res.contentType("application/pdf");
    res.send(pdf);
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to generate PDF' });
  }
};
