import app, { initializeApp } from './src/app.js';
import { env } from './src/config/env.js';
import { closeConnection } from './src/config/database.js';

/**
 * Server Entry Point
 * Starts the Express server
 */

const PORT = env.PORT;
const HOST = env.HOST;

// Initialize application and start server
async function startServer() {
  try {
    // Initialize database and tables
    await initializeApp();
    
    // Start server (HOST=0.0.0.0 for IP-based network access)
    app.listen(PORT, HOST, () => {
      console.log(`🚀 Server running on ${env.BASE_URL} (listening on ${HOST}:${PORT})`);
      console.log(`📝 Environment: ${env.NODE_ENV}`);
      console.log(`🔐 API Prefix: ${env.API_PREFIX}`);
      console.log(`\nAvailable endpoints:`);
      console.log(`  - POST ${env.API_PREFIX}/auth/login (Patient login)`);
      console.log(`  - POST ${env.API_PREFIX}/auth/register (Patient registration)`);
      console.log(`  - POST ${env.API_PREFIX}/auth/forgot-password (Patient forgot password)`);
      console.log(`  - POST ${env.API_PREFIX}/auth/reset-password (Patient reset password)`);
      console.log(`  - POST ${env.API_PREFIX}/admin/login (Admin login)`);
      console.log(`  - POST ${env.API_PREFIX}/doctor/login (Doctor login)`);
      console.log(`  - GET  /plans (Public active plans)`);
      console.log(`  - GET  ${env.API_PREFIX}/consent (Public consent content)`);
      console.log(`  - POST /payments/create-intent (JWT required)`);
      console.log(`  - POST /payments/webhook (Stripe webhook)`);
      console.log(`  - GET  /user/plan (JWT required)`);
    });
  } catch (error) {
    console.error('❌ Failed to start server:', error);
    process.exit(1);
  }
}

// Handle graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  await closeConnection();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully...');
  await closeConnection();
  process.exit(0);
});

// Start the server
startServer();
