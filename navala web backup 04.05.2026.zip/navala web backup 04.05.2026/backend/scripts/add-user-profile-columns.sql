-- Add all patient profile columns to users table
-- Database: navala_travelapp
-- Table: users
-- Run once: mysql -u root -p navala_travelapp < scripts/add-user-profile-columns.sql

USE navala_travelapp;

ALTER TABLE users ADD COLUMN phone VARCHAR(20) NULL;
ALTER TABLE users ADD COLUMN date_of_birth DATE NULL;
ALTER TABLE users ADD COLUMN street_address VARCHAR(255) NULL;
ALTER TABLE users ADD COLUMN city VARCHAR(100) NULL;
ALTER TABLE users ADD COLUMN state VARCHAR(100) NULL;
ALTER TABLE users ADD COLUMN zip_code VARCHAR(20) NULL;
ALTER TABLE users ADD COLUMN country VARCHAR(100) NULL;
ALTER TABLE users ADD COLUMN emergency_contact_name VARCHAR(100) NULL;
ALTER TABLE users ADD COLUMN emergency_contact_phone VARCHAR(50) NULL;
ALTER TABLE users ADD COLUMN emergency_contact_relationship VARCHAR(50) NULL;
ALTER TABLE users ADD COLUMN blood_type VARCHAR(10) NULL;
