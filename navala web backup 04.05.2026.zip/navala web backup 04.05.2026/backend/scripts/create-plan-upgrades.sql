-- Plan upgrade history (storage/audit only, not for display).
-- Run once: mysql -u root -p navala_travelapp < scripts/create-plan-upgrades.sql

USE navala_travelapp;

CREATE TABLE IF NOT EXISTS plan_upgrades (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  old_plan_id INT NOT NULL,
  new_plan_id INT NOT NULL,
  old_price_cents INT NOT NULL,
  new_price_cents INT NOT NULL,
  amount_charged_cents INT NOT NULL,
  payment_id INT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_plan_upgrades_user_id (user_id),
  UNIQUE INDEX idx_plan_upgrades_payment_id (payment_id),
  INDEX idx_plan_upgrades_created_at (created_at),
  CONSTRAINT fk_plan_upgrades_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_plan_upgrades_old_plan FOREIGN KEY (old_plan_id) REFERENCES plans(id) ON DELETE CASCADE,
  CONSTRAINT fk_plan_upgrades_new_plan FOREIGN KEY (new_plan_id) REFERENCES plans(id) ON DELETE CASCADE,
  CONSTRAINT fk_plan_upgrades_payment FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE CASCADE
);
