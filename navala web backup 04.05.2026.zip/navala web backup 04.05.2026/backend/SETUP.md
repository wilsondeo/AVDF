# Quick Setup Guide

Since your database `navala_travelapp` is already created, follow these steps:

## Step 1: Create .env File

Create a `.env` file in the `backend` folder with the following content:

```env
# Server Configuration
NODE_ENV=development
PORT=3000
BASE_URL=http://192.168.1.225:3000
API_PREFIX=/api

# Frontend Configuration (for CORS)
# Use IP address for network access, or localhost for local development
FRONTEND_URL=http://192.168.1.225:8080
CORS_ORIGIN=http://192.168.1.225:8080

# Database Configuration
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_mysql_password_here
DB_NAME=navala_travelapp

# JWT Configuration
JWT_SECRET=navala-travel-jwt-secret-key-change-in-production-min-32-chars
JWT_REFRESH_SECRET=navala-travel-refresh-secret-key-change-in-production-min-32-chars
JWT_ACCESS_EXPIRY=15m
JWT_REFRESH_EXPIRY=7d

# Password Hashing
BCRYPT_ROUNDS=10

# SMTP Configuration (Optional - for sending doctor credentials via email)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SMTP_FROM_EMAIL=your-email@gmail.com
SMTP_FROM_NAME=Navala Travel
```

**Important:** Replace `your_mysql_password_here` with your actual MySQL root password.

## Step 2: Seed Admin User

Run the seed script to create the default admin user:

```bash
npm run seed
```

This will create an admin user with:
- Email: `admin@navala.com`
- Password: `Admin@123`

⚠️ **Change this password after first login!**

## Step 3: Start the Server

**Development mode (with auto-reload):**
```bash
npm run dev
```

**Production mode:**
```bash
npm start
```

The server will start on `http://localhost:3000`

## Step 4: Test the API

You can test the endpoints using:

### Admin Login
```bash
POST http://localhost:3000/api/admin/login
Content-Type: application/json

{
  "email": "admin@navala.com",
  "password": "Admin@123"
}
```

### Patient Registration
```bash
POST http://localhost:3000/api/auth/register
Content-Type: application/json

{
  "email": "patient@example.com",
  "password": "SecurePass123",
  "firstName": "John",
  "lastName": "Doe"
}
```

## Troubleshooting

### Database Connection Error
- Check your MySQL is running
- Verify `DB_PASSWORD` in `.env` is correct
- Ensure database `navala_travelapp` exists

### Email Not Sending
- SMTP configuration is optional
- If you don't configure SMTP, doctor creation will still work but won't send emails
- For Gmail, you need to use an [App Password](https://support.google.com/accounts/answer/185833)

### Port Already in Use
- Change `PORT` in `.env` to a different port (e.g., 3001)
