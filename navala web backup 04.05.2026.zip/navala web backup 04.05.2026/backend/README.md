# Navala Travel Backend - Authentication System

Production-ready backend authentication system for the Navala Travel healthcare booking platform.

## Features

- ✅ JWT-based authentication (access + refresh tokens)
- ✅ Role-based access control (ADMIN, DOCTOR, PATIENT)
- ✅ Secure password hashing with bcrypt
- ✅ Separate login endpoints for each role
- ✅ Centralized configuration management
- ✅ NodeMailer integration for doctor credentials
- ✅ Environment-based configuration
- ✅ Clean layered architecture
- ✅ **Sequelize ORM** for database operations

## Project Structure

```
backend/
├── src/
│   ├── config/          # Configuration files
│   │   ├── env.js       # Environment variables
│   │   ├── jwt.js       # JWT token management
│   │   ├── database.js  # Database connection
│   │   └── mail.js      # Email configuration
│   ├── models/          # Database models
│   │   └── User.js      # User model
│   ├── routes/          # API routes
│   │   ├── auth.routes.js
│   │   ├── admin.routes.js
│   │   └── doctor.routes.js
│   ├── controllers/     # Route controllers
│   │   ├── auth.controller.js
│   │   ├── admin.controller.js
│   │   └── doctor.controller.js
│   ├── services/        # Business logic
│   │   ├── auth.service.js
│   │   └── mail.service.js
│   ├── middlewares/     # Express middlewares
│   │   ├── auth.middleware.js
│   │   └── role.middleware.js
│   ├── scripts/         # Utility scripts
│   │   └── seed.js      # Database seed
│   └── app.js           # Express app setup
├── server.js            # Server entry point
├── package.json
├── .env.example
└── README.md
```

## Installation

1. **Install dependencies:**
   ```bash
   cd backend
   npm install
   ```

2. **Configure environment variables:**
   ```bash
   cp .env.example .env
   ```
   
   Edit `.env` and set your configuration:
   - Database credentials
   - JWT secrets (use strong, random strings in production)
   - SMTP configuration for emails

3. **Create database:**
   ```sql
   CREATE DATABASE navala_travelapp;
   ```

4. **Seed admin user:**
   ```bash
   npm run seed
   ```
   
   Default admin credentials:
   - Email: `admin@navala.com`
   - Password: `Admin@123`
   
   ⚠️ **Change these after first login!**

## Running the Server

**Development mode:**
```bash
npm run dev
```

**Production mode:**
```bash
npm start
```

The server listens on `HOST:PORT` (default `0.0.0.0:3000` for IP-based network access). Use `BASE_URL` from `.env` (e.g. `http://192.168.1.225:3000`) to reach it from other devices.

### Stripe webhook (local / IP-based)

Forward Stripe events to your backend using the **same host as `BASE_URL`** (no localhost):

```bash
stripe listen --forward-to http://192.168.1.225:3000/payments/webhook
```

If your machine IP differs, use it instead of `192.168.1.225`. Copy the webhook signing secret (`whsec_...`) into `.env` as `STRIPE_WEBHOOK_SECRET`.

## API Endpoints

### Authentication Endpoints

#### Patient Registration
```http
POST /api/auth/register
Content-Type: application/json

{
  "email": "patient@example.com",
  "password": "SecurePass123",
  "firstName": "John",
  "lastName": "Doe"
}
```

#### Patient Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "patient@example.com",
  "password": "SecurePass123"
}
```

#### Refresh Token
```http
POST /api/auth/refresh
Content-Type: application/json

{
  "refreshToken": "your-refresh-token"
}
```

### Admin Endpoints

#### Admin Login
```http
POST /api/admin/login
Content-Type: application/json

{
  "email": "admin@navala.com",
  "password": "Admin@123"
}
```

#### Create Doctor (Protected - Admin only)
```http
POST /api/admin/doctors
Authorization: Bearer <admin-access-token>
Content-Type: application/json

{
  "email": "doctor@example.com",
  "firstName": "Jane",
  "lastName": "Smith"
}
```

The system will:
- Generate a temporary password
- Create the doctor account
- Send credentials via email

#### Get All Doctors (Protected - Admin only)
```http
GET /api/admin/doctors
Authorization: Bearer <admin-access-token>
```

#### Get All Patients (Protected - Admin only)
```http
GET /api/admin/patients
Authorization: Bearer <admin-access-token>
```

### Doctor Endpoints

#### Doctor Login
```http
POST /api/doctor/login
Content-Type: application/json

{
  "email": "doctor@example.com",
  "password": "temporary-password"
}
```

#### Get Doctor Profile (Protected - Doctor only)
```http
GET /api/doctor/profile
Authorization: Bearer <doctor-access-token>
```

## Authentication Flow

1. **Login/Register** → Receive `accessToken` and `refreshToken`
2. **Include token in requests:**
   ```http
   Authorization: Bearer <accessToken>
   ```
3. **When access token expires** → Use refresh token to get new access token
4. **Refresh token expires** → User must login again

## Role Rules

- **ADMIN**: Created manually via seed script only
- **DOCTOR**: Created only by Admin (credentials sent via email)
- **PATIENT**: Can self-register via `/api/auth/register`

## Security Features

- ✅ Passwords are hashed with bcrypt (never stored in plain text)
- ✅ JWT tokens include userId and role
- ✅ Role-based middleware protection
- ✅ Token expiration and refresh mechanism
- ✅ Account activation/deactivation support

## Environment Variables

All configuration is centralized in `src/config/env.js`. Key variables:

- `JWT_SECRET` - Secret for access tokens
- `JWT_REFRESH_SECRET` - Secret for refresh tokens
- `JWT_ACCESS_EXPIRY` - Access token expiry (default: 15m)
- `JWT_REFRESH_EXPIRY` - Refresh token expiry (default: 7d)
- `DB_*` - Database configuration
- `SMTP_*` - Email configuration

## Email Configuration

The system uses NodeMailer for sending emails. Configure SMTP settings in `.env`:

**Gmail Example:**
```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
```

**Note:** For Gmail, you need to use an [App Password](https://support.google.com/accounts/answer/185833) instead of your regular password.

## Database Schema

The database uses **Sequelize ORM** for all operations. Tables are automatically created when you run the server or seed script.

### Adding new columns (e.g. user profile fields)

If you see **"Unknown column 'phone' in 'field list'"** (or similar) after adding profile fields to the User model:

- **Option A:** Set `DB_SYNC_ALTER=true` in `.env`, restart the backend once, then set it back to `false` if you prefer.
- **Option B:** Run the migration script once:
  ```bash
  cd backend
  mysql -u root -p navala_travelapp < scripts/add-user-profile-columns.sql
  ```
  (Replace `root` and password with your DB user.)

### Users Table
- `id` - Primary key (INTEGER, AUTO_INCREMENT)
- `email` - Unique email address (STRING, UNIQUE)
- `password` - Hashed password (bcrypt, automatically hashed on create/update)
- `firstName` - User first name (STRING)
- `lastName` - User last name (STRING)
- `role` - ENUM('ADMIN', 'DOCTOR', 'PATIENT')
- `isActive` - Account status (BOOLEAN, default: true)
- `createdAt` - Creation timestamp (automatically managed)
- `updatedAt` - Update timestamp (automatically managed)

**Note:** Sequelize automatically handles password hashing via model hooks before create/update operations.

## Error Handling

All endpoints return consistent error responses:

```json
{
  "success": false,
  "message": "Error message here"
}
```

## Development

- Uses ES6 modules (`type: "module"`)
- Nodemon for auto-reload in development
- Centralized configuration for easy deployment
- No hardcoded URLs or secrets

## Production Deployment

1. Set `NODE_ENV=production`
2. Use strong, random JWT secrets
3. Configure production database
4. Set up proper SMTP service
5. Configure CORS origin
6. Use environment variables for all sensitive data

## License

ISC
