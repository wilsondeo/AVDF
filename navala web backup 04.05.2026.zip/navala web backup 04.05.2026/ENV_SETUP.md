# Environment Configuration Guide

This project uses environment variables for configuration. No manual localhost setup is required!

## Frontend Configuration

Create a `.env` file in the **root directory** (same level as `package.json`):

```env
# Backend API Configuration
# Use IP address for network access (e.g., 192.168.1.225:3000)
# Or use localhost for local development
VITE_API_BASE_URL=http://192.168.1.225:3000
VITE_API_PREFIX=/api

# Frontend URL (optional, for reference)
VITE_FRONTEND_URL=http://192.168.1.225:8080
```

**Important:** Vite requires the `VITE_` prefix for environment variables to be exposed to the client.

### Quick Setup:
1. Copy the example above
2. Replace `192.168.1.225` with your actual IP address
3. Save as `.env` in the root directory
4. Restart the dev server

## Backend Configuration

Create a `.env` file in the `backend` directory:

```env
# Server Configuration
NODE_ENV=development
PORT=3000
BASE_URL=http://192.168.1.225:3000
API_PREFIX=/api

# Frontend Configuration (for CORS)
FRONTEND_URL=http://192.168.1.225:8080
CORS_ORIGIN=http://192.168.1.225:8080

# Database Configuration
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_password_here
DB_NAME=navala_travelapp

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-change-in-production-min-32-chars
JWT_REFRESH_SECRET=your-super-secret-refresh-key-change-in-production-min-32-chars
JWT_ACCESS_EXPIRY=15m
JWT_REFRESH_EXPIRY=7d

# Password Hashing
BCRYPT_ROUNDS=10

# SMTP Configuration (Optional)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SMTP_FROM_EMAIL=your-email@gmail.com
SMTP_FROM_NAME=Navala Travel
```

**Important:** Replace `192.168.1.225` with your actual IP address in both files.

## How It Works

1. **Frontend** reads `VITE_API_BASE_URL` from `.env` and uses it in `src/config/api.ts`
2. **Backend** reads `FRONTEND_URL` and `CORS_ORIGIN` from `.env` and allows that origin
3. **No hardcoded URLs** - everything is configurable via environment variables

## Finding Your IP Address

**Windows:**
```powershell
ipconfig
# Look for IPv4 Address under your network adapter
```

**Mac/Linux:**
```bash
ifconfig
# Look for inet address
```

## Network Access

The frontend is configured to listen on `0.0.0.0:8080`, which means:
- ✅ Accessible via `localhost:8080`
- ✅ Accessible via `192.168.1.225:8080` (your IP)
- ✅ Accessible from other devices on the same network

## Example Usage in Code

### Frontend (TypeScript/React):
```typescript
import { API_ENDPOINTS, API_BASE_URL } from '@/config/api';

// Use predefined endpoints
fetch(API_ENDPOINTS.AUTH.LOGIN, { ... });

// Or build custom URLs
fetch(`${API_BASE_URL}/custom/endpoint`, { ... });
```

### Backend:
```javascript
import { env } from './config/env.js';

// Access frontend URL
console.log(env.FRONTEND_URL); // http://192.168.1.225:8080
console.log(env.CORS_ORIGIN);  // http://192.168.1.225:8080
```

## Switching Between Environments

To switch from localhost to network IP (or vice versa), simply update the `.env` files:

**For localhost:**
```env
VITE_API_BASE_URL=http://localhost:3000
FRONTEND_URL=http://localhost:8080
```

**For network access:**
```env
VITE_API_BASE_URL=http://192.168.1.225:3000
FRONTEND_URL=http://192.168.1.225:8080
```

No code changes required! 🎉
