import http from 'http';

const API_BASE = 'http://localhost:3000';
const ADMIN_EMAIL = 'admin@navala.com';
const ADMIN_PASSWORD = 'Admin@123';

async function request(path, method = 'GET', body = null, token = null) {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: 'localhost',
            port: 3000,
            path,
            method,
            headers: {
                'Content-Type': 'application/json',
            },
        };

        if (token) {
            options.headers['Authorization'] = `Bearer ${token}`;
        }

        const req = http.request(options, (res) => {
            let data = '';
            res.on('data', (chunk) => data += chunk);
            res.on('end', () => {
                try {
                    const json = JSON.parse(data);
                    resolve({ status: res.statusCode, data: json });
                } catch (e) {
                    resolve({ status: res.statusCode, data });
                }
            });
        });

        req.on('error', (e) => reject(e));

        if (body) {
            req.write(JSON.stringify(body));
        }
        req.end();
    });
}

async function run() {
    console.log('1. Logging in as Admin...');
    // Note: Admin login is at /admin/login (standalone)
    const loginRes = await request('/admin/login', 'POST', {
        email: ADMIN_EMAIL,
        password: ADMIN_PASSWORD
    });

    if (!loginRes.data.success) {
        console.error('Login failed:', loginRes.data);
        return;
    }

    const token = loginRes.data.data.accessToken;
    console.log('Login successful. Token obtained.');

    console.log('\n2. Fetching Transactions...');
    const txnRes = await request('/api/admin/transactions?limit=5', 'GET', null, token);
    console.log('Status:', txnRes.status);
    console.log('Data:', JSON.stringify(txnRes.data, null, 2));

    if (txnRes.status !== 200) {
        console.error('Failed to fetch transactions');
        process.exit(1);
    }

    console.log('\n3. Fetching Transaction Stats...');
    const statsRes = await request('/api/admin/transactions/stats', 'GET', null, token);
    console.log('Status:', statsRes.status);
    console.log('Data:', JSON.stringify(statsRes.data, null, 2));

    if (statsRes.status !== 200) {
        console.error('Failed to fetch stats');
        process.exit(1);
    }
}

run().catch(console.error);
