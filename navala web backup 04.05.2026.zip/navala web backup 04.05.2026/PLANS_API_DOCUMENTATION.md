# Plans API Documentation

Complete API documentation for the Plans management system.

## Base URL

```
http://localhost:3000
```

Or with IP address:
```
http://192.168.1.225:3000
```

---

## Public Endpoints (No Authentication Required)

### Get Active Plans

**Endpoint:** `GET /plans`

**Description:** Get all active plans (public access, no authentication required)

**Headers:**
```
Content-Type: application/json
```

**Response (200):**
```json
{
  "success": true,
  "message": "Active plans retrieved successfully",
  "data": {
    "plans": [
      {
        "id": 1,
        "planId": "PLAN-1704067200000-ABC123",
        "name": "Travel Basic",
        "price": "29.99",
        "validityDays": 30,
        "description": "Perfect for occasional travelers",
        "services": ["TELEHEALTH"],
        "features": [
          "24/7 Telehealth consultations",
          "Digital prescriptions",
          "Medical history access"
        ],
        "isActive": true,
        "createdAt": "2024-01-01T00:00:00.000Z",
        "updatedAt": "2024-01-01T00:00:00.000Z"
      }
    ],
    "count": 1
  }
}
```

**Use Case:** Patient dashboard, plan selection page

---

## Admin Endpoints (Authentication Required)

All admin endpoints require:
- **Authentication:** Bearer token in Authorization header
- **Role:** ADMIN role

### Get All Plans (Admin)

**Endpoint:** `GET /api/admin/plans`

**Description:** Get all plans including inactive ones (admin only)

**Headers:**
```
Content-Type: application/json
Authorization: Bearer <admin-access-token>
```

**Query Parameters (Optional):**
- `limit` - Limit number of results
- `offset` - Offset for pagination

**Response (200):**
```json
{
  "success": true,
  "message": "Plans retrieved successfully",
  "data": {
    "plans": [
      {
        "id": 1,
        "planId": "PLAN-1704067200000-ABC123",
        "name": "Travel Basic",
        "price": "29.99",
        "validityDays": 30,
        "description": "Perfect for occasional travelers",
        "services": ["TELEHEALTH"],
        "features": [
          "24/7 Telehealth consultations",
          "Digital prescriptions"
        ],
        "isActive": true,
        "createdAt": "2024-01-01T00:00:00.000Z",
        "updatedAt": "2024-01-01T00:00:00.000Z"
      }
    ],
    "count": 1
  }
}
```

---

### Get Plan by PlanId (Admin)

**Endpoint:** `GET /api/admin/plans/:planId`

**Description:** Get a specific plan by its planId (admin only)

**Headers:**
```
Content-Type: application/json
Authorization: Bearer <admin-access-token>
```

**URL Parameters:**
- `planId` - The unique plan identifier (e.g., `PLAN-1704067200000-ABC123`)

**Response (200):**
```json
{
  "success": true,
  "message": "Plan retrieved successfully",
  "data": {
    "plan": {
      "id": 1,
      "planId": "PLAN-1704067200000-ABC123",
      "name": "Travel Basic",
      "price": "29.99",
      "validityDays": 30,
      "description": "Perfect for occasional travelers",
      "services": ["TELEHEALTH"],
      "features": ["24/7 Telehealth consultations"],
      "isActive": true,
      "createdAt": "2024-01-01T00:00:00.000Z",
      "updatedAt": "2024-01-01T00:00:00.000Z"
    }
  }
}
```

**Error Response (404):**
```json
{
  "success": false,
  "message": "Plan not found"
}
```

---

### Create Plan (Admin)

**Endpoint:** `POST /api/admin/plans`

**Description:** Create a new plan (admin only). planId is auto-generated.

**Headers:**
```
Content-Type: application/json
Authorization: Bearer <admin-access-token>
```

**Request Body:**
```json
{
  "name": "Travel Premium",
  "price": 99.99,
  "validityDays": 90,
  "description": "Premium plan for frequent travelers",
  "services": ["TELEHEALTH", "EMERGENCY"],
  "features": [
    "24/7 Telehealth consultations",
    "Emergency services",
    "Digital prescriptions",
    "Priority booking"
  ],
  "isActive": true
}
```

**Required Fields:**
- `name` (string) - Plan name
- `price` (number) - Plan price (must be positive)
- `validityDays` (number) - Validity in days (minimum 1)
- `services` (array) - Array of service types: `["TELEHEALTH"]`, `["EMERGENCY"]`, or `["TELEHEALTH", "EMERGENCY"]`

**Optional Fields:**
- `description` (string) - Plan description
- `features` (array) - Array of feature strings
- `isActive` (boolean) - Whether plan is active (default: true)

**Response (201):**
```json
{
  "success": true,
  "message": "Plan created successfully",
  "data": {
    "plan": {
      "id": 2,
      "planId": "PLAN-1704067300000-XYZ789",
      "name": "Travel Premium",
      "price": "99.99",
      "validityDays": 90,
      "description": "Premium plan for frequent travelers",
      "services": ["TELEHEALTH", "EMERGENCY"],
      "features": [
        "24/7 Telehealth consultations",
        "Emergency services",
        "Digital prescriptions",
        "Priority booking"
      ],
      "isActive": true,
      "createdAt": "2024-01-01T00:00:00.000Z",
      "updatedAt": "2024-01-01T00:00:00.000Z"
    }
  }
}
```

**Error Response (400):**
```json
{
  "success": false,
  "message": "Name, price, and validityDays are required"
}
```

---

### Update Plan (Admin)

**Endpoint:** `PUT /api/admin/plans/:planId`

**Description:** Update an existing plan (admin only)

**Headers:**
```
Content-Type: application/json
Authorization: Bearer <admin-access-token>
```

**URL Parameters:**
- `planId` - The unique plan identifier

**Request Body (all fields optional):**
```json
{
  "name": "Travel Premium Plus",
  "price": 119.99,
  "validityDays": 120,
  "description": "Updated description",
  "services": ["TELEHEALTH", "EMERGENCY"],
  "features": [
    "Updated feature 1",
    "Updated feature 2"
  ],
  "isActive": true
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Plan updated successfully",
  "data": {
    "plan": {
      "id": 2,
      "planId": "PLAN-1704067300000-XYZ789",
      "name": "Travel Premium Plus",
      "price": "119.99",
      "validityDays": 120,
      "description": "Updated description",
      "services": ["TELEHEALTH", "EMERGENCY"],
      "features": ["Updated feature 1", "Updated feature 2"],
      "isActive": true,
      "createdAt": "2024-01-01T00:00:00.000Z",
      "updatedAt": "2024-01-01T00:01:00.000Z"
    }
  }
}
```

**Error Response (404):**
```json
{
  "success": false,
  "message": "Plan not found"
}
```

---

### Delete Plan (Admin - Soft Delete)

**Endpoint:** `DELETE /api/admin/plans/:planId`

**Description:** Soft delete a plan by setting isActive to false (admin only)

**Headers:**
```
Content-Type: application/json
Authorization: Bearer <admin-access-token>
```

**URL Parameters:**
- `planId` - The unique plan identifier

**Response (200):**
```json
{
  "success": true,
  "message": "Plan deleted successfully"
}
```

**Error Response (404):**
```json
{
  "success": false,
  "message": "Plan not found"
}
```

---

## Data Models

### Plan Object

```typescript
{
  id: number;                    // Database ID (auto-increment)
  planId: string;                // Unique business identifier (auto-generated)
  name: string;                  // Plan name
  price: number | string;         // Plan price (DECIMAL from DB may be string)
  validityDays: number;           // Validity in days
  description: string | null;    // Plan description
  services: string[];             // Array: ["TELEHEALTH"] or ["EMERGENCY"] or both
  features: string[];             // Array of feature strings
  isActive: boolean;              // Active status (soft delete)
  createdAt: string;             // ISO timestamp
  updatedAt: string;             // ISO timestamp
}
```

### Service Types

- `TELEHEALTH` - Telehealth consultation services
- `EMERGENCY` - Emergency medical services

---

## Validation Rules

### Create/Update Plan

1. **Name:** Required, string
2. **Price:** Required, number, must be >= 0
3. **ValidityDays:** Required, number, must be >= 1
4. **Services:** Required, array, must contain at least one of: `TELEHEALTH`, `EMERGENCY`
5. **Features:** Optional, array of strings
6. **Description:** Optional, string
7. **isActive:** Optional, boolean (default: true)

---

## Plan ID Generation

- **Format:** `PLAN-{timestamp}-{random}`
- **Example:** `PLAN-1704067200000-ABC123`
- **Auto-generated:** Backend automatically generates unique planId
- **Frontend:** Never sends planId, only receives it

---

## Error Responses

### 400 Bad Request
```json
{
  "success": false,
  "message": "Validation error message"
}
```

### 401 Unauthorized
```json
{
  "success": false,
  "message": "Invalid or expired token"
}
```

### 403 Forbidden
```json
{
  "success": false,
  "message": "Insufficient permissions. Required role: ADMIN"
}
```

### 404 Not Found
```json
{
  "success": false,
  "message": "Plan not found"
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "message": "Internal server error"
}
```

---

## Postman Examples

### Get Active Plans (Public)
```
GET http://localhost:3000/plans
```

### Get All Plans (Admin)
```
GET http://localhost:3000/api/admin/plans
Authorization: Bearer <admin-token>
```

### Create Plan (Admin)
```
POST http://localhost:3000/api/admin/plans
Authorization: Bearer <admin-token>
Content-Type: application/json

{
  "name": "Travel Basic",
  "price": 29.99,
  "validityDays": 30,
  "description": "Perfect for occasional travelers",
  "services": ["TELEHEALTH"],
  "features": [
    "24/7 Telehealth consultations",
    "Digital prescriptions"
  ]
}
```

### Update Plan (Admin)
```
PUT http://localhost:3000/api/admin/plans/PLAN-1704067200000-ABC123
Authorization: Bearer <admin-token>
Content-Type: application/json

  {
    "price": 39.99,
    "isActive": true
  }
```

### Delete Plan (Admin)
```
DELETE http://localhost:3000/api/admin/plans/PLAN-1704067200000-ABC123
Authorization: Bearer <admin-token>
```

---

## Notes

1. **planId vs id:** Use `planId` for API operations, `id` is internal database ID
2. **Price Format:** May be returned as string from database (DECIMAL type)
3. **Services Array:** Must be uppercase: `TELEHEALTH`, `EMERGENCY`
4. **Soft Delete:** Deleting sets `isActive: false`, doesn't remove from database
5. **Public Endpoint:** `/plans` only returns active plans, no authentication needed
