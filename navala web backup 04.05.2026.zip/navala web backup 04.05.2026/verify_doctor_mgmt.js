let adminToken = '';
const BASE_URL = 'http://localhost:3001/api';

async function loginAdmin() {
    console.log('Logging in as admin...');
    try {
        const response = await fetch(`${BASE_URL}/admin/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                email: 'admin@navala.com',
                password: 'Admin@123'
            })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.message || 'Login failed');
        adminToken = data.data.accessToken;
        console.log('✅ Admin login successful');
    } catch (error) {
        console.error('❌ Admin login failed:', error.message);
        process.exit(1);
    }
}

async function testListDoctors() {
    console.log('\nTesting List Doctors...');
    try {
        const response = await fetch(`${BASE_URL}/admin/doctors/`, {
            headers: { Authorization: `Bearer ${adminToken}` }
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.message || 'Listing failed');
        console.log(`✅ Retrieved ${data.data.length} doctors`);
    } catch (error) {
        console.error('❌ List doctors failed:', error.message);
    }
}

async function testCreateDoctor() {
    console.log('\nTesting Create Doctor...');
    const uniqueEmail = `dr.test.${Date.now()}@example.com`;
    try {
        const response = await fetch(`${BASE_URL}/admin/doctors/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${adminToken}`
            },
            body: JSON.stringify({
                name: 'Dr. Test Verification',
                firstName: 'Test',
                lastName: 'Verification',
                email: uniqueEmail,
                phone: '1234567890',
                city: 'London',
                specialization: 'General Medicine',
                yearsOfExperience: 10,
                sendEmail: false
            })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.message || 'Creation failed');
        console.log('✅ Doctor created:', data.data.name);
    } catch (error) {
        console.error('❌ Create doctor failed:', error.message);
    }
}

async function verifyAll() {
    await loginAdmin();
    await testCreateDoctor();
    await testListDoctors();
}

verifyAll();
