# Postman Testing Guide

Complete guide for testing the Navala Travel Backend API in Postman.

## Prerequisites

1. **Backend server must be running:**
   ```bash
   cd backend
   npm run dev
   ```
   Server should be running on `http://localhost:3000` (or your configured port)

2. **Database must be seeded:**
   ```bash
   cd backend
   npm run seed
   ```
   This creates the default admin user.

## Default Admin Credentials

- **Email:** `admin@navala.com`
- **Password:** `Admin@123`

## Base URL

```
http://localhost:3000/api
```

Or if using IP address:
```
http://192.168.1.225:3000/api
```

---

## 1. Patient Registration

**Endpoint:** `POST /api/auth/register`

**Headers:**
```
Content-Type: application/json
```

**Request Body:**
```json
{
  "email": "patient@example.com",
  "password": "SecurePass123",
  "firstName": "John",
  "lastName": "Doe"
}
```

**Expected Response (201):**
```json
{
  "success": true,
  "message": "Registration successful",
  "data": {
    "user": {
      "id": 1,
      "email": "patient@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "role": "PATIENT",
      "isActive": true,
      "createdAt": "2024-01-01T00:00:00.000Z",
      "updatedAt": "2024-01-01T00:00:00.000Z"
    },
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

**Error Response (400):**
```json
{
  "success": false,
  "message": "Email already registered"
}
```

---

## 2. Patient Login

**Endpoint:** `POST /api/auth/login`

**Headers:**
```
Content-Type: application/json
```

**Request Body:**
```json
{
  "email": "patient@example.com",
  "password": "SecurePass123"
}
```

**Expected Response (200):**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "id": 1,
      "email": "patient@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "role": "PATIENT",
      "isActive": true
    },
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

**Error Response (401):**
```json
{
  "success": false,
  "message": "Invalid email or password"
}
```

---

## 3. Admin Login

**Endpoint:** `POST /api/admin/login`

**Headers:**
```
Content-Type: application/json
```

**Request Body:**
```json
{
  "email": "admin@navala.com",
  "password": "Admin@123"
}
```

**Expected Response (200):**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "id": 1,
      "email": "admin@navala.com",
      "firstName": "Admin",
      "lastName": "User",
      "role": "ADMIN",
      "isActive": true
    },
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

---

## 4. Doctor Login

**Endpoint:** `POST /api/doctor/login`

**Headers:**
```
Content-Type: application/json
```

**Request Body:**
```json
{
  "email": "doctor@example.com",
  "password": "temporary-password"
}
```

**Note:** Doctors must be created by admin first. See "Create Doctor" endpoint below.

---

## 5. Refresh Access Token

**Endpoint:** `POST /api/auth/refresh`

**Headers:**
```
Content-Type: application/json
```

**Request Body:**
```json
{
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Expected Response (200):**
```json
{
  "success": true,
  "message": "Token refreshed successfully",
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

---

## 5a. Patient Profile (Patient Only - Protected)

Use the **patient** access token from login/register.

### GET profile

**Endpoint:** `GET /api/user/profile` or `GET /user/profile`

**Headers:**
```
Content-Type: application/json
Authorization: Bearer <patient-access-token>
```

**Expected Response (200):** Full user profile from users table:
```json
{
  "success": true,
  "message": "Profile retrieved",
  "data": {
    "id": 4,
    "userUuid": "...",
    "email": "patient@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "role": "PATIENT",
    "isActive": true,
    "phone": null,
    "dateOfBirth": null,
    "streetAddress": null,
    "city": null,
    "state": null,
    "zipCode": null,
    "country": null,
    "emergencyContactName": null,
    "emergencyContactPhone": null,
    "emergencyContactRelationship": null,
    "bloodType": null,
    "createdAt": "...",
    "updatedAt": "..."
  }
}
```

### PATCH profile

**Endpoint:** `PATCH /api/user/profile` or `PATCH /user/profile`

**Headers:**
```
Content-Type: application/json
Authorization: Bearer <patient-access-token>
```

**Request Body (all fields optional):**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "phone": "+15551234567",
  "dateOfBirth": "2002-02-08",
  "streetAddress": "123 Main St",
  "city": "New York",
  "state": "NY",
  "zipCode": "10001",
  "country": "United States",
  "emergencyContactName": "Jane Doe",
  "emergencyContactPhone": "+15559999999",
  "emergencyContactRelationship": "spouse",
  "bloodType": "A+"
}
```

**Expected Response (200):** Same shape as GET – `{ "success": true, "message": "Profile updated", "data": <UserProfile> }`.

---

## 6. Create Doctor (Admin Only - Protected)

**Endpoint:** `POST /api/admin/doctors`

**Headers:**
```
Content-Type: application/json
Authorization: Bearer <admin-access-token>
```

**Request Body:**
```json
{
  "email": "doctor@example.com",
  "firstName": "Jane",
  "lastName": "Smith"
}
```

**Expected Response (201):**
```json
{
  "success": true,
  "message": "Doctor created successfully. Credentials sent via email.",
  "data": {
    "doctor": {
      "id": 2,
      "email": "doctor@example.com",
      "firstName": "Jane",
      "lastName": "Smith",
      "role": "DOCTOR"
    }
  }
}
```

**Note:** A temporary password is generated and sent via email (if SMTP is configured).

---

## 7. Get All Doctors (Admin Only - Protected)

**Endpoint:** `GET /api/admin/doctors`

**Headers:**
```
Authorization: Bearer <admin-access-token>
```

**Expected Response (200):**
```json
{
  "success": true,
  "message": "Doctors retrieved successfully",
  "data": {
    "doctors": [
      {
        "id": 2,
        "email": "doctor@example.com",
        "firstName": "Jane",
        "lastName": "Smith",
        "role": "DOCTOR",
        "isActive": true,
        "createdAt": "2024-01-01T00:00:00.000Z",
        "updatedAt": "2024-01-01T00:00:00.000Z"
      }
    ],
    "count": 1
  }
}
```

---

## 8. Get All Patients (Admin Only - Protected)

**Endpoint:** `GET /api/admin/patients`

**Headers:**
```
Authorization: Bearer <admin-access-token>
```

**Expected Response (200):**
```json
{
  "success": true,
  "message": "Patients retrieved successfully",
  "data": {
    "patients": [
      {
        "id": 1,
        "email": "patient@example.com",
        "firstName": "John",
        "lastName": "Doe",
        "role": "PATIENT",
        "isActive": true,
        "createdAt": "2024-01-01T00:00:00.000Z",
        "updatedAt": "2024-01-01T00:00:00.000Z"
      }
    ],
    "count": 1
  }
}
```

---

## 9. Get User by ID (Admin Only - Protected)

**Endpoint:** `GET /api/admin/users/:id`

**Headers:**
```
Authorization: Bearer <admin-access-token>
```

**Example:** `GET /api/admin/users/1`

**Expected Response (200):**
```json
{
  "success": true,
  "message": "User retrieved successfully",
  "data": {
    "user": {
      "id": 1,
      "email": "patient@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "role": "PATIENT",
      "isActive": true,
      "createdAt": "2024-01-01T00:00:00.000Z",
      "updatedAt": "2024-01-01T00:00:00.000Z"
    }
  }
}
```

---

## 10. Update User Status (Admin Only - Protected)

**Endpoint:** `PATCH /api/admin/users/:id/status`

**Headers:**
```
Content-Type: application/json
Authorization: Bearer <admin-access-token>
```

**Request Body:**
```json
{
  "isActive": false
}
```

**Expected Response (200):**
```json
{
  "success": true,
  "message": "User deactivated successfully",
  "data": {
    "user": {
      "id": 1,
      "email": "patient@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "role": "PATIENT",
      "isActive": false,
      "createdAt": "2024-01-01T00:00:00.000Z",
      "updatedAt": "2024-01-01T00:00:00.000Z"
    }
  }
}
```

---

## 10a. Update User (Admin – full profile)

**Endpoint:** `PATCH /api/admin/users/:id`

Same as patient profile PATCH: send any of `firstName`, `lastName`, `phone`, `dateOfBirth`, `streetAddress`, `city`, `state`, `zipCode`, `country`, `emergencyContactName`, `emergencyContactPhone`, `emergencyContactRelationship`, `bloodType`, and optionally `isActive` (boolean). Response: `{ "success": true, "message": "User updated successfully", "data": { "user": <UserProfile> } }`.

---

## 11. Get Doctor Profile (Doctor Only - Protected)

**Endpoint:** `GET /api/doctor/profile`

**Headers:**
```
Authorization: Bearer <doctor-access-token>
```

**Expected Response (200):**
```json
{
  "success": true,
  "message": "Profile retrieved successfully",
  "data": {
    "user": {
      "id": 2,
      "email": "doctor@example.com",
      "firstName": "Jane",
      "lastName": "Smith",
      "role": "DOCTOR",
      "isActive": true,
      "createdAt": "2024-01-01T00:00:00.000Z",
      "updatedAt": "2024-01-01T00:00:00.000Z"
    }
  }
}
```

---

## Postman Setup Tips

### 1. Environment Variables

Create a Postman environment with:
- `base_url`: `http://localhost:3000/api`
- `access_token`: (will be set automatically)
- `refresh_token`: (will be set automatically)

### 2. Auto-save Tokens

Create a **Test Script** for login requests:

```javascript
// For login/register endpoints
if (pm.response.code === 200 || pm.response.code === 201) {
    const jsonData = pm.response.json();
    if (jsonData.data && jsonData.data.accessToken) {
        pm.environment.set("access_token", jsonData.data.accessToken);
        pm.environment.set("refresh_token", jsonData.data.refreshToken);
    }
}
```

### 3. Use Environment Variables in Headers

For protected endpoints, use:
```
Authorization: Bearer {{access_token}}
```

### 4. Collection Structure

Organize your requests:
```
📁 Navala Travel API
  📁 Auth
    - Patient Register
    - Patient Login
    - Admin Login
    - Doctor Login
    - Refresh Token
  📁 Admin (Protected)
    - Create Doctor
    - Get All Doctors
    - Get All Patients
    - Get User by ID
    - Update User Status
  📁 Doctor (Protected)
    - Get Profile
```

---

## Testing Workflow

### Step 1: Test Patient Registration
1. Use "Patient Register" request
2. Save the `accessToken` and `refreshToken` from response

### Step 2: Test Patient Login
1. Use "Patient Login" request with registered credentials
2. Verify tokens are returned

### Step 3: Test Admin Login
1. Use "Admin Login" with default credentials
2. Save admin `accessToken`

### Step 4: Test Protected Endpoints
1. Use admin token to create a doctor
2. Use admin token to get all patients/doctors
3. Test doctor login with created doctor credentials

### Step 5: Test Token Refresh
1. Use refresh token from login
2. Verify new access token is returned

---

## Common Errors

### 401 Unauthorized
- Token missing or invalid
- Token expired (use refresh token)
- Wrong role for endpoint

### 403 Forbidden
- User doesn't have required role
- Account is deactivated

### 400 Bad Request
- Missing required fields
- Invalid email format
- Password too short
- Email already exists

### 404 Not Found
- User doesn't exist
- Invalid endpoint

---

## Health Check

**Endpoint:** `GET /health`

**Expected Response:**
```json
{
  "success": true,
  "message": "Server is running",
  "timestamp": "2024-01-01T00:00:00.000Z"
}
```

Use this to verify the server is running before testing other endpoints.
