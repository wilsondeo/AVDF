import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Trophy, Medal, Award } from "lucide-react";

interface Performer {
  id: string;
  name: string;
  role: string;
  avatar?: string;
  score: number;
  department: string;
}

interface TopPerformersProps {
  performers: Performer[];
  period?: string;
}

export function TopPerformers({ performers, period = "this month" }: TopPerformersProps) {
  const getPositionIcon = (index: number) => {
    switch (index) {
      case 0:
        return <Trophy className="w-5 h-5 text-warning" />;
      case 1:
        return <Medal className="w-5 h-5 text-muted-foreground" />;
      case 2:
        return <Award className="w-5 h-5 text-orange-400" />;
      default:
        return <span className="w-5 h-5 flex items-center justify-center text-sm font-bold text-muted-foreground">#{index + 1}</span>;
    }
  };

  const getPositionBadge = (index: number) => {
    const badges = [
      { text: "1st", className: "bg-warning text-warning-foreground" },
      { text: "2nd", className: "bg-muted text-muted-foreground" },
      { text: "3rd", className: "bg-orange-500/10 text-orange-400 border-orange-400/20" }
    ];
    
    return badges[index] || { text: `${index + 1}th`, className: "bg-muted/50 text-muted-foreground" };
  };

  return (
    <div className="p-6 rounded-xl bg-gradient-glass border border-border/50 backdrop-blur-sm shadow-glass">
      <div className="flex items-center space-x-2 mb-6">
        <Trophy className="w-5 h-5 text-warning" />
        <h3 className="text-lg font-semibold text-foreground">Top Performers of {period}</h3>
      </div>

      {/* Winner Spotlight */}
      {performers[0] && (
        <div className="relative mb-6 p-4 rounded-lg bg-gradient-to-r from-warning/20 to-transparent border border-warning/30">
          <div className="absolute top-2 right-2">
            <div className="w-16 h-16 rounded-full bg-warning/20 flex items-center justify-center">
              <span className="text-3xl">👑</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Avatar className="w-16 h-16 border-4 border-warning/30">
              <AvatarImage src={performers[0].avatar} />
              <AvatarFallback className="bg-gradient-primary text-primary-foreground text-lg font-bold">
                {performers[0].name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div>
              <h4 className="font-bold text-lg text-foreground">{performers[0].name}</h4>
              <p className="text-sm text-muted-foreground">{performers[0].role}</p>
              <Badge variant="outline" className="mt-1 text-warning border-warning/50">
                {performers[0].department}
              </Badge>
            </div>
          </div>
        </div>
      )}

      {/* Performers List */}
      <div className="space-y-3">
        {performers.slice(0, 5).map((performer, index) => {
          const badge = getPositionBadge(index);
          
          return (
            <div
              key={performer.id}
              className="flex items-center space-x-3 p-3 rounded-lg bg-background/30 border border-border/30 hover:bg-background/50 transition-colors"
            >
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-muted/20">
                {getPositionIcon(index)}
              </div>
              
              <Avatar className="w-10 h-10">
                <AvatarImage src={performer.avatar} />
                <AvatarFallback className="text-sm font-medium">
                  {performer.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground truncate">{performer.name}</p>
                <p className="text-sm text-muted-foreground truncate">{performer.role}</p>
              </div>
              
              <div className="text-right space-y-1">
                <Badge className={badge.className}>
                  {badge.text}
                </Badge>
                <p className="text-xs text-muted-foreground">{performer.score} pts</p>
              </div>
            </div>
          );
        })}
      </div>

      {performers.length === 0 && (
        <div className="text-center py-8 text-muted-foreground">
          <Trophy className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>No performance data available</p>
        </div>
      )}
    </div>
  );
}