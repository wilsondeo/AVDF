import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

interface EffortData {
  name: string;
  billable: number;
  nonBillable: number;
  office: number;
}

interface EffortChartProps {
  data: EffortData[];
  title?: string;
  period?: string;
}

const colors = {
  billable: "hsl(var(--success))",
  nonBillable: "hsl(var(--destructive))",
  office: "hsl(var(--primary))"
};

export function EffortChart({ data, title = "Effort Graph", period = "July 2025" }: EffortChartProps) {
  return (
    <div className="p-6 rounded-xl bg-gradient-glass border border-border/50 backdrop-blur-sm shadow-glass">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-foreground mb-1">{title}</h3>
        <p className="text-sm text-muted-foreground">{period}</p>
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
            <XAxis 
              dataKey="name" 
              axisLine={false}
              tickLine={false}
              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
            />
            <YAxis 
              axisLine={false}
              tickLine={false}
              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
                boxShadow: "var(--shadow-glass)"
              }}
              labelStyle={{ color: "hsl(var(--foreground))" }}
            />
            <Bar dataKey="billable" fill={colors.billable} radius={[4, 4, 0, 0]} />
            <Bar dataKey="nonBillable" fill={colors.nonBillable} radius={[4, 4, 0, 0]} />
            <Bar dataKey="office" fill={colors.office} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Legend */}
      <div className="flex justify-center space-x-6 mt-4">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-full bg-success" />
          <span className="text-sm text-muted-foreground">Billable</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-full bg-destructive" />
          <span className="text-sm text-muted-foreground">Non-billable</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 rounded-full bg-primary" />
          <span className="text-sm text-muted-foreground">Office</span>
        </div>
      </div>
    </div>
  );
}