import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Brain, RotateCcw, Play, Square } from "lucide-react";

export function MindGame() {
  const [sequence, setSequence] = useState<number[]>([]);
  const [userSequence, setUserSequence] = useState<number[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isShowingSequence, setIsShowingSequence] = useState(false);
  const [activeButton, setActiveButton] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);

  const colors = ['bg-success', 'bg-primary', 'bg-warning', 'bg-destructive'];

  const startGame = () => {
    setSequence([Math.floor(Math.random() * 4)]);
    setUserSequence([]);
    setScore(0);
    setGameOver(false);
    setIsPlaying(true);
    showSequence([Math.floor(Math.random() * 4)]);
  };

  const showSequence = (seq: number[]) => {
    setIsShowingSequence(true);
    let i = 0;
    const interval = setInterval(() => {
      setActiveButton(seq[i]);
      setTimeout(() => setActiveButton(null), 300);
      i++;
      if (i >= seq.length) {
        clearInterval(interval);
        setIsShowingSequence(false);
      }
    }, 600);
  };

  const handleButtonClick = (index: number) => {
    if (isShowingSequence || !isPlaying) return;

    const newUserSequence = [...userSequence, index];
    setUserSequence(newUserSequence);

    // Check if correct
    if (newUserSequence[newUserSequence.length - 1] !== sequence[newUserSequence.length - 1]) {
      setGameOver(true);
      setIsPlaying(false);
      return;
    }

    // Check if sequence complete
    if (newUserSequence.length === sequence.length) {
      setScore(score + 1);
      setUserSequence([]);
      const newSequence = [...sequence, Math.floor(Math.random() * 4)];
      setSequence(newSequence);
      setTimeout(() => showSequence(newSequence), 1000);
    }
  };

  const resetGame = () => {
    setSequence([]);
    setUserSequence([]);
    setIsPlaying(false);
    setScore(0);
    setGameOver(false);
  };

  return (
    <div className="p-6 rounded-xl bg-gradient-glass border border-border/50 backdrop-blur-sm shadow-glass">
      <div className="flex items-center space-x-2 mb-6">
        <Brain className="w-5 h-5 text-accent" />
        <h3 className="text-lg font-semibold text-foreground">Mind Game</h3>
      </div>

      <div className="space-y-4">
        {/* Score */}
        <div className="flex items-center justify-between">
          <div className="text-2xl font-bold text-accent">
            Score: {score}
          </div>
          <div className="text-sm text-muted-foreground">
            00:00:00
          </div>
        </div>

        {/* Game Grid */}
        <div className="grid grid-cols-4 gap-2 mb-4">
          {colors.map((color, index) => (
            <button
              key={index}
              onClick={() => handleButtonClick(index)}
              disabled={isShowingSequence || !isPlaying}
              className={`
                h-12 rounded-lg transition-all duration-200 hover:scale-105 border-2 
                ${color} 
                ${activeButton === index ? 'scale-110 brightness-150' : 'brightness-75'}
                ${isShowingSequence || !isPlaying ? 'cursor-not-allowed' : 'cursor-pointer'}
                hover:brightness-100
              `}
            />
          ))}
        </div>

        {/* Controls */}
        <div className="flex space-x-2">
          {!isPlaying ? (
            <Button onClick={startGame} className="flex-1 bg-gradient-primary">
              <Play className="w-4 h-4 mr-2" />
              Start
            </Button>
          ) : (
            <Button onClick={resetGame} variant="outline" className="flex-1">
              <Square className="w-4 h-4 mr-2" />
              Stop
            </Button>
          )}
          <Button onClick={resetGame} variant="outline" size="icon">
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        {gameOver && (
          <div className="text-center p-4 rounded-lg bg-destructive/10 border border-destructive/20">
            <p className="text-destructive font-medium">Game Over!</p>
            <p className="text-sm text-muted-foreground">Final Score: {score}</p>
          </div>
        )}

        {isShowingSequence && (
          <div className="text-center p-2 rounded-lg bg-primary/10 border border-primary/20">
            <p className="text-primary text-sm">Watch the sequence...</p>
          </div>
        )}
      </div>
    </div>
  );
}