import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: ReactNode;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  variant?: "default" | "primary" | "success" | "warning" | "accent";
  className?: string;
}

export function StatsCard({
  title,
  value,
  subtitle,
  icon,
  trend,
  variant = "default",
  className
}: StatsCardProps) {
  const variants = {
    default: "bg-gradient-glass border-border/50",
    primary: "bg-gradient-primary text-primary-foreground border-primary/20",
    success: "bg-gradient-success text-white border-success/20",
    warning: "bg-warning/10 border-warning/20",
    accent: "bg-gradient-accent text-accent-foreground border-accent/20"
  };

  return (
    <div className={cn(
      "relative p-6 rounded-xl border backdrop-blur-sm shadow-glass transition-all duration-300 hover:shadow-glow hover:scale-[1.02]",
      variants[variant],
      className
    )}>
      {/* Background Pattern */}
      <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-white/5 to-transparent pointer-events-none" />
      
      <div className="relative z-10">
        <div className="flex items-start justify-between mb-4">
          <div className="space-y-1">
            <p className="text-sm font-medium opacity-80">{title}</p>
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-bold">{value}</span>
              {trend && (
                <span className={cn(
                  "text-sm font-medium px-2 py-1 rounded-full",
                  trend.isPositive 
                    ? "bg-success/20 text-success-light" 
                    : "bg-destructive/20 text-destructive"
                )}>
                  {trend.isPositive ? "+" : ""}{trend.value}%
                </span>
              )}
            </div>
            {subtitle && (
              <p className="text-sm opacity-60">{subtitle}</p>
            )}
          </div>
          {icon && (
            <div className="p-3 rounded-lg bg-white/10 backdrop-blur-sm">
              {icon}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}