import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { QrCode, Smartphone } from "lucide-react";

export function QRAccessCard() {
  return (
    <Card className="bg-glass-subtle border-glass-border backdrop-blur-xl shadow-glow h-full">
      <CardHeader className="space-y-0 pb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-lg bg-gradient-brand/20">
            <QrCode className="w-5 h-5 text-brand-600" />
          </div>
          <CardTitle className="text-lg font-semibold text-neutral-900">QR Access</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* QR Code Display */}
        <div className="flex justify-center">
          <div className="bg-white p-4 rounded-2xl shadow-elegant border border-glass-border">
            <div className="w-32 h-32 bg-neutral-900 rounded-lg flex items-center justify-center">
              {/* QR Code Pattern Simulation */}
              <div className="grid grid-cols-8 gap-0.5 w-24 h-24">
                {[...Array(64)].map((_, i) => (
                  <div 
                    key={i} 
                    className={`w-2 h-2 ${Math.random() > 0.5 ? 'bg-white' : 'bg-neutral-900'}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {/* Description */}
        <div className="text-center space-y-2">
          <p className="text-sm text-neutral-600">
            Scan this QR code to access your employee portal on mobile
          </p>
        </div>
        
        {/* Action Button */}
        <Button 
          className="w-full bg-gradient-brand text-white hover:shadow-glow-brand transition-all duration-300"
        >
          <Smartphone className="w-4 h-4 mr-2" />
          Generate QR Code
        </Button>
        
        {/* Info */}
        <div className="bg-glass-medium rounded-lg p-3 border border-glass-border">
          <p className="text-xs text-neutral-600 text-center">
            QR codes refresh every 5 minutes for security
          </p>
        </div>
      </CardContent>
    </Card>
  );
}