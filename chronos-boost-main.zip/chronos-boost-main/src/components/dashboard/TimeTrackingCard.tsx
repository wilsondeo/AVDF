import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, Download, Calendar } from "lucide-react";

const timeTrackingData = [
  {
    date: "17 Jul",
    day: "Thu",
    checkIn: "10:03",
    checkOut: "19:19",
    hours: "08:15",
    status: "On Time",
    statusColor: "bg-success"
  },
  {
    date: "16 Jul", 
    day: "Wed",
    checkIn: "10:08",
    checkOut: "19:09", 
    hours: "08:00",
    status: "On Time",
    statusColor: "bg-success"
  },
  {
    date: "15 Jul",
    day: "Tue", 
    checkIn: "10:00",
    checkOut: "19:12",
    hours: "08:11", 
    status: "On Time",
    statusColor: "bg-success"
  },
  {
    date: "14 Jul",
    day: "Mon",
    checkIn: "10:07", 
    checkOut: "19:25",
    hours: "08:17",
    status: "Late",
    statusColor: "bg-danger"
  },
  {
    date: "13 Jul",
    day: "Sun",
    checkIn: "-",
    checkOut: "-", 
    hours: "-",
    status: "Weekend",
    statusColor: "bg-info"
  },
  {
    date: "12 Jul",
    day: "Sat",
    checkIn: "-",
    checkOut: "-",
    hours: "-", 
    status: "Weekend",
    statusColor: "bg-info"
  }
];

export function TimeTrackingCard() {
  return (
    <Card className="bg-glass-subtle border-glass-border backdrop-blur-xl shadow-glow h-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-lg bg-gradient-brand/20">
            <Clock className="w-5 h-5 text-brand-600" />
          </div>
          <div>
            <CardTitle className="text-lg font-semibold text-neutral-900">Time Tracking</CardTitle>
            <p className="text-sm text-neutral-600">Recent activity</p>
          </div>
        </div>
        <Button variant="outline" size="sm" className="text-xs">
          <Download className="w-3 h-3 mr-1" />
          Export
        </Button>
      </CardHeader>
      <CardContent className="space-y-0 p-0">
        <div className="overflow-hidden rounded-lg">
          {/* Header */}
          <div className="grid grid-cols-5 gap-4 p-4 bg-glass-medium border-b border-glass-border text-xs font-medium text-neutral-700">
            <div>Date</div>
            <div>Check In</div>
            <div>Check Out</div>
            <div>Hours</div>
            <div>Status</div>
          </div>
          
          {/* Rows */}
          <div className="max-h-64 overflow-y-auto">
            {timeTrackingData.map((entry, index) => (
              <div 
                key={index}
                className="grid grid-cols-5 gap-4 p-4 border-b border-glass-border/50 hover:bg-glass-subtle/50 transition-colors"
              >
                <div className="flex flex-col">
                  <span className="text-sm font-medium text-neutral-900">{entry.date}</span>
                  <span className="text-xs text-neutral-600">{entry.day}</span>
                </div>
                <div className="text-sm text-neutral-900">{entry.checkIn}</div>
                <div className="text-sm text-neutral-900">{entry.checkOut}</div>
                <div className="text-sm font-medium text-brand-600">{entry.hours}</div>
                <div>
                  <Badge 
                    className={`${entry.statusColor} text-white text-xs px-2 py-1`}
                  >
                    {entry.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}