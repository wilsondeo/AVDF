import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Star, Calendar, MapPin } from "lucide-react";

interface ProfileCardProps {
  name: string;
  role: string;
  avatar?: string;
  rating: number;
  totalRatings: number;
  joinDate: string;
  location?: string;
}

export function ProfileCard({
  name,
  role,
  avatar,
  rating,
  totalRatings,
  joinDate,
  location
}: ProfileCardProps) {
  return (
    <div className="relative p-6 rounded-xl bg-gradient-glass border border-border/50 backdrop-blur-sm shadow-glass transition-all duration-300 hover:shadow-glow">
      {/* Background Gradient */}
      <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-primary/10 via-transparent to-accent/5 pointer-events-none" />
      
      <div className="relative z-10 text-center space-y-4">
        {/* Avatar */}
        <div className="relative mx-auto w-24 h-24">
          <Avatar className="w-24 h-24 border-4 border-primary/20 shadow-glow">
            <AvatarImage src={avatar} alt={name} />
            <AvatarFallback className="text-xl font-bold bg-gradient-primary text-primary-foreground">
              {name.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-success rounded-full border-4 border-background flex items-center justify-center">
            <div className="w-3 h-3 bg-white rounded-full animate-pulse" />
          </div>
        </div>

        {/* User Info */}
        <div className="space-y-2">
          <h3 className="text-xl font-bold text-foreground">{name}</h3>
          <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">
            {role}
          </Badge>
        </div>

        {/* Rating */}
        <div className="flex items-center justify-center space-x-2 py-3 px-4 rounded-lg bg-warning/10 border border-warning/20">
          <div className="flex items-center space-x-1">
            <Star className="w-5 h-5 fill-warning text-warning" />
            <span className="text-2xl font-bold text-warning">{rating}</span>
            <span className="text-sm text-muted-foreground">/10</span>
          </div>
          <div className="text-xs text-muted-foreground">
            ({totalRatings} ratings)
          </div>
        </div>

        {/* Additional Info */}
        <div className="space-y-2 pt-2 border-t border-border/50">
          <div className="flex items-center justify-center space-x-1 text-sm text-muted-foreground">
            <Calendar className="w-4 h-4" />
            <span>Joined {joinDate}</span>
          </div>
          {location && (
            <div className="flex items-center justify-center space-x-1 text-sm text-muted-foreground">
              <MapPin className="w-4 h-4" />
              <span>{location}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}