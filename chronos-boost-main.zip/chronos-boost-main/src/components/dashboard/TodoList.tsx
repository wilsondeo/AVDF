import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Calendar, CheckCircle2 } from "lucide-react";

interface TodoItem {
  id: string;
  text: string;
  date: string;
  completed: boolean;
}

interface TodoListProps {
  initialTodos?: TodoItem[];
}

export function TodoList({ initialTodos = [] }: TodoListProps) {
  const [todos, setTodos] = useState<TodoItem[]>(initialTodos);
  const [newTodo, setNewTodo] = useState("");

  const addTodo = () => {
    if (newTodo.trim()) {
      const todo: TodoItem = {
        id: Date.now().toString(),
        text: newTodo,
        date: new Date().toLocaleDateString(),
        completed: false
      };
      setTodos([...todos, todo]);
      setNewTodo("");
    }
  };

  const toggleTodo = (id: string) => {
    setTodos(todos.map(todo => 
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  return (
    <div className="p-6 rounded-xl bg-gradient-glass border border-border/50 backdrop-blur-sm shadow-glass">
      <div className="flex items-center space-x-2 mb-6">
        <CheckCircle2 className="w-5 h-5 text-primary" />
        <h3 className="text-lg font-semibold text-foreground">To-Do</h3>
      </div>

      {/* Add New Todo */}
      <div className="flex space-x-2 mb-4">
        <Input
          value={newTodo}
          onChange={(e) => setNewTodo(e.target.value)}
          placeholder="Add a new task"
          className="flex-1 bg-background/50 border-border/50"
          onKeyPress={(e) => e.key === 'Enter' && addTodo()}
        />
        <Button onClick={addTodo} size="icon" className="shrink-0">
          <Plus className="w-4 h-4" />
        </Button>
      </div>

      {/* Todo List */}
      <div className="space-y-3 max-h-80 overflow-y-auto">
        {todos.map((todo) => (
          <div
            key={todo.id}
            className="flex items-center space-x-3 p-3 rounded-lg bg-background/30 border border-border/30 hover:bg-background/50 transition-colors"
          >
            <Checkbox
              checked={todo.completed}
              onCheckedChange={() => toggleTodo(todo.id)}
              className="data-[state=checked]:bg-success data-[state=checked]:border-success"
            />
            <div className="flex-1 min-w-0">
              <p className={`text-sm ${todo.completed ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
                {todo.text}
              </p>
              <div className="flex items-center space-x-1 mt-1">
                <Calendar className="w-3 h-3 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">{todo.date}</span>
              </div>
            </div>
          </div>
        ))}
        
        {todos.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <CheckCircle2 className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No tasks yet. Add one above!</p>
          </div>
        )}
      </div>
    </div>
  );
}