import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Clock, AlertTriangle } from "lucide-react";

interface TimelogEntry {
  date: string;
  day: string;
  workStart: string;
  workEnd: string;
  workingHours: string;
  status?: "normal" | "weekend" | "late" | "incomplete";
}

interface TimelogTableProps {
  entries: TimelogEntry[];
  title?: string;
}

export function TimelogTable({ entries, title = "Login & Logout History" }: TimelogTableProps) {
  const getStatusBadge = (status?: string) => {
    switch (status) {
      case "weekend":
        return <Badge variant="secondary" className="bg-primary/10 text-primary">Weekend</Badge>;
      case "late":
        return <Badge variant="destructive" className="gap-1"><AlertTriangle className="w-3 h-3" />Late</Badge>;
      case "incomplete":
        return <Badge variant="outline" className="text-warning border-warning/50">Incomplete</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="p-6 rounded-xl bg-gradient-glass border border-border/50 backdrop-blur-sm shadow-glass">
      <div className="flex items-center space-x-2 mb-6">
        <Clock className="w-5 h-5 text-primary" />
        <h3 className="text-lg font-semibold text-foreground">{title}</h3>
      </div>

      <div className="overflow-hidden rounded-lg border border-border/50">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/20 hover:bg-muted/30">
              <TableHead className="font-medium">Date</TableHead>
              <TableHead className="font-medium">Work Start</TableHead>
              <TableHead className="font-medium">Work End</TableHead>
              <TableHead className="font-medium">Working Hours</TableHead>
              <TableHead className="font-medium">Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {entries.map((entry, index) => (
              <TableRow 
                key={index}
                className="border-border/50 hover:bg-muted/10 transition-colors"
              >
                <TableCell>
                  <div>
                    <div className="font-medium">{entry.date}</div>
                    <div className="text-sm text-muted-foreground">{entry.day}</div>
                  </div>
                </TableCell>
                <TableCell className="font-mono text-sm">{entry.workStart}</TableCell>
                <TableCell className="font-mono text-sm">{entry.workEnd}</TableCell>
                <TableCell className="font-mono text-sm font-medium">{entry.workingHours}</TableCell>
                <TableCell>{getStatusBadge(entry.status)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}