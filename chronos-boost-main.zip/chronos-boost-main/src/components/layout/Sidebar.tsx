import { 
  LayoutDashboard, 
  Calendar, 
  FolderOpen, 
  Clock, 
  Bug, 
  Users, 
  Settings,
  MessageSquare,
  BarChart3,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { NavLink } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useState } from "react";

const navigationItems = [
  {
    title: "Dashboard",
    href: "/",
    icon: LayoutDashboard,
  },
  {
    title: "Projects",
    href: "/projects",
    icon: FolderOpen,
  },
  {
    title: "Timesheet",
    href: "/timesheet",
    icon: Clock,
  },
  {
    title: "Bug Tracking",
    href: "/bugs",
    icon: Bug,
  },
  {
    title: "Team",
    href: "/team",
    icon: Users,
  },
  {
    title: "Analytics",
    href: "/analytics",
    icon: BarChart3,
  },
  {
    title: "Chat",
    href: "/chat",
    icon: MessageSquare,
  },
  {
    title: "Calendar",
    href: "/calendar",
    icon: Calendar,
  },
];

export function Sidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <aside className={cn(
      "sticky top-16 h-[calc(100vh-4rem)] border-r border-glass-border bg-glass-subtle transition-all duration-300",
      isCollapsed ? "w-16" : "w-64"
    )}>
      <div className="flex flex-col h-full">
        {/* Toggle Button */}
        <div className="flex items-center justify-end p-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="h-8 w-8"
          >
            {isCollapsed ? (
              <ChevronRight className="h-4 w-4" />
            ) : (
              <ChevronLeft className="h-4 w-4" />
            )}
          </Button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 pb-4">
          <ul className="space-y-2">
            {navigationItems.map((item) => (
              <li key={item.href}>
                <NavLink
                  to={item.href}
                  className={({ isActive }) =>
                    cn(
                      "flex items-center rounded-lg px-3 py-2 text-sm font-medium transition-all duration-200",
                      "hover:bg-glass-medium hover:text-brand-600",
                      isActive 
                        ? "bg-gradient-brand text-white shadow-glow-brand" 
                        : "text-neutral-600 hover:text-neutral-900"
                    )
                  }
                >
                  <item.icon className={cn("h-5 w-5", !isCollapsed && "mr-3")} />
                  {!isCollapsed && (
                    <span className="truncate">{item.title}</span>
                  )}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>

        {/* Bottom Section */}
        <div className="p-3 border-t border-glass-border">
          <NavLink
            to="/settings"
            className={({ isActive }) =>
              cn(
                "flex items-center rounded-lg px-3 py-2 text-sm font-medium transition-all duration-200",
                "hover:bg-glass-medium hover:text-brand-600",
                isActive 
                  ? "bg-gradient-brand text-white shadow-glow-brand" 
                  : "text-neutral-600 hover:text-neutral-900"
              )
            }
          >
            <Settings className={cn("h-5 w-5", !isCollapsed && "mr-3")} />
            {!isCollapsed && <span>Settings</span>}
          </NavLink>
        </div>
      </div>
    </aside>
  );
}