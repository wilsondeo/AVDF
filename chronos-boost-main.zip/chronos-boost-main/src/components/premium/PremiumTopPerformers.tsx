import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { PremiumCard } from "./PremiumCard";
import { Trophy, Medal, Award, Crown, TrendingUp } from "lucide-react";
import { cn } from "@/lib/utils";

interface Performer {
  id: string;
  name: string;
  role: string;
  avatar?: string;
  score: number;
  department: string;
  improvement: number;
}

interface PremiumTopPerformersProps {
  performers: Performer[];
  period?: string;
}

export function PremiumTopPerformers({ 
  performers, 
  period = "this month" 
}: PremiumTopPerformersProps) {
  const getPositionIcon = (index: number) => {
    switch (index) {
      case 0:
        return <Crown className="w-5 h-5 text-warning" />;
      case 1:
        return <Trophy className="w-5 h-5 text-gray-400" />;
      case 2:
        return <Medal className="w-5 h-5 text-orange-400" />;
      default:
        return (
          <div className="w-8 h-8 rounded-full bg-muted/20 flex items-center justify-center">
            <span className="text-sm font-bold text-muted-foreground">#{index + 1}</span>
          </div>
        );
    }
  };

  const getPositionGradient = (index: number) => {
    switch (index) {
      case 0:
        return "bg-gradient-to-r from-warning/20 to-yellow-500/20 border-warning/30";
      case 1:
        return "bg-gradient-to-r from-gray-400/20 to-gray-500/20 border-gray-400/30";
      case 2:
        return "bg-gradient-to-r from-orange-400/20 to-orange-500/20 border-orange-400/30";
      default:
        return "bg-background-secondary/50 border-white/10";
    }
  };

  return (
    <PremiumCard variant="glow" className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-lg bg-gradient-warm">
            <Trophy className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Top Performers</h3>
            <p className="text-sm text-muted-foreground">{period}</p>
          </div>
        </div>
        <TrendingUp className="w-5 h-5 text-accent" />
      </div>

      {/* Winner Spotlight */}
      {performers[0] && (
        <div className="relative p-6 rounded-2xl bg-gradient-to-r from-warning/20 via-yellow-500/10 to-orange-500/20 border border-warning/30 overflow-hidden">
          {/* Animated background */}
          <div className="absolute inset-0 bg-gradient-to-r from-warning/10 to-yellow-500/10 animate-gradient" />
          
          {/* Floating crown */}
          <div className="absolute top-4 right-4 text-4xl animate-float">
            👑
          </div>
          
          <div className="relative z-10 flex items-center space-x-4">
            <div className="relative">
              <Avatar className="w-16 h-16 border-4 border-warning/50 shadow-glow-primary">
                <AvatarImage src={performers[0].avatar} />
                <AvatarFallback className="bg-gradient-hero text-white text-lg font-bold">
                  {performers[0].name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div className="absolute -top-2 -right-2 w-6 h-6 bg-warning rounded-full flex items-center justify-center">
                <span className="text-xs font-bold text-background">1</span>
              </div>
            </div>
            
            <div className="flex-1">
              <h4 className="font-bold text-lg text-foreground mb-1">{performers[0].name}</h4>
              <p className="text-sm text-muted-foreground mb-2">{performers[0].role}</p>
              <div className="flex items-center space-x-2">
                <Badge variant="outline" className="text-warning border-warning/50 bg-warning/10">
                  {performers[0].department}
                </Badge>
                <Badge variant="outline" className="text-accent border-accent/50 bg-accent/10">
                  +{performers[0].improvement}%
                </Badge>
              </div>
            </div>
            
            <div className="text-right">
              <p className="text-3xl font-bold text-warning">{performers[0].score}</p>
              <p className="text-sm text-muted-foreground">points</p>
            </div>
          </div>
        </div>
      )}

      {/* Performers List */}
      <div className="space-y-3">
        {performers.slice(1, 6).map((performer, index) => {
          const actualIndex = index + 1;
          
          return (
            <div
              key={performer.id}
              className={cn(
                "flex items-center space-x-4 p-4 rounded-xl border transition-all duration-300 hover:scale-[1.02]",
                getPositionGradient(actualIndex)
              )}
            >
              <div className="flex items-center justify-center">
                {getPositionIcon(actualIndex)}
              </div>
              
              <Avatar className="w-12 h-12 border-2 border-white/20">
                <AvatarImage src={performer.avatar} />
                <AvatarFallback className="text-sm font-medium bg-gradient-cool text-white">
                  {performer.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-foreground truncate">{performer.name}</p>
                <p className="text-sm text-muted-foreground truncate">{performer.role}</p>
                <div className="flex items-center space-x-2 mt-1">
                  <Badge variant="outline" className="text-xs px-2 py-0">
                    {performer.department}
                  </Badge>
                  {performer.improvement > 0 && (
                    <span className="text-xs text-accent font-medium">
                      +{performer.improvement}%
                    </span>
                  )}
                </div>
              </div>
              
              <div className="text-right">
                <p className="text-xl font-bold text-foreground">{performer.score}</p>
                <p className="text-xs text-muted-foreground">pts</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* View All Button */}
      <button className="w-full py-3 bg-gradient-accent text-white font-semibold rounded-xl hover:shadow-glow-accent transition-all duration-300 btn-premium">
        View Full Leaderboard
      </button>

      {performers.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <Trophy className="w-16 h-16 mx-auto mb-4 opacity-30" />
          <p className="text-lg font-medium mb-2">No Performance Data</p>
          <p className="text-sm">Start tracking to see top performers</p>
        </div>
      )}
    </PremiumCard>
  );
}