import { useState } from "react";
import { Button } from "@/components/ui/button";
import { PremiumCard } from "./PremiumCard";
import { Brain, RotateCcw, Play, Square, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

export function PremiumMindGame() {
  const [sequence, setSequence] = useState<number[]>([]);
  const [userSequence, setUserSequence] = useState<number[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isShowingSequence, setIsShowingSequence] = useState(false);
  const [activeButton, setActiveButton] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [bestScore, setBestScore] = useState(12); // Mock best score

  const colors = [
    { bg: 'bg-accent', glow: 'shadow-[0_0_20px_hsl(var(--accent))]' },
    { bg: 'bg-primary', glow: 'shadow-[0_0_20px_hsl(var(--primary))]' },
    { bg: 'bg-warning', glow: 'shadow-[0_0_20px_hsl(var(--warning))]' },
    { bg: 'bg-destructive', glow: 'shadow-[0_0_20px_hsl(var(--destructive))]' }
  ];

  const startGame = () => {
    setSequence([Math.floor(Math.random() * 4)]);
    setUserSequence([]);
    setScore(0);
    setGameOver(false);
    setIsPlaying(true);
    showSequence([Math.floor(Math.random() * 4)]);
  };

  const showSequence = (seq: number[]) => {
    setIsShowingSequence(true);
    let i = 0;
    const interval = setInterval(() => {
      setActiveButton(seq[i]);
      setTimeout(() => setActiveButton(null), 400);
      i++;
      if (i >= seq.length) {
        clearInterval(interval);
        setIsShowingSequence(false);
      }
    }, 700);
  };

  const handleButtonClick = (index: number) => {
    if (isShowingSequence || !isPlaying) return;

    const newUserSequence = [...userSequence, index];
    setUserSequence(newUserSequence);

    if (newUserSequence[newUserSequence.length - 1] !== sequence[newUserSequence.length - 1]) {
      setGameOver(true);
      setIsPlaying(false);
      if (score > bestScore) setBestScore(score);
      return;
    }

    if (newUserSequence.length === sequence.length) {
      setScore(score + 1);
      setUserSequence([]);
      const newSequence = [...sequence, Math.floor(Math.random() * 4)];
      setSequence(newSequence);
      setTimeout(() => showSequence(newSequence), 1000);
    }
  };

  const resetGame = () => {
    setSequence([]);
    setUserSequence([]);
    setIsPlaying(false);
    setScore(0);
    setGameOver(false);
  };

  return (
    <PremiumCard variant="elevated" className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-lg bg-gradient-accent">
            <Brain className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Memory Challenge</h3>
            <p className="text-xs text-muted-foreground">Test your memory skills</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs text-muted-foreground">Best</p>
          <p className="text-lg font-bold text-primary">{bestScore}</p>
        </div>
      </div>

      {/* Score Display */}
      <div className="flex items-center justify-between p-4 rounded-xl bg-gradient-hero">
        <div className="text-white">
          <p className="text-sm opacity-80">Current Score</p>
          <p className="text-3xl font-bold">{score}</p>
        </div>
        <div className="text-white text-right">
          <p className="text-sm opacity-80">Level</p>
          <p className="text-xl font-bold">{sequence.length}</p>
        </div>
      </div>

      {/* Game Grid */}
      <div className="grid grid-cols-2 gap-3">
        {colors.map((color, index) => (
          <button
            key={index}
            onClick={() => handleButtonClick(index)}
            disabled={isShowingSequence || !isPlaying}
            className={cn(
              "h-16 rounded-xl transition-all duration-300 border-2 border-white/10",
              "hover:scale-105 active:scale-95",
              color.bg,
              activeButton === index ? `scale-110 ${color.glow}` : "opacity-70 hover:opacity-90",
              (isShowingSequence || !isPlaying) && "cursor-not-allowed"
            )}
          />
        ))}
      </div>

      {/* Game Status */}
      {isShowingSequence && (
        <div className="text-center p-3 rounded-lg bg-primary/20 border border-primary/30">
          <div className="flex items-center justify-center space-x-2">
            <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            <p className="text-primary text-sm font-medium">Watch the sequence...</p>
          </div>
        </div>
      )}

      {gameOver && (
        <div className="text-center p-4 rounded-xl bg-destructive/20 border border-destructive/30">
          <Zap className="w-8 h-8 mx-auto mb-2 text-destructive" />
          <p className="text-destructive font-semibold mb-1">Game Over!</p>
          <p className="text-sm text-muted-foreground">You reached level {score}</p>
          {score === bestScore && score > 0 && (
            <p className="text-xs text-warning mt-1">🎉 New best score!</p>
          )}
        </div>
      )}

      {!isPlaying && !gameOver && (
        <div className="text-center p-4 rounded-xl bg-accent/20 border border-accent/30">
          <Brain className="w-8 h-8 mx-auto mb-2 text-accent" />
          <p className="text-accent text-sm">Ready to challenge your memory?</p>
        </div>
      )}

      {/* Controls */}
      <div className="flex space-x-3">
        {!isPlaying ? (
          <Button 
            onClick={startGame} 
            className="flex-1 btn-premium h-12 text-base font-semibold"
          >
            <Play className="w-5 h-5 mr-2" />
            Start Game
          </Button>
        ) : (
          <Button 
            onClick={resetGame} 
            variant="outline" 
            className="flex-1 h-12 bg-background-secondary/50 border-white/10 hover:bg-destructive/20"
          >
            <Square className="w-5 h-5 mr-2" />
            Stop Game
          </Button>
        )}
        
        <Button 
          onClick={resetGame} 
          variant="outline" 
          size="icon"
          className="h-12 w-12 bg-background-secondary/50 border-white/10"
        >
          <RotateCcw className="w-5 h-5" />
        </Button>
      </div>
    </PremiumCard>
  );
}