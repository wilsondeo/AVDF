import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell } from "recharts";
import { PremiumCard } from "./PremiumCard";
import { TrendingUp } from "lucide-react";

interface EffortData {
  name: string;
  billable: number;
  nonBillable: number;
  office: number;
}

interface PremiumEffortChartProps {
  data: EffortData[];
  title?: string;
  period?: string;
}

const colors = {
  billable: "#10b981", // Emerald
  nonBillable: "#ef4444", // Red  
  office: "#3b82f6" // Blue
};

export function PremiumEffortChart({ 
  data, 
  title = "Performance Analytics", 
  period = "July 2025" 
}: PremiumEffortChartProps) {
  return (
    <PremiumCard variant="glow" className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-gradient-accent">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-foreground">{title}</h3>
          </div>
          <p className="text-muted-foreground">{period}</p>
        </div>
        
        {/* Period selector */}
        <div className="flex space-x-2">
          {['7D', '1M', '3M'].map((period) => (
            <button
              key={period}
              className="px-3 py-1 text-xs font-medium rounded-lg bg-background-secondary/50 text-muted-foreground hover:bg-primary/20 hover:text-primary transition-all duration-200"
            >
              {period}
            </button>
          ))}
        </div>
      </div>

      {/* Chart */}
      <div className="h-80 relative">
        <div className="absolute inset-0 bg-gradient-to-t from-background-secondary/20 to-transparent rounded-xl" />
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <XAxis 
              dataKey="name" 
              axisLine={false}
              tickLine={false}
              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
            />
            <YAxis 
              axisLine={false}
              tickLine={false}
              tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
              domain={[0, 'dataMax + 50']}
            />
            <Bar 
              dataKey="billable" 
              fill={colors.billable} 
              radius={[8, 8, 0, 0]}
              className="drop-shadow-lg"
            />
            <Bar 
              dataKey="nonBillable" 
              fill={colors.nonBillable} 
              radius={[8, 8, 0, 0]}
              className="drop-shadow-lg" 
            />
            <Bar 
              dataKey="office" 
              fill={colors.office} 
              radius={[8, 8, 0, 0]}
              className="drop-shadow-lg"
            />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Legend with stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="text-center p-4 rounded-xl bg-accent/10 border border-accent/20">
          <div className="flex items-center justify-center space-x-2 mb-2">
            <div className="w-3 h-3 rounded-full bg-accent" />
            <span className="text-sm font-medium text-accent">Billable</span>
          </div>
          <p className="text-2xl font-bold text-foreground">186.83h</p>
          <p className="text-xs text-muted-foreground">+12% from last month</p>
        </div>
        
        <div className="text-center p-4 rounded-xl bg-destructive/10 border border-destructive/20">
          <div className="flex items-center justify-center space-x-2 mb-2">
            <div className="w-3 h-3 rounded-full bg-destructive" />
            <span className="text-sm font-medium text-destructive">Non-billable</span>
          </div>
          <p className="text-2xl font-bold text-foreground">147.25h</p>
          <p className="text-xs text-muted-foreground">-8% from last month</p>
        </div>
        
        <div className="text-center p-4 rounded-xl bg-primary/10 border border-primary/20">
          <div className="flex items-center justify-center space-x-2 mb-2">
            <div className="w-3 h-3 rounded-full bg-primary" />
            <span className="text-sm font-medium text-primary">Office</span>
          </div>
          <p className="text-2xl font-bold text-foreground">45h</p>
          <p className="text-xs text-muted-foreground">+5% from last month</p>
        </div>
      </div>
    </PremiumCard>
  );
}