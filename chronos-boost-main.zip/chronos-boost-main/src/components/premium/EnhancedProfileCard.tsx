import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { PremiumCard } from "./PremiumCard";
import { Star, MapPin, Calendar, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

interface EnhancedProfileCardProps {
  name: string;
  role: string;
  avatar?: string;
  rating: number;
  totalRatings: number;
  joinDate: string;
  location?: string;
  status?: "online" | "away" | "offline";
}

export function EnhancedProfileCard({
  name,
  role,
  avatar,
  rating,
  totalRatings,
  joinDate,
  location,
  status = "online"
}: EnhancedProfileCardProps) {
  const statusColors = {
    online: "bg-accent",
    away: "bg-warning",
    offline: "bg-muted"
  };

  return (
    <PremiumCard variant="elevated" className="text-center space-y-6">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-hero opacity-20 rounded-t-2xl" />
      
      {/* Profile Section */}
      <div className="relative pt-4">
        <div className="relative inline-block">
          <Avatar className="w-24 h-24 border-4 border-white/20 shadow-medium">
            <AvatarImage src={avatar} alt={name} />
            <AvatarFallback className="text-xl font-bold bg-gradient-hero text-white">
              {name.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          
          {/* Status indicator */}
          <div className={cn(
            "absolute -bottom-1 -right-1 w-6 h-6 rounded-full border-4 border-background",
            statusColors[status]
          )}>
            <div className="w-full h-full rounded-full animate-pulse" />
          </div>
          
          {/* Floating badge */}
          <div className="absolute -top-2 -right-2 bg-gradient-accent text-white text-xs px-2 py-1 rounded-full font-bold shadow-medium">
            ⭐ TOP
          </div>
        </div>

        <div className="mt-4 space-y-2">
          <h3 className="text-xl font-bold text-foreground">{name}</h3>
          <Badge 
            variant="secondary" 
            className="bg-primary/20 text-primary border-primary/30 backdrop-blur-sm"
          >
            {role}
          </Badge>
        </div>
      </div>

      {/* Rating Section */}
      <div className="bg-gradient-warm p-4 rounded-xl border border-white/10 backdrop-blur-sm">
        <div className="flex items-center justify-center space-x-2 mb-2">
          <Star className="w-5 h-5 fill-warning text-warning" />
          <span className="text-2xl font-bold text-white">{rating}</span>
          <span className="text-sm text-white/70">/10</span>
        </div>
        <p className="text-xs text-white/70">
          Based on {totalRatings} reviews
        </p>
      </div>

      {/* Info Grid */}
      <div className="grid grid-cols-1 gap-3">
        <div className="flex items-center space-x-3 p-3 rounded-lg bg-background-secondary/50 border border-white/5">
          <Calendar className="w-4 h-4 text-primary" />
          <div className="text-left">
            <p className="text-xs text-muted-foreground">Joined</p>
            <p className="text-sm font-medium">{joinDate}</p>
          </div>
        </div>
        
        {location && (
          <div className="flex items-center space-x-3 p-3 rounded-lg bg-background-secondary/50 border border-white/5">
            <MapPin className="w-4 h-4 text-accent" />
            <div className="text-left">
              <p className="text-xs text-muted-foreground">Location</p>
              <p className="text-sm font-medium">{location}</p>
            </div>
          </div>
        )}
      </div>

      {/* Action Button */}
      <button className="w-full py-3 bg-gradient-hero text-white font-semibold rounded-xl hover:shadow-glow-primary transition-all duration-300 btn-premium">
        <div className="flex items-center justify-center space-x-2">
          <Zap className="w-4 h-4" />
          <span>View Profile</span>
        </div>
      </button>
    </PremiumCard>
  );
}