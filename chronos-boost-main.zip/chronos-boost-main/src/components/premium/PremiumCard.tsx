import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface PremiumCardProps {
  children: ReactNode;
  className?: string;
  variant?: "default" | "glow" | "elevated" | "minimal";
  interactive?: boolean;
}

export function PremiumCard({ 
  children, 
  className, 
  variant = "default",
  interactive = false 
}: PremiumCardProps) {
  const variants = {
    default: "glass-card",
    glow: "glass-card glow-primary",
    elevated: "glass-card shadow-hard transform hover:scale-[1.02]",
    minimal: "bg-background-secondary/50 border border-white/5 backdrop-blur-sm"
  };

  return (
    <div className={cn(
      "rounded-2xl p-6 transition-all duration-500 ease-spring",
      variants[variant],
      interactive && "hover:shadow-glow-primary hover:scale-[1.02] cursor-pointer",
      className
    )}>
      {children}
    </div>
  );
}

interface MetricCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: ReactNode;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  gradient?: "hero" | "accent" | "warm" | "cool";
  className?: string;
}

export function MetricCard({
  title,
  value,
  subtitle,
  icon,
  trend,
  gradient = "hero",
  className
}: MetricCardProps) {
  const gradients = {
    hero: "bg-gradient-hero",
    accent: "bg-gradient-accent", 
    warm: "bg-gradient-warm",
    cool: "bg-gradient-cool"
  };

  return (
    <PremiumCard 
      variant="glow" 
      interactive 
      className={cn("group relative overflow-hidden", className)}
    >
      {/* Animated background */}
      <div className={cn(
        "absolute inset-0 opacity-10 group-hover:opacity-20 transition-opacity duration-500",
        gradients[gradient],
        "gradient-animate"
      )} />
      
      {/* Floating particles effect */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(3)].map((_, i) => (
          <div
            key={i}
            className={cn(
              "absolute w-2 h-2 rounded-full opacity-20",
              "bg-white animate-float",
              i === 0 && "top-4 right-8 animation-delay-1000",
              i === 1 && "top-12 right-16 animation-delay-2000", 
              i === 2 && "top-8 right-4 animation-delay-3000"
            )}
            style={{ animationDelay: `${i * 0.5}s` }}
          />
        ))}
      </div>

      <div className="relative z-10">
        <div className="flex items-start justify-between mb-6">
          <div className="space-y-2">
            <p className="text-sm font-medium text-white/70 uppercase tracking-wider">
              {title}
            </p>
            <div className="flex items-end space-x-3">
              <span className="text-4xl font-bold text-white">
                {value}
              </span>
              {trend && (
                <div className={cn(
                  "px-3 py-1 rounded-full text-xs font-semibold",
                  "backdrop-blur-sm border border-white/20",
                  trend.isPositive 
                    ? "bg-accent/20 text-accent-light" 
                    : "bg-destructive/20 text-destructive"
                )}>
                  {trend.isPositive ? "↗" : "↘"} {Math.abs(trend.value)}%
                </div>
              )}
            </div>
            {subtitle && (
              <p className="text-sm text-white/60">{subtitle}</p>
            )}
          </div>
          
          {icon && (
            <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 group-hover:scale-110 transition-transform duration-300">
              {icon}
            </div>
          )}
        </div>
      </div>
    </PremiumCard>
  );
}