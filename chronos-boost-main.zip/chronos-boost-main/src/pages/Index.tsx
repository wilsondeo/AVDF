import { MetricCard, PremiumCard } from "@/components/premium/PremiumCard";
import { EnhancedProfileCard } from "@/components/premium/EnhancedProfileCard";
import { PremiumEffortChart } from "@/components/premium/PremiumEffortChart";
import { PremiumMindGame } from "@/components/premium/PremiumMindGame";
import { PremiumTopPerformers } from "@/components/premium/PremiumTopPerformers";
import { TimeTrackingCard } from "@/components/dashboard/TimeTrackingCard";
import { QRAccessCard } from "@/components/dashboard/QRAccessCard";
import { Calendar } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Clock, Users, TrendingUp, Bug, Zap, Target, Calendar as CalendarIcon, 
  CheckCircle2, Plus, QrCode, AlertTriangle, MapPin 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";

const Index = () => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());

  // Sample data with enhanced information
  const effortData = [
    { name: "Anup", billable: 186.83, nonBillable: 147.25, office: 45 }
  ];

  const timelogData = [
    { date: "17 Jul", day: "Thu", workStart: "10:03", workEnd: "19:19", workingHours: "08:15", status: "normal" as const },
    { date: "16 Jul", day: "Wed", workStart: "10:08", workEnd: "19:09", workingHours: "08:00", status: "normal" as const },
    { date: "15 Jul", day: "Tue", workStart: "10:00", workEnd: "19:12", workingHours: "08:11", status: "normal" as const },
    { date: "14 Jul", day: "Mon", workStart: "10:07", workEnd: "19:25", workingHours: "08:17", status: "late" as const },
    { date: "13 Jul", day: "Sun", workStart: "-", workEnd: "-", workingHours: "-", status: "weekend" as const },
    { date: "12 Jul", day: "Sat", workStart: "-", workEnd: "-", workingHours: "-", status: "weekend" as const }
  ];

  const performers = [
    { id: "1", name: "Sonali Maharana", role: "eLearning Development", avatar: "", score: 95, department: "Development", improvement: 12 },
    { id: "2", name: "Subhashree Rout", role: "Multimedia Design", avatar: "", score: 88, department: "Design", improvement: 8 },
    { id: "3", name: "Jayaprakash Rout", role: "Quality Assurance", avatar: "", score: 82, department: "QA", improvement: 15 }
  ];

  const getStatusBadge = (status?: string) => {
    switch (status) {
      case "weekend":
        return <Badge className="bg-primary/20 text-primary border-primary/30">Weekend</Badge>;
      case "late":
        return <Badge className="bg-destructive/20 text-destructive border-destructive/30 gap-1">
          <AlertTriangle className="w-3 h-3" />Late
        </Badge>;
      case "incomplete":
        return <Badge variant="outline" className="text-warning border-warning/50">Incomplete</Badge>;
      default:
        return <Badge className="bg-accent/20 text-accent border-accent/30">On Time</Badge>;
    }
  };

  return (
    <div className="p-6 space-y-6 animate-stagger-in">
      {/* Header Section */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-hero bg-clip-text text-transparent">
            Dashboard
          </h1>
          <p className="text-muted-foreground mt-2">
            Welcome back, Anup Jena! Here's your productivity overview.
          </p>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Left Column - Profile & Stats */}
        <div className="lg:col-span-1 space-y-6">
          <EnhancedProfileCard
            name="Anup Jena"
            role="Software Developer"
            avatar="/placeholder.svg"
            rating={7.5}
            totalRatings={25}
            joinDate="02-Jun-2025"
            location="Bhubaneswar, India"
            status="online"
          />
          
          <div className="grid grid-cols-1 gap-4">
            <MetricCard
              title="Punctuality"
              value="79%"
              subtitle="July"
              icon="🎯"
              gradient="warm"
            />
            
            <MetricCard
              title="Late Coming"
              value="11"
              subtitle="in 2025"
              icon="⏰"
              gradient="accent"
            />
            
            <MetricCard
              title="Extra Effort"
              value="6 hr(s) 20 min(s)"
              subtitle="This month"
              icon="⚡"
              gradient="cool"
            />
          </div>
        </div>

        {/* Right Columns - Charts & Activities */}
        <div className="lg:col-span-3 space-y-6">
          {/* Time Tracking & QR Access Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <TimeTrackingCard />
            <QRAccessCard />
          </div>
          
          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <PremiumEffortChart data={effortData} />
            <PremiumTopPerformers performers={performers} />
          </div>
          
          {/* Bottom Row - Game & Stats */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <PremiumMindGame />
            <PremiumCard variant="elevated" className="p-6">
              <h3 className="text-lg font-semibold mb-4 text-foreground">
                Quick Stats
              </h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-glass-primary rounded-lg">
                  <span className="text-sm text-muted-foreground">Today's Hours</span>
                  <span className="font-semibold text-primary">8.5</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-glass-primary rounded-lg">
                  <span className="text-sm text-muted-foreground">Week's Total</span>
                  <span className="font-semibold text-accent">42.5</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-glass-primary rounded-lg">
                  <span className="text-sm text-muted-foreground">Projects Active</span>
                  <span className="font-semibold text-warning">5</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-glass-primary rounded-lg">
                  <span className="text-sm text-muted-foreground">Tasks Completed</span>
                  <span className="font-semibold text-secondary">23</span>
                </div>
              </div>
            </PremiumCard>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
