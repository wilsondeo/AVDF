import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Plus, Filter, Bug, AlertTriangle, CheckCircle, Clock } from "lucide-react";
import { PremiumCard } from "@/components/premium/PremiumCard";

const bugData = [
  {
    id: "T1477",
    title: "Mental Health Slide: Human Brain",
    description: "Issue in page navigation.",
    severity: "Major",
    functionality: "page navigation-toc",
    priority: "High",
    project: "BAI Captivate 15 Courses",
    module: "30801c",
    assignedTo: "Akhila",
    raisedBy: "Biswanath",
    devStatus: "Open",
    qaStatus: "Open",
    status: "open"
  },
  {
    id: "T1476",
    title: "Mental Health Slide: Human Brain",
    description: "Issue in page navigation.",
    severity: "Major",
    functionality: "page navigation-toc",
    priority: "High",
    project: "BAI Captivate 15 Courses",
    module: "30801c",
    assignedTo: "Akhila",
    raisedBy: "Biswanath",
    devStatus: "Wait",
    qaStatus: "Open",
    status: "in-progress"
  },
  {
    id: "T1460",
    title: "Test bug - Slide: Differential Privacy",
    description: "Enter Bug details.",
    severity: "Major",
    functionality: "button-hover",
    priority: "High",
    project: "Hexalearn Internal",
    module: "JavaScript R&D",
    assignedTo: "Arup",
    raisedBy: "Bibek",
    devStatus: "Pass",
    qaStatus: "Pass",
    status: "resolved"
  },
  {
    id: "T1459",
    title: "Demo bug.",
    description: "Enter bug details",
    severity: "Major",
    functionality: "ui-graphics",
    priority: "High",
    project: "Hexalearn Internal",
    module: "JavaScript R&D",
    assignedTo: "Arup",
    raisedBy: "Bibek",
    devStatus: "Pass",
    qaStatus: "Pass",
    status: "resolved"
  },
  {
    id: "T1458",
    title: "Clinical research.",
    description: "Enter bug details.",
    severity: "Minor",
    functionality: "alignment",
    priority: "High",
    project: "Hexalearn Internal",
    module: "JavaScript R&D",
    assignedTo: "Arup",
    raisedBy: "Bibek",
    devStatus: "Open",
    qaStatus: "Open",
    status: "open"
  }
];

export default function BugTracking() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-brand bg-clip-text text-transparent">
            Bug Tracking
          </h1>
          <p className="text-neutral-600 mt-2">
            Track and manage project bugs and issues
          </p>
        </div>
        <Button className="bg-gradient-brand text-white">
          <Plus className="w-4 h-4 mr-2" />
          Add Bug
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <PremiumCard variant="default">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 rounded-lg bg-gradient-brand/20">
                <Bug className="w-5 h-5 text-brand-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-brand-600">23</div>
                <div className="text-sm text-neutral-600">Total Bugs</div>
              </div>
            </div>
          </CardContent>
        </PremiumCard>
        
        <PremiumCard variant="default">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 rounded-lg bg-gradient-warning/20">
                <AlertTriangle className="w-5 h-5 text-warning" />
              </div>
              <div>
                <div className="text-2xl font-bold text-warning">8</div>
                <div className="text-sm text-neutral-600">Open Bugs</div>
              </div>
            </div>
          </CardContent>
        </PremiumCard>
        
        <PremiumCard variant="default">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 rounded-lg bg-gradient-accent/20">
                <Clock className="w-5 h-5 text-accent" />
              </div>
              <div>
                <div className="text-2xl font-bold text-accent">5</div>
                <div className="text-sm text-neutral-600">In Progress</div>
              </div>
            </div>
          </CardContent>
        </PremiumCard>
        
        <PremiumCard variant="default">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 rounded-lg bg-gradient-success/20">
                <CheckCircle className="w-5 h-5 text-success" />
              </div>
              <div>
                <div className="text-2xl font-bold text-success">10</div>
                <div className="text-sm text-neutral-600">Resolved</div>
              </div>
            </div>
          </CardContent>
        </PremiumCard>
      </div>

      {/* Filters */}
      <PremiumCard variant="default">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-8 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Bug ID:</label>
              <Input placeholder="Enter Bug ID" className="bg-glass-subtle border-glass-border" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Title:</label>
              <Input placeholder="Bug Title" className="bg-glass-subtle border-glass-border" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Client:</label>
              <Select>
                <SelectTrigger className="bg-glass-subtle border-glass-border">
                  <SelectValue placeholder="Select Client" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bai">BAI</SelectItem>
                  <SelectItem value="hexalearn">Hexalearn</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Project:</label>
              <Select>
                <SelectTrigger className="bg-glass-subtle border-glass-border">
                  <SelectValue placeholder="Select Project" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bai-courses">BAI Captivate 15 Courses</SelectItem>
                  <SelectItem value="internal">Hexalearn Internal</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Severity:</label>
              <Select>
                <SelectTrigger className="bg-glass-subtle border-glass-border">
                  <SelectValue placeholder="Select Severity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="major">Major</SelectItem>
                  <SelectItem value="minor">Minor</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Status:</label>
              <Select>
                <SelectTrigger className="bg-glass-subtle border-glass-border">
                  <SelectValue placeholder="Select Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="open">Open</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button className="w-full bg-gradient-brand">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
        </CardContent>
      </PremiumCard>

      {/* Bug Table */}
      <PremiumCard variant="elevated" className="overflow-hidden">
        <CardHeader>
          <CardTitle className="text-xl font-semibold">Bug Reports</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-glass-medium border-b border-glass-border">
                <tr>
                  <th className="text-left p-3 font-medium text-neutral-700">ID</th>
                  <th className="text-left p-3 font-medium text-neutral-700">Title</th>
                  <th className="text-left p-3 font-medium text-neutral-700">Severity</th>
                  <th className="text-left p-3 font-medium text-neutral-700">Functionality</th>
                  <th className="text-left p-3 font-medium text-neutral-700">Priority</th>
                  <th className="text-left p-3 font-medium text-neutral-700">Project</th>
                  <th className="text-left p-3 font-medium text-neutral-700">Assigned To</th>
                  <th className="text-left p-3 font-medium text-neutral-700">Dev Status</th>
                  <th className="text-left p-3 font-medium text-neutral-700">QA Status</th>
                  <th className="text-left p-3 font-medium text-neutral-700">Action</th>
                </tr>
              </thead>
              <tbody>
                {bugData.map((bug) => (
                  <tr key={bug.id} className="border-b border-glass-border hover:bg-glass-subtle transition-colors">
                    <td className="p-3">
                      <span className="font-medium text-brand-600">{bug.id}</span>
                    </td>
                    <td className="p-3 max-w-xs">
                      <div className="truncate font-medium">{bug.title}</div>
                      <div className="text-xs text-neutral-500 truncate">{bug.description}</div>
                    </td>
                    <td className="p-3">
                      <Badge 
                        variant="outline"
                        className={
                          bug.severity === 'Major' ? 'border-warning text-warning' : 
                          bug.severity === 'Minor' ? 'border-accent text-accent' : 
                          'border-red-500 text-red-500'
                        }
                      >
                        {bug.severity}
                      </Badge>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center space-x-1 text-xs">
                        <span className="px-2 py-1 bg-glass-medium rounded">{bug.functionality}</span>
                      </div>
                    </td>
                    <td className="p-3">
                      <Badge variant="outline" className="border-red-500 text-red-500">
                        {bug.priority}
                      </Badge>
                    </td>
                    <td className="p-3">
                      <div className="text-xs max-w-xs truncate">{bug.project}</div>
                    </td>
                    <td className="p-3">
                      <span className="text-sm">{bug.assignedTo}</span>
                    </td>
                    <td className="p-3">
                      <Badge 
                        variant="outline"
                        className={
                          bug.devStatus === 'Pass' ? 'border-success text-success' : 
                          bug.devStatus === 'Wait' ? 'border-warning text-warning' : 
                          'border-neutral-400 text-neutral-600'
                        }
                      >
                        {bug.devStatus}
                      </Badge>
                    </td>
                    <td className="p-3">
                      <Badge 
                        variant="outline"
                        className={
                          bug.qaStatus === 'Pass' ? 'border-success text-success' : 
                          'border-neutral-400 text-neutral-600'
                        }
                      >
                        {bug.qaStatus}
                      </Badge>
                    </td>
                    <td className="p-3">
                      <Button variant="ghost" size="sm" className="text-xs">
                        {bug.status === 'resolved' ? 'View' : 'Edit'}
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </PremiumCard>
    </div>
  );
}