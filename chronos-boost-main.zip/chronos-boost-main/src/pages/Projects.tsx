import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Eye, Calendar, User } from "lucide-react";
import { PremiumCard } from "@/components/premium/PremiumCard";

const projects = [
  {
    id: 1,
    name: "IKEA Bathroom",
    description: "IKEA Bathroom, the course has divided into 4 Modules and each module has 38 translation languages. Summary: A 90-minute online course on customer needs, activities and solutions related to bathrooms.",
    client: "DXC",
    estimatedHours: 400,
    moduleDate: "07-Oct-2021",
    status: "active"
  },
  {
    id: 2,
    name: "IKEA BRK (Basic range knowledge)",
    description: "A 90-minute online course introducing the clothes, shoes, coming and going storage range. The total no. of modules is 15 and each module has 38 translation languages.",
    client: "DXC",
    estimatedHours: 2000,
    moduleDate: "07-Oct-2021",
    status: "active"
  },
  {
    id: 3,
    name: "IKEA Canada",
    description: "IKEA Canada",
    client: "DXC",
    estimatedHours: 450,
    moduleDate: "07-Oct-2021",
    status: "completed"
  },
  {
    id: 4,
    name: "Hexalearn Internal",
    description: "Hexalearn internal project",
    client: "Hexalearn",
    estimatedHours: 1000,
    moduleDate: "08-Oct-2021",
    status: "active"
  },
  {
    id: 5,
    name: "Console Nitro BMC",
    description: "Create new Rise course based on the edits in Console Network BMC",
    client: "Amazon AWS",
    estimatedHours: 30,
    moduleDate: "11-Oct-2021",
    status: "pending"
  }
];

export default function Projects() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-hero bg-clip-text text-transparent">
            Projects
          </h1>
          <p className="text-muted-foreground mt-2">
            Manage and track all your projects in one place
          </p>
        </div>
        <Button className="bg-gradient-hero text-primary-foreground">
          <Plus className="w-4 h-4 mr-2" />
          New Project
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <PremiumCard variant="default">
          <CardContent className="p-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">12</div>
              <div className="text-sm text-muted-foreground">Total Projects</div>
            </div>
          </CardContent>
        </PremiumCard>
        
        <PremiumCard variant="default">
          <CardContent className="p-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-accent">8</div>
              <div className="text-sm text-muted-foreground">Active Projects</div>
            </div>
          </CardContent>
        </PremiumCard>
        
        <PremiumCard variant="default">
          <CardContent className="p-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-warning">2</div>
              <div className="text-sm text-muted-foreground">Pending</div>
            </div>
          </CardContent>
        </PremiumCard>
        
        <PremiumCard variant="default">
          <CardContent className="p-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-secondary">2</div>
              <div className="text-sm text-muted-foreground">Completed</div>
            </div>
          </CardContent>
        </PremiumCard>
      </div>

      {/* Projects Table */}
      <PremiumCard variant="elevated" className="overflow-hidden">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-foreground">All Projects</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-glass-medium border-b border-glass-border">
                <tr>
                  <th className="text-left p-4 font-medium text-muted-foreground">Name</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Description</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Client</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Est. Hours</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Module Date</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Status</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Action</th>
                </tr>
              </thead>
              <tbody>
                {projects.map((project) => (
                  <tr key={project.id} className="border-b border-glass-border hover:bg-glass-subtle transition-colors">
                    <td className="p-4">
                      <div className="font-medium text-foreground">{project.name}</div>
                    </td>
                    <td className="p-4 max-w-md">
                      <div className="text-sm text-muted-foreground truncate">
                        {project.description}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <User className="w-4 h-4 text-neutral-400" />
                        <span className="text-sm text-muted-foreground">{project.client}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="text-sm font-medium text-foreground">{project.estimatedHours}</span>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4 text-neutral-400" />
                        <span className="text-sm text-muted-foreground">{project.moduleDate}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge 
                        variant={
                          project.status === 'active' ? 'default' : 
                          project.status === 'completed' ? 'secondary' : 
                          'outline'
                        }
                        className={
                          project.status === 'active' ? 'bg-accent text-white' : 
                          project.status === 'completed' ? 'bg-success text-white' : 
                          'bg-warning text-white'
                        }
                      >
                        {project.status}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <Button variant="ghost" size="sm">
                        <Eye className="w-4 h-4 mr-1" />
                        View
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </PremiumCard>
    </div>
  );
}