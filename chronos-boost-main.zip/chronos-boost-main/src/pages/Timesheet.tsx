import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Download, Filter, Plus, Search } from "lucide-react";
import { PremiumCard } from "@/components/premium/PremiumCard";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const timesheetData = [
  {
    id: 1,
    date: "Jul 31, 2025",
    employee: { name: "Amarendra", avatar: "/placeholder.svg" },
    client: "Hexalearn",
    project: "Hexalearn Internal",
    module: "New Hire Training (Trainee)",
    description: "Team Meeting",
    effortB: 0,
    effortNB: 0.5,
    status: "approved"
  },
  {
    id: 2,
    date: "Jul 31, 2025",
    employee: { name: "Amarendra", avatar: "/placeholder.svg" },
    client: "Hexalearn",
    project: "Hexalearn Internal",
    module: "Morning Meeting",
    description: "attended",
    effortB: 0,
    effortNB: 1.5,
    status: "pending"
  },
  {
    id: 3,
    date: "Jul 30, 2025",
    employee: { name: "Anushree", avatar: "/placeholder.svg" },
    client: "CITI Program",
    project: "Quantitative Research",
    module: "Module 21755",
    description: "Final round QA of this module & released.",
    effortB: 1.5,
    effortNB: 3,
    status: "approved"
  },
  {
    id: 4,
    date: "Jul 30, 2025",
    employee: { name: "Anushree", avatar: "/placeholder.svg" },
    client: "Hexalearn",
    project: "Meeting with Noida team",
    module: "Meeting with Noida team",
    description: "Morning meeting.",
    effortB: 0,
    effortNB: 0.5,
    status: "pending"
  }
];

export default function Timesheet() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-hero bg-clip-text text-transparent">
            Timesheet
          </h1>
          <p className="text-muted-foreground mt-2">
            Track and manage employee work hours and efforts
          </p>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button className="bg-gradient-hero text-primary-foreground">
            <Plus className="w-4 h-4 mr-2" />
            Add Entry
          </Button>
        </div>
      </div>

      {/* Filters */}
      <PremiumCard variant="default">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Start Date:</label>
              <Input type="date" className="bg-glass-subtle border-glass-border text-foreground" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">End Date:</label>
              <Input type="date" className="bg-glass-subtle border-glass-border text-foreground" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Employee:</label>
              <Select>
                <SelectTrigger className="bg-glass-subtle border-glass-border text-foreground">
                  <SelectValue placeholder="Select Employee" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="amarendra">Amarendra</SelectItem>
                  <SelectItem value="anushree">Anushree</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Client:</label>
              <Select>
                <SelectTrigger className="bg-glass-subtle border-glass-border">
                  <SelectValue placeholder="Select Client" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="hexalearn">Hexalearn</SelectItem>
                  <SelectItem value="citi">CITI Program</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Project:</label>
              <Select>
                <SelectTrigger className="bg-glass-subtle border-glass-border">
                  <SelectValue placeholder="Select Project" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="internal">Hexalearn Internal</SelectItem>
                  <SelectItem value="research">Quantitative Research</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button className="w-full bg-gradient-hero text-primary-foreground">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
        </CardContent>
      </PremiumCard>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <PremiumCard variant="default">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 rounded-lg bg-primary/20">
                <Clock className="w-5 h-5 text-primary" />
              </div>
              <div>
                <div className="text-2xl font-bold text-primary">156</div>
                <div className="text-sm text-muted-foreground">Total Hours</div>
              </div>
            </div>
          </CardContent>
        </PremiumCard>
        
        <PremiumCard variant="default">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 rounded-lg bg-gradient-accent/20">
                <Calendar className="w-5 h-5 text-accent" />
              </div>
              <div>
                <div className="text-2xl font-bold text-accent">24</div>
                <div className="text-sm text-muted-foreground">Billable Hours</div>
              </div>
            </div>
          </CardContent>
        </PremiumCard>
        
        <PremiumCard variant="default">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 rounded-lg bg-gradient-warm/20">
                <Clock className="w-5 h-5 text-warning" />
              </div>
              <div>
                <div className="text-2xl font-bold text-warning">132</div>
                <div className="text-sm text-muted-foreground">Non-Billable</div>
              </div>
            </div>
          </CardContent>
        </PremiumCard>
        
        <PremiumCard variant="default">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 rounded-lg bg-gradient-success/20">
                <Search className="w-5 h-5 text-success" />
              </div>
              <div>
                <div className="text-2xl font-bold text-secondary">89%</div>
                <div className="text-sm text-muted-foreground">Efficiency</div>
              </div>
            </div>
          </CardContent>
        </PremiumCard>
      </div>

      {/* Timesheet Table */}
      <PremiumCard variant="elevated" className="overflow-hidden">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-xl font-semibold text-foreground">Timesheet Entries</CardTitle>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">25 records per page</span>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-glass-medium border-b border-glass-border">
                <tr>
                  <th className="text-left p-4 font-medium text-muted-foreground">Date</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Employee</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Client</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Project</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Module</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Description</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Effort(B)</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Effort(NB)</th>
                  <th className="text-left p-4 font-medium text-muted-foreground">Status</th>
                </tr>
              </thead>
              <tbody>
                {timesheetData.map((entry) => (
                  <tr key={entry.id} className="border-b border-glass-border hover:bg-glass-subtle transition-colors">
                    <td className="p-4">
                      <span className="text-sm font-medium">{entry.date}</span>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-3">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={entry.employee.avatar} />
                          <AvatarFallback className="bg-gradient-brand text-white text-xs">
                            {entry.employee.name.slice(0, 2)}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-sm font-medium">{entry.employee.name}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="text-sm text-neutral-600">{entry.client}</span>
                    </td>
                    <td className="p-4">
                      <span className="text-sm text-neutral-600">{entry.project}</span>
                    </td>
                    <td className="p-4">
                      <span className="text-sm text-neutral-600">{entry.module}</span>
                    </td>
                    <td className="p-4 max-w-xs">
                      <span className="text-sm text-neutral-600 truncate block">{entry.description}</span>
                    </td>
                    <td className="p-4">
                      <span className="text-sm font-medium text-accent">{entry.effortB}</span>
                    </td>
                    <td className="p-4">
                      <span className="text-sm font-medium text-warning">{entry.effortNB}</span>
                    </td>
                    <td className="p-4">
                      <Badge 
                        variant={entry.status === 'approved' ? 'default' : 'outline'}
                        className={entry.status === 'approved' ? 'bg-success text-white' : 'bg-warning text-white'}
                      >
                        {entry.status}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </PremiumCard>
    </div>
  );
}