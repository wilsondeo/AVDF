import { Layout } from "@/components/layout/Layout";

export default function Analytics() {
  return (
    <Layout>
      <div className="p-6">
        <h1 className="text-3xl font-bold bg-gradient-brand bg-clip-text text-transparent">
          Analytics
        </h1>
        <p className="text-neutral-600 mt-2">Coming Soon...</p>
      </div>
    </Layout>
  );
}