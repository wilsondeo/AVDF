export interface User {
  id: string;
  email: string;
  name: string;
  phone: string;
  age: number;
  gender: 'male' | 'female' | 'other';
  emergencyContact: string;
  activePlan?: string;
}

export interface Plan {
  id: string;
  name: string;
  price: number;
  features: string[];
  duration: string;
  popular?: boolean;
}

export interface Appointment {
  id: string;
  userId: string;
  city: string;
  service: 'telehealth' | 'emergency';
  date: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  doctorName: string;
  prescriptionId?: string;
}

export interface Prescription {
  id: string;
  appointmentId: string;
  medicines: {
    name: string;
    dosage: string;
    frequency: string;
  }[];
  instructions: string;
  doctorName: string;
  date: string;
}
