import { User, Plan, Appointment, Prescription } from './types';

export const mockUser: User = {
  id: '1',
  email: 'john.doe@example.com',
  name: 'John Doe',
  phone: '+1 (555) 123-4567',
  age: 35,
  gender: 'male',
  emergencyContact: '+1 (555) 987-6543',
  activePlan: 'plan-2',
};

export const mockPlans: Plan[] = [
  {
    id: 'plan-1',
    name: 'Basic',
    price: 29,
    duration: 'per month',
    features: [
      '2 Telehealth consultations',
      'Basic prescriptions',
      'Email support',
      'Health tips',
    ],
  },
  {
    id: 'plan-2',
    name: 'Premium',
    price: 79,
    duration: 'per month',
    popular: true,
    features: [
      'Unlimited telehealth consultations',
      'Emergency services priority',
      'All prescriptions included',
      '24/7 phone support',
      'Family coverage (up to 4)',
      'Annual health checkup',
    ],
  },
  {
    id: 'plan-3',
    name: 'Enterprise',
    price: 149,
    duration: 'per month',
    features: [
      'All Premium features',
      'Dedicated health concierge',
      'Home visits available',
      'Specialist consultations',
      'Mental health support',
      'Unlimited family coverage',
    ],
  },
];

export const mockAppointments: Appointment[] = [
  {
    id: 'apt-1',
    userId: '1',
    city: 'New York, NY',
    service: 'telehealth',
    date: '2026-02-05T14:00:00',
    status: 'confirmed',
    doctorName: 'Dr. Sarah Johnson',
  },
  {
    id: 'apt-2',
    userId: '1',
    city: 'Los Angeles, CA',
    service: 'telehealth',
    date: '2026-01-20T10:30:00',
    status: 'completed',
    doctorName: 'Dr. Michael Chen',
    prescriptionId: 'rx-1',
  },
  {
    id: 'apt-3',
    userId: '1',
    city: 'Chicago, IL',
    service: 'emergency',
    date: '2026-01-15T08:00:00',
    status: 'completed',
    doctorName: 'Dr. Emily Rodriguez',
    prescriptionId: 'rx-2',
  },
];

export const mockPrescriptions: Prescription[] = [
  {
    id: 'rx-1',
    appointmentId: 'apt-2',
    doctorName: 'Dr. Michael Chen',
    date: '2026-01-20T10:30:00',
    instructions: 'Take with food. Complete the full course even if symptoms improve.',
    medicines: [
      {
        name: 'Amoxicillin',
        dosage: '500mg',
        frequency: 'Three times daily',
      },
      {
        name: 'Ibuprofen',
        dosage: '400mg',
        frequency: 'As needed for pain',
      },
    ],
  },
  {
    id: 'rx-2',
    appointmentId: 'apt-3',
    doctorName: 'Dr. Emily Rodriguez',
    date: '2026-01-15T08:00:00',
    instructions: 'Avoid alcohol. May cause drowsiness.',
    medicines: [
      {
        name: 'Lisinopril',
        dosage: '10mg',
        frequency: 'Once daily in the morning',
      },
    ],
  },
];

export const usaCities = [
  'New York, NY',
  'Los Angeles, CA',
  'Chicago, IL',
  'Houston, TX',
  'Phoenix, AZ',
  'Philadelphia, PA',
  'San Antonio, TX',
  'San Diego, CA',
  'Dallas, TX',
  'San Jose, CA',
  'Austin, TX',
  'Jacksonville, FL',
  'Fort Worth, TX',
  'Columbus, OH',
  'Charlotte, NC',
  'San Francisco, CA',
  'Indianapolis, IN',
  'Seattle, WA',
  'Denver, CO',
  'Boston, MA',
];
