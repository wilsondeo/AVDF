# Navala Travel Health App

## Production Deployment Checklist

### 1. Update Base URL
To point the app to your production server:
1. Open `src/api/config.ts`.
2. Change the `API_BASE_URL` constant from the local IP to your production domain (e.g., `https://api.yourdomain.com`).
3. Ensure your production server has an SSL certificate (HTTPS) as mobile platforms require secure connections for production.

### 2. Update Stripe Configuration
1. Open `src/config/stripe.ts`.
2. Update the publishable key with your Stripe Production Key.
3. Update the `urlScheme` if necessary for redirection.

### 3. Plan Application Dates & Visibility Toggle
The app displays a global message regarding plan application:
**"The travel app health plan will be applied on Jun 09 to July 20"**

#### How to Toggle Visibility or Change Message:
1. Open `src/config/settings.ts`.
2. To **HIDE** the notice across all screens, set `SHOW_PLAN_NOTICE: false`.
3. To **SHOW** the notice, set `SHOW_PLAN_NOTICE: true`.
4. To change the text, update the `PLAN_NOTICE_MESSAGE` string.

This notice is implemented in:
- **Dashboard (Home)**: Inside the Active Plan card.
- **Appointments Page**: Top-of-screen notice banner.
- **Booking Page**: Top-of-screen notice banner.
- **Plans Purchase**: Success alert message.

---

## Technical Stack
- **Frontend**: React Native with Expo Router
- **Styling**: Vanilla CSS (StyleSheet)
- **Icons**: Lucide React Native
- **API**: Axios for backend communication
- **State**: React Hooks (useState, useEffect, useFocusEffect)
