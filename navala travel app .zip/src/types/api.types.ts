export interface ApiResponse<T> {
    success: boolean;
    message: string;
    data: T;
}

export interface AuthResponse {
    user: User;
    accessToken: string;
    refreshToken: string;
}

export interface User {
    id: string;
    email: string;
    role: 'PATIENT' | 'ADMIN' | 'DOCTOR';
    firstName?: string;
    lastName?: string;
}

export interface Plan {
    id: number;
    planId: string;
    name: string;
    price: string;
    validityDays: number;
    services: string[];
    isActive: boolean;
}

export interface UserPlan {
    userPlanId: number;
    planId: string;
    planName: string;
    status: 'ACTIVE' | 'EXPIRED' | 'PENDING';
    startDate: string;
    endDate: string;
    plan: Plan;
}

export interface AppointmentRequest {
    requestUuid: string;
    serviceType: string;
    status: 'PENDING' | 'ASSIGNED' | 'CANCELLED';
    city: string;
    createdAt: string;
}

export interface AppointmentCreateInput {
    city: string;
    age: number;
    gender: 'male' | 'female' | 'other';
    emergencyContact: string;
    serviceType: 'TELEHEALTH' | 'EMERGENCY';
    notes?: string;
}
