export interface City {
  name: string;
  state: string;
}

export interface CountryLocation {
  country: string;
  cities: City[];
}

export const WORLD_CUP_LOCATIONS: CountryLocation[] = [
  {
    country: 'United States',
    cities: [
      { name: 'Atlanta', state: 'Georgia' },
      { name: 'Boston', state: 'Massachusetts' },
      { name: 'Dallas', state: 'Texas' },
      { name: 'Houston', state: 'Texas' },
      { name: 'Kansas City', state: 'Missouri' },
      { name: 'Los Angeles', state: 'California' },
      { name: 'Miami', state: 'Florida' },
      { name: 'New York/New Jersey', state: 'New York/New Jersey' },
      { name: 'Philadelphia', state: 'Pennsylvania' },
      { name: 'San Francisco Bay Area', state: 'California' },
      { name: 'Seattle', state: 'Washington' },
    ],
  },
  {
    country: 'Canada',
    cities: [
      { name: 'Toronto', state: 'Ontario' },
      { name: 'Vancouver', state: 'British Columbia' },
    ],
  },
  {
    country: 'Mexico',
    cities: [
      { name: 'Mexico City', state: 'Mexico City' },
      { name: 'Guadalajara', state: 'Jalisco' },
      { name: 'Monterrey', state: 'Nuevo León' },
    ],
  },
];
