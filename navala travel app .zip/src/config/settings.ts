/**
 * Global UI Settings for Navala Travel App
 * Use these toggles to control the visibility of various elements in the app.
 */
export const UI_SETTINGS = {
    // Set this to false to hide the plan notice card/banners across the app
    SHOW_PLAN_NOTICE: false,

    // The specific notice message
    PLAN_NOTICE_MESSAGE: "The travel app health plan will be applied on Jun 09 to July 20",

    // Dates for structured display
    START_DATE: "Jun 09",
    END_DATE: "July 20"
};
