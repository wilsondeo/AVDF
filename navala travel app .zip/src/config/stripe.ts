// Stripe Configuration for Mobile App
export const STRIPE_CONFIG = {
    publishableKey: 'pk_test_51SxSSPHwSW4gSqwxrlOePCWloQP1nY8w2wSH1Qv5ZvfUnuYZkwRpUSHMVhQOIexpxDvSdhn7g5U89cCzd0LNWMgI00vDnnVjRM',
    merchantIdentifier: 'merchant.com.navala.travelapp', // For Apple Pay
    urlScheme: 'navala-travel-app', // For redirects
};
