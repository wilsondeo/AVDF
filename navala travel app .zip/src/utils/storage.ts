import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';

const isWeb = Platform.OS === 'web';

export const saveItem = async (key: string, value: string) => {
    if (isWeb) {
        try {
            localStorage.setItem(key, value);
        } catch (e) {
            console.error('Local storage may be unavailable:', e);
        }
    } else {
        await SecureStore.setItemAsync(key, value);
    }
};

export const getItem = async (key: string): Promise<string | null> => {
    if (isWeb) {
        try {
            if (typeof localStorage !== 'undefined') {
                return localStorage.getItem(key);
            }
        } catch (e) {
            console.error('Local storage may be unavailable:', e);
        }
        return null;
    } else {
        return await SecureStore.getItemAsync(key);
    }
};

export const deleteItem = async (key: string) => {
    if (isWeb) {
        try {
            if (typeof localStorage !== 'undefined') {
                localStorage.removeItem(key);
            }
        } catch (e) {
            console.error('Local storage may be unavailable:', e);
        }
    } else {
        await SecureStore.deleteItemAsync(key);
    }
};
