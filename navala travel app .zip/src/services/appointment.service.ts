import apiClient from '../api/client';
import { ENDPOINTS } from '../api/endpoints';
import { ApiResponse, AppointmentRequest, AppointmentCreateInput } from '../types/api.types';

export const AppointmentService = {
    async createRequest(data: AppointmentCreateInput): Promise<ApiResponse<{ requestUuid: string }>> {
        return apiClient.post(ENDPOINTS.APPOINTMENTS.REQUEST, data);
    },

    async getMyRequests(): Promise<ApiResponse<AppointmentRequest[]>> {
        return apiClient.get(ENDPOINTS.APPOINTMENTS.MY_REQUESTS);
    }
};
