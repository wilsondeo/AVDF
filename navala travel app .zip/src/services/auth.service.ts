import apiClient from '../api/client';
import { ENDPOINTS } from '../api/endpoints';
import { ApiResponse, AuthResponse, User } from '../types/api.types';
import { saveItem, getItem, deleteItem } from '../utils/storage';

export const AuthService = {
    async login(credentials: any): Promise<ApiResponse<AuthResponse>> {
        const response = await apiClient.post(ENDPOINTS.AUTH.LOGIN, credentials);

        // Store tokens on successful login
        if (response.success && response.data) {
            await saveItem('accessToken', response.data.accessToken);
            await saveItem('refreshToken', response.data.refreshToken);
            await saveItem('userData', JSON.stringify(response.data.user));
        }

        return response as ApiResponse<AuthResponse>;
    },

    async register(data: any): Promise<ApiResponse<AuthResponse>> {
        const response = await apiClient.post(ENDPOINTS.AUTH.REGISTER, data);

        if (response.success && response.data) {
            await saveItem('accessToken', response.data.accessToken);
            await saveItem('refreshToken', response.data.refreshToken);
            // Optionally store user data if it's returned on register, or fetch it separately
            if (response.data.user) {
                await saveItem('userData', JSON.stringify(response.data.user));
            }
        }

        return response as ApiResponse<AuthResponse>;
    },

    async logout(): Promise<void> {
        await deleteItem('accessToken');
        await deleteItem('refreshToken');
        await deleteItem('userData');
    },

    async getCurrentUser(): Promise<User | null> {
        const userData = await getItem('userData');
        return userData ? JSON.parse(userData) : null;
    },

    async isAuthenticated(): Promise<boolean> {
        const token = await getItem('accessToken');
        return !!token;
    }
};
