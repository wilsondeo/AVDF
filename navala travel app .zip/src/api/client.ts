import axios from 'axios';
import { API_BASE_URL } from './endpoints';
import { saveItem, getItem, deleteItem } from '../utils/storage';

const apiClient = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
    timeout: 30000,
});

// Request Interceptor: Attach Bearer Token
apiClient.interceptors.request.use(
    async (config) => {
        const token = await getItem('accessToken');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Response Interceptor: Handle Token Refresh or Global Errors
apiClient.interceptors.response.use(
    (response) => response.data,
    async (error) => {
        const originalRequest = error.config;

        // Handle 401 Unauthorized (Expired Token)
        if (error.response?.status === 401 && !originalRequest._retry) {
            originalRequest._retry = true;

            try {
                const refreshToken = await getItem('refreshToken');
                if (refreshToken) {
                    // Attempt to refresh the token
                    const response = await axios.post(`${API_BASE_URL}/api/auth/refresh`, {
                        refreshToken,
                    });

                    const { accessToken } = response.data.data;
                    await saveItem('accessToken', accessToken);

                    // Retry the original request with the new token
                    originalRequest.headers.Authorization = `Bearer ${accessToken}`;
                    return apiClient(originalRequest);
                }
            } catch (refreshError) {
                // Refresh token failed or expired, log out the user
                await deleteItem('accessToken');
                await deleteItem('refreshToken');
                // You might want to trigger a logout in your Global State here
            }
        }

        return Promise.reject(error.response?.data || error.message);
    }
);

export default apiClient;
