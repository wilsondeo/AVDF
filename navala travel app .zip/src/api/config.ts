import axios from 'axios';
import { saveItem, getItem, deleteItem } from '../utils/storage';

export const API_BASE_URL = 'https://travelhealth.navalaglobal.com';
export const API_PREFIX = '/api';

export const apiClient = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
    timeout: 30000,
});

apiClient.interceptors.request.use(
    async (config) => {
        const token = await getItem('accessToken');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => Promise.reject(error)
);

apiClient.interceptors.response.use(
    (response) => response.data,
    async (error) => {
        const originalRequest = error.config;
        if (error.response?.status === 401 && !originalRequest._retry) {
            originalRequest._retry = true;
            try {
                const refreshToken = await getItem('refreshToken');
                if (refreshToken) {
                    const response = await axios.post(`${API_BASE_URL}/api/auth/refresh`, { refreshToken });
                    const { accessToken } = response.data.data;
                    await saveItem('accessToken', accessToken);
                    originalRequest.headers.Authorization = `Bearer ${accessToken}`;
                    return apiClient(originalRequest);
                }
            } catch (refreshError) {
                await deleteItem('accessToken');
                await deleteItem('refreshToken');
            }
        }
        return Promise.reject(error.response?.data || error.message);
    }
);
