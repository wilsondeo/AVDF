import { apiClient, API_PREFIX } from '../config';
import { ApiResponse } from '../../types/api.types';

export interface UserProfile {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    phone?: string;
    dateOfBirth?: string;
    streetAddress?: string;
    city?: string;
    state?: string;
    zipCode?: string;
    country?: string;
    emergencyContactName?: string;
    emergencyContactPhone?: string;
    emergencyContactRelationship?: string;
    bloodType?: string;
}

export const UserApi = {
    async getProfile(): Promise<ApiResponse<UserProfile>> {
        return apiClient.get(`${API_PREFIX}/user/profile`) as unknown as Promise<ApiResponse<UserProfile>>;
    },

    async updateProfile(data: Partial<UserProfile>): Promise<ApiResponse<UserProfile>> {
        return apiClient.patch(`${API_PREFIX}/user/profile`, data) as unknown as Promise<ApiResponse<UserProfile>>;
    },

    async getActivePlan(): Promise<ApiResponse<any>> {
        return apiClient.get(`${API_PREFIX}/user/plan`) as unknown as Promise<ApiResponse<any>>;
    },

    async getFamilyMembers(): Promise<ApiResponse<{ familyMembers: any[], maxSlots: number }>> {
        return apiClient.get(`${API_PREFIX}/user/family-members`) as unknown as Promise<ApiResponse<{ familyMembers: any[], maxSlots: number }>>;
    },

    async addFamilyMember(data: any): Promise<ApiResponse<any>> {
        return apiClient.post(`${API_PREFIX}/user/family-members`, data) as unknown as Promise<ApiResponse<any>>;
    },

    async updateFamilyMember(id: number | string, data: any): Promise<ApiResponse<any>> {
        return apiClient.patch(`${API_PREFIX}/user/family-members/${id}`, data) as unknown as Promise<ApiResponse<any>>;
    },

    async deleteFamilyMember(id: number | string): Promise<ApiResponse<any>> {
        return apiClient.delete(`${API_PREFIX}/user/family-members/${id}`) as unknown as Promise<ApiResponse<any>>;
    }
};
