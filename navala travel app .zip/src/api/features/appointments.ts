import { apiClient, API_PREFIX } from '../config';
import { ApiResponse } from '../../types/api.types';

export interface AppointmentRequest {
    country: string;
    state: string;
    city: string;
    age: number;
    gender: string;
    emergencyContact?: string;
    appointmentDate: string;
    serviceType: 'TELEHEALTH' | 'EMERGENCY';
    notes?: string;
}

export const AppointmentsApi = {
    async createRequest(data: AppointmentRequest): Promise<ApiResponse<{ requestUuid: string }>> {
        return apiClient.post(`${API_PREFIX}/appointments/request`, data) as unknown as Promise<ApiResponse<{ requestUuid: string }>>;
    },

    async getMyRequests(): Promise<ApiResponse<any[]>> {
        return apiClient.get(`${API_PREFIX}/appointments/my-requests`) as unknown as Promise<ApiResponse<any[]>>;
    }
};
