import { apiClient, API_PREFIX } from '../config';
import { ApiResponse } from '../../types/api.types';

export const PlansApi = {
    async getPlans(): Promise<ApiResponse<any>> {
        return apiClient.get(`${API_PREFIX}/plans`) as unknown as Promise<ApiResponse<any>>;
    },

    async purchasePlan(planId: string): Promise<ApiResponse<{
        clientSecret: string;
        paymentIntentId: string;
        type: string;
        amountCharged: number;
        amountChargedCents: number;
    }>> {
        return apiClient.post(`${API_PREFIX}/payments/create-intent`, { planId }) as unknown as Promise<ApiResponse<{
            clientSecret: string;
            paymentIntentId: string;
            type: string;
            amountCharged: number;
            amountChargedCents: number;
        }>>;
    },

    async getMyPayments(limit: number = 20, offset: number = 0): Promise<ApiResponse<any>> {
        return apiClient.get(`${API_PREFIX}/payments/my?limit=${limit}&offset=${offset}`) as unknown as Promise<ApiResponse<any>>;
    }
};
