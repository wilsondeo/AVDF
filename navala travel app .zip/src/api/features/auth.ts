import { apiClient, API_PREFIX } from '../config';
import { ApiResponse, AuthResponse } from '../../types/api.types';
import { saveItem, deleteItem } from '../../utils/storage';

export const AuthApi = {
    async login(credentials: any): Promise<ApiResponse<AuthResponse>> {
        const response = await apiClient.post(`${API_PREFIX}/auth/login`, credentials) as unknown as ApiResponse<AuthResponse>;
        if (response.success && response.data) {
            await saveItem('accessToken', response.data.accessToken);
            await saveItem('refreshToken', response.data.refreshToken);
            await saveItem('userData', JSON.stringify(response.data.user));
        }
        return response;
    },

    async register(data: any): Promise<ApiResponse<AuthResponse>> {
        const response = await apiClient.post(`${API_PREFIX}/auth/register`, data) as unknown as ApiResponse<AuthResponse>;
        if (response.success && response.data) {
            await saveItem('accessToken', response.data.accessToken);
            await saveItem('refreshToken', response.data.refreshToken);
            if (response.data.user) {
                await saveItem('userData', JSON.stringify(response.data.user));
            }
        }
        return response;
    },

    async logout(): Promise<void> {
        await deleteItem('accessToken');
        await deleteItem('refreshToken');
        await deleteItem('userData');
    },

    async forgotPassword(email: string): Promise<ApiResponse<any>> {
        return apiClient.post(`${API_PREFIX}/auth/forgot-password`, { email }) as unknown as Promise<ApiResponse<any>>;
    },

    async resetPassword(data: any): Promise<ApiResponse<any>> {
        return apiClient.post(`${API_PREFIX}/auth/reset-password`, data) as unknown as Promise<ApiResponse<any>>;
    }
};
