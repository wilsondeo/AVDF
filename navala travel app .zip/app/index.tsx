import React, { useEffect, useState, useRef } from 'react';
import { View, Text, StyleSheet, Image, Animated, ActivityIndicator } from 'react-native';
import { Redirect } from 'expo-router';
import { getItem } from '../src/utils/storage';
import { LinearGradient } from 'expo-linear-gradient';

export default function Index() {
    const [isLoading, setIsLoading] = useState(true);
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    
    // Animation refs for a premium feel
    const fadeAnim = useRef(new Animated.Value(0)).current;
    const scaleAnim = useRef(new Animated.Value(0.95)).current;

    useEffect(() => {
        // Start the intro animation
        Animated.parallel([
            Animated.timing(fadeAnim, {
                toValue: 1,
                duration: 800,
                useNativeDriver: true,
            }),
            Animated.spring(scaleAnim, {
                toValue: 1,
                friction: 8,
                tension: 40,
                useNativeDriver: true,
            }),
        ]).start();

        async function checkAuth() {
            try {
                // Ensure the branded intro is visible for at least 2 seconds for branding
                const [token] = await Promise.all([
                    getItem('accessToken'),
                    new Promise(resolve => setTimeout(resolve, 2000))
                ]);
                setIsAuthenticated(!!token);
            } catch (error) {
                setIsAuthenticated(false);
            } finally {
                // Fade out before redirecting
                Animated.timing(fadeAnim, {
                    toValue: 0,
                    duration: 400,
                    useNativeDriver: true,
                }).start(() => {
                    setIsLoading(false);
                });
            }
        }
        checkAuth();
    }, []);

    if (isLoading) {
        return (
            <View style={styles.container}>
                <LinearGradient
                    colors={['#2563eb', '#1e40af', '#1e3a8a']}
                    style={styles.gradient}
                >
                    <Animated.View style={[
                        styles.content,
                        { opacity: fadeAnim, transform: [{ scale: scaleAnim }] }
                    ]}>
                        <View style={styles.logoContainer}>
                            <Image
                                source={require('../assets/images/icon.png')}
                                style={styles.logo}
                                resizeMode="contain"
                            />
                        </View>
                        <Text style={styles.appName}>Navala Travel</Text>
                        <Text style={styles.appSubtitle}>Health & Concierge</Text>
                        
                        <View style={styles.loaderContainer}>
                            <ActivityIndicator size="small" color="#ffffff" style={styles.loader} />
                            <Text style={styles.loadingText}>Initializing safe travel...</Text>
                        </View>
                    </Animated.View>
                </LinearGradient>
            </View>
        );
    }

    if (!isAuthenticated) {
        return <Redirect href="/login" />;
    }

    return <Redirect href="/(tabs)" />;
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    gradient: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    content: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    logoContainer: {
        width: 140,
        height: 140,
        backgroundColor: '#ffffff',
        borderRadius: 35,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 24,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.2,
        shadowRadius: 15,
        elevation: 8,
    },
    logo: {
        width: '80%',
        height: '80%',
    },
    appName: {
        fontSize: 32,
        fontWeight: 'bold',
        color: '#ffffff',
        letterSpacing: 1,
        marginBottom: 4,
    },
    appSubtitle: {
        fontSize: 16,
        color: '#dbeafe',
        fontWeight: '500',
        marginBottom: 40,
        opacity: 0.8,
    },
    loaderContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        position: 'absolute',
        bottom: -100,
    },
    loader: {
        opacity: 0.8,
    },
    loadingText: {
        color: '#ffffff',
        fontSize: 14,
        fontWeight: '500',
        opacity: 0.6,
    },
});
