import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    KeyboardAvoidingView,
    Platform,
    Alert,
    ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Mail, Lock, Key, ChevronLeft, ArrowRight, CheckCircle } from 'lucide-react-native';
import { AuthApi } from '../src/api/features/auth';

export default function ForgotPasswordScreen() {
    const [email, setEmail] = useState('');
    const [otp, setOtp] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [step, setStep] = useState(1); // 1: Email, 2: Reset
    const [loading, setLoading] = useState(false);

    const handleSendOtp = async () => {
        if (!email.trim() || !email.includes('@')) {
            Alert.alert('Error', 'Please enter a valid email address.');
            return;
        }

        try {
            setLoading(true);
            const response = await AuthApi.forgotPassword(email);
            if (response.success) {
                Alert.alert('Success', 'OTP has been sent to your email.');
                setStep(2);
            } else {
                Alert.alert('Error', response.message || 'Failed to send OTP.');
            }
        } catch (error: any) {
            Alert.alert('Error', error.message || 'An unexpected error occurred.');
        } finally {
            setLoading(false);
        }
    };

    const handleResetPassword = async () => {
        if (!otp || otp.length < 6) {
            Alert.alert('Error', 'Please enter a valid 6-digit OTP.');
            return;
        }
        if (newPassword.length < 8) {
            Alert.alert('Error', 'Password must be at least 8 characters long.');
            return;
        }
        if (newPassword !== confirmPassword) {
            Alert.alert('Error', 'Passwords do not match.');
            return;
        }

        try {
            setLoading(true);
            const response = await AuthApi.resetPassword({
                email,
                otp,
                newPassword,
                confirmPassword
            });

            if (response.success) {
                Alert.alert('Success', 'Password has been reset successfully. You can now log in.', [
                    { text: 'Login', onPress: () => router.replace('/login') }
                ]);
            } else {
                Alert.alert('Error', response.message || 'Failed to reset password.');
            }
        } catch (error: any) {
            Alert.alert('Error', error.message || 'An unexpected error occurred.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <KeyboardAvoidingView
            style={styles.container}
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
            <LinearGradient colors={['#2563eb', '#1d4ed8']} style={styles.header}>
                <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
                    <ChevronLeft size={24} color="#ffffff" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Reset Password</Text>
                <Text style={styles.headerSubtitle}>
                    {step === 1
                        ? "Enter your email for password reset instructions."
                        : "Enter the OTP sent to your email and your new password."}
                </Text>
            </LinearGradient>

            <View style={styles.content}>
                <View style={styles.card}>
                    {step === 1 ? (
                        <>
                            <View style={styles.inputGroup}>
                                <Text style={styles.inputLabel}>Email Address</Text>
                                <View style={styles.inputWrapper}>
                                    <Mail size={18} color="#6b7280" />
                                    <TextInput
                                        style={styles.input}
                                        placeholder="you@example.com"
                                        placeholderTextColor="#9ca3af"
                                        keyboardType="email-address"
                                        autoCapitalize="none"
                                        value={email}
                                        onChangeText={setEmail}
                                    />
                                </View>
                            </View>

                            <TouchableOpacity
                                style={[styles.button, loading && styles.buttonDisabled]}
                                disabled={loading}
                                onPress={handleSendOtp}>
                                <Text style={styles.buttonText}>{loading ? 'Sending OTP...' : 'Send OTP'}</Text>
                                {!loading && <ArrowRight size={18} color="#ffffff" />}
                            </TouchableOpacity>
                        </>
                    ) : (
                        <>
                            <View style={styles.inputGroup}>
                                <Text style={styles.inputLabel}>Enter 6-digit OTP</Text>
                                <View style={styles.inputWrapper}>
                                    <Key size={18} color="#6b7280" />
                                    <TextInput
                                        style={styles.input}
                                        placeholder="123456"
                                        placeholderTextColor="#9ca3af"
                                        keyboardType="number-pad"
                                        maxLength={6}
                                        value={otp}
                                        onChangeText={setOtp}
                                    />
                                </View>
                            </View>

                            <View style={styles.inputGroup}>
                                <Text style={styles.inputLabel}>New Password</Text>
                                <View style={styles.inputWrapper}>
                                    <Lock size={18} color="#6b7280" />
                                    <TextInput
                                        style={styles.input}
                                        placeholder="At least 8 characters"
                                        placeholderTextColor="#9ca3af"
                                        secureTextEntry
                                        value={newPassword}
                                        onChangeText={setNewPassword}
                                    />
                                </View>
                            </View>

                            <View style={styles.inputGroup}>
                                <Text style={styles.inputLabel}>Confirm Password</Text>
                                <View style={styles.inputWrapper}>
                                    <Lock size={18} color="#6b7280" />
                                    <TextInput
                                        style={styles.input}
                                        placeholder="Confirm your new password"
                                        placeholderTextColor="#9ca3af"
                                        secureTextEntry
                                        value={confirmPassword}
                                        onChangeText={setConfirmPassword}
                                    />
                                </View>
                            </View>

                            <TouchableOpacity
                                style={[styles.button, loading && styles.buttonDisabled]}
                                disabled={loading}
                                onPress={handleResetPassword}>
                                <CheckCircle size={18} color="#ffffff" />
                                <Text style={styles.buttonText}>{loading ? 'Resetting...' : 'Reset Password'}</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={styles.resendBtn}
                                onPress={() => setStep(1)}
                                disabled={loading}
                            >
                                <Text style={styles.resendText}>Didn't get OTP? Try again</Text>
                            </TouchableOpacity>
                        </>
                    )}
                </View>
            </View>
        </KeyboardAvoidingView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f9fafb',
    },
    header: {
        paddingTop: 60,
        paddingBottom: 32,
        paddingHorizontal: 24,
    },
    backButton: {
        marginBottom: 20,
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    headerTitle: {
        fontSize: 28,
        fontWeight: '700',
        color: '#ffffff',
        marginBottom: 8,
    },
    headerSubtitle: {
        fontSize: 15,
        color: '#e0e7ff',
        lineHeight: 22,
    },
    content: {
        flex: 1,
        paddingHorizontal: 16,
        marginTop: -20,
    },
    card: {
        backgroundColor: '#ffffff',
        borderRadius: 16,
        padding: 24,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.1,
        shadowRadius: 12,
        elevation: 5,
    },
    inputGroup: {
        marginBottom: 20,
    },
    inputLabel: {
        fontSize: 14,
        fontWeight: '600',
        color: '#374151',
        marginBottom: 8,
    },
    inputWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#f3f4f6',
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#e5e7eb',
        paddingHorizontal: 16,
    },
    input: {
        flex: 1,
        paddingVertical: 14,
        paddingHorizontal: 12,
        fontSize: 15,
        color: '#111827',
    },
    button: {
        backgroundColor: '#2563eb',
        paddingVertical: 16,
        borderRadius: 12,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 10,
        marginTop: 10,
    },
    buttonDisabled: {
        backgroundColor: '#9ca3af',
    },
    buttonText: {
        color: '#ffffff',
        fontSize: 16,
        fontWeight: '700',
    },
    resendBtn: {
        alignItems: 'center',
        marginTop: 20,
    },
    resendText: {
        fontSize: 14,
        color: '#2563eb',
        fontWeight: '600',
    },
});
