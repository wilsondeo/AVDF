import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, ActivityIndicator, Alert, Modal, KeyboardAvoidingView, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { ChevronLeft, MapPin, Video, AlertCircle, Check, Info, User, Users, Calendar, Clock, ChevronDown } from 'lucide-react-native';
import { AppointmentsApi, UserApi } from '../src/api';
import { UI_SETTINGS } from '../src/config/settings';
import { WORLD_CUP_LOCATIONS } from '../src/config/locations';

export default function BookingScreen() {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);

  // Data State
  const [familyMembers, setFamilyMembers] = useState<any[]>([]);
  const [userData, setUserData] = useState<any>(null);
  const [activePlan, setActivePlan] = useState<any>(null);

  // Step 1: Location
  const [showCountryDrop, setShowCountryDrop] = useState(false);
  const [showCityDrop, setShowCityDrop] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState(WORLD_CUP_LOCATIONS[0].country);
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedState, setSelectedState] = useState('');

  // Step 2: Patient
  const [selectedPatientId, setSelectedPatientId] = useState<'myself' | number>('myself');

  // Step 3: Details
  const [patientDetails, setPatientDetails] = useState({
    fullName: '',
    age: '',
    gender: '',
    emergencyContact: '',
    notes: '',
  });

  // Step 4: Schedule
  const [selectedService, setSelectedService] = useState<'TELEHEALTH' | 'EMERGENCY' | ''>('');

  // Calendar State
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [profileRes, familyRes, planRes] = await Promise.all([
        UserApi.getProfile().catch(() => null),
        UserApi.getFamilyMembers().catch(() => null),
        UserApi.getActivePlan().catch(() => null)
      ]);

      if (profileRes && profileRes.success) {
        setUserData(profileRes.data);
        setPatientDetails(prev => ({
          ...prev,
          fullName: `${profileRes.data.firstName} ${profileRes.data.lastName || ''}`.trim(),
        }));
      }
      if (familyRes && familyRes.success && familyRes.data) {
        setFamilyMembers(familyRes.data.familyMembers || []);
      }
      if (planRes && planRes.success && planRes.data) {
        const actualPlan = planRes.data.activePlan || planRes.data;
        // Aligned with web app logic: hide banner if plan.plan is empty
        if (actualPlan && actualPlan.plan) {
          setActivePlan(actualPlan);
        } else {
          setActivePlan(null);
        }
      }
    } catch (e) { }
  };

  const handlePatientSelect = (id: 'myself' | number) => {
    setSelectedPatientId(id);
    if (id === 'myself' && userData) {
      setPatientDetails(prev => ({
        ...prev,
        fullName: `${userData.firstName} ${userData.lastName || ''}`.trim(),
        gender: '',
        age: '',
      }));
    } else if (typeof id === 'number') {
      const member = familyMembers.find(m => m.id === id);
      if (member) {
        // Helper to calculate age if dob exists
        let calculatedAge = '';
        if (member.dateOfBirth) {
          const birthDate = new Date(member.dateOfBirth);
          if (!isNaN(birthDate.getTime())) {
            const diffTime = Math.abs(Date.now() - birthDate.getTime());
            calculatedAge = Math.floor(diffTime / (1000 * 60 * 60 * 24 * 365.25)).toString();
          }
        }
        setPatientDetails(prev => ({
          ...prev,
          fullName: `${member.firstName} ${member.lastName || ''}`.trim(),
          gender: member.gender || '',
          age: calculatedAge,
        }));
      }
    }
  };

  const handleConfirm = async () => {
    if (!activePlan) {
      Alert.alert(
        'No Active Plan',
        'You do not have an active plan. Please choose a plan before booking an appointment.',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Go to Plans', onPress: () => router.push('/plans') }
        ]
      );
      return;
    }

    if (!selectedCity || !patientDetails.age || !patientDetails.gender || !patientDetails.fullName || !selectedDate || !selectedTime) {
      Alert.alert('Missing Requirements', 'Please ensure all required fields are filled out correctly.');
      return;
    }

    setLoading(true);
    try {
      const hours = parseInt(selectedTime.split(':')[0], 10) || 0;
      const minutes = parseInt(selectedTime.split(':')[1], 10) || 0;
      const aptDateObj = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate(), hours, minutes);
      const appointmentIsoString = aptDateObj.toISOString();

      const combinedNotes = `Patient: ${patientDetails.fullName}
Type: ${selectedPatientId === 'myself' ? 'Self' : 'Family Member'}
Symptoms/Allergies: ${patientDetails.notes}`;

      const response = await AppointmentsApi.createRequest({
        country: selectedCountry,
        state: selectedState || selectedCity,
        city: selectedCity,
        age: parseInt(patientDetails.age, 10),
        gender: patientDetails.gender.toUpperCase(),
        appointmentDate: appointmentIsoString,
        emergencyContact: patientDetails.emergencyContact || '',
        serviceType: selectedService as 'TELEHEALTH' | 'EMERGENCY',
        notes: combinedNotes
      });

      if (response && response.success) {
        Alert.alert('Success', 'Appointment request submitted successfully!', [
          { text: 'OK', onPress: () => router.push('/(tabs)/appointments') }
        ]);
      } else {
        const msg = response?.message || 'Please check all required fields.';
        // If error seems to be about the plan, provide a direct link to plans
        const isPlanError = msg.toLowerCase().includes('plan') || msg.toLowerCase().includes('subscription') || msg.toLowerCase().includes('limit');
        
        Alert.alert('Booking Notice', msg, [
          { text: 'Cancel', style: 'cancel' },
          ...(isPlanError ? [{ text: 'View Plans', onPress: () => router.push('/plans' as any) }] : [{ text: 'OK' }])
        ]);
      }
    } catch (error: any) {
      Alert.alert('Error', error?.message || 'Failed to submit request');
    } finally {
      setLoading(false);
    }
  };

  const renderStepIndicator = () => (
    <View style={styles.stepIndicator}>
      {[1, 2, 3, 4, 5].map((s) => (
        <View key={s} style={styles.stepContainer}>
          <View style={[styles.stepCircle, s === step && styles.stepCircleActive, s < step && styles.stepCircleCompleted]}>
            {s < step ? <Check size={14} color="#ffffff" strokeWidth={3} /> : <Text style={[styles.stepText, s === step && styles.stepTextActive]}>{s}</Text>}
          </View>
          {s < 5 && <View style={[styles.stepLine, s < step && styles.stepLineCompleted]} />}
        </View>
      ))}
    </View>
  );

  const activeCountryObj = WORLD_CUP_LOCATIONS.find(c => c.country === selectedCountry);
  const citiesForCountry = activeCountryObj ? activeCountryObj.cities : [];

  // Calendar Helpers
  const getDaysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const getFirstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();
  const daysInMonth = getDaysInMonth(currentDate.getFullYear(), currentDate.getMonth());
  const firstDay = getFirstDayOfMonth(currentDate.getFullYear(), currentDate.getMonth());
  const blanks = Array.from({ length: firstDay }, (_, i) => i);
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  const isToday = (day: number) => {
    const today = new Date();
    return currentDate.getFullYear() === today.getFullYear() &&
      currentDate.getMonth() === today.getMonth() &&
      day === today.getDate();
  };

  const isPast = (day: number) => {
    const today = new Date();
    if (currentDate.getFullYear() < today.getFullYear()) return true;
    if (currentDate.getFullYear() === today.getFullYear() && currentDate.getMonth() < today.getMonth()) return true;
    if (currentDate.getFullYear() === today.getFullYear() && currentDate.getMonth() === today.getMonth() && day < today.getDate()) return true;
    return false;
  };

  const isSelectedDate = (day: number) => {
    if (!selectedDate) return false;
    return selectedDate.getFullYear() === currentDate.getFullYear() &&
      selectedDate.getMonth() === currentDate.getMonth() &&
      selectedDate.getDate() === day;
  };

  const handleDaySelect = (day: number) => {
    if (isPast(day)) return;
    setSelectedDate(new Date(currentDate.getFullYear(), currentDate.getMonth(), day));
    setSelectedTime(''); // reset time on new date
  };

  const changeMonth = (direction: number) => {
    const newDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + direction, 1);
    setCurrentDate(newDate);
  };

  const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.container}>
        <LinearGradient colors={['#1e40af', '#1e3a8a']} style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backNavBtn}>
            <ChevronLeft size={24} color="#ffffff" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Book Appointment</Text>
          {renderStepIndicator()}
          <View style={styles.stepLabels}>
            <Text style={[styles.stepLabelText, step === 1 && styles.stepLabelTextActive]}>Location</Text>
            <Text style={[styles.stepLabelText, step === 2 && styles.stepLabelTextActive]}>Patient</Text>
            <Text style={[styles.stepLabelText, step === 3 && styles.stepLabelTextActive]}>Details</Text>
            <Text style={[styles.stepLabelText, step === 4 && styles.stepLabelTextActive]}>Schedule</Text>
            <Text style={[styles.stepLabelText, step === 5 && styles.stepLabelTextActive]}>Confirm</Text>
          </View>
        </LinearGradient>

        <ScrollView
          style={styles.container}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {UI_SETTINGS.SHOW_PLAN_NOTICE ? (
            <View style={styles.noticeBannerLarge}>
              <Info size={32} color="#1e3a8a" />
              <Text style={styles.noticeTextLarge}>{UI_SETTINGS.PLAN_NOTICE_MESSAGE}</Text>
            </View>
          ) : (
            <View style={styles.cardContainer}>
              {step === 1 && (
                <View>
                  <View style={styles.stepHeaderRow}>
                    <MapPin size={24} color="#0d9488" />
                    <Text style={styles.stepTitle}>Where are you located?</Text>
                  </View>
                  <Text style={styles.stepSubtitle}>Select your current World Cup location</Text>

                  <View style={[styles.dropdownContainer, { zIndex: 20 }]}>
                    <Text style={styles.label}>Country *</Text>
                    <TouchableOpacity style={styles.dropdownTrigger} onPress={() => { setShowCountryDrop(!showCountryDrop); setShowCityDrop(false); }}>
                      <Text style={[styles.dropdownValue, !selectedCountry && styles.placeholderText]}>{selectedCountry || 'Select Country'}</Text>
                      <ChevronDown size={20} color="#94a3b8" />
                    </TouchableOpacity>
                    {showCountryDrop && (
                      <ScrollView style={styles.dropdownMenu} nestedScrollEnabled={true}>
                        {WORLD_CUP_LOCATIONS.map(c => (
                          <TouchableOpacity key={c.country} style={styles.dropdownItem} onPress={() => { setSelectedCountry(c.country); setSelectedCity(''); setSelectedState(''); setShowCountryDrop(false); }}>
                            <Text style={styles.dropdownItemText}>{c.country}</Text>
                          </TouchableOpacity>
                        ))}
                      </ScrollView>
                    )}
                  </View>

                  <View style={[styles.dropdownContainer, { zIndex: 10 }]}>
                    <Text style={styles.label}>City *</Text>
                    <TouchableOpacity style={[styles.dropdownTrigger, !selectedCountry && styles.disabledInput]} disabled={!selectedCountry} onPress={() => { setShowCityDrop(!showCityDrop); setShowCountryDrop(false); }}>
                      <Text style={[styles.dropdownValue, !selectedCity && styles.placeholderText]}>{selectedCity || 'Select City'}</Text>
                      <ChevronDown size={20} color="#94a3b8" />
                    </TouchableOpacity>
                    {showCityDrop && (
                      <ScrollView style={styles.dropdownMenu} nestedScrollEnabled={true}>
                        {citiesForCountry.map(c => (
                          <TouchableOpacity key={c.name} style={styles.dropdownItem} onPress={() => { setSelectedCity(c.name); setSelectedState(c.state); setShowCityDrop(false); }}>
                            <Text style={styles.dropdownItemText}>{c.name}</Text>
                          </TouchableOpacity>
                        ))}
                      </ScrollView>
                    )}
                  </View>

                  <Text style={styles.label}>State / Province (Auto-populated)</Text>
                  <TextInput style={styles.inputDisabled} value={selectedState} editable={false} placeholder="State / Province" placeholderTextColor="#cbd5e1" />

                  <View style={styles.btnRowBetween}>
                    <TouchableOpacity style={styles.cancelBtn} onPress={() => router.back()}><Text style={styles.cancelText}>Cancel</Text></TouchableOpacity>
                    <TouchableOpacity style={[styles.nextBtn, !selectedCity && styles.nextButtonDisabled]} disabled={!selectedCity} onPress={() => setStep(2)}>
                      <Text style={styles.nextText}>Next</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              )}

              {step === 2 && (
                <View>
                  <View style={styles.stepHeaderRow}>
                    <Users size={24} color="#0d9488" />
                    <Text style={styles.stepTitle}>Who is this appointment for?</Text>
                  </View>
                  <Text style={styles.stepSubtitle}>Select the person who needs medical attention</Text>

                  <TouchableOpacity
                    style={[styles.patientSelectCard, selectedPatientId === 'myself' && styles.patientSelectCardActive]}
                    onPress={() => handlePatientSelect('myself')}
                  >
                    <View style={[styles.patientIconWrap, selectedPatientId === 'myself' && styles.patientIconWrapActive]}>
                      <User size={20} color={selectedPatientId === 'myself' ? '#0d9488' : '#64748b'} />
                    </View>
                    <Text style={styles.patientName}>Myself</Text>
                    {selectedPatientId === 'myself' && <Check size={20} color="#0d9488" style={{ marginLeft: 'auto' }} />}
                  </TouchableOpacity>

                  {familyMembers.length > 0 && <Text style={styles.familyMembersLabel}>Family Members Covered</Text>}

                  {familyMembers.map(member => (
                    <TouchableOpacity
                      key={member.id}
                      style={[styles.patientSelectCard, selectedPatientId === member.id && styles.patientSelectCardActive]}
                      onPress={() => handlePatientSelect(member.id)}
                    >
                      <View style={[styles.patientIconWrap, selectedPatientId === member.id && styles.patientIconWrapActive]}>
                        <Users size={20} color={selectedPatientId === member.id ? '#0d9488' : '#64748b'} />
                      </View>
                      <View>
                        <Text style={styles.patientName}>{member.firstName} {member.lastName}</Text>
                        <Text style={styles.patientSubtext}>{member.relationship || 'Family Member'}</Text>
                      </View>
                      {selectedPatientId === member.id && <Check size={20} color="#0d9488" style={{ marginLeft: 'auto' }} />}
                    </TouchableOpacity>
                  ))}

                  <View style={styles.btnRowBetween}>
                    <TouchableOpacity style={styles.backBtnLight} onPress={() => setStep(1)}><Text style={styles.backText}>Back</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.nextBtn} onPress={() => setStep(3)}><Text style={styles.nextText}>Next</Text></TouchableOpacity>
                  </View>
                </View>
              )}

              {step === 3 && (
                <View>
                  <View style={styles.stepHeaderRow}>
                    <View style={styles.docIcon}><View style={styles.docIconLine1} /><View style={styles.docIconLine2} /></View>
                    <Text style={styles.stepTitle}>Patient Details</Text>
                  </View>
                  <Text style={styles.stepSubtitle}>Verify and complete the patient's information</Text>

                  <View style={styles.row}>
                    <View style={styles.col}>
                      <Text style={styles.label}>Full Name *</Text>
                      <TextInput style={styles.input} value={patientDetails.fullName} onChangeText={t => setPatientDetails({ ...patientDetails, fullName: t })} placeholder="John Doe" />
                    </View>
                    <View style={styles.col}>
                      <Text style={styles.label}>Age *</Text>
                      <TextInput style={styles.input} keyboardType="number-pad" value={patientDetails.age} onChangeText={t => setPatientDetails({ ...patientDetails, age: t })} placeholder="e.g. 30" />
                    </View>
                  </View>

                  <Text style={styles.label}>Gender *</Text>
                  <View style={styles.pillsRow}>
                    {['Male', 'Female', 'Other'].map(g => (
                      <TouchableOpacity key={g} style={[styles.pillBtn, patientDetails.gender === g && styles.pillBtnActive]} onPress={() => setPatientDetails({ ...patientDetails, gender: g })}>
                        <Text style={[styles.pillText, patientDetails.gender === g && styles.pillTextActive]}>{g}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>

                  <Text style={styles.label}>Emergency Contact (Optional)</Text>
                  <TextInput style={styles.input} value={patientDetails.emergencyContact} onChangeText={t => setPatientDetails({ ...patientDetails, emergencyContact: t })} placeholder="Phone number" keyboardType="phone-pad" />

                  <Text style={styles.label}>Symptoms / Reasons for Visit / Allergies</Text>
                  <TextInput
                    style={[styles.input, { height: 100, textAlignVertical: 'top' }]}
                    placeholder="Please describe symptoms or any known allergies..."
                    multiline
                    value={patientDetails.notes}
                    onChangeText={t => setPatientDetails({ ...patientDetails, notes: t })}
                  />

                  <View style={styles.btnRowBetween}>
                    <TouchableOpacity style={styles.backBtnLight} onPress={() => setStep(2)}><Text style={styles.backText}>Back</Text></TouchableOpacity>
                    <TouchableOpacity style={[styles.nextBtn, (!patientDetails.age || !patientDetails.gender || !patientDetails.fullName) && styles.nextButtonDisabled]} disabled={!patientDetails.age || !patientDetails.gender || !patientDetails.fullName} onPress={() => setStep(4)}>
                      <Text style={styles.nextText}>Next</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              )}

              {step === 4 && (
                <View>
                  <View style={styles.stepHeaderRow}>
                    <Clock size={24} color="#0d9488" />
                    <Text style={styles.stepTitle}>Schedule Appointment</Text>
                  </View>
                  <Text style={styles.stepSubtitle}>Choose service type and preferred time</Text>

                  <View style={styles.serviceRow}>
                    <TouchableOpacity style={[styles.serviceOption, selectedService === 'TELEHEALTH' && styles.serviceOptionActive]} onPress={() => setSelectedService('TELEHEALTH')}>
                      <Video size={20} color={selectedService === 'TELEHEALTH' ? '#0d9488' : '#64748b'} />
                      <View style={{ marginLeft: 10, flex: 1 }}>
                        <Text style={[styles.serviceOptionTitle, selectedService === 'TELEHEALTH' && styles.serviceOptionTitleActive]}>Telehealth</Text>
                        <Text style={styles.serviceOptionSub}>Video Call</Text>
                      </View>
                      {selectedService === 'TELEHEALTH' && <Check size={16} color="#0d9488" />}
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.serviceOption, selectedService === 'EMERGENCY' && styles.serviceOptionActive]} onPress={() => setSelectedService('EMERGENCY')}>
                      <AlertCircle size={20} color={selectedService === 'EMERGENCY' ? '#0d9488' : '#64748b'} />
                      <View style={{ marginLeft: 10, flex: 1 }}>
                        <Text style={[styles.serviceOptionTitle, selectedService === 'EMERGENCY' && styles.serviceOptionTitleActive]}>Emergency</Text>
                        <Text style={styles.serviceOptionSub}>In-person Visit</Text>
                      </View>
                      {selectedService === 'EMERGENCY' && <Check size={16} color="#0d9488" />}
                    </TouchableOpacity>
                  </View>

                  <Text style={styles.label}>Select Date *</Text>
                  <View style={styles.calendarContainer}>
                    <View style={styles.calHeader}>
                      <TouchableOpacity style={styles.calNav} onPress={() => changeMonth(-1)}><ChevronLeft size={20} color="#1e293b" /></TouchableOpacity>
                      <Text style={styles.calMonthText}>{monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}</Text>
                      <TouchableOpacity style={styles.calNav} onPress={() => changeMonth(1)}><ChevronLeft size={20} color="#1e293b" style={{ transform: [{ rotate: '180deg' }] }} /></TouchableOpacity>
                    </View>
                    <View style={styles.calWeekdays}>
                      {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map(d => <Text key={d} style={styles.calWeekdayText}>{d}</Text>)}
                    </View>
                    <View style={styles.calDaysGrid}>
                      {blanks.map(b => <View key={`blank-${b}`} style={styles.calDayWrap} />)}
                      {days.map(d => {
                        const past = isPast(d);
                        const selected = isSelectedDate(d);
                        const today = isToday(d);
                        return (
                          <TouchableOpacity
                            key={d}
                            style={[styles.calDayWrap, selected && styles.calDayWrapActive]}
                            onPress={() => handleDaySelect(d)}
                            disabled={past}
                          >
                            <Text style={[
                              styles.calDayText,
                              past && styles.calDayTextPast,
                              today && !selected && styles.calDayTextToday,
                              selected && styles.calDayTextActive
                            ]}>{d}</Text>
                          </TouchableOpacity>
                        );
                      })}
                    </View>
                  </View>

                  {selectedDate && (
                    <View style={styles.timeSection}>
                      <Text style={styles.label}>Select Time * (Available after 1 hour)</Text>
                      <View style={styles.timeGrid}>
                        {['16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30'].map(t => (
                          <TouchableOpacity
                            key={t}
                            style={[styles.timeBtn, selectedTime === t && styles.timeBtnActive]}
                            onPress={() => setSelectedTime(t)}
                          >
                            <Text style={[styles.timeBtnText, selectedTime === t && styles.timeBtnTextActive]}>{t}</Text>
                          </TouchableOpacity>
                        ))}
                      </View>
                    </View>
                  )}

                  <View style={styles.btnRowBetween}>
                    <TouchableOpacity style={styles.backBtnLight} onPress={() => setStep(3)}><Text style={styles.backText}>Back</Text></TouchableOpacity>
                    <TouchableOpacity style={[styles.nextBtn, (!selectedService || !selectedDate || !selectedTime) && styles.nextButtonDisabled]} disabled={!selectedService || !selectedDate || !selectedTime} onPress={() => setStep(5)}>
                      <Text style={styles.nextText}>Next</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              )}

              {step === 5 && (
                <View>
                  <View style={styles.stepHeaderRow}>
                    <Check size={24} color="#0d9488" />
                    <Text style={styles.stepTitle}>Confirm Booking</Text>
                  </View>
                  <Text style={styles.stepSubtitle}>Review your details before confirming. Missing Requirements will fail the request.</Text>

                  <View style={styles.reviewBlock}>
                    <View style={styles.reviewRow}>
                      <Text style={styles.reviewLabel}>Patient:</Text>
                      <Text style={styles.reviewValue}>{patientDetails.fullName} ({patientDetails.age}y, {patientDetails.gender})</Text>
                    </View>
                    <View style={styles.reviewRow}>
                      <Text style={styles.reviewLabel}>Location:</Text>
                      <Text style={styles.reviewValue}>{selectedCity}, {selectedState || selectedCountry}</Text>
                    </View>
                    <View style={styles.reviewRow}>
                      <Text style={styles.reviewLabel}>Service:</Text>
                      <Text style={styles.reviewValue}>{selectedService === 'TELEHEALTH' ? 'Telehealth (Video Call)' : 'Emergency'} on {selectedDate?.getDate()} {monthNames[selectedDate?.getMonth() || 0]}, @ {selectedTime}</Text>
                    </View>
                    {patientDetails.notes ? <View style={styles.reviewRow}><Text style={styles.reviewLabel}>Notes/Symptoms:</Text><Text style={styles.reviewValue}>{patientDetails.notes}</Text></View> : null}
                  </View>

                  <View style={styles.btnRowBetween}>
                    <TouchableOpacity style={styles.backBtnLight} onPress={() => setStep(4)}><Text style={styles.backText}>Back</Text></TouchableOpacity>
                    <TouchableOpacity style={styles.confirmBtn} onPress={handleConfirm} disabled={loading}>
                      {loading ? <ActivityIndicator color="#fff" /> : <Text style={{ color: '#fff', fontWeight: '700', fontSize: 16 }}>Confirm</Text>}
                    </TouchableOpacity>
                  </View>
                </View>
              )}
            </View>
          )}
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f1f5f9' },
  header: { paddingTop: 60, paddingBottom: 20, paddingHorizontal: 20 },
  backNavBtn: { position: 'absolute', top: 56, left: 16, zIndex: 10, padding: 8 },
  headerTitle: { fontSize: 20, fontWeight: '700', color: '#ffffff', marginBottom: 16, textAlign: 'center' },

  stepIndicator: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginBottom: 10 },
  stepContainer: { flexDirection: 'row', alignItems: 'center' },
  stepCircle: { width: 30, height: 30, borderRadius: 15, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' },
  stepCircleActive: { backgroundColor: '#ffffff', elevation: 2 },
  stepCircleCompleted: { backgroundColor: '#0ea5e9' },
  stepText: { color: '#e2e8f0', fontSize: 13, fontWeight: '700' },
  stepTextActive: { color: '#1e40af' },
  stepLine: { width: 20, height: 2, backgroundColor: 'rgba(255,255,255,0.2)', marginHorizontal: 2 },
  stepLineCompleted: { backgroundColor: '#0ea5e9' },
  stepLabels: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', paddingHorizontal: 0 },
  stepLabelText: { fontSize: 9, color: '#bfdbfe', width: 56, textAlign: 'center', fontWeight: '500' },
  stepLabelTextActive: { color: '#ffffff', fontWeight: '700' },

  scrollContent: { padding: 16, paddingBottom: 60 },

  cardContainer: { backgroundColor: '#ffffff', borderRadius: 20, padding: 24, elevation: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 8, borderWidth: 1, borderColor: '#f1f5f9' },
  stepHeaderRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 6 },
  stepTitle: { fontSize: 20, fontWeight: '700', color: '#0f172a', marginLeft: 10 },
  stepSubtitle: { fontSize: 14, color: '#64748b', marginBottom: 24 },

  row: { flexDirection: 'row', gap: 16 },
  col: { flex: 1 },
  label: { fontSize: 13, fontWeight: '600', color: '#334155', marginBottom: 8 },
  input: { backgroundColor: '#f8fafc', padding: 16, borderRadius: 12, marginBottom: 20, borderWidth: 1, borderColor: '#e2e8f0', fontSize: 15, color: '#0f172a' },
  inputDisabled: { backgroundColor: '#f1f5f9', padding: 16, borderRadius: 12, marginBottom: 20, borderWidth: 1, borderColor: '#e2e8f0', fontSize: 15, color: '#94a3b8' },

  dropdownContainer: { marginBottom: 20, position: 'relative' },
  dropdownTrigger: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#f8fafc', padding: 16, borderRadius: 12, borderWidth: 1, borderColor: '#e2e8f0' },
  dropdownValue: { fontSize: 15, color: '#0f172a' },
  placeholderText: { color: '#94a3b8' },
  disabledInput: { backgroundColor: '#f1f5f9', opacity: 0.7 },
  dropdownMenu: { backgroundColor: '#f8fafc', borderRadius: 12, borderWidth: 1, borderColor: '#e2e8f0', marginTop: 8, maxHeight: 200, overflow: 'hidden' },
  dropdownItem: { padding: 16, borderBottomWidth: 1, borderBottomColor: '#e2e8f0' },
  dropdownItemText: { fontSize: 15, color: '#334155' },

  btnRowBetween: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 16, alignItems: 'center' },
  cancelBtn: { padding: 16, borderRadius: 12, backgroundColor: '#f1f5f9' },
  cancelText: { color: '#64748b', fontWeight: '600', fontSize: 15 },
  backBtnLight: { padding: 16, borderRadius: 12, backgroundColor: '#f1f5f9', paddingHorizontal: 24 },
  backText: { color: '#475569', fontWeight: '600', fontSize: 15 },
  nextBtn: { padding: 16, borderRadius: 12, backgroundColor: '#1e3a8a', paddingHorizontal: 40, elevation: 2 },
  nextText: { color: '#ffffff', fontWeight: '600', fontSize: 15 },
  nextButtonDisabled: { backgroundColor: '#94a3b8', elevation: 0 },
  confirmBtn: { padding: 16, borderRadius: 12, backgroundColor: '#0d9488', paddingHorizontal: 40, elevation: 2 },

  patientSelectCard: { flexDirection: 'row', alignItems: 'center', padding: 16, borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 14, marginBottom: 12, backgroundColor: '#ffffff' },
  patientSelectCardActive: { borderColor: '#0d9488', backgroundColor: '#f0fdfa', borderWidth: 1.5 },
  patientIconWrap: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#f1f5f9', justifyContent: 'center', alignItems: 'center', marginRight: 16 },
  patientIconWrapActive: { backgroundColor: '#ccfbf1' },
  patientName: { fontSize: 16, fontWeight: '700', color: '#1e293b' },
  patientSubtext: { fontSize: 14, color: '#64748b', marginTop: 2 },
  familyMembersLabel: { fontSize: 13, fontWeight: '600', color: '#94a3b8', marginTop: 16, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 0.5 },

  pillsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  pillBtn: { paddingHorizontal: 20, paddingVertical: 12, borderRadius: 12, backgroundColor: '#f8fafc', borderWidth: 1, borderColor: '#e2e8f0' },
  pillBtnActive: { backgroundColor: '#eff6ff', borderColor: '#3b82f6', borderWidth: 1.5 },
  pillText: { fontSize: 14, color: '#475569', fontWeight: '600' },
  pillTextActive: { color: '#2563eb' },

  serviceRow: { flexDirection: 'column', gap: 12, marginBottom: 24 },
  serviceOption: { flex: 1, padding: 20, borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 16, flexDirection: 'row', alignItems: 'center', backgroundColor: '#ffffff' },
  serviceOptionActive: { borderColor: '#0d9488', backgroundColor: '#f0fdfa', borderWidth: 1.5 },
  serviceOptionTitle: { fontSize: 16, fontWeight: '700', color: '#1e293b', marginBottom: 4 },
  serviceOptionTitleActive: { color: '#0d9488' },
  serviceOptionSub: { fontSize: 13, color: '#64748b' },

  calendarContainer: { borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 16, padding: 16, backgroundColor: '#ffffff', marginBottom: 24 },
  calHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  calNav: { padding: 8, backgroundColor: '#f1f5f9', borderRadius: 8 },
  calMonthText: { fontSize: 16, fontWeight: '700', color: '#0f172a' },
  calWeekdays: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 12 },
  calWeekdayText: { width: 32, textAlign: 'center', fontSize: 13, fontWeight: '600', color: '#94a3b8' },
  calDaysGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-around' },
  calDayWrap: { width: '14%', aspectRatio: 1, justifyContent: 'center', alignItems: 'center', marginBottom: 4 },
  calDayWrapActive: { backgroundColor: '#1e3a8a', borderRadius: 10 },
  calDayText: { fontSize: 15, color: '#1e293b', fontWeight: '500' },
  calDayTextPast: { color: '#cbd5e1' },
  calDayTextToday: { color: '#0d9488', fontWeight: '700' },
  calDayTextActive: { color: '#ffffff', fontWeight: '700' },

  timeSection: { marginBottom: 16 },
  timeGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  timeBtn: { paddingVertical: 12, paddingHorizontal: 16, borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 10, width: '31%', alignItems: 'center', backgroundColor: '#ffffff' },
  timeBtnActive: { borderColor: '#1e3a8a', backgroundColor: '#eff6ff', borderWidth: 1.5 },
  timeBtnText: { fontSize: 14, color: '#475569', fontWeight: '600' },
  timeBtnTextActive: { color: '#1e3a8a' },

  reviewBlock: { backgroundColor: '#f8fafc', padding: 20, borderRadius: 16, borderWidth: 1, borderColor: '#e2e8f0', gap: 16 },
  reviewRow: {},
  reviewLabel: { fontSize: 13, color: '#64748b', fontWeight: '600', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 },
  reviewValue: { fontSize: 16, color: '#0f172a', fontWeight: '600', lineHeight: 24 },

  noticeBannerLarge: { backgroundColor: '#eff6ff', padding: 32, borderRadius: 20, alignItems: 'center', justifyContent: 'center', marginTop: 40, gap: 20, borderWidth: 2, borderColor: '#dbeafe', borderStyle: 'dashed' },
  noticeTextLarge: { fontSize: 18, lineHeight: 26, fontWeight: '700', color: '#1e40af', textAlign: 'center' },

  docIcon: { width: 24, height: 28, borderWidth: 2, borderColor: '#0d9488', borderRadius: 4, justifyContent: 'center', alignItems: 'center' },
  docIconLine1: { width: 12, height: 2, backgroundColor: '#0d9488', marginBottom: 4 },
  docIconLine2: { width: 8, height: 2, backgroundColor: '#0d9488', alignSelf: 'flex-start', marginLeft: 4 }
});
