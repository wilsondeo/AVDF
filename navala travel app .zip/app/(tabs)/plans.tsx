import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ActivityIndicator,
    FlatList,
    TouchableOpacity,
    Alert,
    Platform,
    RefreshControl
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { PlansApi } from '../../src/api/features/plans';
import { UserApi } from '../../src/api/features/user';
import { STRIPE_CONFIG } from '../../src/config/stripe';
import { Check, ShieldCheck, ChevronRight, Users, Plus } from 'lucide-react-native';

// Safe Stripe hook for web compatibility
let useStripeHook: any = () => ({ initPaymentSheet: async () => ({}), presentPaymentSheet: async () => ({}) });

if (Platform.OS !== 'web') {
    try {
        const Stripe = require('@stripe/stripe-react-native');
        useStripeHook = Stripe.useStripe;
    } catch (e) {
        console.warn('Stripe native module not found');
    }
}

interface Plan {
    id: number;
    planId: string;
    name: string;
    price: string | number;
    validityDays: number;
    description: string;
    features: string;
    services?: string[];
    planTabName?: string;
    maxPersons?: number;
}

export default function PlansScreen() {
    const [plans, setPlans] = useState<Plan[]>([]);
    const [loading, setLoading] = useState(true);
    const [activePlan, setActivePlan] = useState<any>(null);
    const [purchasing, setPurchasing] = useState<number | null>(null);
    const [refreshing, setRefreshing] = useState(false);
    const [activeTab, setActiveTab] = useState<'INDIVIDUAL' | 'FAMILY_2' | 'FAMILY_3_4'>('INDIVIDUAL');
    const [familyMembers, setFamilyMembers] = useState<any[]>([]);
    const [userData, setUserData] = useState<any>(null);
    const [maxSlots, setMaxSlots] = useState<number>(0);
    const stripe = useStripeHook();

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            if (!refreshing) setLoading(true);
            const [plansRes, activeRes, familyRes, profileRes] = await Promise.all([
                PlansApi.getPlans().catch(() => null),
                UserApi.getActivePlan().catch(() => null),
                UserApi.getFamilyMembers().catch(() => null),
                UserApi.getProfile().catch(() => null)
            ]);

            if (plansRes && plansRes.success && plansRes.data && plansRes.data.plans) {
                const sorted = [...plansRes.data.plans].sort((a, b) => Number(a.price) - Number(b.price));
                setPlans(sorted);
            } else if (plansRes && Array.isArray(plansRes)) {
                const sorted = [...plansRes].sort((a, b) => Number(a.price) - Number(b.price));
                setPlans(sorted);
            }

            if (activeRes && activeRes.success && activeRes.data) {
                const planData = activeRes.data.activePlan || activeRes.data;
                // Aligned with web app logic: hide banner if planData.plan is missing
                // This correctly handles the "Basic" or No Plan default states
                if (planData && planData.plan) {
                    setActivePlan(planData);

                    if (familyRes && familyRes.success && familyRes.data) {
                        setFamilyMembers(familyRes.data.familyMembers || []);
                        let slots = familyRes.data.maxSlots;
                        if (!slots || slots <= 1) slots = planData.plan?.maxPersons || planData.maxPersons || 1;
                        setMaxSlots(slots);
                    }
                } else {
                    setActivePlan(null);
                }
            } else {
                setActivePlan(null);
            }

            if (profileRes && profileRes.success && profileRes.data) {
                setUserData(profileRes.data);
            }
        } catch (error: any) {
            console.error('Failed to fetch plans:', error);
            Alert.alert('Error', 'Could not load plans.');
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    const onRefresh = () => {
        setRefreshing(true);
        loadData();
    };

    const handleBuy = async (plan: Plan) => {
        if (Platform.OS === 'web') {
            Alert.alert('Not Supported', 'Payments require a physical device.');
            return;
        }

        if (activePlan) {
            const currentPlanPrice = Number(activePlan?.plan?.price || activePlan?.price || 0);
            const selectedPlanPrice = Number(plan.price);

            if (selectedPlanPrice < currentPlanPrice) {
                Alert.alert(
                    'Plan Downgrade',
                    'You cannot move down to a lower plan.',
                    [{ text: 'OK' }]
                );
                return;
            }

            Alert.alert(
                'Plan Active',
                'You already have an active plan. Would you like to replace it?',
                [
                    { text: 'Cancel', style: 'cancel' },
                    { text: 'Purchase New', onPress: () => processPurchase(plan) }
                ]
            );
        } else {
            processPurchase(plan);
        }
    };

    const processPurchase = async (plan: Plan) => {
        setPurchasing(plan.id);
        try {
            const response = await PlansApi.purchasePlan(plan.planId);
            if (response.success && response.data) {
                const { clientSecret } = response.data;
                const { error: initError } = await stripe.initPaymentSheet({
                    merchantDisplayName: 'Navala Travel',
                    paymentIntentClientSecret: clientSecret,
                    returnURL: `${STRIPE_CONFIG.urlScheme}://plans`,
                });

                if (initError) {
                    Alert.alert('Error', initError.message);
                } else {
                    const { error: paymentError } = await stripe.presentPaymentSheet();
                    if (!paymentError) {
                        const amountText = response.data.type === 'UPGRADE'
                            ? `(Paid difference: $${response.data.amountCharged})`
                            : `($${response.data.amountCharged})`;

                        Alert.alert('Success', `Purchased ${plan.name} ${amountText}. Your health plan will be applied from Jun 09 to July 20.`, [
                            { text: 'OK', onPress: () => loadData() }
                        ]);
                    }
                }
            }
        } catch (error) {
            Alert.alert('Error', 'Payment failed');
        } finally {
            setPurchasing(null);
        }
    };

    const renderPlan = ({ item }: { item: Plan }) => {
        let featuresList: string[] = [];
        if (Array.isArray(item.features)) {
            featuresList = item.features;
        } else {
            try { featuresList = JSON.parse(item.features); } catch (e) { featuresList = [item.description]; }
        }

        const currentPlanIdStr = activePlan?.plan?.planId || activePlan?.planId;
        const currentPlanInternalId = activePlan?.plan?.id || activePlan?.plan_id;
        const currentPlanPrice = Number(activePlan?.plan?.price || activePlan?.price || 0);
        const isActive = activePlan && (item.planId === currentPlanIdStr || item.id === currentPlanInternalId);
        const isUpgrade = activePlan && !isActive && Number(item.price) > currentPlanPrice;
        const isDowngrade = activePlan && !isActive && Number(item.price) < currentPlanPrice;
        const upgradePrice = isUpgrade ? (Number(item.price) - currentPlanPrice).toFixed(2) : null;

        return (
            <View style={[styles.card, isActive && styles.activeCard]}>
                {isActive && (
                    <View style={styles.activeBadge}>
                        <Text style={styles.activeBadgeText}>Current Plan</Text>
                    </View>
                )}
                {!isActive && Number(item.price) === 150 && (
                    <View style={styles.recommendedBadge}>
                        <Text style={styles.recommendedBadgeText}>Recommended</Text>
                    </View>
                )}

                <View style={styles.cardHeader}>
                    <Text style={styles.planName}>{item.name}</Text>
                    <Text style={styles.planPrice}>${item.price}</Text>
                    {isUpgrade && (
                        <Text style={styles.upgradeDifference}>Upgrade for only ${upgradePrice}</Text>
                    )}
                    <Text style={styles.planValidity}>/ {item.validityDays} days</Text>
                </View>

                <Text style={styles.planDescription}>{item.description}</Text>

                <View style={styles.divider} />

                <View style={styles.featuresContainer}>
                    {featuresList.map((f, i) => (
                        <View key={i} style={styles.featureRow}>
                            <Check size={16} color="#10b981" />
                            <Text style={styles.featureText}>{f}</Text>
                        </View>
                    ))}
                </View>

                <TouchableOpacity
                    style={[
                        styles.buyButton,
                        isActive && styles.activeBuyButton,
                        purchasing === item.id && styles.disabledButton
                    ]}
                    onPress={() => !isActive && handleBuy(item)}
                    disabled={purchasing === item.id || isActive}
                >
                    {purchasing === item.id ? (
                        <ActivityIndicator color="#fff" />
                    ) : (
                        <Text style={[styles.buyButtonText, isActive && styles.activeBuyButtonText]}>
                            {isActive ? 'Currently Active' : (isUpgrade ? 'Upgrade Plan' : (isDowngrade ? 'Lower Plan' : 'Get Started'))}
                        </Text>
                    )}
                </TouchableOpacity>
            </View>
        );
    };

    if (loading && !refreshing) return <View style={styles.center}><ActivityIndicator size="large" color="#2563eb" /></View>;

    return (
        <View style={styles.container}>
            <LinearGradient colors={['#0251fc', '#072169']} style={styles.header}>
                <Text style={styles.headerTitle}>Plans & Pricing</Text>

                <View style={styles.tabsContainer}>
                    <TouchableOpacity
                        style={[styles.tabButton, activeTab === 'INDIVIDUAL' && styles.activeTabButton]}
                        onPress={() => setActiveTab('INDIVIDUAL')}
                    >
                        <Text style={[styles.tabText, activeTab === 'INDIVIDUAL' && styles.activeTabText]}>Individual</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={[styles.tabButton, activeTab === 'FAMILY_2' && styles.activeTabButton]}
                        onPress={() => setActiveTab('FAMILY_2')}
                    >
                        <Text style={[styles.tabText, activeTab === 'FAMILY_2' && styles.activeTabText]}>Family of 2</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={[styles.tabButton, activeTab === 'FAMILY_3_4' && styles.activeTabButton]}
                        onPress={() => setActiveTab('FAMILY_3_4')}
                    >
                        <Text style={[styles.tabText, activeTab === 'FAMILY_3_4' && styles.activeTabText]}>Family 3-4</Text>
                    </TouchableOpacity>
                </View>
            </LinearGradient>
            <FlatList
                data={plans.filter(p => {
                    const maxP = p.maxPersons || 1;
                    const tabName = (p.planTabName || '').toLowerCase();
                    if (activeTab === 'INDIVIDUAL') return maxP === 1 || tabName.includes('individual');
                    if (activeTab === 'FAMILY_2') return maxP === 2 || tabName.includes('family of 2');
                    if (activeTab === 'FAMILY_3_4') return maxP >= 3 || tabName.includes('family of 3-4');
                    return false;
                })}
                renderItem={renderPlan}
                keyExtractor={(item) => item.id.toString()}
                contentContainerStyle={{ padding: 16 }}
                refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
                ListHeaderComponent={activePlan ? (
                    <View style={styles.activePlanBanner}>
                        <View style={styles.bannerTopRow}>
                            <View style={styles.bannerIconWrapper}>
                                <ShieldCheck size={28} color="#059669" />
                            </View>
                            <View style={styles.bannerPlanDetails}>
                                <View style={styles.bannerPlanTitleRow}>
                                    <Text style={styles.bannerPlanName}>
                                        Active Plan: {activePlan.plan?.name || activePlan.name || 'Basic'}
                                    </Text>
                                    <View style={styles.activePill}>
                                        <Text style={styles.activePillText}>ACTIVE</Text>
                                    </View>
                                </View>
                                <Text style={styles.bannerPlanDate}>
                                    {/* Ideally format dates, using placeholders if not available immediately */}
                                    Coverage active
                                </Text>
                            </View>
                        </View>

                        <View style={styles.bannerDivider} />

                        <View style={styles.coverageSection}>
                            <View style={styles.coverageHeaderRow}>
                                <Users size={16} color="#047857" />
                                <Text style={styles.coverageLabel}>COVERAGE DETAILS</Text>
                            </View>

                            <View style={styles.coverageMembersRow}>
                                <View style={styles.userPill}>
                                    <View style={styles.userAvatar}>
                                        <Text style={styles.userAvatarText}>
                                            {(userData?.firstName?.[0] || 'Y').toUpperCase()}
                                        </Text>
                                    </View>
                                    <Text style={styles.userPillText}>
                                        {userData?.firstName ? `${userData.firstName} ${userData.lastName || ''}` : 'You'} (You)
                                    </Text>
                                </View>

                                {familyMembers.map((member, idx) => (
                                    <View key={idx} style={styles.userPill}>
                                        <View style={styles.userAvatar}>
                                            <Text style={styles.userAvatarText}>{member.firstName[0].toUpperCase()}</Text>
                                        </View>
                                        <Text style={styles.userPillText}>{member.firstName}</Text>
                                    </View>
                                ))}

                                {familyMembers.length < (maxSlots > 0 ? maxSlots - 1 : 0) && (
                                    <TouchableOpacity style={styles.addFamilyInlineBtn} onPress={() => router.push('/family')}>
                                        <Text style={styles.addFamilyInlineText}>+ Add Family Member</Text>
                                    </TouchableOpacity>
                                )}
                            </View>
                        </View>
                    </View>
                ) : null}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f9fafb' },
    center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
    header: { paddingTop: 50, paddingBottom: 24, paddingHorizontal: 20 },
    headerTitle: { fontSize: 24, fontWeight: '700', color: '#ffffff', marginBottom: 16 },
    tabsContainer: { flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 12, padding: 4 },
    tabButton: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 10 },
    activeTabButton: { backgroundColor: '#ffffff' },
    tabText: { color: '#ffffff', fontSize: 13, fontWeight: '600' },
    activeTabText: { color: '#2563eb' },
    card: { backgroundColor: '#ffffff', borderRadius: 16, padding: 20, marginBottom: 16, elevation: 3 },
    cardHeader: { alignItems: 'center', marginBottom: 16 },
    planName: { fontSize: 20, fontWeight: '700', color: '#111827' },
    planPrice: { fontSize: 32, fontWeight: '800', color: '#2563eb' },
    planValidity: { fontSize: 14, color: '#6b7280' },
    divider: { height: 1, backgroundColor: '#f3f4f6', marginVertical: 16 },
    featuresContainer: { marginBottom: 20 },
    featureRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 8, gap: 8 },
    featureText: { fontSize: 14, color: '#4b5563', flex: 1 },
    buyButton: { backgroundColor: '#2563eb', paddingVertical: 14, borderRadius: 12, alignItems: 'center' },
    buyButtonText: { color: '#ffffff', fontSize: 16, fontWeight: '600' },
    activeCard: {
        borderColor: '#16a34a',
        borderWidth: 2,
    },
    activeBadge: {
        position: 'absolute',
        top: -12,
        right: 20,
        backgroundColor: '#16a34a',
        paddingHorizontal: 12,
        paddingVertical: 4,
        borderRadius: 20,
        zIndex: 10,
    },
    activeBadgeText: {
        color: '#ffffff',
        fontSize: 12,
        fontWeight: 'bold',
    },
    recommendedBadge: {
        position: 'absolute',
        top: -12,
        right: 20,
        backgroundColor: '#f59e0b',
        paddingHorizontal: 12,
        paddingVertical: 4,
        borderRadius: 20,
        zIndex: 10,
    },
    recommendedBadgeText: {
        color: '#ffffff',
        fontSize: 12,
        fontWeight: 'bold',
    },
    planDescription: {
        fontSize: 14,
        color: '#6b7280',
        marginBottom: 16,
        lineHeight: 20,
        textAlign: 'center'
    },
    activeBuyButton: {
        backgroundColor: '#f0fdf4',
        borderWidth: 1,
        borderColor: '#16a34a',
    },
    activeBuyButtonText: {
        color: '#16a34a',
    },
    disabledButton: {
        opacity: 0.5,
    },
    activePlanBanner: {
        backgroundColor: '#ecfdf5',
        borderRadius: 16,
        padding: 16,
        marginBottom: 20,
        borderWidth: 1,
        borderColor: '#a7f3d0',
    },
    bannerTopRow: { flexDirection: 'row', gap: 12, alignItems: 'center' },
    bannerIconWrapper: { width: 48, height: 48, borderRadius: 24, backgroundColor: '#d1fae5', justifyContent: 'center', alignItems: 'center' },
    bannerPlanDetails: { flex: 1 },
    bannerPlanTitleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
    bannerPlanName: { fontSize: 18, fontWeight: '700', color: '#047857' },
    activePill: { backgroundColor: '#10b981', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
    activePillText: { color: '#ffffff', fontSize: 10, fontWeight: '800' },
    bannerPlanDate: { fontSize: 13, color: '#64748b' },
    bannerDivider: { height: 1, backgroundColor: '#a7f3d0', marginVertical: 16 },
    coverageSection: {},
    coverageHeaderRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 12 },
    coverageLabel: { fontSize: 12, fontWeight: '700', color: '#047857', letterSpacing: 0.5 },
    coverageMembersRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, alignItems: 'center' },
    userPill: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#ffffff', borderRadius: 20, paddingRight: 12, paddingLeft: 4, paddingVertical: 4, borderWidth: 1, borderColor: '#d1fae5' },
    userAvatar: { width: 24, height: 24, borderRadius: 12, backgroundColor: '#cbd5e1', justifyContent: 'center', alignItems: 'center', marginRight: 8 },
    userAvatarText: { fontSize: 12, fontWeight: '700', color: '#334155' },
    userPillText: { fontSize: 13, fontWeight: '500', color: '#334155' },
    addFamilyInlineBtn: { paddingHorizontal: 8, paddingVertical: 6 },
    addFamilyInlineText: { color: '#10b981', fontSize: 13, fontWeight: '600' },

    activePlanInfo: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    activePlanText: { fontSize: 15, fontWeight: '600', color: '#16a34a', flex: 1 },
    upgradeDifference: {
        fontSize: 14,
        fontWeight: '700',
        color: '#16a34a',
        marginTop: 4,
        marginBottom: 2,
    },
});
