import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator, RefreshControl } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Calendar, MapPin, User, FileText, Plus, Info, Video, CheckCircle2, Clock } from 'lucide-react-native';
import { router } from 'expo-router';
import { AppointmentsApi } from '../../src/api';
import { format } from 'date-fns';
import { UI_SETTINGS } from '../../src/config/settings';

export default function AppointmentsScreen() {
  const [appointments, setAppointments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchAppointments();
  }, []);

  const fetchAppointments = async () => {
    try {
      const response = await AppointmentsApi.getMyRequests();
      if (response.success) {
        setAppointments(response.data);
      }
    } catch (error) {
      console.error('Error fetching appointments:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    fetchAppointments();
  };

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'confirmed':
      case 'assigned':
      case 'scheduled': return { bg: '#def7ec', text: '#03543f' };
      case 'pending': return { bg: '#fef3c7', text: '#92400e' };
      case 'rejected':
      case 'cancelled': return { bg: '#fde8e8', text: '#9b1c1c' };
      default: return { bg: '#f3f4f6', text: '#6b7280' };
    }
  };

  if (loading && !refreshing) {
    return <View style={styles.center}><ActivityIndicator size="large" color="#2563eb" /></View>;
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#0251fc', '#072169']} style={styles.header}>
        <View style={styles.headerRow}>
          <View>
            <Text style={styles.headerTitle}>My Appointments</Text>
            <Text style={styles.headerSubtitle}>{appointments.length} active requests</Text>
          </View>
          <TouchableOpacity style={styles.addButton} onPress={() => router.push('/booking')}>
            <Plus size={24} color="#2563eb" />
          </TouchableOpacity>
        </View>
      </LinearGradient>

      <ScrollView
        style={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {UI_SETTINGS.SHOW_PLAN_NOTICE ? (
          <View style={styles.noticeBannerLarge}>
            <Info size={32} color="#1e3a8a" />
            <Text style={styles.noticeTextLarge}>{UI_SETTINGS.PLAN_NOTICE_MESSAGE}</Text>
          </View>
        ) : (
          appointments.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Calendar size={64} color="#d1d5db" />
              <Text style={styles.emptyText}>No appointments found</Text>
              <TouchableOpacity style={styles.bookButton} onPress={() => router.push('/booking')}>
                <Text style={styles.bookButtonText}>Book Now</Text>
              </TouchableOpacity>
            </View>
          ) : (
            appointments.map((apt) => {
              const statusColors = getStatusColor(apt.status);
              return (
                <View key={apt.id || apt.requestUuid} style={styles.appointmentCard}>
                  <View style={styles.cardHeader}>
                    <View style={styles.serviceTag}>
                      <Text style={styles.serviceTagText}>{apt.serviceType || 'Consultation'}</Text>
                    </View>
                    <View style={[styles.statusBadge, { backgroundColor: statusColors.bg }]}>
                      <Text style={[styles.statusText, { color: statusColors.text }]}>{apt.status}</Text>
                    </View>
                  </View>

                  <View style={styles.detailsSection}>
                    {apt.doctor && (
                      <View style={styles.detailRow}>
                        <User size={16} color="#2563eb" />
                        <Text style={[styles.detailText, { color: '#2563eb', fontWeight: '600' }]}>
                          Dr. {apt.doctor.firstName} {apt.doctor.lastName}
                        </Text>
                      </View>
                    )}
                    <View style={styles.detailRow}>
                      <Calendar size={16} color="#6b7280" />
                      <Text style={styles.detailText}>
                        Requested: {apt.createdAt ? format(new Date(apt.createdAt), 'MMM dd, yyyy') : 'Recently'}
                      </Text>
                    </View>
                    <View style={styles.detailRow}>
                      <MapPin size={16} color="#6b7280" />
                      <Text style={styles.detailText}>{apt.city}</Text>
                    </View>
                  </View>

                  {(apt.status?.toLowerCase() === 'pending' || apt.status?.toLowerCase() === 'assigned') && (
                    <View style={styles.statusInfoBox}>
                      <View style={styles.successRow}>
                        <CheckCircle2 size={18} color="#059669" />
                        <Text style={styles.successTitle}>Appointment booked</Text>
                      </View>
                      <View style={styles.statusWaitRow}>
                        <Clock size={16} color="#d97706" />
                        <Text style={styles.statusWaitText}>
                          Status: <Text style={{ fontWeight: '700' }}>Waiting for doctor</Text>
                        </Text>
                      </View>
                      <Text style={styles.joinNote}>Doctor will be assigned shortly,You will be notified when the doctor is assigned.</Text>
                    </View>
                  )}

                  {apt.notes && (
                    <View style={styles.notesBox}>
                      <FileText size={14} color="#6b7280" />
                      <Text style={styles.notesText} numberOfLines={2}>{apt.notes}</Text>
                    </View>
                  )}

                  {apt.status?.toLowerCase() === 'assigned' || apt.status?.toLowerCase() === 'confirmed' || apt.status?.toLowerCase() === 'scheduled' ? (
                    <TouchableOpacity
                      style={styles.joinBtn}
                      onPress={() => Alert.alert('Join Call', 'Connecting to secure video session...')}
                    >
                      <Video size={18} color="#fff" />
                      <Text style={styles.joinBtnText}>Join Video Call</Text>
                    </TouchableOpacity>
                  ) : apt.status?.toLowerCase() === 'pending' && (
                    <View style={[styles.joinBtn, styles.joinBtnDisabled]}>
                      <Clock size={18} color="#9ca3af" />
                      <Text style={[styles.joinBtnText, { color: '#9ca3af' }]}>Waiting for Doctor...</Text>
                    </View>
                  )}
                </View>
              );
            })
          )
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f9fafb' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { paddingTop: 50, paddingBottom: 24, paddingHorizontal: 20 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  headerTitle: { fontSize: 24, fontWeight: '700', color: '#ffffff' },
  headerSubtitle: { fontSize: 13, color: '#e0e7ff' },
  addButton: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#ffffff', alignItems: 'center', justifyContent: 'center' },
  content: { padding: 16 },
  appointmentCard: { backgroundColor: '#ffffff', borderRadius: 16, padding: 16, marginBottom: 16, elevation: 2 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 },
  serviceTag: { backgroundColor: '#f3f4f6', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  serviceTagText: { fontSize: 11, fontWeight: '600', color: '#6b7280', textTransform: 'uppercase' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  statusText: { fontSize: 11, fontWeight: '700', textTransform: 'capitalize' },
  detailsSection: { marginBottom: 12 },
  detailRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 6 },
  detailText: { fontSize: 14, color: '#4b5563', marginLeft: 8 },
  notesBox: { backgroundColor: '#f9fafb', padding: 8, borderRadius: 8, flexDirection: 'row', gap: 8 },
  notesText: { fontSize: 12, color: '#6b7280', flex: 1 },
  emptyContainer: { alignItems: 'center', marginTop: 100 },
  emptyText: { fontSize: 16, color: '#6b7280', marginTop: 16, marginBottom: 24 },
  bookButton: { backgroundColor: '#2563eb', paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12 },
  bookButtonText: { color: '#ffffff', fontWeight: '600' },
  noticeBannerLarge: {
    backgroundColor: '#eff6ff',
    padding: 32,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 60,
    gap: 20,
    borderWidth: 2,
    borderColor: '#dbeafe',
    borderStyle: 'dashed',
  },
  noticeTextLarge: {
    fontSize: 18,
    lineHeight: 26,
    fontWeight: '700',
    color: '#1e40af',
    textAlign: 'center',
  },
  noticeBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#eff6ff',
    padding: 12,
    borderRadius: 12,
    marginBottom: 16,
    gap: 10,
    borderWidth: 1,
    borderColor: '#dbeafe',
  },
  noticeText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#1e40af',
    flex: 1,
  },
  statusInfoBox: {
    backgroundColor: '#f0fdf4',
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#bbf7d0',
    marginBottom: 12,
  },
  successRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  successTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: '#065f46',
  },
  statusWaitRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  statusWaitText: {
    fontSize: 14,
    color: '#92400e',
  },
  joinNote: {
    fontSize: 12,
    color: '#065f46',
    marginLeft: 26,
    opacity: 0.8,
  },
  joinBtn: {
    backgroundColor: '#2563eb',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 12,
    gap: 8,
    marginTop: 8,
  },
  joinBtnDisabled: {
    backgroundColor: '#f3f4f6',
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  joinBtnText: {
    color: '#ffffff',
    fontWeight: '700',
    fontSize: 15,
  },
});
