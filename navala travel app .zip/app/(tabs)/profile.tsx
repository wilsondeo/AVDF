import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator, Image, RefreshControl } from 'react-native';
import {
  User, Mail, Phone, Calendar, MapPin, Activity,
  Heart, Shield, LogOut, ChevronRight, Edit3,
  Map, Fingerprint, Camera, Clock, CheckCircle, FileText, Users
} from 'lucide-react-native';
import { router, useFocusEffect } from 'expo-router';
import { UserApi, AppointmentsApi } from '../../src/api';
import { deleteItem } from '../../src/utils/storage';

export default function ProfileScreen() {
  const [profile, setProfile] = useState<any>(null);
  const [plan, setPlan] = useState<any>(null);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [familyMembers, setFamilyMembers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchData = useCallback(async (isSilent = false) => {
    try {
      if (!isSilent) setLoading(true);
      const [profileRes, planRes, appointmentsRes, familyRes] = await Promise.all([
        UserApi.getProfile(),
        UserApi.getActivePlan(),
        AppointmentsApi.getMyRequests(),
        UserApi.getFamilyMembers().catch(() => ({ success: false, data: { familyMembers: [] } }))
      ]);

      if (profileRes.success) setProfile(profileRes.data);
      if (planRes.success) setPlan(planRes.data);
      if (appointmentsRes.success) setAppointments(appointmentsRes.data);
      if (familyRes && familyRes.success && familyRes.data) {
        setFamilyMembers(familyRes.data.familyMembers || []);
      }
    } catch (error) {
      console.error('Error fetching profile data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      // Only show the full loading spinner if we don't have profile data yet
      fetchData(!!profile);
    }, [fetchData, profile])
  );

  const onRefresh = () => {
    setRefreshing(true);
    fetchData(true);
  };

  const calculateDaysLeft = () => {
    if (!plan?.endDate) return 0;
    const end = new Date(plan.endDate);
    const now = new Date();
    const diff = end.getTime() - now.getTime();
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    return days > 0 ? days : 0;
  };

  const handleLogout = async () => {
    Alert.alert('Logout', 'Are you sure you want to log out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Logout',
        style: 'destructive',
        onPress: async () => {
          await deleteItem('accessToken');
          await deleteItem('refreshToken');
          await deleteItem('userData');
          router.replace('/login');
        }
      }
    ]);
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#1e3a8a" />
      </View>
    );
  }

  const initials = profile ? `${profile.firstName?.[0] || ''}${profile.lastName?.[0] || ''}` : 'US';

  return (
    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
    >
      {/* Header Banner */}
      <View style={styles.headerBanner} />

      {/* Profile Header Content */}
      <View style={styles.headerContent}>
        <View style={styles.avatarWrapper}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>{initials}</Text>
          </View>
          {/* <TouchableOpacity style={styles.cameraButton}>
            <Camera size={14} color="#fff" />
          </TouchableOpacity> */}
        </View>

        <TouchableOpacity
          style={styles.editProfileBtn}
          onPress={() => router.push('/edit-profile')}
        >
          <Edit3 size={16} color="#64748b" />
          <Text style={styles.editProfileText}>Edit Profile</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.userInfo}>
        <Text style={styles.userName}>{profile?.firstName} {profile?.lastName}</Text>
        <Text style={styles.userEmail}>{profile?.email}</Text>
      </View>

      <View style={styles.mainContent}>
        {/* Personal Information */}
        <SectionHeader icon={<User size={18} color="#0ea5e9" />} title="Personal Information" />
        <View style={styles.card}>
          <Text style={styles.cardSubtext}>Data you provided at registration. You can edit and save anytime.</Text>

          <View style={styles.fieldRow}>
            <ReadOnlyField label="First Name" value={profile?.firstName} flex={1} />
            <View style={{ width: 12 }} />
            <ReadOnlyField label="Last Name" value={profile?.lastName} flex={1} />
          </View>

          <ReadOnlyField label="Email Address" value={profile?.email} />
          <ReadOnlyField label="Phone Number" value={profile?.phone || 'Not provided'} />
          <ReadOnlyField label="Date of Birth" value={profile?.dateOfBirth ? new Date(profile.dateOfBirth).toLocaleDateString() : 'Not set'} />
        </View>
        {/* Family Members */}
        {familyMembers.length > 0 && (
          <>
            <SectionHeader icon={<Users size={18} color="#0ea5e9" />} title="Family Members" />
            <View style={styles.card}>
              <Text style={styles.cardSubtext}>Family members covered under your active plan.</Text>
              {familyMembers.map((member, index) => (
                <View key={member.id} style={{ marginBottom: index === familyMembers.length - 1 ? 0 : 16 }}>
                  <ReadOnlyField
                    label={`${member.relationship || 'Family Member'}`}
                    value={`${member.firstName} ${member.lastName}`}
                  />
                </View>
              ))}
            </View>
          </>
        )}

        {/* Address Details */}
        <SectionHeader icon={<MapPin size={18} color="#0ea5e9" />} title="Address Details" />
        <View style={styles.card}>
          <ReadOnlyField label="Street Address" value={profile?.streetAddress || 'Not set'} />
          <ReadOnlyField label="City" value={profile?.city || 'Not set'} />

          <View style={styles.fieldRow}>
            <ReadOnlyField label="State" value={profile?.state || 'Not set'} flex={1} />
            <View style={{ width: 12 }} />
            <ReadOnlyField label="ZIP Code" value={profile?.zipCode || 'Not set'} flex={1} />
          </View>

          <ReadOnlyField label="Country" value={profile?.country || 'Not set'} />
        </View>

        {/* Health Summary */}
        {/* <SectionHeader icon={<Activity size={18} color="#0ea5e9" />} title="Health Summary" />
        <View style={styles.statsRow}>
          <StatCard count={appointments.length} label="Total Visits" color="#f0f9ff" textColor="#0ea5e9" />
          <StatCard count={appointments.filter(a => a.status === 'COMPLETED').length} label="Completed" color="#f0fdf4" textColor="#22c55e" />
          <StatCard count={0} label="Prescriptions" color="#f5f3ff" textColor="#8b5cf6" />
          <StatCard count={calculateDaysLeft()} label="Days Left" color="#fffbeb" textColor="#f59e0b" />
        </View> */}

        {/* Emergency Contact */}
        <SectionHeader icon={<Phone size={18} color="#ef4444" />} title="Emergency Contact" />
        <View style={styles.card}>
          <View style={styles.fieldRow}>
            <ReadOnlyField label="Contact Name" value={profile?.emergencyContactName || 'Not set'} flex={1} />
            <View style={{ width: 12 }} />
            <ReadOnlyField label="Contact Phone" value={profile?.emergencyContactPhone || 'Not set'} flex={1} />
          </View>

          <View style={styles.fieldRow}>
            <ReadOnlyField label="Relationship" value={profile?.emergencyContactRelationship || 'Not set'} flex={1} />
            <View style={{ width: 12 }} />
            <ReadOnlyField label="Blood Type" value={profile?.bloodType || 'Not set'} flex={1} />
          </View>
        </View>



        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
          <LogOut size={20} color="#ef4444" />
          <Text style={styles.logoutText}>Log Out</Text>
        </TouchableOpacity>

        <Text style={styles.versionText}>Version 1.0.0</Text>
      </View>
    </ScrollView>
  );
}

function SectionHeader({ icon, title }: { icon: React.ReactNode, title: string }) {
  return (
    <View style={styles.sectionHeader}>
      {icon}
      <Text style={styles.sectionTitle}>{title}</Text>
    </View>
  );
}

function ReadOnlyField({ label, value, flex }: { label: string, value: string, flex?: number }) {
  return (
    <View style={[styles.fieldContainer, flex ? { flex } : {}]}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <View style={styles.fieldBox}>
        <Text style={styles.fieldValue} numberOfLines={1}>{value}</Text>
      </View>
    </View>
  );
}

function StatCard({ count, label, color, textColor }: { count: number, label: string, color: string, textColor: string }) {
  return (
    <View style={[styles.statCard, { backgroundColor: color }]}>
      <Text style={[styles.statCount, { color: textColor }]}>{count}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerBanner: {
    height: 100,
    backgroundColor: '#0c2d88',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    paddingHorizontal: 20,
    marginTop: -30,
  },
  avatarWrapper: {
    position: 'relative',
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#0ea5e9',
    borderWidth: 4,
    borderColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    color: '#fff',
    fontSize: 28,
    fontWeight: 'bold',
  },
  cameraButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: '#64748b',
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#fff',
  },
  editProfileBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fafafa',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#12329ee1',
    marginBottom: 8,

    gap: 6,
  },
  editProfileText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#64748b',
  },
  userInfo: {
    paddingHorizontal: 20,
    marginTop: 12,
    marginBottom: 20,
  },
  userName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  userEmail: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 2,
  },
  mainContent: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    marginTop: 8,
    gap: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e3a8a',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  cardSubtext: {
    fontSize: 12,
    color: '#64748b',
    marginBottom: 16,
  },
  fieldContainer: {
    marginBottom: 12,
  },
  fieldLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: '#1e3a8a',
    marginBottom: 6,
  },
  fieldBox: {
    backgroundColor: '#f1f5f9',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  fieldValue: {
    fontSize: 14,
    color: '#334155',
  },
  fieldRow: {
    flexDirection: 'row',
  },
  statsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 24,
    gap: 12,
  },
  statCard: {
    width: '48%',
    paddingVertical: 16,
    paddingHorizontal: 8,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  statCount: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#64748b',
    textAlign: 'center',
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
    paddingVertical: 14,
    borderRadius: 12,
    marginTop: 12,
    gap: 8,
    borderWidth: 1,
    borderColor: '#fee2e2',
  },
  logoutText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ef4444',
  },
  versionText: {
    textAlign: 'center',
    fontSize: 12,
    color: '#94a3b8',
    marginTop: 20,
  },
});
