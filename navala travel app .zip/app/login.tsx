import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Image,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Lock, Mail, ArrowRight, Eye, EyeOff } from 'lucide-react-native';
import { AuthApi } from '../src/api/features/auth';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const isValid = email.trim().length > 0 && password.trim().length >= 6;

  const handleLogin = async () => {
    if (!isValid) {
      Alert.alert('Error', 'Please enter a valid email and a password with at least 6 characters.');
      return;
    }

    try {
      setLoading(true);
      const response = await AuthApi.login({ email, password });

      if (response && response.success) {
        // Check if user already has an active plan
        try {
          const { UserApi } = require('../src/api/features/user');
          const planRes = await UserApi.getActivePlan();
          if (planRes && planRes.success && planRes.data) {
            router.replace('/(tabs)');
          } else {
            router.replace('/plans');
          }
        } catch (e) {
          // If check fails, default to plans screen
          router.replace('/plans');
        }
      } else {
        Alert.alert('Login Failed', response?.message || 'Invalid credentials');
      }
    } catch (error: any) {
      console.error(error);
      Alert.alert('Login Failed', error.message || 'An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  const goToSignup = () => {
    router.push('/signup');
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <LinearGradient colors={['#2563eb', '#1d4ed8']} style={styles.header}>
        <View style={styles.headerRow}>
          <View style={styles.headerLogoWrapper}>
            <Image
              source={require('../assets/images/icon.png')}
              style={styles.headerLogo}
            />
          </View>
          <View style={styles.headerTextWrapper}>
            <Text style={styles.appTitle}>Navala Travel Health</Text>
            <Text style={styles.appSubtitle}>
              Sign in to manage your trips, health records, and plans.
            </Text>
          </View>
        </View>
      </LinearGradient>

      <View style={styles.content}>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Welcome back</Text>
          <Text style={styles.cardSubtitle}>
            Login to continue to your appointments and subscriptions.
          </Text>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Email</Text>
            <View style={styles.inputWrapper}>
              <Mail size={18} color="#6b7280" />
              <TextInput
                style={styles.input}
                placeholder="you@example.com"
                placeholderTextColor="#9ca3af"
                keyboardType="email-address"
                autoCapitalize="none"
                value={email}
                onChangeText={setEmail}
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <View style={styles.labelRow}>
              <Text style={styles.inputLabel}>Password</Text>
              <TouchableOpacity onPress={() => router.push('/forgot-password')}>
                <Text style={styles.forgotLink}>Forgot Password?</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.inputWrapper}>
              <Lock size={18} color="#6b7280" />
              <TextInput
                style={styles.input}
                placeholder="••••••••"
                placeholderTextColor="#9ca3af"
                secureTextEntry={!showPassword}
                value={password}
                onChangeText={setPassword}
              />
              <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={{ padding: 8 }}>
                {showPassword ? <EyeOff size={18} color="#6b7280" /> : <Eye size={18} color="#6b7280" />}
              </TouchableOpacity>
            </View>
          </View>

          <TouchableOpacity
            style={[
              styles.loginButton,
              (!isValid || loading) && styles.loginButtonDisabled,
            ]}
            disabled={!isValid || loading}
            onPress={handleLogin}>
            <Text style={styles.loginButtonText}>{loading ? 'Signing in...' : 'Sign In'}</Text>
            {!loading && <ArrowRight size={18} color="#ffffff" />}
          </TouchableOpacity>

          <TouchableOpacity style={styles.switchRow} onPress={goToSignup}>
            <Text style={styles.switchText}>Don’t have an account?</Text>
            <Text style={styles.switchLink}>Sign up</Text>
          </TouchableOpacity>

          <Text style={styles.helperText}>
            Demo login only. When you connect real authentication, validate
            the email and password here before entering the app.
          </Text>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  header: {
    paddingTop: 80,
    paddingBottom: 32,
    paddingHorizontal: 24,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerLogoWrapper: {
    width: 120,
    height: 80,
    backgroundColor: '#ffffff',
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 18,
  },
  headerLogo: {
    width: '88%',
    height: '88%',
    resizeMode: 'contain',
  },
  headerTextWrapper: {
    flex: 1,
  },
  appTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#ffffff',
    marginBottom: 8,
  },
  appSubtitle: {
    fontSize: 15,
    color: '#e0e7ff',
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  card: {
    backgroundColor: '#ffffffff',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 10,
    elevation: 3,
  },
  cardTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#111827',
    marginTop: 8,
    marginBottom: 8,
  },
  cardSubtitle: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 20,
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 13,
    fontWeight: '500',
    color: '#4b5563',
    marginBottom: 6,
  },
  labelRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  forgotLink: {
    fontSize: 12,
    fontWeight: '600',
    color: '#2563eb',
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f9fafb',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e5e7eb',
    paddingHorizontal: 12,
  },
  input: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 8,
    fontSize: 14,
    color: '#111827',
  },
  loginButton: {
    marginTop: 8,
    backgroundColor: '#2563eb',
    paddingVertical: 14,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  loginButtonDisabled: {
    backgroundColor: '#9ca3af',
  },
  loginButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 16,
    gap: 4,
  },
  switchText: {
    fontSize: 13,
    color: '#6b7280',
  },
  switchLink: {
    fontSize: 13,
    fontWeight: '600',
    color: '#2563eb',
  },
  helperText: {
    marginTop: 12,
    fontSize: 12,
    color: '#9ca3af',
    textAlign: 'center',
  },
});
