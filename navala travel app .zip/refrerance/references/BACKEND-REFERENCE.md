# Backend Reference – Patient Mobile API

This document points to the **source code** of the backend that implements the Patient Mobile API. Use it when debugging or when you need to align request/response with the server.

---

## Repository layout

The backend lives in the parent folder:

```
Navala Travel app/
├── backend/                    # Main backend (Express + Sequelize)
│   ├── server.js
│   ├── src/
│   │   ├── app.js              # Route mounting, CORS, middleware
│   │   ├── config/
│   │   ├── controllers/
│   │   ├── middlewares/
│   │   ├── models/
│   │   ├── routes/
│   │   └── services/
│   └── .env
└── patient-mobile-api/         # This folder (docs + config only)
```

---

## Patient-related backend files

| Purpose | Path |
|--------|------|
| Auth (login, register, refresh) | `backend/src/routes/auth.routes.js` |
| Auth logic | `backend/src/services/auth.service.js` |
| Auth controller | `backend/src/controllers/auth.controller.js` |
| Appointments (request, my-requests) | `backend/src/routes/appointment.routes.js` |
| Appointment logic | `backend/src/services/appointment.service.js` |
| Appointment controller | `backend/src/controllers/appointment.controller.js` |
| Payments (create-intent, user/plan, my) | `backend/src/routes/payment.routes.js` |
| Payment logic | `backend/src/services/payment.service.js` |
| Payment controller | `backend/src/controllers/payment.controller.js` |
| Public plans (GET /plans) | Handled in `backend/src/app.js` (getActivePlansController from plan.controller.js) |
| JWT (tokens, verify) | `backend/src/config/jwt.js` |
| Auth middleware (Bearer) | `backend/src/middlewares/auth.middleware.js` |
| Role (patientOnly) | `backend/src/middlewares/role.middleware.js` |

---

## How routes are mounted (app.js)

- `GET /health` – app root
- `GET /plans` – app root (public active plans)
- Payment routes mounted at **root** and at **API_PREFIX**:
  - `POST /payments/create-intent`, `GET /user/plan`, `GET /payments/my`
  - `POST /api/payments/create-intent`, `GET /api/user/plan`, `GET /api/payments/my`
- `API_PREFIX` = `/api` (default from env):
  - `/api/auth/*` – auth routes
  - `/api/appointments/*` – patient appointment routes
  - `/api/user/plan`, `/api/payments/*` – payment routes

So the **patient mobile app** can use either:

- Base URL = `http://localhost:3001` and paths like `/api/auth/login`, `/api/user/plan`, `/plans`, etc., or  
- Same with a production host instead of localhost.

---

## Environment (backend)

Backend reads from `backend/.env`. Relevant for mobile:

- `PORT` – server port (default 3001)
- `API_PREFIX` – default `/api`
- `BASE_URL` – used in emails/links
- `JWT_SECRET`, `JWT_REFRESH_SECRET` – token signing
- `STRIPE_*` – payment (create-intent returns Stripe client secret)

The **mobile app** does not need these; it only needs the **base URL** (and optionally Stripe publishable key for the payment UI). See `patient-mobile-api/config/env.example`.

---

## Running the backend

From the project root:

```bash
cd backend
npm install
# Set .env (copy from .env.example if present)
node server.js
# or: npm start
```

Then use `http://localhost:3001` (or your `PORT`) as `BASE_URL` in the mobile app and in the cURL examples.
