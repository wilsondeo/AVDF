# cURL Examples – Patient Mobile API

Replace `BASE_URL` with your backend base (e.g. `http://localhost:3001`) and `ACCESS_TOKEN` with a valid JWT after login.

---

## Health

```bash
curl -s -X GET "${BASE_URL}/health"
```

---

## Auth

### Register

```bash
curl -s -X POST "${BASE_URL}/api/auth/register" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "patient@example.com",
    "password": "SecurePass8",
    "firstName": "John",
    "lastName": "Doe"
  }'
```

### Login

```bash
curl -s -X POST "${BASE_URL}/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "patient@example.com",
    "password": "SecurePass8"
  }'
```

### Refresh token

```bash
curl -s -X POST "${BASE_URL}/api/auth/refresh" \
  -H "Content-Type: application/json" \
  -d '{"refreshToken": "YOUR_REFRESH_TOKEN"}'
```

---

## Plans (no auth)

### Get active plans

```bash
curl -s -X GET "${BASE_URL}/plans"
```

---

## User plan (auth required)

### Get my active plan

```bash
curl -s -X GET "${BASE_URL}/api/user/plan" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}"
```

---

## Payments (auth required)

### Create payment intent

```bash
curl -s -X POST "${BASE_URL}/api/payments/create-intent" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -d '{"planId": "plan_basic_001"}'
```

### Get my payments

```bash
curl -s -X GET "${BASE_URL}/api/payments/my?limit=10&offset=0" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}"
```

---

## Appointments (auth required)

### Create appointment request

```bash
curl -s -X POST "${BASE_URL}/api/appointments/request" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -d '{
    "city": "New York",
    "age": 35,
    "gender": "male",
    "emergencyContact": "+1234567890",
    "serviceType": "TELEHEALTH",
    "notes": "First consultation"
  }'
```

### Get my appointment requests

```bash
curl -s -X GET "${BASE_URL}/api/appointments/my-requests" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}"
```

---

## One-liner: login and save token (Unix)

```bash
# Save access token to ACCESS_TOKEN
ACCESS_TOKEN=$(curl -s -X POST "${BASE_URL}/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email":"patient@example.com","password":"SecurePass8"}' \
  | jq -r '.data.accessToken')
echo "Token: $ACCESS_TOKEN"
```

Then use in a protected call:

```bash
curl -s -X GET "${BASE_URL}/api/user/plan" -H "Authorization: Bearer $ACCESS_TOKEN"
```
