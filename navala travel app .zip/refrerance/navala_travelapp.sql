-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 13, 2026 at 10:32 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `navala_travelapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `appointment_uuid` varchar(36) NOT NULL COMMENT 'Public identifier for the appointment',
  `request_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `service_type` enum('TELEHEALTH','EMERGENCY') NOT NULL,
  `appointment_date` datetime DEFAULT NULL,
  `status` enum('SCHEDULED','COMPLETED','CANCELLED') NOT NULL DEFAULT 'SCHEDULED',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `appointment_uuid`, `request_id`, `patient_id`, `doctor_id`, `service_type`, `appointment_date`, `status`, `created_at`, `updated_at`) VALUES
(1, '61b7359c-fa5e-45e0-9f7e-d94d2bdb9ffd', 1, 4, 2, 'TELEHEALTH', NULL, 'SCHEDULED', '2026-02-11 11:23:13', '2026-02-11 11:23:13');

-- --------------------------------------------------------

--
-- Table structure for table `appointment_requests`
--

CREATE TABLE `appointment_requests` (
  `id` int(11) NOT NULL,
  `request_uuid` varchar(36) NOT NULL COMMENT 'Public identifier for the appointment request',
  `patient_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL COMMENT 'FK to plans.id for the active plan at the time of request',
  `city` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `emergency_contact` varchar(50) NOT NULL,
  `service_type` enum('TELEHEALTH','EMERGENCY') NOT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('PENDING','ASSIGNED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `allergies` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment_requests`
--

INSERT INTO `appointment_requests` (`id`, `request_uuid`, `patient_id`, `plan_id`, `city`, `age`, `gender`, `emergency_contact`, `service_type`, `notes`, `status`, `created_at`, `updated_at`, `allergies`) VALUES
(1, 'bee13572-34b1-4024-a509-4a3af24aff0a', 4, 3, 'Paris', 41, 'Female', '4541348874', 'TELEHEALTH', NULL, 'ASSIGNED', '2026-02-11 11:10:46', '2026-02-11 11:23:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `doctor_uuid` varchar(36) NOT NULL COMMENT 'Unique public identifier for doctor profile',
  `user_id` int(11) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `specialization` varchar(100) NOT NULL,
  `years_of_experience` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `plain_password` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `doctor_uuid`, `user_id`, `phone`, `city`, `specialization`, `years_of_experience`, `created_at`, `updated_at`, `plain_password`) VALUES
(2, 'd4869514-2c00-4bf9-8054-577986294ffb', 11, '6371936832', 'New York', 'Cardiology', 2, '2026-02-10 10:00:03', '2026-02-10 10:00:03', '&QDfAW%5r#a^'),
(3, 'c8cde3a2-121e-44dc-9515-52ab205390eb', 13, '7412589630', 'Los Angeles', 'Pediatrics', 2, '2026-02-10 10:29:48', '2026-02-10 10:29:48', '$N42*XX0SEya'),
(4, 'e4a5b2cb-f549-414d-b458-dfa6365a409e', 14, '7410258963', 'Philadelphia', 'Emergency Medicine', 5, '2026-02-10 11:10:39', '2026-02-10 11:10:39', '9cXu9%1sZ'),
(5, '70ee6632-5829-4137-a266-8289fb4f3b0d', 15, '8521479630', 'Chicago', 'General Medicine', 3, '2026-02-11 10:55:50', '2026-02-11 10:55:50', 'xM@@bBK6%');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `stripe_payment_intent_id` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL,
  `currency` varchar(10) NOT NULL,
  `status` enum('PENDING','SUCCESS','FAILED') NOT NULL DEFAULT 'PENDING',
  `type` enum('PURCHASE','UPGRADE') NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `user_id`, `plan_id`, `stripe_payment_intent_id`, `amount`, `currency`, `status`, `type`, `created_at`) VALUES
(1, 2, 2, 'pi_3Sxl6eQUhXNFe23p0xAK31O2', 8999, 'usd', 'SUCCESS', 'PURCHASE', '2026-02-06 09:13:40'),
(2, 4, 2, 'pi_3SxlRHQUhXNFe23p5MxPaoZ5', 8999, 'usd', 'PENDING', 'PURCHASE', '2026-02-06 09:34:59'),
(3, 4, 2, 'pi_3SxlRSQUhXNFe23p45EToloY', 8999, 'usd', 'PENDING', 'PURCHASE', '2026-02-06 09:35:10'),
(4, 4, 5, 'pi_3SxobCQUhXNFe23p2kJeCfuY', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-06 12:57:26'),
(5, 4, 5, 'pi_3Sy46tQUhXNFe23p3Xev6nRd', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 05:31:11'),
(6, 4, 5, 'pi_3Sy4AMQUhXNFe23p2E8fjGks', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 05:34:45'),
(7, 4, 5, 'pi_3Sy4BIQUhXNFe23p42HloCQv', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 05:35:43'),
(8, 4, 5, 'pi_3Sy4FIQUhXNFe23p57aeTAah', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 05:39:51'),
(9, 4, 5, 'pi_3Sy4FqQUhXNFe23p5QFzEgoi', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 05:40:25'),
(10, 1, 5, 'pi_3Sy4HcQUhXNFe23p5DHD5bpA', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 05:42:15'),
(11, 1, 5, 'pi_3Sy4KFQUhXNFe23p2sVppUbb', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 05:44:59'),
(12, 1, 5, 'pi_3Sy4KMQUhXNFe23p5psC1fPD', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 05:45:06'),
(13, 1, 5, 'pi_3Sy4TxQUhXNFe23p54HqsyKM', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 05:55:00'),
(14, 4, 3, 'pi_3Sy4gsHwSW4gSqwx0TArZIz1', 13000, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 06:08:22'),
(15, 4, 5, 'pi_3Sy4lPHwSW4gSqwx03OAFzE7', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 06:13:02'),
(16, 4, 5, 'pi_3Sy4nFHwSW4gSqwx1l0Brmsp', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 06:14:56'),
(17, 4, 5, 'pi_3Sy4nuHwSW4gSqwx0wCDpJAZ', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 06:15:38'),
(18, 4, 5, 'pi_3Sy5ACHwSW4gSqwx16EhgRKt', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 06:38:39'),
(19, 4, 3, 'pi_3Sy5BlHwSW4gSqwx0uuBKG4Y', 13000, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 06:40:17'),
(20, 4, 4, 'pi_3Sy5EKHwSW4gSqwx06Ebp0Am', 15000, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 06:42:56'),
(21, 4, 4, 'pi_3Sy5uhHwSW4gSqwx0DW4Ry8y', 15000, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 07:26:42'),
(22, 4, 4, 'pi_3Sy5vDHwSW4gSqwx0p2R424M', 15000, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 07:27:14'),
(23, 4, 5, 'pi_3Sy5wZHwSW4gSqwx0uyjmsQC', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 07:28:39'),
(24, 4, 5, 'pi_3Sy5x2HwSW4gSqwx1WYXTvpd', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 07:29:07'),
(25, 4, 3, 'pi_3Sy7keHwSW4gSqwx04nDdVXt', 13000, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 09:24:28'),
(26, 4, 3, 'pi_3Sy7l9HwSW4gSqwx0ULlClKh', 13000, 'usd', 'FAILED', 'PURCHASE', '2026-02-07 09:24:59'),
(27, 4, 3, 'pi_3Sy7oiHwSW4gSqwx0qLbTLhd', 13000, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 09:28:39'),
(28, 4, 5, 'pi_3Sy8VBHwSW4gSqwx1oZibubj', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-07 10:12:33'),
(29, 4, 3, 'pi_3SyA1uHwSW4gSqwx00YbYIFc', 13000, 'usd', 'SUCCESS', 'PURCHASE', '2026-02-07 11:50:26'),
(30, 4, 4, 'pi_3SynEIHwSW4gSqwx0qPRsLx6', 15000, 'usd', 'PENDING', 'UPGRADE', '2026-02-09 05:41:50'),
(31, 4, 5, 'pi_3SynENHwSW4gSqwx1dbx5oga', 17500, 'usd', 'PENDING', 'UPGRADE', '2026-02-09 05:41:55'),
(32, 7, 5, 'pi_3SzAs5QUhXNFe23p31RDQp62', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-10 06:56:30'),
(33, 7, 5, 'pi_3SzAxwQUhXNFe23p4XJHqsme', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-10 07:02:32'),
(34, 7, 5, 'pi_3SzAylQUhXNFe23p5KV022Gy', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-10 07:03:24'),
(35, 7, 5, 'pi_3SzAz5QUhXNFe23p2jdaBfcW', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-10 07:03:44'),
(36, 7, 4, 'pi_3SzB5YQUhXNFe23p5A7asu8Q', 15000, 'usd', 'PENDING', 'PURCHASE', '2026-02-10 07:10:24'),
(37, 7, 4, 'pi_3SzB79QUhXNFe23p4QBkc1QW', 15000, 'usd', 'PENDING', 'PURCHASE', '2026-02-10 07:12:03'),
(38, 7, 5, 'pi_3SzB9CQUhXNFe23p2NPZ6R3o', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-10 07:14:10'),
(39, 7, 5, 'pi_3SzCTiQUhXNFe23p49sE4xU0', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-10 08:39:27'),
(40, 7, 4, 'pi_3SzCVmQUhXNFe23p5q7jlVWp', 15000, 'usd', 'PENDING', 'PURCHASE', '2026-02-10 08:41:35'),
(41, 7, 4, 'pi_3SzCdOQUhXNFe23p3wIXIDYi', 15000, 'usd', 'PENDING', 'PURCHASE', '2026-02-10 08:49:27'),
(42, 7, 4, 'pi_3SzCosQUhXNFe23p4ACSVKTR', 15000, 'usd', 'PENDING', 'PURCHASE', '2026-02-10 09:01:19'),
(43, 7, 5, 'pi_3SzD47QUhXNFe23p1CUhHScP', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-10 09:17:04'),
(44, 7, 5, 'pi_3SzDBYQUhXNFe23p2IZMaOn2', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-10 09:24:45'),
(45, 7, 4, 'pi_3SzDC5QUhXNFe23p3NXLmavw', 15000, 'usd', 'PENDING', 'PURCHASE', '2026-02-10 09:25:17'),
(46, 7, 5, 'pi_3SzDTIHwSW4gSqwx1Kpbb91H', 17500, 'usd', 'PENDING', 'PURCHASE', '2026-02-10 09:43:04'),
(47, 7, 5, 'pi_3SzDUHHwSW4gSqwx1eSGJ9uy', 17500, 'usd', 'SUCCESS', 'PURCHASE', '2026-02-10 09:44:05'),
(48, 7, 4, 'pi_3SzEveHwSW4gSqwx1gyRqxjw', 15000, 'usd', 'PENDING', 'UPGRADE', '2026-02-10 11:16:26');

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

CREATE TABLE `plans` (
  `id` int(11) NOT NULL,
  `planId` varchar(50) NOT NULL COMMENT 'Unique business identifier for the plan',
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `validityDays` int(11) NOT NULL COMMENT 'Number of days the plan is valid',
  `description` text DEFAULT NULL,
  `services` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'Array of service types: TELEHEALTH, EMERGENCY' CHECK (json_valid(`services`)),
  `features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'Array of feature strings' CHECK (json_valid(`features`)),
  `isActive` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Soft delete support',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `plans`
--

INSERT INTO `plans` (`id`, `planId`, `name`, `price`, `validityDays`, `description`, `services`, `features`, `isActive`, `createdAt`, `updatedAt`) VALUES
(2, 'PLAN-1770288701833-WOGMY5', 'Travel Premium', 89.99, 90, 'Premium plan for frequent travelers', '[\"TELEHEALTH\"]', '[\"24/7 Telehealth consultations\",\"Emergency services\",\"Digital prescriptions\",\"Priority booking\"]', 0, '2026-02-05 10:51:41', '2026-02-07 05:30:34'),
(3, 'PLAN-1770373175906-5NN9ZS', 'Basic Health Plan - Silver', 130.00, 30, 'Basic health coverage with telehealth support and limited prescription benefits.', '[\"TELEHEALTH\"]', '[\"3 Telehealth visits\",\"Prescription coverage up to $250\",\"Specialty care coordination (out of pocket)\"]', 1, '2026-02-06 10:19:35', '2026-02-06 10:19:35'),
(4, 'PLAN-1770373191941-X9CR1D', 'Premium Health Plan - Gold', 150.00, 30, 'Enhanced health plan with telehealth, in-person consultations, and higher prescription coverage.', '[\"TELEHEALTH\"]', '[\"3 Telehealth visits\",\"2 In-person consultations\",\"Prescription coverage up to $400\",\"Specialty care coordination\"]', 1, '2026-02-06 10:19:51', '2026-02-06 10:19:51'),
(5, 'PLAN-1770373201956-6VEMMQ', 'Premium Plus Plan - Diamond', 175.00, 30, 'Comprehensive health coverage including telehealth, in-person care, and emergency ambulance services.', '[\"TELEHEALTH\",\"EMERGENCY\"]', '[\"3 Telehealth visits\",\"2 In-person consultations\",\"Prescription coverage up to $400\",\"Emergency ambulance ride to hospital\",\"Priority assistance\"]', 1, '2026-02-06 10:20:01', '2026-02-06 10:20:01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `role` enum('ADMIN','DOCTOR','PATIENT') NOT NULL DEFAULT 'PATIENT',
  `isActive` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `user_uuid` varchar(36) DEFAULT NULL COMMENT 'Public/user-facing UUID (do not expose auto-increment id in UI)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `firstName`, `lastName`, `role`, `isActive`, `createdAt`, `updatedAt`, `user_uuid`) VALUES
(1, 'admin@navala.com', '$2b$10$sfz30XBLNt5X.qoZFwC2ceaHr70dA8SqoRVKDKR.tI9aTCYGOLNwW', 'Admin', 'User', 'ADMIN', 1, '2026-02-04 10:26:26', '2026-02-04 10:26:26', 'd1b662d1-033d-11f1-8ee1-047c164e131e'),
(2, 'patient@example.com', '$2b$10$ZSC5DtB8O0Obo3W8GNcUpuT9t1XcOoHnCD2wdTemTPTFX9LdFj/aq', 'John', 'Doe', 'PATIENT', 1, '2026-02-04 11:17:44', '2026-02-04 11:17:44', 'd1b6648b-033d-11f1-8ee1-047c164e131e'),
(4, 'bhagyasreesendh@gmail.com', '$2b$10$bwipOPJEG/3VK/TRyilFgu4ZM/ac.UrinChUeY2IKWHhkDzjndlsW', 'Bhagyasree', 'Sendh', 'PATIENT', 1, '2026-02-04 13:32:11', '2026-02-04 13:32:11', 'd1b6662e-033d-11f1-8ee1-047c164e131e'),
(5, 'dr.test.1770623429725@example.com', '$2b$10$qBssKo4J0PhdbaeBH8eRpu5zmLjH.rnPcJVDz7OU2mG5Jc1Yel./q', 'Test', 'Verification', 'DOCTOR', 1, '2026-02-09 07:50:29', '2026-02-09 07:50:29', '97f675d1-3763-4ade-8f1b-67a625ce00aa'),
(6, 'bhagyasree.sendh@hexalearn.co.in', '$2b$10$hAgZ8QXl1FYjxkgXBNWUqu9Rh2jTdFxPd1ysA0sE0ADl0FESZuE6O', 'Dr.Bhagyasree', 'sendh', 'DOCTOR', 1, '2026-02-10 05:41:28', '2026-02-10 05:41:28', '48c494e3-a56f-40fe-95f2-0674a97349bc'),
(7, 'anup.jena2025@gmail.com', '$2b$10$Bh6ZJWEaqd1Gm7ay8OwTPOH9y.cPpKOg.ZNLlLWEF6gc64vL9S5v6', 'anup', 'jena', 'PATIENT', 1, '2026-02-10 06:56:14', '2026-02-10 06:56:14', 'e89b5027-a2c6-419c-858b-700cc3cba824'),
(11, 'sbhagyasree09@gmail.com', '$2b$10$28QaluwO.Orw3.sdVZyKzehY7ONM/nlG5DV2QbBT2FxkZGpJBR3kK', 'Bhagyasree', 'sendh', 'DOCTOR', 1, '2026-02-10 10:00:03', '2026-02-10 10:00:03', '614039ab-75a6-4b03-a24c-7a961644777b'),
(13, 'arup.panda@hexalearn.com', '$2b$10$udlSPG/oYQk1A9QPG5jxF.C0OAgz5XBBglcr//wSCpevBdPBO0Tq2', 'Arup', 'panda', 'DOCTOR', 1, '2026-02-10 10:29:48', '2026-02-10 10:29:48', 'f1d3d22e-3c3b-4d05-bdaf-41e8df17e92b'),
(14, 'anup.jena@hexalearn.co.in', '$2b$10$f0hinrGxqNk9/O5rzXv8VOvQyi8hhuJl4AiBQKvK/F/AHiz3hUMHS', 'Dr.Anup', 'Jena', 'DOCTOR', 1, '2026-02-10 11:10:39', '2026-02-10 11:12:13', '949699ae-be88-4fa5-85b3-04c1e0f6aa6b'),
(15, 'sagarika.pradhan@hexalearn.co.in', '$2b$10$OswT0rhxuHdlBxoeeLkUwOr/7dz6ljXd0TB9maekO.G60vcNT3Wzy', 'Sagarika', 'Pradhan', 'DOCTOR', 1, '2026-02-11 10:55:50', '2026-02-11 10:55:50', '98a18cdb-032d-47a0-a820-3fb08f62f84c');

-- --------------------------------------------------------

--
-- Table structure for table `user_plans`
--

CREATE TABLE `user_plans` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `status` enum('ACTIVE','EXPIRED') NOT NULL DEFAULT 'ACTIVE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_plans`
--

INSERT INTO `user_plans` (`id`, `user_id`, `plan_id`, `start_date`, `end_date`, `status`) VALUES
(1, 4, 3, '2026-02-07 11:50:42', '2026-03-09 11:50:42', 'ACTIVE'),
(2, 7, 5, '2026-02-10 09:45:13', '2026-03-12 09:45:13', 'ACTIVE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `appointment_uuid` (`appointment_uuid`),
  ADD UNIQUE KEY `appointments_appointment_uuid` (`appointment_uuid`),
  ADD KEY `appointments_request_id` (`request_id`),
  ADD KEY `appointments_patient_id` (`patient_id`),
  ADD KEY `appointments_doctor_id` (`doctor_id`),
  ADD KEY `appointments_status` (`status`);

--
-- Indexes for table `appointment_requests`
--
ALTER TABLE `appointment_requests`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `request_uuid` (`request_uuid`),
  ADD UNIQUE KEY `appointment_requests_request_uuid` (`request_uuid`),
  ADD KEY `appointment_requests_patient_id` (`patient_id`),
  ADD KEY `appointment_requests_plan_id` (`plan_id`),
  ADD KEY `appointment_requests_status` (`status`),
  ADD KEY `appointment_requests_service_type` (`service_type`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `doctor_uuid` (`doctor_uuid`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `doctors_doctor_uuid` (`doctor_uuid`),
  ADD UNIQUE KEY `doctors_user_id` (`user_id`),
  ADD KEY `doctors_specialization` (`specialization`),
  ADD KEY `doctors_city` (`city`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `payments_stripe_payment_intent_id` (`stripe_payment_intent_id`),
  ADD KEY `payments_user_id` (`user_id`),
  ADD KEY `payments_plan_id` (`plan_id`),
  ADD KEY `payments_status` (`status`),
  ADD KEY `payments_type` (`type`),
  ADD KEY `payments_created_at` (`created_at`);

--
-- Indexes for table `plans`
--
ALTER TABLE `plans`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `planId` (`planId`),
  ADD UNIQUE KEY `plans_plan_id` (`planId`),
  ADD UNIQUE KEY `planId_2` (`planId`),
  ADD UNIQUE KEY `planId_3` (`planId`),
  ADD UNIQUE KEY `planId_4` (`planId`),
  ADD UNIQUE KEY `planId_5` (`planId`),
  ADD UNIQUE KEY `planId_6` (`planId`),
  ADD UNIQUE KEY `planId_7` (`planId`),
  ADD UNIQUE KEY `planId_8` (`planId`),
  ADD UNIQUE KEY `planId_9` (`planId`),
  ADD UNIQUE KEY `planId_10` (`planId`),
  ADD UNIQUE KEY `planId_11` (`planId`),
  ADD UNIQUE KEY `planId_12` (`planId`),
  ADD UNIQUE KEY `planId_13` (`planId`),
  ADD UNIQUE KEY `planId_14` (`planId`),
  ADD UNIQUE KEY `planId_15` (`planId`),
  ADD UNIQUE KEY `planId_16` (`planId`),
  ADD UNIQUE KEY `planId_17` (`planId`),
  ADD UNIQUE KEY `planId_18` (`planId`),
  ADD UNIQUE KEY `planId_19` (`planId`),
  ADD UNIQUE KEY `planId_20` (`planId`),
  ADD UNIQUE KEY `planId_21` (`planId`),
  ADD UNIQUE KEY `planId_22` (`planId`),
  ADD UNIQUE KEY `planId_23` (`planId`),
  ADD UNIQUE KEY `planId_24` (`planId`),
  ADD UNIQUE KEY `planId_25` (`planId`),
  ADD UNIQUE KEY `planId_26` (`planId`),
  ADD UNIQUE KEY `planId_27` (`planId`),
  ADD UNIQUE KEY `planId_28` (`planId`),
  ADD UNIQUE KEY `planId_29` (`planId`),
  ADD UNIQUE KEY `planId_30` (`planId`),
  ADD KEY `plans_is_active` (`isActive`),
  ADD KEY `plans_name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `email_2` (`email`),
  ADD UNIQUE KEY `email_3` (`email`),
  ADD UNIQUE KEY `email_4` (`email`),
  ADD UNIQUE KEY `email_5` (`email`),
  ADD UNIQUE KEY `email_6` (`email`),
  ADD UNIQUE KEY `email_7` (`email`),
  ADD UNIQUE KEY `email_8` (`email`),
  ADD UNIQUE KEY `email_9` (`email`),
  ADD UNIQUE KEY `email_10` (`email`),
  ADD UNIQUE KEY `email_11` (`email`),
  ADD UNIQUE KEY `email_12` (`email`),
  ADD UNIQUE KEY `email_13` (`email`),
  ADD UNIQUE KEY `email_14` (`email`),
  ADD UNIQUE KEY `email_15` (`email`),
  ADD UNIQUE KEY `email_16` (`email`),
  ADD UNIQUE KEY `email_17` (`email`),
  ADD UNIQUE KEY `email_18` (`email`),
  ADD UNIQUE KEY `email_19` (`email`),
  ADD UNIQUE KEY `email_20` (`email`),
  ADD UNIQUE KEY `email_21` (`email`),
  ADD UNIQUE KEY `email_22` (`email`),
  ADD UNIQUE KEY `email_23` (`email`),
  ADD UNIQUE KEY `email_24` (`email`),
  ADD UNIQUE KEY `email_25` (`email`),
  ADD UNIQUE KEY `email_26` (`email`),
  ADD UNIQUE KEY `email_27` (`email`),
  ADD UNIQUE KEY `email_28` (`email`),
  ADD UNIQUE KEY `email_29` (`email`),
  ADD UNIQUE KEY `email_30` (`email`),
  ADD UNIQUE KEY `user_uuid` (`user_uuid`),
  ADD UNIQUE KEY `users_user_uuid` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_2` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_3` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_4` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_5` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_6` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_7` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_8` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_9` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_10` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_11` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_12` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_13` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_14` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_15` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_16` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_17` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_18` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_19` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_20` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_21` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_22` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_23` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_24` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_25` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_26` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_27` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_28` (`user_uuid`),
  ADD UNIQUE KEY `user_uuid_29` (`user_uuid`),
  ADD KEY `users_email` (`email`),
  ADD KEY `users_role` (`role`),
  ADD KEY `users_is_active` (`isActive`);

--
-- Indexes for table `user_plans`
--
ALTER TABLE `user_plans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_plans_user_id` (`user_id`),
  ADD KEY `user_plans_plan_id` (`plan_id`),
  ADD KEY `user_plans_status` (`status`),
  ADD KEY `user_plans_start_date` (`start_date`),
  ADD KEY `user_plans_end_date` (`end_date`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment_requests`
--
ALTER TABLE `appointment_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `plans`
--
ALTER TABLE `plans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `user_plans`
--
ALTER TABLE `user_plans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `appointment_requests` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `appointments_ibfk_3` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `appointment_requests`
--
ALTER TABLE `appointment_requests`
  ADD CONSTRAINT `appointment_requests_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `appointment_requests_ibfk_2` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `doctors`
--
ALTER TABLE `doctors`
  ADD CONSTRAINT `doctors_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `payments_ibfk_4` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `user_plans`
--
ALTER TABLE `user_plans`
  ADD CONSTRAINT `user_plans_ibfk_1` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
