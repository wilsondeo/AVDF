# Patient Mobile API

Complete API reference, configuration, and documentation for the **Patient Mobile Application** of the Navala Travel Healthcare Booking Platform.

This folder contains everything needed to integrate a mobile client (iOS, Android, React Native, Flutter, etc.) with the backend patient-facing APIs.

---

## Overview

| Item | Description |
|------|-------------|
| **Platform** | Travel Healthcare Booking |
| **Audience** | Patient mobile apps only (no admin/doctor endpoints) |
| **Auth** | JWT (Bearer token); refresh token supported |
| **Base URL** | See [config/env.example](./config/env.example) |

---

## Quick Start

1. **Set base URL**  
   Use `config/env.example` as a template. Default development base: `http://localhost:3001`

2. **Authentication**  
   - Register: `POST {BASE_URL}/api/auth/register`  
   - Login: `POST {BASE_URL}/api/auth/login`  
   - Use `accessToken` in header: `Authorization: Bearer <accessToken>`

3. **Protected endpoints**  
   All booking, plan, and payment endpoints require the `Authorization: Bearer <accessToken>` header.

4. **Refresh token**  
   When the access token expires (401), call `POST {BASE_URL}/api/auth/refresh` with `refreshToken` in the body to get a new `accessToken`.

---

## Contents

| Path | Description |
|------|-------------|
| [docs/API-REFERENCE.md](./docs/API-REFERENCE.md) | Full list of patient endpoints with request/response |
| [docs/AUTHENTICATION.md](./docs/AUTHENTICATION.md) | Auth flow, token format, refresh |
| [docs/OPENAPI.yaml](./docs/OPENAPI.yaml) | OpenAPI 3.0 spec for patient APIs |
| [config/env.example](./config/env.example) | Environment variables / base URL |
| [config/endpoints.json](./config/endpoints.json) | Centralized paths and config |
| [references/curl-examples.md](./references/curl-examples.md) | cURL examples for each endpoint |
| [references/BACKEND-REFERENCE.md](./references/BACKEND-REFERENCE.md) | Backend source file locations |

---

## Patient API Summary

| Area | Endpoints |
|------|-----------|
| **Auth** | Register, Login, Refresh token |
| **Plans** | Get active plans (public) |
| **User plan** | Get current user's active plan (auth) |
| **Payments** | Create payment intent, Get my payments (auth) |
| **Appointments** | Create request, Get my requests (auth) |

---

## Backend Reference

The live API is served by the main backend in this repo:

- **Backend app**: `../backend/`
- **Server entry**: `../backend/server.js`
- **API prefix**: `/api` (configurable via `API_PREFIX`)

Patient routes are defined in:

- `../backend/src/routes/auth.routes.js`
- `../backend/src/routes/appointment.routes.js`
- `../backend/src/routes/payment.routes.js`

Public plans: `GET /plans` is mounted at root (no `/api` prefix).

---

## Support

For backend bugs or new patient endpoints, see the main project README and backend source in `../backend/`.
