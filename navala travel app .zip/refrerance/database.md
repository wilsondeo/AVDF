# Database Schema Documentation

This document describes the database tables and their relationships in the Navala Travel Health application.

## Core Tables
 Tables_in_navala_travel_health_db |
+-----------------------------------+
| appointment_requests              |
| appointments                      |
| doctors                           |
| family_members                    |
| medication_taken                  |
| notification_settings             |
| password_reset_otps               |
| patient_medications               |
| patient_vitals                    |
| payments                          |
| plan_upgrades                     |
| plans                             |
| user_plans                        |
| users          

DESCRIBE users;
+--------------------------------+----------------------------------+------+-----+---------+----------------+
| Field                          | Type                             | Null | Key | Default | Extra          |
+--------------------------------+----------------------------------+------+-----+---------+----------------+
| id                             | int                              | NO   | PRI | NULL    | auto_increment |
| email                          | varchar(255)                     | NO   | UNI | NULL    |                |
| password                       | varchar(255)                     | NO   |     | NULL    |                |
| firstName                      | varchar(100)                     | NO   |     | NULL    |                |
| lastName                       | varchar(100)                     | NO   |     | NULL    |                |
| role                           | enum('ADMIN','DOCTOR','PATIENT') | NO   | MUL | PATIENT |                |
| isActive                       | tinyint(1)                       | NO   | MUL | 1       |                |
| createdAt                      | datetime                         | NO   |     | NULL    |                |
| updatedAt                      | datetime                         | NO   |     | NULL    |                |
| user_uuid                      | varchar(36)                      | YES  | UNI | NULL    |                |
| phone                          | varchar(20)                      | YES  |     | NULL    |                |
| date_of_birth                  | date                             | YES  |     | NULL    |                |
| street_address                 | varchar(255)                     | YES  |     | NULL    |                |
| city                           | varchar(100)                     | YES  |     | NULL    |                |
| state                          | varchar(100)                     | YES  |     | NULL    |                |
| zip_code                       | varchar(20)                      | YES  |     | NULL    |                |
| country                        | varchar(100)                     | YES  |     | NULL    |                |
| emergency_contact_name         | varchar(100)                     | YES  |     | NULL    |                |
| emergency_contact_phone        | varchar(50)                      | YES  |     | NULL    |                |
| emergency_contact_relationship | varchar(50)                      | YES  |     | NULL    |                |
| blood_type                     | varchar(10)                      | YES  |     | NULL    |                |
| gender                         | enum('MALE','FEMALE','OTHER')    | YES  |     | NULL    |                |
+--------------------------------+----------------------------------+------+-----+---------+----------------+
22 rows in set (0.003 sec)

MySQL [navala_travel_health_db]> ^C
DESCRIBE plans;
DESCRIBE plans;
+--------------+---------------+------+-----+---------+----------------+
| Field        | Type          | Null | Key | Default | Extra          |
+--------------+---------------+------+-----+---------+----------------+
| id           | int           | NO   | PRI | NULL    | auto_increment |
| planId       | varchar(50)   | NO   | UNI | NULL    |                |
| name         | varchar(100)  | NO   | MUL | NULL    |                |
| price        | decimal(10,2) | NO   |     | NULL    |                |
| validityDays | int           | NO   |     | NULL    |                |
| description  | text          | YES  |     | NULL    |                |
| services     | longtext      | NO   |     | NULL    |                |
| features     | longtext      | NO   |     | NULL    |                |
| isActive     | tinyint(1)    | NO   | MUL | 1       |                |
| createdAt    | datetime      | NO   |     | NULL    |                |
| updatedAt    | datetime      | NO   |     | NULL    |                |
| planFeatures | json          | YES  |     | NULL    |                |
| planTabName  | varchar(50)   | YES  |     | NULL    |                |
| maxPersons   | int           | YES  |     | 1       |                |
+--------------+---------------+------+-----+---------+----------------+
14 rows in set (0.003 sec)

MySQL [navala_travel_health_db]> ^C
DESCRIBE user_plans;
DESCRIBE user_plans;
+------------+--------------------------+------+-----+---------+----------------+
| Field      | Type                     | Null | Key | Default | Extra          |
+------------+--------------------------+------+-----+---------+----------------+
| id         | int                      | NO   | PRI | NULL    | auto_increment |
| user_id    | int                      | NO   | MUL | NULL    |                |
| plan_id    | int                      | NO   | MUL | NULL    |                |
| start_date | datetime                 | NO   | MUL | NULL    |                |
| end_date   | datetime                 | NO   | MUL | NULL    |                |
| status     | enum('ACTIVE','EXPIRED') | NO   | MUL | ACTIVE  |                |
+------------+--------------------------+------+-----+---------+----------------+
6 rows in set (0.003 sec)

MySQL [navala_travel_health_db]> ^C
DESCRIBE payments;
DESCRIBE payments;
+--------------------------+------------------------------------+------+-----+---------+----------------+
| Field                    | Type                               | Null | Key | Default | Extra          |
+--------------------------+------------------------------------+------+-----+---------+----------------+
| id                       | int                                | NO   | PRI | NULL    | auto_increment |
| user_id                  | int                                | NO   | MUL | NULL    |                |
| plan_id                  | int                                | NO   | MUL | NULL    |                |
| stripe_payment_intent_id | varchar(255)                       | NO   | UNI | NULL    |                |
| amount                   | int                                | NO   |     | NULL    |                |
| currency                 | varchar(10)                        | NO   |     | NULL    |                |
| status                   | enum('PENDING','SUCCESS','FAILED') | NO   | MUL | PENDING |                |
| type                     | enum('PURCHASE','UPGRADE')         | NO   | MUL | NULL    |                |
| created_at               | datetime                           | NO   | MUL | NULL    |                |
+--------------------------+------------------------------------+------+-----+---------+----------------+
9 rows in set (0.003 sec)

MySQL [navala_travel_health_db]> ^C
DESCRIBE plan_upgrades;
DESCRIBE plan_upgrades;
+----------------------+----------+------+-----+-------------------+-------------------+
| Field                | Type     | Null | Key | Default           | Extra             |
+----------------------+----------+------+-----+-------------------+-------------------+
| id                   | int      | NO   | PRI | NULL              | auto_increment    |
| user_id              | int      | NO   | MUL | NULL              |                   |
| old_plan_id          | int      | NO   | MUL | NULL              |                   |
| new_plan_id          | int      | NO   | MUL | NULL              |                   |
| old_price_cents      | int      | NO   |     | NULL              |                   |
| new_price_cents      | int      | NO   |     | NULL              |                   |
| amount_charged_cents | int      | NO   |     | NULL              |                   |
| payment_id           | int      | NO   | UNI | NULL              |                   |
| created_at           | datetime | NO   | MUL | CURRENT_TIMESTAMP | DEFAULT_GENERATED |
+----------------------+----------+------+-----+-------------------+-------------------+
9 rows in set (0.003 sec)

MySQL [navala_travel_health_db]> DESCRIBE doctors;
+---------------------+--------------+------+-----+---------+----------------+
| Field               | Type         | Null | Key | Default | Extra          |
+---------------------+--------------+------+-----+---------+----------------+
| id                  | int          | NO   | PRI | NULL    | auto_increment |
| doctor_uuid         | varchar(36)  | NO   | UNI | NULL    |                |
| user_id             | int          | NO   | UNI | NULL    |                |
| phone               | varchar(20)  | YES  |     | NULL    |                |
| city                | varchar(100) | YES  | MUL | NULL    |                |
| specialization      | varchar(100) | NO   | MUL | NULL    |                |
| years_of_experience | int          | NO   |     | 0       |                |
| created_at          | datetime     | NO   |     | NULL    |                |
| updated_at          | datetime     | NO   |     | NULL    |                |
| plain_password      | varchar(128) | YES  |     | NULL    |                |
+---------------------+--------------+------+-----+---------+----------------+
10 rows in set (0.003 sec)

MySQL [navala_travel_health_db]> DESCRIBE appointments;
+------------------+-------------------------------------------+------+-----+-----------+----------------+
| Field            | Type                                      | Null | Key | Default   | Extra          |
+------------------+-------------------------------------------+------+-----+-----------+----------------+
| id               | int                                       | NO   | PRI | NULL      | auto_increment |
| appointment_uuid | varchar(36)                               | NO   | UNI | NULL      |                |
| request_id       | int                                       | NO   | MUL | NULL      |                |
| patient_id       | int                                       | NO   | MUL | NULL      |                |
| doctor_id        | int                                       | NO   | MUL | NULL      |                |
| service_type     | enum('TELEHEALTH','EMERGENCY')            | NO   |     | NULL      |                |
| country          | varchar(100)                              | YES  |     | NULL      |                |
| state            | varchar(100)                              | YES  |     | NULL      |                |
| city             | varchar(100)                              | YES  |     | NULL      |                |
| appointment_date | datetime                                  | YES  |     | NULL      |                |
| status           | enum('SCHEDULED','COMPLETED','CANCELLED') | NO   | MUL | SCHEDULED |                |
| created_at       | datetime                                  | NO   |     | NULL      |                |
| updated_at       | datetime                                  | NO   |     | NULL      |                |
+------------------+-------------------------------------------+------+-----+-----------+----------------+
13 rows in set (0.003 sec)

MySQL [navala_travel_health_db]> DESCRIBE appointment_requests;
+-------------------+----------------------------------------+------+-----+---------+----------------+
| Field             | Type                                   | Null | Key | Default | Extra          |
+-------------------+----------------------------------------+------+-----+---------+----------------+
| id                | int                                    | NO   | PRI | NULL    | auto_increment |
| request_uuid      | varchar(36)                            | NO   | UNI | NULL    |                |
| patient_id        | int                                    | NO   | MUL | NULL    |                |
| plan_id           | int                                    | NO   | MUL | NULL    |                |
| country           | varchar(100)                           | NO   |     | NULL    |                |
| state             | varchar(100)                           | NO   |     | NULL    |                |
| city              | varchar(100)                           | NO   |     | NULL    |                |
| preferred_date    | datetime                               | YES  |     | NULL    |                |
| age               | int                                    | NO   |     | NULL    |                |
| gender            | varchar(20)                            | NO   |     | NULL    |                |
| emergency_contact | varchar(50)                            | YES  |     | NULL    |                |
| service_type      | enum('TELEHEALTH','EMERGENCY')         | NO   | MUL | NULL    |                |
| notes             | text                                   | YES  |     | NULL    |                |
| status            | enum('PENDING','ASSIGNED','CANCELLED') | NO   | MUL | PENDING |                |
| created_at        | datetime                               | NO   |     | NULL    |                |
| updated_at        | datetime                               | NO   |     | NULL    |                |
| allergies         | text                                   | YES  |     | NULL    |                |
| family_member_id  | int                                    | YES  |     | NULL    |                |
+-------------------+----------------------------------------+------+-----+---------+----------------+
18 rows in set (0.003 sec)

MySQL [navala_travel_health_db]> DESCRIBE family_members;
+---------------+--------------+------+-----+---------+----------------+
| Field         | Type         | Null | Key | Default | Extra          |
+---------------+--------------+------+-----+---------+----------------+
| id            | int          | NO   | PRI | NULL    | auto_increment |
| user_id       | int          | NO   | MUL | NULL    |                |
| first_name    | varchar(100) | NO   |     | NULL    |                |
| last_name     | varchar(100) | NO   |     | NULL    |                |
| date_of_birth | date         | YES  |     | NULL    |                |
| gender        | varchar(20)  | YES  |     | NULL    |                |
| relationship  | varchar(50)  | YES  |     | NULL    |                |
| created_at    | datetime     | YES  |     | NULL    |                |
| updated_at    | datetime     | YES  |     | NULL    |                |
+---------------+--------------+------+-----+---------+----------------+
9 rows in set (0.003 sec)

MySQL [navala_travel_health_db]> DESCRIBE patient_medications;
+-------------+---------------------------------------+------+-----+-------------------+-----------------------------------------------+
| Field       | Type                                  | Null | Key | Default           | Extra                                         |
+-------------+---------------------------------------+------+-----+-------------------+-----------------------------------------------+
| id          | int                                   | NO   | PRI | NULL              | auto_increment                                |
| user_id     | int                                   | NO   | MUL | NULL              |                                               |
| name        | varchar(255)                          | NO   |     | NULL              |                                               |
| dosage      | varchar(100)                          | NO   |     | NULL              |                                               |
| time_of_day | enum('morning','afternoon','evening') | NO   |     | NULL              |                                               |
| sort_order  | int                                   | YES  |     | 0                 |                                               |
| createdAt   | datetime                              | NO   |     | CURRENT_TIMESTAMP | DEFAULT_GENERATED                             |
| updatedAt   | datetime                              | NO   |     | CURRENT_TIMESTAMP | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |
+-------------+---------------------------------------+------+-----+-------------------+-----------------------------------------------+
8 rows in set (0.003 sec)

MySQL [navala_travel_health_db]> DESCRIBE medication_taken;
+---------------+------------+------+-----+-------------------+-----------------------------------------------+
| Field         | Type       | Null | Key | Default           | Extra                                         |
+---------------+------------+------+-----+-------------------+-----------------------------------------------+
| id            | int        | NO   | PRI | NULL              | auto_increment                                |
| user_id       | int        | NO   | MUL | NULL              |                                               |
| medication_id | int        | NO   | MUL | NULL              |                                               |
| date          | date       | NO   |     | NULL              |                                               |
| taken         | tinyint(1) | NO   |     | 0                 |                                               |
| createdAt     | datetime   | NO   |     | CURRENT_TIMESTAMP | DEFAULT_GENERATED                             |
| updatedAt     | datetime   | NO   |     | CURRENT_TIMESTAMP | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |
+---------------+------------+------+-----+-------------------+-----------------------------------------------+
7 rows in set (0.003 sec)

MySQL [navala_travel_health_db]> DESCRIBE patient_vitals;
+--------------------------+--------------+------+-----+-------------------+-----------------------------------------------+
| Field                    | Type         | Null | Key | Default           | Extra                                         |
+--------------------------+--------------+------+-----+-------------------+-----------------------------------------------+
| id                       | int          | NO   | PRI | NULL              | auto_increment                                |
| user_id                  | int          | NO   | MUL | NULL              |                                               |
| heart_rate               | int          | YES  |     | NULL              |                                               |
| blood_pressure_systolic  | int          | YES  |     | NULL              |                                               |
| blood_pressure_diastolic | int          | YES  |     | NULL              |                                               |
| temperature              | decimal(4,1) | YES  |     | NULL              |                                               |
| oxygen_level             | int          | YES  |     | NULL              |                                               |
| recorded_at              | datetime     | NO   |     | NULL              |                                               |
| createdAt                | datetime     | NO   |     | CURRENT_TIMESTAMP | DEFAULT_GENERATED                             |
| updatedAt                | datetime     | NO   |     | CURRENT_TIMESTAMP | DEFAULT_GENERATED on update CURRENT_TIMESTAMP |
+--------------------------+--------------+------+-----+-------------------+-----------------------------------------------+
10 rows in set (0.003 sec)

MySQL [navala_travel_health_db]> DESCRIBE notification_settings;
+--------------------+------------+------+-----+---------+----------------+
| Field              | Type       | Null | Key | Default | Extra          |
+--------------------+------------+------+-----+---------+----------------+
| id                 | int        | NO   | PRI | NULL    | auto_increment |
| user_id            | int        | NO   | UNI | NULL    |                |
| email_appointments | tinyint(1) | NO   |     | 1       |                |
| email_reminders    | tinyint(1) | NO   |     | 1       |                |
| email_promo        | tinyint(1) | NO   |     | 0       |                |
| in_app_enabled     | tinyint(1) | NO   |     | 1       |                |
| createdAt          | datetime   | NO   |     | NULL    |                |
| updatedAt          | datetime   | NO   |     | NULL    |                |
+--------------------+------------+------+-----+---------+----------------+
8 rows in set (0.003 sec)

MySQL [navala_travel_health_db]> DESCRIBE password_reset_otps;
+------------+--------------+------+-----+---------+----------------+
| Field      | Type         | Null | Key | Default | Extra          |
+------------+--------------+------+-----+---------+----------------+
| id         | int          | NO   | PRI | NULL    | auto_increment |
| email      | varchar(255) | NO   | UNI | NULL    |                |
| otp        | varchar(10)  | NO   |     | NULL    |                |
| expires_at | datetime     | NO   |     | NULL    |                |
| createdAt  | datetime     | NO   |     | NULL    |                |
| updatedAt  | datetime     | NO   |     | NULL    |                |
+------------+--------------+------+-----+---------+----------------+
6 rows in set (0.003 sec)