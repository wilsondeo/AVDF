# API Reference – Patient Mobile

Base URL: `{BASE_URL}` (e.g. `http://localhost:3001`). All request/response bodies are JSON unless noted.

---

## Health

### GET /health

No auth. Use to check if the server is up.

**Response (200):**
```json
{
  "success": true,
  "message": "Server is running",
  "timestamp": "2025-02-10T12:00:00.000Z"
}
```

---

## Auth

See [AUTHENTICATION.md](./AUTHENTICATION.md) for full details.

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | /api/auth/register | No | Register patient |
| POST | /api/auth/login | No | Patient login |
| POST | /api/auth/refresh | No | Refresh access token |

---

## Plans (Public)

### GET /plans

Returns all **active** plans (no auth). Use this to show plan options before or after login.

**Response (200):**
```json
{
  "success": true,
  "message": "Active plans retrieved successfully",
  "data": {
    "plans": [
      {
        "id": 1,
        "planId": "plan_basic_001",
        "name": "Basic",
        "price": "29.99",
        "validityDays": 30,
        "services": ["TELEHEALTH"],
        "isActive": true
      }
    ],
    "count": 1
  }
}
```

**Plan fields:** `id`, `planId`, `name`, `price`, `validityDays`, `services` (array, e.g. `["TELEHEALTH","EMERGENCY"]`), `isActive`.

---

## User Plan (Authenticated)

### GET /api/user/plan

Returns the current user’s active plan, if any. Requires `Authorization: Bearer <accessToken>`.

**Response (200):**
```json
{
  "success": true,
  "message": "User plan fetched",
  "data": {
    "activePlan": {
      "userPlanId": 1,
      "planId": "plan_basic_001",
      "planName": "Basic",
      "status": "ACTIVE",
      "startDate": "2025-01-01T00:00:00.000Z",
      "endDate": "2025-01-31T23:59:59.999Z",
      "plan": {
        "planId": "plan_basic_001",
        "name": "Basic",
        "price": "29.99",
        "validityDays": 30,
        "services": ["TELEHEALTH", "EMERGENCY"]
      }
    }
  }
}
```

If the user has no active plan, `data.activePlan` may be `null`.

**Errors:** `401` – Missing or invalid token.

---

## Payments (Authenticated)

All payment endpoints require `Authorization: Bearer <accessToken>`.

### POST /api/payments/create-intent

Creates a Stripe PaymentIntent for purchasing or upgrading to a plan. Use the returned `clientSecret` with Stripe’s mobile SDK to collect payment.

**Request:**
```json
{
  "planId": "plan_basic_001"
}
```

`planId` is the plan’s business identifier (`planId` from GET /plans).

**Response (201):**
```json
{
  "success": true,
  "message": "Payment intent created",
  "data": {
    "clientSecret": "pi_xxx_secret_xxx",
    "paymentIntentId": "pi_xxx",
    "type": "PURCHASE"
  }
}
```

`type` is `PURCHASE` or `UPGRADE`. After successful payment, Stripe sends a webhook to the backend; the user’s plan is activated by the server. Then use GET /api/user/plan to show the new active plan.

**Errors:** `400` – planId missing or plan not found/inactive. `401` – Not authenticated.

---

### GET /api/payments/my

Returns the current user’s payment history (latest first).

**Query (optional):**
- `limit` – number (default 20)
- `offset` – number (default 0)

**Response (200):**
```json
{
  "success": true,
  "message": "Payments retrieved successfully",
  "data": {
    "payments": [
      {
        "id": 1,
        "amount": 2999,
        "currency": "usd",
        "status": "SUCCESS",
        "type": "PURCHASE",
        "createdAt": "2025-01-15T10:00:00.000Z",
        "plan": { "planId": "plan_basic_001", "name": "Basic" }
      }
    ],
    "count": 1
  }
}
```

`amount` is in cents.

---

## Appointments (Authenticated)

All appointment endpoints require `Authorization: Bearer <accessToken>` and a **PATIENT** user.

### POST /api/appointments/request

Creates an appointment request (booking). The admin will assign a doctor later; the patient sees status in “my requests”.

**Request:**
```json
{
  "city": "New York",
  "age": 35,
  "gender": "male",
  "emergencyContact": "+1234567890",
  "serviceType": "TELEHEALTH",
  "notes": "Optional notes"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| city | string | Yes | City for the request |
| age | number | Yes | Patient age |
| gender | string | Yes | e.g. male, female, other |
| emergencyContact | string | Yes | Phone or contact string |
| serviceType | string | Yes | `TELEHEALTH` or `EMERGENCY` |
| notes | string | No | Free text |

**Response (201):**
```json
{
  "success": true,
  "message": "Appointment request created",
  "data": {
    "requestUuid": "550e8400-e29b-41d4-a716-446655440000"
  }
}
```

**Errors:** `400` – Validation or business rule. `401` – Not authenticated. `403` – Not a patient or no active plan (if backend enforces plan for booking).

---

### GET /api/appointments/my-requests

Returns the current user’s appointment requests (all statuses).

**Response (200):**
```json
{
  "success": true,
  "message": "Appointment requests fetched",
  "data": [
    {
      "requestUuid": "550e8400-e29b-41d4-a716-446655440000",
      "serviceType": "TELEHEALTH",
      "status": "PENDING",
      "city": "New York",
      "createdAt": "2025-02-10T12:00:00.000Z"
    }
  ]
}
```

**Status values:** `PENDING`, `ASSIGNED`, `CANCELLED`. When status is `ASSIGNED`, the patient may receive a confirmation email; the doctor is visible in the admin/doctor side.

---

## Error Format

All error responses follow:

```json
{
  "success": false,
  "message": "Human-readable error message"
}
```

Optional: `error`, `stack` (in development). HTTP status: 400 (validation/bad request), 401 (unauthorized), 403 (forbidden), 404 (not found), 500 (server error).
