// Quick API Test Script
// Run this to verify backend connectivity and response format

const BASE_URL = 'http://192.168.1.225:3000';

async function testBackendConnection() {
    console.log('=== Testing Backend API ===\n');

    // Test 1: Health Check
    console.log('1. Testing Health Endpoint...');
    try {
        const healthResponse = await fetch(`${BASE_URL}/health`);
        const healthData = await healthResponse.json();
        console.log('✓ Health Check:', JSON.stringify(healthData, null, 2));
    } catch (error) {
        console.log('✗ Health Check Failed:', error.message);
    }

    // Test 2: Get Plans
    console.log('\n2. Testing Plans Endpoint...');
    try {
        const plansResponse = await fetch(`${BASE_URL}/plans`);
        const plansData = await plansResponse.json();
        console.log('✓ Plans Response:', JSON.stringify(plansData, null, 2));
    } catch (error) {
        console.log('✗ Plans Failed:', error.message);
    }

    // Test 3: Register (with test data)
    console.log('\n3. Testing Register Endpoint...');
    try {
        const registerResponse = await fetch(`${BASE_URL}/api/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                email: `test${Date.now()}@example.com`,
                password: 'Test1234',
                firstName: 'Test',
                lastName: 'User'
            })
        });
        const registerData = await registerResponse.json();
        console.log('✓ Register Response:', JSON.stringify(registerData, null, 2));
    } catch (error) {
        console.log('✗ Register Failed:', error.message);
    }

    console.log('\n=== Test Complete ===');
}

// Run the test
testBackendConnection();
