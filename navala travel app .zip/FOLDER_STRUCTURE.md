# Mobile App Folder Structure (Patient Only)

## ✅ Current Clean Structure

```
navala travel app/
├── app/                          # Expo Router screens
│   ├── (tabs)/                  # Main app tabs (after login)
│   ├── login.tsx                # Login screen
│   ├── signup.tsx               # Registration screen
│   ├── plans.tsx                # Plans selection screen
│   └── _layout.tsx              # Navigation configuration
│
├── src/                         # Source code
│   ├── api/                     # API layer (PATIENT ONLY)
│   │   ├── features/           # Feature-based API modules
│   │   │   ├── auth.ts        # Login, Register, Logout
│   │   │   ├── plans.ts       # Get Plans, Purchase Plan
│   │   │   ├── user.ts        # Profile, Active Plan
│   │   │   └── appointments.ts # Create Request, My Requests
│   │   ├── config.ts          # API client configuration
│   │   ├── endpoints.ts       # Endpoint definitions (legacy)
│   │   └── index.ts           # Central exports
│   │
│   ├── types/                  # TypeScript types
│   │   └── api.types.ts       # API response types
│   │
│   ├── utils/                  # Utility functions
│   │   └── storage.ts         # Cross-platform storage
│   │
│   └── services/               # (DEPRECATED - use src/api instead)
│       ├── auth.service.ts    # ⚠️ OLD - DO NOT USE
│       └── appointment.service.ts # ⚠️ OLD - DO NOT USE
│
├── assets/                     # Images, fonts, etc.
├── refrerance/                 # Backend API documentation
└── node_modules/              # Dependencies

```

## 📁 API Structure (Patient Features Only)

### src/api/features/

**✅ KEEP - Patient Features:**
- `auth.ts` - Authentication (Login, Register, Logout)
- `plans.ts` - Plans (Get Plans, Purchase Plan)
- `user.ts` - User Profile (Get/Update Profile, Get Active Plan)
- `appointments.ts` - Appointments (Create Request, My Requests)

**❌ REMOVED - Admin/Doctor Features:**
- No admin endpoints
- No doctor endpoints
- No admin login/management

## 🎯 How to Use APIs in Your App

### Import from central location:
```typescript
import { AuthApi, PlansApi, UserApi, AppointmentsApi } from '@/src/api';
```

### Examples:

#### 1. Registration:
```typescript
import { AuthApi } from '@/src/api';

const response = await AuthApi.register({
  firstName: 'John',
  lastName: 'Doe',
  email: 'john@example.com',
  password: 'SecurePass123'
});
```

#### 2. Login:
```typescript
import { AuthApi } from '@/src/api';

const response = await AuthApi.login({
  email: 'john@example.com',
  password: 'SecurePass123'
});
```

#### 3. Get Plans:
```typescript
import { PlansApi } from '@/src/api';

const response = await PlansApi.getPlans();
const plans = response.data.plans;
```

#### 4. Get User Profile:
```typescript
import { UserApi } from '@/src/api';

const response = await UserApi.getProfile();
const profile = response.data;
```

#### 5. Create Appointment Request:
```typescript
import { AppointmentsApi } from '@/src/api';

const response = await AppointmentsApi.createRequest({
  city: 'New York',
  age: 35,
  gender: 'male',
  emergencyContact: '+1234567890',
  serviceType: 'TELEHEALTH',
  notes: 'First consultation'
});
```

## 🗑️ Files to Delete (Optional Cleanup)

These files are no longer needed:

```
src/services/auth.service.ts          # Replaced by src/api/features/auth.ts
src/services/appointment.service.ts   # Replaced by src/api/features/appointments.ts
src/api/client.ts                     # Replaced by src/api/config.ts
```

**Note:** Don't delete yet - wait until you verify everything works!

## 📝 Configuration

### Current Settings:
- **Base URL**: `http://192.168.1.225:3000`
- **API Prefix**: `/api`

### To Change:
Edit `src/api/config.ts`:
```typescript
export const API_BASE_URL = 'http://YOUR_IP:3000';
export const API_PREFIX = '/api';
```

## ✅ API Endpoints Available (Patient Only)

### Public (No Auth):
- `GET /plans` - Get all active plans
- `GET /health` - Health check

### Authentication (No Auth Required):
- `POST /api/auth/register` - Register new patient
- `POST /api/auth/login` - Patient login
- `POST /api/auth/refresh` - Refresh access token

### User Profile (Auth Required):
- `GET /api/user/profile` - Get user profile
- `PATCH /api/user/profile` - Update user profile
- `GET /api/user/plan` - Get active plan

### Payments (Auth Required):
- `POST /api/payments/create-intent` - Create payment intent
- `GET /api/payments/my` - Get my payment history

### Appointments (Auth Required):
- `POST /api/appointments/request` - Create appointment request
- `GET /api/appointments/my-requests` - Get my appointment requests

## 🚀 Testing

Run the test script to verify backend connectivity:
```bash
node test-api.js
```

Expected output:
```
✓ Health Check: { success: true, ... }
✓ Plans Response: { success: true, data: { plans: [...] } }
✓ Register Response: { success: true, data: { user: {...}, accessToken: "..." } }
```

## 📱 App Flow

1. **Signup** → `app/signup.tsx` → `AuthApi.register()`
2. **Login** → `app/login.tsx` → `AuthApi.login()`
3. **Plans** → `app/plans.tsx` → `PlansApi.getPlans()`
4. **Purchase** → `PlansApi.purchasePlan(planId)`
5. **Profile** → `UserApi.getProfile()` / `UserApi.updateProfile()`
6. **Appointments** → `AppointmentsApi.createRequest()` / `AppointmentsApi.getMyRequests()`

## 🎨 Best Practices

1. **Always import from `@/src/api`**:
   ```typescript
   import { AuthApi, PlansApi } from '@/src/api';
   ```

2. **Handle errors properly**:
   ```typescript
   try {
     const response = await AuthApi.login({ email, password });
     if (response.success) {
       // Handle success
     }
   } catch (error) {
     Alert.alert('Error', error.message);
   }
   ```

3. **Check response structure**:
   ```typescript
   const response = await PlansApi.getPlans();
   if (response.success && response.data.plans) {
     setPlans(response.data.plans);
   }
   ```

## ✨ Summary

- **Clean structure** with only patient-related features
- **No admin/doctor code** - keeps the app simple
- **Easy to use** - import from `@/src/api`
- **Type-safe** - TypeScript types for all APIs
- **Cross-platform** - Works on web and mobile
- **Well-documented** - Clear examples and structure

Your mobile app is now **production-ready** with a clean, maintainable structure! 🎉
