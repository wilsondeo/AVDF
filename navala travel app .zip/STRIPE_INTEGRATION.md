# 💳 Stripe Payment Integration Guide

## ✅ What's Been Implemented

Your mobile app now has **full Stripe payment integration** for purchasing plans!

### Features:
- ✅ Dynamic plan fetching from backend
- ✅ Stripe payment sheet integration
- ✅ Secure payment processing
- ✅ Payment intent creation
- ✅ Success/failure handling
- ✅ Automatic navigation after purchase

## 🔧 Configuration

### Stripe Keys (Already Configured):
```typescript
// src/config/stripe.ts
publishableKey: 'pk_test_51SxSSPHwSW4gSqwxrlOePCWloQP1nY8w2wSH1Qv5ZvfUnuYZkwRpUSHMVhQOIexpxDvSdhn7g5U89cCzd0LNWMgI00vDnnVjRM'
```

### Backend Configuration:
```
STRIPE_SECRET_KEY=sk_test_51SxSSPHwSW4gSqwxNJvA72zItj1xO67ayayFHAcxFNBbOyCvIbcgAlIrisy49yUtalCEplKnBDmMxbm8iJYiOKK500TmkDs9p1
STRIPE_WEBHOOK_SECRET=whsec_49188fd9f39985402bf6866c267d6916577d930cb270113adb1f6cdeb2b50819
STRIPE_CURRENCY=usd
```

## 🚀 How It Works

### Payment Flow:

1. **User Views Plans**
   - App fetches plans from `GET /plans`
   - Displays all active plans with features and pricing

2. **User Clicks "Buy Plan"**
   - App calls `POST /api/payments/create-intent` with `planId`
   - Backend creates Stripe PaymentIntent
   - Returns `clientSecret` to mobile app

3. **Payment Sheet Opens**
   - Stripe payment sheet initializes with `clientSecret`
   - User enters card details (or uses saved payment method)
   - Stripe handles all payment validation

4. **Payment Processing**
   - Stripe processes the payment securely
   - Webhook notifies backend of payment status
   - Backend activates user's plan

5. **Success Handling**
   - App shows success message
   - Redirects to main app (tabs)
   - User can now access their purchased plan

## 📱 User Experience

### Plans Screen:
```
┌─────────────────────────────┐
│   Available Plans           │
│   Choose a plan that fits   │
│   your travel needs         │
├─────────────────────────────┤
│                             │
│   ┌─────────────────────┐   │
│   │   Basic Plan        │   │
│   │   $29.99            │   │
│   │   / 30 days         │   │
│   │                     │   │
│   │   ✓ TELEHEALTH      │   │
│   │   ✓ 24/7 Support    │   │
│   │                     │   │
│   │   [Buy Plan]        │   │
│   └─────────────────────┘   │
│                             │
│   ┌─────────────────────┐   │
│   │   Premium Plan      │   │
│   │   $49.99            │   │
│   │   / 30 days         │   │
│   │                     │   │
│   │   ✓ TELEHEALTH      │   │
│   │   ✓ EMERGENCY       │   │
│   │   ✓ Priority        │   │
│   │                     │   │
│   │   [Buy Plan]        │   │
│   └─────────────────────┘   │
└─────────────────────────────┘
```

### Payment Sheet (Stripe):
```
┌─────────────────────────────┐
│   Pay Navala Travel         │
├─────────────────────────────┤
│                             │
│   Card Information          │
│   ┌─────────────────────┐   │
│   │ 4242 4242 4242 4242 │   │
│   └─────────────────────┘   │
│                             │
│   ┌──────────┬──────────┐   │
│   │ MM / YY  │   CVC    │   │
│   └──────────┴──────────┘   │
│                             │
│   [Pay $29.99]              │
└─────────────────────────────┘
```

## 🧪 Testing

### Test Cards (Stripe Test Mode):

#### Successful Payment:
```
Card Number: 4242 4242 4242 4242
Expiry: Any future date (e.g., 12/34)
CVC: Any 3 digits (e.g., 123)
ZIP: Any 5 digits (e.g., 12345)
```

#### Payment Requires Authentication (3D Secure):
```
Card Number: 4000 0025 0000 3155
Expiry: Any future date
CVC: Any 3 digits
```

#### Declined Payment:
```
Card Number: 4000 0000 0000 0002
Expiry: Any future date
CVC: Any 3 digits
```

### Testing Steps:

1. **Start the app**:
   ```bash
   npx expo start
   ```

2. **Login** with your test account

3. **Navigate to Plans** screen

4. **Click "Buy Plan"** on any plan

5. **Enter test card** details:
   - Card: `4242 4242 4242 4242`
   - Expiry: `12/34`
   - CVC: `123`

6. **Click "Pay"**

7. **Verify success** message appears

8. **Check backend** to confirm plan activation

## 🔍 API Endpoints Used

### 1. Get Plans
```
GET http://192.168.1.225:3000/plans

Response:
{
  "success": true,
  "message": "Active plans retrieved successfully",
  "data": {
    "plans": [
      {
        "id": 1,
        "planId": "PLAN-BASIC-001",
        "name": "Basic",
        "price": "29.99",
        "validityDays": 30,
        "services": ["TELEHEALTH"],
        "features": ["24/7 Support", "Telehealth Consultations"],
        "isActive": true
      }
    ],
    "count": 1
  }
}
```

### 2. Create Payment Intent
```
POST http://192.168.1.225:3000/api/payments/create-intent
Headers: Authorization: Bearer <accessToken>

Request:
{
  "planId": "PLAN-BASIC-001"
}

Response:
{
  "success": true,
  "message": "Payment intent created",
  "data": {
    "clientSecret": "pi_xxx_secret_xxx",
    "paymentIntentId": "pi_xxx",
    "type": "PURCHASE"
  }
}
```

### 3. Get My Payments (Optional)
```
GET http://192.168.1.225:3000/api/payments/my?limit=20&offset=0
Headers: Authorization: Bearer <accessToken>

Response:
{
  "success": true,
  "message": "Payments retrieved successfully",
  "data": {
    "payments": [
      {
        "id": 1,
        "amount": 2999,
        "currency": "usd",
        "status": "SUCCESS",
        "type": "PURCHASE",
        "createdAt": "2026-02-13T10:00:00.000Z",
        "plan": {
          "planId": "PLAN-BASIC-001",
          "name": "Basic"
        }
      }
    ],
    "count": 1
  }
}
```

## 📁 Files Modified/Created

### Created:
- `src/config/stripe.ts` - Stripe configuration
- Updated `app/plans.tsx` - Full Stripe integration

### Updated:
- `src/api/features/plans.ts` - Added payment methods
- `app.json` - Added URL scheme for Stripe

### Installed:
- `@stripe/stripe-react-native` - Stripe SDK

## 🎨 Features Breakdown

### Dynamic Plan Display:
```typescript
// Automatically parses features from JSON or services array
let featuresList: string[] = [];
if (item.features) {
  featuresList = JSON.parse(item.features);
} else if (item.services) {
  featuresList = item.services;
}
```

### Payment Processing:
```typescript
// 1. Create payment intent
const response = await PlansApi.purchasePlan(plan.planId);
const { clientSecret } = response.data;

// 2. Initialize payment sheet
await initPaymentSheet({
  merchantDisplayName: 'Navala Travel',
  paymentIntentClientSecret: clientSecret,
});

// 3. Present payment sheet
const { error } = await presentPaymentSheet();

// 4. Handle result
if (!error) {
  // Payment successful!
}
```

## 🐛 Troubleshooting

### Issue: "Payment sheet not showing"
**Solution**: Make sure Stripe provider wraps the component:
```typescript
<StripeProvider publishableKey={STRIPE_CONFIG.publishableKey}>
  <PlansContent />
</StripeProvider>
```

### Issue: "Invalid publishable key"
**Solution**: Verify the key in `src/config/stripe.ts` starts with `pk_test_`

### Issue: "Payment intent creation failed"
**Solution**: 
- Check backend is running
- Verify user is logged in (token is valid)
- Check backend logs for errors

### Issue: "Webhook not working"
**Solution**: 
- Ensure webhook secret is correct in backend `.env`
- Use Stripe CLI for local testing:
  ```bash
  stripe listen --forward-to http://192.168.1.225:3000/payments/webhook
  ```

## ✨ Next Steps

### Optional Enhancements:

1. **Add Payment History Screen**:
   ```typescript
   import { PlansApi } from '@/src/api';
   const payments = await PlansApi.getMyPayments();
   ```

2. **Show Active Plan**:
   ```typescript
   import { UserApi } from '@/src/api';
   const activePlan = await UserApi.getActivePlan();
   ```

3. **Add Apple Pay / Google Pay**:
   ```typescript
   // In payment sheet initialization
   applePay: {
     merchantCountryCode: 'US',
   },
   googlePay: {
     merchantCountryCode: 'US',
     testEnv: true,
   },
   ```

## 🎉 Summary

Your app now has:
- ✅ **Full Stripe integration**
- ✅ **Dynamic plan loading**
- ✅ **Secure payment processing**
- ✅ **Beautiful UI**
- ✅ **Error handling**
- ✅ **Test mode ready**

**Everything is ready for testing!** 🚀

Just run the app, login, go to plans, and try purchasing with the test card `4242 4242 4242 4242`!
