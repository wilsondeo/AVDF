# Navala Travel – Mobile API Reference

Single reference for base URLs, auth, and all API endpoints. Use this for mobile app (React Native, Flutter, etc.) configuration and integration.

---

## 1. Base URLs & Config

| Key | Value | Notes |
|-----|--------|------|
| **Backend base URL** | `http://192.168.1.225:3000` | Replace with your server IP/host in production. For local emulator use `http://10.0.2.2:3000` (Android) or `http://localhost:3000` (iOS simulator). |
| **API prefix** | `/api` | Prefixed routes use this (e.g. `/api/auth/login`). |
| **Full API base URL** | `{BACKEND_BASE_URL}{API_PREFIX}` = `http://192.168.1.225:3000/api` | Use for all endpoints under "API-prefixed" below. |

**Mobile env suggestion:**  
Set one variable, e.g. `BASE_URL = http://192.168.1.225:3000`, then:
- API base = `BASE_URL + "/api"`
- Paths listed below are relative to backend root or to API base as indicated.

---

## 2. Authentication Header

For protected endpoints, send the JWT in the header:

```
Authorization: Bearer <accessToken>
Content-Type: application/json
```

Store `accessToken` from login/register/refresh responses; send it on every request that requires auth.

---

## 3. All API Endpoints

### 3.1 Public (no auth)

| Method | Full path | Description |
|--------|-----------|-------------|
| GET | `{BASE_URL}/plans` | List active plans (public). |
| GET | `{BASE_URL}/health` | Health check. |

### 3.2 Auth – Patient (no auth for login/register)

| Method | Full path | Description | Body |
|--------|-----------|-------------|------|
| POST | `{BASE_URL}/api/auth/login` | Patient login. | `{ "email": "", "password": "" }` |
| POST | `{BASE_URL}/api/auth/register` | Patient register. | `{ "email", "password", "firstName", "lastName", "phone?", "dateOfBirth?", "streetAddress?", "city?", "state?", "zipCode?", "country?", "emergencyContactName?", "emergencyContactPhone?", "emergencyContactRelationship?", "bloodType?" }` |
| POST | `{BASE_URL}/api/auth/refresh` | Refresh access token. | `{ "refreshToken": "" }` |
| POST | `{BASE_URL}/api/auth/forgot-password` | Forgot password: send OTP to patient email. | `{ "email": "" }` |
| POST | `{BASE_URL}/api/auth/reset-password` | Reset password with OTP (patient only). | `{ "email": "", "otp": "", "newPassword": "", "confirmPassword": "" }` |

#### Forgot password (POST `{BASE_URL}/api/auth/forgot-password`)

**Request body:** `{ "email": "patient@example.com" }`  
**Response (200):** `{ "success": true, "message": "OTP sent to your email. Check your inbox." }`  
**Errors:** `400` – Email required; no account with this email; or password reset only for patients.

The server sends a 6-digit OTP to the given email (valid for 10 minutes). Use it in the reset-password call.

#### Reset password (POST `{BASE_URL}/api/auth/reset-password`)

**Request body:**
```json
{
  "email": "patient@example.com",
  "otp": "123456",
  "newPassword": "NewSecurePass8",
  "confirmPassword": "NewSecurePass8"
}
```
- `newPassword` and `confirmPassword` must match and be at least 8 characters.  
**Response (200):** `{ "success": true, "message": "Password reset successfully. You can now log in." }`  
**Errors:** `400` – Missing fields; passwords don’t match; invalid or expired OTP; password too short.

### 3.3 Admin login (no API prefix)

| Method | Full path | Description | Body |
|--------|-----------|-------------|------|
| POST | `{BASE_URL}/admin/login` | Admin login. | `{ "email": "", "password": "" }` |

### 3.4 Doctor login (API prefix)

| Method | Full path | Description | Body |
|--------|-----------|-------------|------|
| POST | `{BASE_URL}/api/doctor/login` | Doctor login. | `{ "email": "", "password": "" }` |

### 3.5 User & payments (mounted at root; also under `/api`)

Use either `{BASE_URL}/...` or `{BASE_URL}/api/...` (same handler).

| Method | Full path | Auth | Description | Body / Query |
|--------|-----------|------|-------------|--------------|
| GET | `{BASE_URL}/user/plan` or `{BASE_URL}/api/user/plan` | Yes | Current user’s active plan. | — |
| GET | `{BASE_URL}/user/profile` or `{BASE_URL}/api/user/profile` | Yes | Get current user’s profile (patient). | — |
| PATCH | `{BASE_URL}/user/profile` or `{BASE_URL}/api/user/profile` | Yes | Update current user’s profile (patient). | See **Patient profile** below. |
| GET | `{BASE_URL}/payments/my` or `{BASE_URL}/api/payments/my` | Yes | My payments. | — |
| POST | `{BASE_URL}/payments/create-intent` or `{BASE_URL}/api/payments/create-intent` | Yes | Create Stripe payment intent for plan purchase or **upgrade** (pay difference only). | `{ "planId": "" }` (plan business id, e.g. `PLAN-xxx`). |
| POST | `{BASE_URL}/payments/webhook` | No | Stripe webhook (server-only). | — |

#### Create payment intent – Plan purchase & upgrade (POST `{BASE_URL}/payments/create-intent` or `.../api/payments/create-intent`)

Use this to start a Stripe payment for a plan. **If the user already has an active plan and selects a higher-priced plan, the backend charges only the difference** (e.g. current $150 plan → new $175 plan = **pay $25 only**).

**Request (auth required):**
```json
{ "planId": "PLAN-1234567890-ABC123" }
```
- `planId` = plan’s business id from `GET /plans` (e.g. `plan.planId`).

**Response (201):**
```json
{
  "success": true,
  "message": "Payment intent created",
  "data": {
    "clientSecret": "pi_xxx_secret_xxx",
    "paymentIntentId": "pi_xxx",
    "type": "PURCHASE",
    "amountChargedCents": 2500,
    "amountCharged": 25
  }
}
```

| Field | Type | Description |
|-------|------|-------------|
| `clientSecret` | string | Pass to Stripe SDK to collect payment and confirm. |
| `paymentIntentId` | string | Stripe PaymentIntent id (for reference). |
| `type` | `"PURCHASE"` \| `"UPGRADE"` | First-time purchase vs upgrading from current plan. |
| `amountChargedCents` | number | Amount to charge in cents (e.g. 2500 = $25). |
| `amountCharged` | number | Same amount in dollars (e.g. 25). |

**Upgrade behavior (backend):**
- If user has an **active plan** and selects a **new plan with higher price**, backend sets amount = **new price − current plan price** (e.g. $175 − $150 = $25).
- If new plan price ≤ current plan price, backend returns **400** with message like: *"Select a higher-tier plan to upgrade. Your current plan is the same price or higher."*
- If user has **no active plan**, amount = full plan price (`type: "PURCHASE"`).

**What to do in the mobile app:**
1. Call **POST** `{BASE_URL}/payments/create-intent` (or `.../api/payments/create-intent`) with **Authorization: Bearer &lt;accessToken&gt;** and body `{ "planId": "<selected plan’s planId>" }`.
2. On success, use `data.clientSecret` with the **Stripe SDK** (e.g. Stripe Android/iOS SDK or Stripe React Native) to collect payment and confirm. Do **not** send a custom amount to Stripe—the PaymentIntent is already created with the correct amount (`amountChargedCents`).
3. Show the user the amount they will pay: use `data.amountCharged` (or `data.amountChargedCents / 100`) for the label, e.g. *"Pay $25.00"* or *"Upgrade: pay $25.00"* when `data.type === "UPGRADE"`.
4. After Stripe confirms payment, poll **GET** `{BASE_URL}/user/plan` until the active plan’s `planId` matches the purchased plan (or show success and refresh plan screen).

**Errors:**
- **400** – Missing `planId`; plan not found/inactive; or upgrade not allowed (same or lower price).

#### Patient profile (GET / PATCH `{BASE_URL}/user/profile` or `.../api/user/profile`)

**GET** – Returns the logged-in user’s profile (no body).  
**Response (200):** `{ "success": true, "message": "Profile retrieved", "data": <UserProfile> }`

**PATCH** – Update profile. Send only fields you want to change.  
**Request body (all optional):**
```json
{
  "firstName": "string",
  "lastName": "string",
  "phone": "string",
  "dateOfBirth": "YYYY-MM-DD",
  "streetAddress": "string",
  "city": "string",
  "state": "string",
  "zipCode": "string",
  "country": "string",
  "emergencyContactName": "string",
  "emergencyContactPhone": "string",
  "emergencyContactRelationship": "string",
  "bloodType": "string"
}
```
**Response (200):** `{ "success": true, "message": "Profile updated", "data": <UserProfile> }`

**UserProfile (data shape):**
`id`, `userUuid`, `email`, `firstName`, `lastName`, `role`, `isActive`, `phone`, `dateOfBirth`, `streetAddress`, `city`, `state`, `zipCode`, `country`, `emergencyContactName`, `emergencyContactPhone`, `emergencyContactRelationship`, `bloodType`, `createdAt`, `updatedAt`

### 3.6 Appointments (API prefix, patient & admin)

| Method | Full path | Auth | Description | Body / Query |
|--------|-----------|------|-------------|--------------|
| POST | `{BASE_URL}/api/appointments/request` | Yes (patient) | Create appointment request. | Request body as per backend (e.g. reason, preferred date/time). |
| GET | `{BASE_URL}/api/appointments/my-requests` | Yes (patient) | My appointment requests. | — |
| GET | `{BASE_URL}/api/admin/appointment-requests` | Yes (admin) | List appointment requests. | Query: status, page, limit, etc. |
| POST | `{BASE_URL}/api/admin/assign-doctor` | Yes (admin) | Assign doctor to request. | `{ "requestUuid": "", "doctorUuid": "" }` optional: `"appointmentDate": "ISO8601"` |
| GET | `{BASE_URL}/api/admin/appointments` | Yes (admin) | List appointments. | Query as needed. |

### 3.7 Doctor (API prefix)

| Method | Full path | Auth | Description |
|--------|-----------|------|-------------|
| GET | `{BASE_URL}/api/doctor/profile` | Yes (doctor) | Doctor profile. |
| GET | `{BASE_URL}/api/doctor/appointments` | Yes (doctor) | Doctor’s appointments. |

### 3.8 Admin – Patients, users, transactions (API prefix)

| Method | Full path | Auth | Description | Body / Query |
|--------|-----------|------|-------------|--------------|
| GET | `{BASE_URL}/api/admin/patients` | Yes (admin) | List patients. | — |
| POST | `{BASE_URL}/api/admin/patients/:userId/plan` | Yes (admin) | Grant plan to patient. | `{ "planId": "", "durationMonths"?: number }` (or as per backend). |
| GET | `{BASE_URL}/api/admin/users/:id` | Yes (admin) | Get user (full profile). | — |
| PATCH | `{BASE_URL}/api/admin/users/:id` | Yes (admin) | Update user (profile + optional status). | Same fields as patient profile PATCH + `"isActive": boolean` (all optional). |
| PATCH | `{BASE_URL}/api/admin/users/:id/status` | Yes (admin) | Update user status only. | `{ "isActive": boolean }` |
| GET | `{BASE_URL}/api/admin/transactions` | Yes (admin) | List transactions. | Query: page, limit, etc. |
| GET | `{BASE_URL}/api/admin/transactions/stats` | Yes (admin) | Transaction stats. | — |

### 3.9 Admin – Plans (API prefix)

| Method | Full path | Auth | Description | Body |
|--------|-----------|------|-------------|------|
| GET | `{BASE_URL}/api/admin/plans` | Yes (admin) | List plans. | — |
| GET | `{BASE_URL}/api/admin/plans/:planId` | Yes (admin) | Get plan by ID. | — |
| POST | `{BASE_URL}/api/admin/plans` | Yes (admin) | Create plan. | Plan object. |
| PUT | `{BASE_URL}/api/admin/plans/:planId` | Yes (admin) | Update plan. | Plan object. |
| DELETE | `{BASE_URL}/api/admin/plans/:planId` | Yes (admin) | Delete plan. | — |

### 3.10 Admin – Doctors (API prefix)

| Method | Full path | Auth | Description | Body |
|--------|-----------|------|-------------|------|
| GET | `{BASE_URL}/api/admin/doctors` | Yes (admin) | List doctors. | — |
| GET | `{BASE_URL}/api/admin/doctors/:id` | Yes (admin) | Get doctor. | — |
| POST | `{BASE_URL}/api/admin/doctors` | Yes (admin) | Create doctor. | Doctor object. |
| PUT | `{BASE_URL}/api/admin/doctors/:id` | Yes (admin) | Update doctor. | Doctor object. |
| DELETE | `{BASE_URL}/api/admin/doctors/:id` | Yes (admin) | Delete doctor. | — |
| POST | `{BASE_URL}/api/admin/doctors/:id/send-email` | Yes (admin) | Send email to doctor. | As per backend. |
| POST | `{BASE_URL}/api/admin/doctors/upload` | Yes (admin) | Bulk upload (e.g. CSV). | `multipart/form-data` with file. |

---

## 4. Response shape (typical)

- Success: `{ "success": true, "data": {...}, "message"?: "..." }`
- Error: `{ "success": false, "message": "...", "error"?: "..." }`
- Auth responses: include `accessToken`, `refreshToken`, and `user` object (`id`, `email`, `firstName`, `lastName`, `role`, `isActive`).

---

## 5. Checklist for mobile build

- [ ] Set **Backend base URL** (e.g. `http://192.168.1.225:3000` or production URL).
- [ ] Use **API prefix** `/api` for all endpoints in sections 3.2, 3.4, 3.6–3.10; use **no prefix** for `/plans`, `/admin/login`, and optionally for `/user/*`, `/payments/*` (or use `/api/...`).
- [ ] Send **Authorization: Bearer &lt;accessToken&gt;** and **Content-Type: application/json** on all protected calls.
- [ ] Store **accessToken** and **refreshToken**; use refresh when access token expires (e.g. 401).
- [ ] For **payments**, use **POST** `/payments/create-intent` (auth) with `{ "planId": "<planId>" }` and **GET** `/payments/my` (auth); do not call `/payments/webhook` from the app (server-only). Use the response `data.clientSecret` with Stripe SDK to confirm; show `data.amountCharged` (or `data.amountChargedCents / 100`) as the amount to pay—on **upgrade** this is the difference only (e.g. $25), not the full plan price.
- [ ] For **patient profile**, use GET and PATCH `{BASE_URL}/user/profile` (or `.../api/user/profile`) with Bearer token; response `data` is the full UserProfile (all fields from users table).
- [ ] For **forgot password**: POST `{BASE_URL}/api/auth/forgot-password` with `{ "email": "" }`; then POST `{BASE_URL}/api/auth/reset-password` with `email`, `otp` (from email), `newPassword`, `confirmPassword` (no auth header).
- [ ] **CORS**: Backend allows credentials; for mobile, no CORS issue if using same BASE_URL.

---

*Last synced with backend routes and frontend `src/config/api.ts` and `src/services/api.ts`.*
