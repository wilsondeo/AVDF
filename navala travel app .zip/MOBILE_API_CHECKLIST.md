# Mobile App API Integration Checklist

## Current Configuration

Based on the reference documentation, the mobile app is now configured to match the backend API structure:

### API Endpoints Configured:
- **Base URL**: `http://192.168.1.225:8080`
- **API Prefix**: `/api`

### Endpoints:
1. **Register**: `POST /api/auth/register`
2. **Login**: `POST /api/auth/login`
3. **Get Plans**: `GET /plans` (root level, no /api prefix)
4. **Create Payment Intent**: `POST /api/payments/create-intent`

### Expected Request/Response Format:

#### Register Request:
```json
{
  "email": "user@example.com",
  "password": "SecurePass8",
  "firstName": "John",
  "lastName": "Doe"
}
```

#### Expected Response Format (All Endpoints):
```json
{
  "success": true,
  "message": "Success message",
  "data": {
    // Response data here
  }
}
```

#### Login Response:
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "id": "uuid",
      "email": "user@example.com",
      "role": "PATIENT",
      "firstName": "John",
      "lastName": "Doe"
    },
    "accessToken": "jwt_token_here",
    "refreshToken": "refresh_token_here"
  }
}
```

#### Plans Response:
```json
{
  "success": true,
  "message": "Active plans retrieved successfully",
  "data": {
    "plans": [
      {
        "id": 1,
        "planId": "plan_basic_001",
        "name": "Basic",
        "price": "29.99",
        "validityDays": 30,
        "services": ["TELEHEALTH"],
        "features": ["Feature 1", "Feature 2"],
        "isActive": true
      }
    ],
    "count": 1
  }
}
```

---

## Questions for Web Team

Please verify the following to ensure the mobile app works correctly:

### 1. Server Configuration
- [ ] Is the backend server running at `http://192.168.1.225:8080`?
- [ ] Is the server accessible from other devices on the same network?
- [ ] Is CORS configured to allow requests from mobile devices?

### 2. API Endpoints
- [ ] Does `POST /api/auth/register` accept `{ email, password, firstName, lastName }`?
- [ ] Does `POST /api/auth/login` accept `{ email, password }`?
- [ ] Is `GET /plans` at root level (not `/api/plans`)?
- [ ] Does the response format match the structure above with `{ success, message, data }`?

### 3. Database
- [ ] Are new users being saved to the `users` table with `firstName` and `lastName` fields?
- [ ] Is the `role` field automatically set to `PATIENT` for mobile registrations?
- [ ] Are passwords being hashed with bcrypt?

### 4. Response Structure
- [ ] Do all API responses include `success`, `message`, and `data` fields?
- [ ] Does the login response include `user`, `accessToken`, and `refreshToken` in the `data` object?
- [ ] Does the plans response include `plans` array inside the `data` object?

### 5. Error Handling
- [ ] Do error responses follow this format?
```json
{
  "success": false,
  "message": "Error message here"
}
```

---

## Testing Steps

### Test Registration:
```bash
curl -X POST "http://192.168.1.225:8080/api/auth/register" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "Test1234",
    "firstName": "Test",
    "lastName": "User"
  }'
```

### Test Login:
```bash
curl -X POST "http://192.168.1.225:8080/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "Test1234"
  }'
```

### Test Get Plans:
```bash
curl -X GET "http://192.168.1.225:8080/plans"
```

---

## Common Issues & Solutions

### Issue: 404 Not Found
**Possible Causes:**
- Endpoint path is incorrect
- Server is not running
- API prefix mismatch

**Solution:**
- Verify the exact endpoint paths in the backend
- Check if server is running on port 8080
- Confirm API_PREFIX environment variable

### Issue: Network Error / Timeout
**Possible Causes:**
- Mobile device not on same Wi-Fi network
- Firewall blocking connections
- Wrong IP address

**Solution:**
- Ensure mobile device and server are on same network
- Check Windows Firewall settings
- Verify IP address with `ipconfig`

### Issue: CORS Error (Web Only)
**Possible Causes:**
- CORS not configured on backend

**Solution:**
- Add CORS middleware in backend with proper origins

### Issue: Data Not Saving to Database
**Possible Causes:**
- Database connection issue
- Validation errors
- Missing fields in request

**Solution:**
- Check backend console logs
- Verify database connection
- Ensure all required fields are sent

---

## Mobile App Implementation Details

### Storage:
- **Web**: Uses `localStorage`
- **Native (iOS/Android)**: Uses `expo-secure-store`

### Authentication Flow:
1. User registers → Tokens saved to storage
2. User redirected to login screen
3. User logs in → Tokens saved to storage
4. User redirected to plans screen
5. User selects plan → Payment flow

### API Client Configuration:
- Automatic token attachment via interceptor
- Automatic token refresh on 401 errors
- Response unwrapping (returns `response.data`)

---

## Next Steps

1. **Verify Backend**: Run the curl commands above to test each endpoint
2. **Check Logs**: Monitor backend console for incoming requests
3. **Test Mobile**: Try registration on mobile device
4. **Share Results**: Send back the exact error messages or response data
