import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, Alert, TextInput, Modal } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { ArrowLeft, UserPlus, Users, Calendar, Check, ChevronDown, ChevronLeft } from 'lucide-react-native';
import { UserApi } from '../src/api';

export default function FamilyScreen() {
    const [familyMembers, setFamilyMembers] = useState<any[]>([]);
    const [maxSlots, setMaxSlots] = useState<number>(0);
    const [loading, setLoading] = useState(true);
    const [adding, setAdding] = useState(false);

    // Form state
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [dateOfBirth, setDateOfBirth] = useState('');
    const [gender, setGender] = useState('');
    const [relationship, setRelationship] = useState('');
    
    // Calendar state
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [currentCalDate, setCurrentCalDate] = useState(new Date());
    const [isSelectingYear, setIsSelectingYear] = useState(false);

    useEffect(() => {
        loadFamily();
    }, []);

    const loadFamily = async () => {
        try {
            setLoading(true);
            const familyRes = await UserApi.getFamilyMembers().catch(() => null);
            const planRes = await UserApi.getActivePlan().catch(() => null);

            if (familyRes && familyRes.success && familyRes.data) {
                setFamilyMembers(familyRes.data.familyMembers || []);

                let slots = familyRes.data.maxSlots;
                
                // Get active plan details for reliable slot calculation
                const activePlan = planRes && planRes.success && planRes.data
                    ? (planRes.data.activePlan || planRes.data)
                    : null;
                
                const planName = (activePlan?.plan?.name || '').toLowerCase();
                
                // Explicitly set slots based on plan type to match "Me + X" logic
                if (planName.includes('3-4') || (activePlan?.plan?.maxPersons && activePlan.plan.maxPersons >= 4)) {
                    slots = 4; // User + 3 members
                } else if (planName.includes('family of 2') || planName.includes('family 2') || activePlan?.plan?.maxPersons === 2) {
                    slots = 2; // User + 1 member
                } else if (!slots || slots <= 1) {
                    // Fallback to maxPersons if available, otherwise default to 1 (Individual)
                    slots = activePlan?.plan?.maxPersons || activePlan?.maxPersons || slots || 1;
                }
                
                setMaxSlots(slots);
            }
        } catch (error) {
            Alert.alert('Error', 'Failed to load family members');
        } finally {
            setLoading(false);
        }
    };

    const handleAdd = () => {
        if (!firstName.trim() || !lastName.trim()) {
            Alert.alert('Required', 'First Name and Last Name are required.');
            return;
        }

        Alert.alert(
            'Confirm Addition',
            'Are you sure you want to add this family member to your plan? You will not be able to edit this later.',
            [
                { text: 'Cancel', style: 'cancel' },
                {
                    text: 'Confirm',
                    onPress: async () => {
                        try {
                            setLoading(true);
                            const res = await UserApi.addFamilyMember({
                                firstName: firstName.trim(),
                                lastName: lastName.trim(),
                                dateOfBirth: dateOfBirth.trim() || undefined,
                                gender: gender.trim() || undefined,
                                relationship: relationship.trim() || undefined
                            });
                            if (res.success) {
                                Alert.alert('Success', 'Family member added!');
                                setAdding(false);
                                setFirstName('');
                                setLastName('');
                                setDateOfBirth('');
                                setGender('');
                                setRelationship('');
                                loadFamily();
                            } else {
                                Alert.alert('Error', res.message || 'Failed to add family member');
                            }
                        } catch (error) {
                            Alert.alert('Error', 'An error occurred while adding family member');
                        } finally {
                            setLoading(false);
                        }
                    }
                }
            ]
        );
    };

    const getDaysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
    const getFirstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();

    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    const handleDaySelect = (day: number) => {
        const selected = new Date(currentCalDate.getFullYear(), currentCalDate.getMonth(), day);
        const yyyy = selected.getFullYear();
        const mm = String(selected.getMonth() + 1).padStart(2, '0');
        const dd = String(selected.getDate()).padStart(2, '0');
        setDateOfBirth(`${yyyy}-${mm}-${dd}`);
        setShowDatePicker(false);
    };

    const changeMonth = (direction: number) => {
        const newDate = new Date(currentCalDate.getFullYear(), currentCalDate.getMonth() + direction, 1);
        setCurrentCalDate(newDate);
    };

    const isSelectedDate = (day: number) => {
        if (!dateOfBirth) return false;
        const [y, m, d] = dateOfBirth.split('-').map(Number);
        return currentCalDate.getFullYear() === y &&
            currentCalDate.getMonth() === (m - 1) &&
            day === d;
    };

    const allowedFamily = maxSlots;

    if (loading && !familyMembers.length && !adding) {
        return <View style={styles.center}><ActivityIndicator size="large" color="#2563eb" /></View>;
    }

    return (
        <View style={styles.container}>
            <LinearGradient colors={['#0251fc', '#072169']} style={styles.header}>
                <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
                    <ArrowLeft color="#fff" size={24} />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Family Members</Text>
            </LinearGradient>

            <ScrollView contentContainerStyle={styles.content}>
                {!adding ? (
                    <>
                        <View style={styles.statsCard}>
                            <Users size={24} color="#2563eb" />
                        <Text style={styles.statsText}>
                            {allowedFamily <= 1 
                                ? 'Individual Plan (No family members allowed)' 
                                : `${familyMembers.length} of ${allowedFamily - 1} family member${allowedFamily - 1 > 1 ? 's' : ''} added`
                            }
                        </Text>
                        </View>

                        {familyMembers.length === 0 ? (
                            <View style={styles.emptyState}>
                                <Text style={styles.emptyText}>No family members added yet.</Text>
                            </View>
                        ) : (
                            familyMembers.map((member) => (
                                <View key={member.id} style={styles.memberCard}>
                                    <View style={styles.memberInfo}>
                                        <Text style={styles.memberName}>{member.firstName} {member.lastName}</Text>
                                        <Text style={styles.memberRel}>{member.relationship || 'Family Member'}</Text>
                                    </View>
                                </View>
                            ))
                        )}

                        <TouchableOpacity 
                            style={styles.addButton} 
                            onPress={() => {
                                // If allowedFamily is 2, it means 1 user + 1 family member
                                if (familyMembers.length + 1 >= allowedFamily) {
                                    Alert.alert(
                                        'Plan Limit Reached',
                                        `Your plan allows up to ${allowedFamily} people total (You + ${allowedFamily - 1} family member${allowedFamily - 1 > 1 ? 's' : ''}). You already have ${familyMembers.length} family member${familyMembers.length === 1 ? '' : 's'} added. Please upgrade your plan to add more.`,
                                        [
                                             { text: 'Cancel', style: 'cancel' },
                                             { text: 'Upgrade Plan', onPress: () => router.push('/plans') }
                                         ]
                                    );
                                } else {
                                    setAdding(true);
                                }
                            }}
                        >
                            <UserPlus size={20} color="#fff" />
                            <Text style={styles.addButtonText}>Add New Member</Text>
                        </TouchableOpacity>
                    </>
                ) : (
                    <View style={styles.formCard}>
                        <Text style={styles.formTitle}>Add Family Member</Text>

                        <Text style={styles.label}>First Name *</Text>
                        <TextInput
                            style={styles.input}
                            value={firstName}
                            onChangeText={setFirstName}
                            placeholder="e.g. Jane"
                        />

                        <Text style={styles.label}>Last Name *</Text>
                        <TextInput
                            style={styles.input}
                            value={lastName}
                            onChangeText={setLastName}
                            placeholder="e.g. Doe"
                        />

                        <Text style={styles.label}>Date of Birth (Optional)</Text>
                        <TouchableOpacity 
                            style={styles.datePickerTrigger} 
                            onPress={() => {
                                if (dateOfBirth) {
                                    const [y, m, d] = dateOfBirth.split('-').map(Number);
                                    if (!isNaN(y)) {
                                        setCurrentCalDate(new Date(y, m - 1, d));
                                    }
                                }
                                setShowDatePicker(true);
                            }}
                        >
                            <Text style={[styles.dateText, !dateOfBirth && styles.placeholderText]}>
                                {dateOfBirth || "Select Date"}
                            </Text>
                            <Calendar size={20} color="#94a3b8" />
                        </TouchableOpacity>

                        <Text style={styles.label}>Gender</Text>
                        <View style={styles.pillsRow}>
                            {['Male', 'Female', 'Other'].map(opt => (
                                <TouchableOpacity
                                    key={opt}
                                    style={[styles.pill, gender === opt && styles.pillActive]}
                                    onPress={() => setGender(opt)}
                                >
                                    <Text style={[styles.pillText, gender === opt && styles.pillTextActive]}>{opt}</Text>
                                </TouchableOpacity>
                            ))}
                        </View>

                        <Text style={styles.label}>Relationship</Text>
                        <View style={styles.pillsRow}>
                            {['Spouse', 'Child', 'Sibling', 'Parent', 'Other'].map(opt => (
                                <TouchableOpacity
                                    key={opt}
                                    style={[styles.pill, relationship === opt && styles.pillActive]}
                                    onPress={() => setRelationship(opt)}
                                >
                                    <Text style={[styles.pillText, relationship === opt && styles.pillTextActive]}>{opt}</Text>
                                </TouchableOpacity>
                            ))}
                        </View>

                        <View style={styles.formActions}>
                            <TouchableOpacity style={styles.cancelButton} onPress={() => setAdding(false)}>
                                <Text style={styles.cancelText}>Cancel</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.saveButton} onPress={handleAdd}>
                                <Text style={styles.saveText}>Save Member</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                )}
            </ScrollView>

            <Modal visible={showDatePicker} transparent animationType="fade">
                <View style={styles.modalOverlay}>
                    <View style={styles.calendarModal}>
                        <View style={styles.calHeader}>
                            {!isSelectingYear && (
                                <TouchableOpacity style={styles.calNav} onPress={() => changeMonth(-1)}>
                                    <ChevronLeft size={24} color="#1e293b" />
                                </TouchableOpacity>
                            )}
                            <TouchableOpacity style={styles.monthYearDisplay} onPress={() => setIsSelectingYear(!isSelectingYear)}>
                                <Text style={styles.calMonthText}>
                                    {isSelectingYear ? "Select Year" : `${monthNames[currentCalDate.getMonth()]} ${currentCalDate.getFullYear()}`}
                                </Text>
                                <ChevronDown size={16} color="#1e293b" style={{ marginLeft: 4, transform: [{ rotate: isSelectingYear ? '180deg' : '0deg' }] }} />
                            </TouchableOpacity>
                            {!isSelectingYear && (
                                <TouchableOpacity style={styles.calNav} onPress={() => changeMonth(1)}>
                                    <ChevronLeft size={24} color="#1e293b" style={{ transform: [{ rotate: '180deg' }] }} />
                                </TouchableOpacity>
                            )}
                        </View>

                        {isSelectingYear ? (
                            <ScrollView style={styles.yearGrid} showsVerticalScrollIndicator={false}>
                                <View style={styles.yearGridInner}>
                                    {Array.from({ length: 121 }).map((_, i) => {
                                        const y = new Date().getFullYear() - i;
                                        return (
                                            <TouchableOpacity
                                                key={y}
                                                style={[styles.yearItem, currentCalDate.getFullYear() === y && styles.yearItemActive]}
                                                onPress={() => {
                                                    setCurrentCalDate(new Date(y, currentCalDate.getMonth(), 1));
                                                    setIsSelectingYear(false);
                                                }}
                                            >
                                                <Text style={[styles.yearItemText, currentCalDate.getFullYear() === y && styles.yearItemTextActive]}>{y}</Text>
                                            </TouchableOpacity>
                                        );
                                    })}
                                </View>
                            </ScrollView>
                        ) : (
                            <>
                                <View style={styles.calWeekdays}>
                                    {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map(d => (
                                        <Text key={d} style={styles.calWeekdayText}>{d}</Text>
                                    ))}
                                </View>

                                <View style={styles.calDaysGrid}>
                                    {Array.from({ length: getFirstDayOfMonth(currentCalDate.getFullYear(), currentCalDate.getMonth()) }).map((_, i) => (
                                        <View key={`blank-${i}`} style={styles.calDayWrap} />
                                    ))}
                                    {Array.from({ length: getDaysInMonth(currentCalDate.getFullYear(), currentCalDate.getMonth()) }).map((_, i) => {
                                        const d = i + 1;
                                        const selected = isSelectedDate(d);
                                        return (
                                            <TouchableOpacity
                                                key={d}
                                                style={[styles.calDayWrap, selected && styles.calDayWrapActive]}
                                                onPress={() => handleDaySelect(d)}
                                            >
                                                <Text style={[styles.calDayText, selected && styles.calDayTextActive]}>{d}</Text>
                                            </TouchableOpacity>
                                        );
                                    })}
                                </View>
                            </>
                        )}

                        <TouchableOpacity style={styles.closeCalBtn} onPress={() => { setShowDatePicker(false); setIsSelectingYear(false); }}>
                            <Text style={styles.closeCalText}>Cancel</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f9fafb' },
    center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
    header: { paddingTop: 60, paddingBottom: 24, paddingHorizontal: 20, flexDirection: 'row', alignItems: 'center', gap: 16 },
    backButton: { padding: 4 },
    headerTitle: { fontSize: 22, fontWeight: '700', color: '#ffffff' },
    content: { padding: 20 },

    statsCard: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: '#eff6ff', padding: 16, borderRadius: 12, marginBottom: 20 },
    statsText: { fontSize: 14, fontWeight: '600', color: '#1d4ed8' },

    emptyState: { padding: 30, alignItems: 'center', backgroundColor: '#fff', borderRadius: 16, borderStyle: 'dashed', borderWidth: 1, borderColor: '#d1d5db', marginBottom: 20 },
    emptyText: { color: '#6b7280', fontSize: 14 },

    memberCard: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#fff', padding: 16, borderRadius: 12, marginBottom: 12, elevation: 1 },
    memberInfo: { flex: 1 },
    memberName: { fontSize: 16, fontWeight: '600', color: '#111827' },
    memberRel: { fontSize: 13, color: '#6b7280', marginTop: 4 },
    deleteBtn: { padding: 8, backgroundColor: '#fee2e2', borderRadius: 8 },

    addButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#2563eb', padding: 16, borderRadius: 12, marginTop: 10 },
    addButtonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
    limitText: { textAlign: 'center', color: '#ef4444', fontSize: 13, marginTop: 20, paddingHorizontal: 10 },

    formCard: { backgroundColor: '#fff', padding: 20, borderRadius: 16, elevation: 2 },
    formTitle: { fontSize: 18, fontWeight: '700', color: '#111827', marginBottom: 20 },
    label: { fontSize: 13, fontWeight: '600', color: '#4b5563', marginBottom: 8 },
    input: { backgroundColor: '#f9fafb', borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, padding: 12, fontSize: 15, marginBottom: 16 },
    pillsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 },
    pill: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, backgroundColor: '#f1f5f9', borderWidth: 1, borderColor: '#cbd5e1' },
    pillActive: { backgroundColor: '#dbeafe', borderColor: '#3b82f6' },
    pillText: { fontSize: 13, color: '#475569', fontWeight: '500' },
    pillTextActive: { color: '#1d4ed8', fontWeight: '600' },
    formActions: { flexDirection: 'row', gap: 12, marginTop: 10 },
    cancelButton: { flex: 1, padding: 14, backgroundColor: '#f3f4f6', borderRadius: 10, alignItems: 'center' },
    cancelText: { color: '#4b5563', fontWeight: '600', fontSize: 15 },
    saveButton: { flex: 1, padding: 14, backgroundColor: '#2563eb', borderRadius: 10, alignItems: 'center' },
    saveText: { color: '#fff', fontWeight: '600', fontSize: 15 },

    datePickerTrigger: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#f9fafb', borderWidth: 1, borderColor: '#d1d5db', borderRadius: 8, padding: 12, marginBottom: 16 },
    dateText: { fontSize: 15, color: '#111827' },
    placeholderText: { color: '#94a3b8' },

    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
    calendarModal: { width: '90%', backgroundColor: '#fff', borderRadius: 16, padding: 20, elevation: 5, maxHeight: '80%' },
    calHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
    monthYearDisplay: { flexDirection: 'row', alignItems: 'center', padding: 8, backgroundColor: '#f8fafc', borderRadius: 8 },
    calNav: { padding: 8, backgroundColor: '#f1f5f9', borderRadius: 8 },
    calMonthText: { fontSize: 18, fontWeight: '700', color: '#0f172a' },
    calWeekdays: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 12 },
    calWeekdayText: { width: 32, textAlign: 'center', fontSize: 13, fontWeight: '600', color: '#94a3b8' },
    calDaysGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'flex-start' },
    calDayWrap: { width: '14.28%', aspectRatio: 1, justifyContent: 'center', alignItems: 'center', marginBottom: 4 },
    calDayWrapActive: { backgroundColor: '#2563eb', borderRadius: 10 },
    calDayText: { fontSize: 15, color: '#1e293b', fontWeight: '500' },
    calDayTextActive: { color: '#ffffff', fontWeight: '700' },
    yearGrid: { maxHeight: 300 },
    yearGridInner: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
    yearItem: { width: '30%', paddingVertical: 12, alignItems: 'center', marginBottom: 8, borderRadius: 8, backgroundColor: '#f1f5f9' },
    yearItemActive: { backgroundColor: '#2563eb' },
    yearItemText: { fontSize: 15, fontWeight: '600', color: '#1e293b' },
    yearItemTextActive: { color: '#fff' },
    closeCalBtn: { marginTop: 20, padding: 15, backgroundColor: '#f1f5f9', borderRadius: 10, alignItems: 'center' },
    closeCalText: { color: '#4b5563', fontWeight: '600', fontSize: 15 },
});
