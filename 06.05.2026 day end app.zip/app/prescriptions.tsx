import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ActivityIndicator,
    ScrollView,
    TouchableOpacity,
    RefreshControl,
    TextInput,
    LayoutAnimation,
    Platform,
    UIManager
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { PrescriptionApi, UserApi, Prescription } from '../src/api';
import { printDocument } from '../src/utils/print';
import { Alert } from 'react-native';
import { 
    ArrowLeft, 
    Pill, 
    FileText, 
    Stethoscope, 
    Clock, 
    User, 
    Download,
    CheckCircle2,
    Activity,
    AlertTriangle,
    Search,
    ChevronDown,
    ChevronUp,
    Users
} from 'lucide-react-native';
import { format } from 'date-fns';
import { LinearGradient } from 'expo-linear-gradient';

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
    UIManager.setLayoutAnimationEnabledExperimental(true);
}

export default function PrescriptionsScreen() {
    const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [expandedId, setExpandedId] = useState<number | null>(null);
    const [printingId, setPrintingId] = useState<number | null>(null);
    const [userData, setUserData] = useState<any>(null);

    const generatePrescriptionHtml = (prescription: any, userProfile: any) => {
        const dateIssued = prescription.createdAt || prescription.created_at;
        const formattedDate = dateIssued ? format(new Date(dateIssued), 'MMMM dd, yyyy') : 'N/A';
        const doctorName = prescription.Doctor?.User 
            ? `Dr. ${prescription.Doctor.User.firstName} ${prescription.Doctor.User.lastName}` 
            : (prescription.doctorName || 'Medical Provider');
        const docSpec = prescription.Doctor?.specialization || 'Attending Physician';
        
        const pFamily = prescription.Appointment?.request?.familyMember;
        const accountHolder = prescription.patient || userProfile || { firstName: 'Unknown', lastName: '' };
        const patient = pFamily || accountHolder;
        const patientName = `${patient.firstName || ''} ${patient.lastName || ''}`.trim() || 'Primary Member';
        const patDob = patient.dateOfBirth || '--';
        const patGender = patient.gender || '--';

        return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Prescription</title>
    <style>
        body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; padding: 0; background-color: #ffffff; color: #1e293b; -webkit-print-color-adjust: exact; print-color-adjust: exact; margin: 0; }
        .container { max-width: 800px; margin: 0 auto; background-color: #ffffff; padding: 40px; min-height: 1000px; position: relative; }
        .flex { display: flex; }
        .justify-between { justify-content: space-between; }
        .items-center { align-items: center; }
        .items-start { align-items: flex-start; }
        .items-end { align-items: flex-end; }
        .gap-1 { gap: 0.25rem; }
        .gap-2 { gap: 0.5rem; }
        .gap-3 { gap: 0.75rem; }
        .gap-4 { gap: 1rem; }
        .gap-8 { gap: 2rem; }
        
        .border-b-2 { border-bottom: 2px solid rgba(30, 58, 138, 0.2); padding-bottom: 1.5rem; margin-bottom: 2rem; }
        .logo-box { width: 56px; height: 56px; background-color: #1e3a8a; border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white; }
        .header-title { font-size: 24px; font-weight: 900; color: #0f172a; letter-spacing: -0.025em; margin: 0; }
        .header-subtitle { font-size: 14px; font-weight: 600; color: #1e3a8a; text-transform: uppercase; letter-spacing: 0.1em; margin: 0; }
        
        .contact-info { text-align: right; font-size: 12px; color: #64748b; line-height: 1.5; }
        .contact-row { display: flex; align-items: center; justify-content: flex-end; gap: 4px; margin-bottom: 4px; }
        
        .rx-logo { font-family: 'Times New Roman', Times, serif; font-style: italic; font-size: 30px; font-weight: 900; color: #cbd5e1; letter-spacing: -0.05em; margin: 0 0 -8px 0; }
        .doc-title { font-size: 20px; font-weight: bold; color: #0f172a; margin: 0; }
        .doc-id { font-size: 12px; font-weight: bold; color: #94a3b8; margin: 0; }
        
        .provider-box { background-color: #f8fafc; border: 1px solid #f1f5f9; border-radius: 12px; padding: 16px; text-align: right; }
        .label-xs { font-size: 10px; font-weight: bold; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.1em; margin: 0 0 4px 0; }
        .val-sm { font-size: 14px; font-weight: bold; color: #0f172a; margin: 0; }
        .val-xs { font-size: 12px; color: #64748b; margin: 0; }
        
        .patient-box { background-color: rgba(30, 58, 138, 0.05); border: 1px solid rgba(30, 58, 138, 0.1); border-radius: 16px; padding: 24px; display: flex; justify-content: space-between; margin-bottom: 2.5rem; }
        .pat-label { font-size: 10px; font-weight: bold; color: #1e3a8a; text-transform: uppercase; letter-spacing: 0.1em; margin: 0 0 4px 0; }
        .pat-name { font-size: 18px; font-weight: 900; color: #0f172a; margin: 0; }
        .pat-sub { font-size: 12px; font-weight: 600; color: #2563eb; margin: 4px 0 0 0; }
        .pat-info { font-size: 14px; font-weight: 600; color: #334155; margin: 0; }
        
        .section-header { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; }
        .section-title { font-size: 18px; font-weight: bold; color: #0f172a; margin: 0; }
        .diag-text { font-size: 16px; font-weight: 500; color: #334155; margin: 0 0 0 28px; line-height: 1.6; }
        
        .med-section-header { display: flex; align-items: center; gap: 8px; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; margin-bottom: 16px; }
        .med-list { padding-left: 28px; }
        .med-row { display: flex; gap: 16px; margin-bottom: 24px; }
        .med-num { font-size: 14px; font-weight: 900; color: #cbd5e1; margin-top: 2px; }
        .med-content { flex: 1; }
        .med-name { font-size: 18px; font-weight: bold; color: #0f172a; margin: 0 0 4px 0; }
        
        .med-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 8px; }
        .med-label { font-size: 10px; font-weight: bold; color: #94a3b8; text-transform: uppercase; margin: 0; }
        .med-val { font-size: 14px; font-weight: 600; margin: 0; }
        
        .med-inst { font-size: 12px; font-weight: bold; color: #0891b2; background-color: #cffafe; display: inline-block; padding: 4px 8px; border-radius: 6px; margin: 0; }
        
        .grid-2 { display: grid; grid-template-columns: repeat(2, 1fr); gap: 32px; margin-bottom: 64px; }
        .advice-header { font-size: 10px; font-weight: bold; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.1em; border-bottom: 1px solid #f1f5f9; padding-bottom: 4px; margin: 0 0 8px 0; }
        .advice-text { font-size: 14px; color: #334155; line-height: 1.6; margin: 0; }
        .restr-header { font-size: 10px; font-weight: bold; color: #f87171; text-transform: uppercase; letter-spacing: 0.1em; border-bottom: 1px solid #fef2f2; padding-bottom: 4px; margin: 0 0 8px 0; }
        .restr-text { font-size: 14px; font-weight: 600; color: #dc2626; line-height: 1.6; margin: 0; }
        
        .footer { margin-top: 80px; display: flex; justify-content: space-between; align-items: flex-end; border-top: 2px solid #f1f5f9; padding-top: 32px; }
        .footer-note { font-size: 12px; color: #94a3b8; margin: 0; }
        .sig-box { width: 192px; text-align: center; }
        .sig-line { border-bottom: 2px solid #1e293b; padding-bottom: 4px; margin-bottom: 8px; }
        .sig-script { font-family: 'Times New Roman', Times, serif; font-style: italic; font-size: 24px; color: #1e293b; opacity: 0.8; margin: 0; }
        .sig-label { font-size: 10px; font-weight: bold; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.1em; margin: 0; }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="flex justify-between items-center border-b-2">
            <div class="flex items-center gap-3">
                <div class="logo-box">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 6v4"/><path d="M14 14h-4"/><path d="M14 18h-4"/><path d="M14 8h-4"/><path d="M18 12h2a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-9a2 2 0 0 1 2-2h2"/><path d="M18 22V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v18"/></svg>
                </div>
                <div>
                    <h1 class="header-title">Navala Travel Health</h1>
                    <p class="header-subtitle">Global Telemedicine</p>
                </div>
            </div>
            <div class="contact-info">
                <div class="contact-row">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                    <span>+1 (800) 555-0199</span>
                </div>
                <div class="contact-row">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                    <span>care@navala.health</span>
                </div>
                <div class="contact-row">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                    <span>123 Health Way, New York, NY</span>
                </div>
            </div>
        </div>

        <!-- Prescription Metadata -->
        <div class="flex justify-between items-start mb-10">
            <div>
                <h2 class="rx-logo">Rx</h2>
                <h3 class="doc-title">Medical Prescription</h3>
                <p class="doc-id">ID: ${prescription.prescriptionUuid || prescription.id}</p>
            </div>
            <div class="provider-box">
                <p class="label-xs">Date of Issue</p>
                <p class="val-sm">${formattedDate}</p>
                <p class="label-xs" style="margin-top: 12px;">Prescribing Doctor</p>
                <p class="val-sm">${doctorName}</p>
                <p class="val-xs">${docSpec}</p>
            </div>
        </div>

        <!-- Patient Details -->
        <div class="patient-box">
            <div>
                <p class="pat-label">Patient Name</p>
                <p class="pat-name">${patientName}</p>
                ${pFamily ? `<p class="pat-sub">${pFamily.relationship || 'Family Member'} of ${accountHolder.firstName || 'Unknown'} ${accountHolder.lastName || ''}</p>` : ''}
            </div>
            <div style="text-align: right;">
                <p class="pat-label">Patient Info</p>
                <p class="pat-info">DOB: ${patDob}</p>
                <p class="pat-info">Gender: ${patGender}</p>
            </div>
        </div>

        <!-- Diagnosis -->
        <div style="margin-bottom: 40px;">
            <div class="section-header">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1e3a8a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.8 2.3A.3.3 0 1 0 5 2H4a2 2 0 0 0-2 2v5a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6V4a2 2 0 0 0-2-2h-1a.2.2 0 1 0 .3.3"/><path d="M8 15v1a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6v-4"/><circle cx="20" cy="10" r="2"/></svg>
                <h4 class="section-title">Diagnosis</h4>
            </div>
            <p class="diag-text">${prescription.diagnosis}</p>
        </div>

        <!-- Medicines -->
        <div style="margin-bottom: 48px;">
            <div class="med-section-header">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0891b2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"/><path d="m8.5 8.5 7 7"/></svg>
                <h4 class="section-title">Medication Instructions</h4>
            </div>
            <div class="med-list">
                ${prescription.medicines?.map((med: any, i: number) => `
                    <div class="med-row">
                        <div class="med-num">${i + 1}.</div>
                        <div class="med-content">
                            <h5 class="med-name">${med.name || med.medicineName}</h5>
                            <div class="med-grid">
                                <div>
                                    <p class="med-label">Dosage</p>
                                    <p class="med-val">${med.dosage}</p>
                                </div>
                                <div>
                                    <p class="med-label">Frequency</p>
                                    <p class="med-val">${med.frequency}</p>
                                </div>
                                <div>
                                    <p class="med-label">Duration</p>
                                    <p class="med-val">${med.duration}</p>
                                </div>
                            </div>
                            ${med.foodInstructions ? `<p class="med-inst">${med.foodInstructions}</p>` : ''}
                        </div>
                    </div>
                `).join('') || ''}
            </div>
        </div>

        <!-- Advice and Restrictions -->
        <div class="grid-2">
            ${prescription.generalAdvice ? `
                <div>
                    <h4 class="advice-header">General Advice</h4>
                    <p class="advice-text">${prescription.generalAdvice}</p>
                </div>
            ` : ''}
            ${prescription.restrictions ? `
                <div>
                    <h4 class="restr-header">Restrictions</h4>
                    <p class="restr-text">${prescription.restrictions}</p>
                </div>
            ` : ''}
        </div>

        <!-- Footer -->
        <div class="footer">
            <div class="footer-note">
                <p style="margin-bottom: 4px;">This is a digitally generated and verified document.</p>
                <p>Valid only with the authorized provider's details above.</p>
            </div>
            <div class="sig-box">
                <div class="sig-line">
                    <p class="sig-script">${doctorName.replace('Dr. ', '')}</p>
                </div>
                <p class="sig-label">Provider Signature</p>
            </div>
        </div>
    </div>
</body>
</html>
        `;
    };

    const handlePrint = async (prescription: Prescription) => {
        try {
            setPrintingId(prescription.id);
            const dateSuffix = format(new Date(), 'MMM_dd');
            const customHtml = generatePrescriptionHtml(prescription, userData);
            await printDocument(`/api/shared/prescription/${prescription.prescriptionUuid}/view`, `Navala_Prescription_${dateSuffix}.pdf`, customHtml);
        } catch (error) {
            Alert.alert('Download Failed', 'The server could not generate your prescription PDF at this moment.');
        } finally {
            setPrintingId(null);
        }
    };

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            if (!refreshing) setLoading(true);
            const [prescRes, userRes] = await Promise.all([
                PrescriptionApi.getForPatient(),
                UserApi.getProfile()
            ]);
            
            if (userRes.success && userRes.data) {
                setUserData(userRes.data);
            }
            
            if (prescRes.success && prescRes.data) {
                setPrescriptions(prescRes.data);
                if (prescRes.data.length > 0) {
                    setExpandedId(prescRes.data[0].id);
                }
            }
        } catch (error) {
            console.error('Failed to load prescriptions:', error);
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    const toggleExpand = (id: number) => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        setExpandedId(expandedId === id ? null : id);
    };

    const onRefresh = () => {
        setRefreshing(true);
        loadData();
    };

    const filteredPrescriptions = prescriptions.filter(p => {
        const docName = p.Doctor?.User ? `${p.Doctor.User.firstName} ${p.Doctor.User.lastName}` : '';
        const diagnosis = p.diagnosis || '';
        return (
            diagnosis.toLowerCase().includes(searchTerm.toLowerCase()) ||
            docName.toLowerCase().includes(searchTerm.toLowerCase())
        );
    });

    const totalMedicines = prescriptions.reduce((acc, p) => acc + (p.medicines?.length || 0), 0);

    if (loading && !refreshing) {
        return (
            <View style={styles.center}>
                <ActivityIndicator size="large" color="#0251fc" />
                <Text style={styles.loadingText}>Retrieving medical records...</Text>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <LinearGradient colors={['#0251fc', '#072169']} style={styles.header}>
                <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
                    <ArrowLeft color="#ffffff" size={24} />
                </TouchableOpacity>
                <Text style={[styles.headerTitle, { color: '#ffffff' }]}>Prescriptions</Text>
                <View style={{ width: 40 }} />
            </LinearGradient>

            <ScrollView 
                contentContainerStyle={styles.scrollContent}
                refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
                showsVerticalScrollIndicator={false}
            >
                {/* Hero Header */}
                <LinearGradient 
                    colors={['#0251fc', '#023fb3']} 
                    start={{ x: 0, y: 0 }} 
                    end={{ x: 1, y: 1 }}
                    style={styles.heroHeader}
                >
                    <View style={styles.heroContent}>
                        <View>
                            <View style={styles.heroLabelRow}>
                                <FileText size={14} color="rgba(255,255,255,0.7)" />
                                <Text style={styles.heroLabel}>MEDICAL RECORDS</Text>
                            </View>
                            <Text style={styles.heroTitle}>My Prescriptions</Text>
                            <Text style={styles.heroSubtitle}>Digital prescription history</Text>
                        </View>
                        <View style={styles.heroStats}>
                            <View style={styles.heroStatBox}>
                                <Text style={styles.heroStatValue}>{prescriptions.length}</Text>
                                <Text style={styles.heroStatLabel}>TOTAL RX</Text>
                            </View>
                            <View style={styles.heroStatBox}>
                                <Text style={styles.heroStatValue}>{totalMedicines}</Text>
                                <Text style={styles.heroStatLabel}>MEDS</Text>
                            </View>
                        </View>
                    </View>
                </LinearGradient>

                {/* Search Bar */}
                <View style={styles.searchContainer}>
                    <Search size={18} color="#94a3b8" style={styles.searchIcon} />
                    <TextInput 
                        style={styles.searchInput}
                        placeholder="Search by diagnosis or doctor..."
                        value={searchTerm}
                        onChangeText={setSearchTerm}
                        placeholderTextColor="#94a3b8"
                    />
                </View>

                {/* List */}
                <View style={styles.listContainer}>
                    {filteredPrescriptions.length === 0 ? (
                        <View style={styles.emptyContainer}>
                            <View style={styles.emptyIconCircle}>
                                <FileText size={40} color="#cbd5e1" />
                            </View>
                            <Text style={styles.emptyTitle}>No Prescriptions Found</Text>
                            <Text style={styles.emptySubtitle}>Your medical records will appear here after a consultation.</Text>
                        </View>
                    ) : (
                        filteredPrescriptions.map((item, index) => (
                            <PrescriptionCard 
                                key={item.id} 
                                item={item} 
                                isExpanded={expandedId === item.id}
                                isPrinting={printingId === item.id}
                                onToggle={() => toggleExpand(item.id)}
                                onDownload={() => handlePrint(item)}
                            />
                        ))
                    )}
                </View>
            </ScrollView>
        </View>
    );
}

function PrescriptionCard({ item, isExpanded, isPrinting, onToggle, onDownload }: { item: Prescription, isExpanded: boolean, isPrinting: boolean, onToggle: () => void, onDownload: () => void }) {
    const dateIssued = item.createdAt || item.created_at;
    const doctorName = item.Doctor?.User 
        ? `Dr. ${item.Doctor.User.firstName} ${item.Doctor.User.lastName}` 
        : (item.doctorName || 'Medical Officer');
    const medicineCount = item.medicines?.length || 0;

    return (
        <View style={styles.cardWrapper}>
            <TouchableOpacity 
                activeOpacity={0.7} 
                onPress={onToggle}
                style={[styles.cardHeader, isExpanded && styles.cardHeaderExpanded]}
            >
                <View style={styles.cardIconBox}>
                    <Stethoscope size={22} color="#0251fc" />
                </View>
                <View style={styles.cardMainInfo}>
                    <Text style={styles.cardDiagnosis} numberOfLines={1}>{item.diagnosis}</Text>
                    <View style={styles.cardMeta}>
                        <View style={styles.metaBadge}>
                            <Clock size={12} color="#64748b" />
                            <Text style={styles.metaBadgeText}>
                                {dateIssued ? format(new Date(dateIssued), 'MMM dd, yyyy') : 'N/A'}
                            </Text>
                        </View>
                        <View style={styles.metaBadge}>
                            <User size={12} color="#64748b" />
                            <Text style={styles.metaBadgeText}>{doctorName}</Text>
                        </View>
                    </View>
                    <View style={styles.statusRow}>
                        <View style={styles.issuedBadge}>
                            <CheckCircle2 size={10} color="#059669" />
                            <Text style={styles.issuedBadgeText}>ISSUED</Text>
                        </View>
                        <View style={styles.countBadge}>
                            <Pill size={10} color="#64748b" />
                            <Text style={styles.countBadgeText}>{medicineCount} Meds</Text>
                        </View>
                        {item.Appointment?.request?.familyMember && (
                            <View style={styles.familyBadge}>
                                <Users size={10} color="#6366f1" />
                                <Text style={styles.familyBadgeText}>
                                    {item.Appointment.request.familyMember.firstName} {item.Appointment.request.familyMember.lastName}
                                </Text>
                            </View>
                        )}
                    </View>
                </View>
                <View style={styles.expandIconBox}>
                    {isExpanded ? <ChevronUp size={20} color="#94a3b8" /> : <ChevronDown size={20} color="#94a3b8" />}
                </View>
            </TouchableOpacity>

            {isExpanded && (
                <View style={styles.cardExpandedContent}>
                    {/* Doctor Details */}
                    <View style={styles.expandedSection}>
                        <View style={styles.doctorInfoRow}>
                            <View style={styles.doctorAvatar}>
                                <Text style={styles.doctorAvatarText}>{item.Doctor?.User?.firstName?.charAt(0) || 'D'}</Text>
                            </View>
                            <View>
                                <Text style={styles.expandedDocName}>{doctorName}</Text>
                                <Text style={styles.expandedDocSpec}>{item.Doctor?.specialization || 'Attending Physician'}</Text>
                            </View>
                            <View style={styles.physicianBadge}>
                                <Text style={styles.physicianBadgeText}>Prescribing Physician</Text>
                            </View>
                        </View>
                    </View>

                    {/* Advice/Restrictions */}
                    {(item.generalAdvice || item.restrictions) && (
                        <View style={styles.notesGrid}>
                            {item.generalAdvice && (
                                <View style={styles.adviceCard}>
                                    <View style={styles.noteHeader}>
                                        <Activity size={14} color="#059669" />
                                        <Text style={styles.adviceLabel}>ADVICE</Text>
                                    </View>
                                    <Text style={styles.noteText}>{item.generalAdvice}</Text>
                                </View>
                            )}
                            {item.restrictions && (
                                <View style={styles.restrictionCard}>
                                    <View style={styles.noteHeader}>
                                        <AlertTriangle size={14} color="#dc2626" />
                                        <Text style={styles.restrictionLabel}>RESTRICTIONS</Text>
                                    </View>
                                    <Text style={styles.noteText}>{item.restrictions}</Text>
                                </View>
                            )}
                        </View>
                    )}

                    {/* Medicines */}
                    <View style={styles.expandedSection}>
                        <View style={styles.sectionHeaderRow}>
                            <Pill size={16} color="#64748b" />
                            <Text style={styles.sectionLabel}>PRESCRIBED MEDICINES</Text>
                        </View>
                        {item.medicines.map((med, idx) => (
                            <View key={idx} style={styles.medItem}>
                                <View style={styles.medItemHeader}>
                                    <View style={styles.medNumber}>
                                        <Text style={styles.medNumberText}>{idx + 1}</Text>
                                    </View>
                                    <Text style={styles.medName}>{med.medicineName || (med as any).name}</Text>
                                </View>
                                <View style={styles.medBadgeRow}>
                                    <View style={styles.medSpecBadge}>
                                        <Text style={styles.medSpecText}>💊 {med.dosage}</Text>
                                    </View>
                                    <View style={styles.medSpecBadgeGray}>
                                        <Text style={styles.medSpecTextGray}>🔁 {med.frequency}x daily</Text>
                                    </View>
                                    {med.duration && (
                                        <View style={styles.medSpecBadgeGray}>
                                            <Text style={styles.medSpecTextGray}>📅 {med.duration} days</Text>
                                        </View>
                                    )}
                                </View>
                                {med.foodInstructions && (
                                    <View style={styles.foodInstBox}>
                                        <Text style={styles.foodInstText}>🍽️ {med.foodInstructions}</Text>
                                    </View>
                                )}
                            </View>
                        ))}
                    </View>

                    {/* Download Button */}
                    <TouchableOpacity 
                        style={[styles.downloadCardBtn, isPrinting && { opacity: 0.7 }]} 
                        onPress={onDownload}
                        disabled={isPrinting}
                    >
                        {isPrinting ? (
                            <ActivityIndicator size="small" color="#fff" />
                        ) : (
                            <Download size={18} color="#fff" />
                        )}
                        <Text style={styles.downloadCardBtnText}>
                            {isPrinting ? 'Preparing Document...' : 'Download as PDF'}
                        </Text>
                    </TouchableOpacity>
                </View>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f8fafc' },
    center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
    loadingText: { marginTop: 12, color: '#64748b', fontWeight: '600' },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 20,
        paddingTop: 50,
        paddingBottom: 16,
    },
    headerTitle: { fontSize: 18, fontWeight: '800', color: '#1e293b' },
    backButton: { width: 44, height: 44, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.2)', justifyContent: 'center', alignItems: 'center' },
    scrollContent: { paddingBottom: 40 },
    
    heroHeader: {
        marginHorizontal: 20,
        marginTop: 10,
        borderRadius: 24,
        padding: 24,
        shadowColor: '#0251fc',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.2,
        shadowRadius: 20,
        elevation: 8,
    },
    heroContent: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    heroLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 8 },
    heroLabel: { fontSize: 10, fontWeight: '900', color: 'rgba(255,255,255,0.7)', letterSpacing: 1 },
    heroTitle: { fontSize: 24, fontWeight: '900', color: '#fff' },
    heroSubtitle: { fontSize: 13, color: 'rgba(255,255,255,0.6)', marginTop: 2 },
    heroStats: { flexDirection: 'row', gap: 12 },
    heroStatBox: { 
        backgroundColor: 'rgba(255,255,255,0.15)', 
        padding: 12, 
        borderRadius: 16, 
        alignItems: 'center', 
        minWidth: 70 
    },
    heroStatValue: { color: '#fff', fontSize: 20, fontWeight: '900' },
    heroStatLabel: { color: 'rgba(255,255,255,0.7)', fontSize: 8, fontWeight: '800', marginTop: 2 },

    searchContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        marginHorizontal: 20,
        marginTop: 25,
        borderRadius: 16,
        paddingHorizontal: 16,
        height: 54,
        borderWidth: 1,
        borderColor: '#e2e8f0',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 10,
        elevation: 2
    },
    searchIcon: { marginRight: 12 },
    searchInput: { flex: 1, fontSize: 15, fontWeight: '500', color: '#1e293b' },

    listContainer: { paddingHorizontal: 20, marginTop: 20, gap: 16 },
    cardWrapper: {
        backgroundColor: '#fff',
        borderRadius: 24,
        borderWidth: 1,
        borderColor: '#e2e8f0',
        overflow: 'hidden',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.03,
        shadowRadius: 10,
        elevation: 2
    },
    cardHeader: {
        flexDirection: 'row',
        padding: 16,
        alignItems: 'center',
    },
    cardHeaderExpanded: {
        borderBottomWidth: 1,
        borderBottomColor: '#f1f5f9',
        backgroundColor: '#f8fafc'
    },
    cardIconBox: {
        width: 48,
        height: 48,
        borderRadius: 16,
        backgroundColor: '#eff6ff',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 16
    },
    cardMainInfo: { flex: 1 },
    cardDiagnosis: { fontSize: 17, fontWeight: '800', color: '#1e293b' },
    cardMeta: { flexDirection: 'row', gap: 12, marginTop: 4 },
    metaBadge: { flexDirection: 'row', alignItems: 'center', gap: 4 },
    metaBadgeText: { fontSize: 12, color: '#64748b', fontWeight: '600' },
    statusRow: { flexDirection: 'row', gap: 10, marginTop: 10 },
    issuedBadge: { 
        flexDirection: 'row', 
        alignItems: 'center', 
        gap: 4, 
        backgroundColor: '#ecfdf5', 
        paddingHorizontal: 8, 
        paddingVertical: 3, 
        borderRadius: 6 
    },
    issuedBadgeText: { fontSize: 10, fontWeight: '800', color: '#059669' },
    countBadge: { 
        flexDirection: 'row', 
        alignItems: 'center', 
        gap: 4, 
        backgroundColor: '#f1f5f9', 
        paddingHorizontal: 8, 
        paddingVertical: 3, 
        borderRadius: 6 
    },
    countBadgeText: { fontSize: 10, fontWeight: '800', color: '#64748b' },
    expandIconBox: { marginLeft: 10 },

    cardExpandedContent: { padding: 20, backgroundColor: '#fff' },
    expandedSection: { marginBottom: 20 },
    doctorInfoRow: { 
        flexDirection: 'row', 
        alignItems: 'center', 
        backgroundColor: '#f8fafc', 
        padding: 12, 
        borderRadius: 16,
        borderWidth: 1,
        borderColor: '#f1f5f9'
    },
    doctorAvatar: {
        width: 44,
        height: 44,
        borderRadius: 22,
        backgroundColor: '#eff6ff',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 12
    },
    doctorAvatarText: { color: '#0251fc', fontWeight: '900', fontSize: 18 },
    expandedDocName: { fontSize: 15, fontWeight: '800', color: '#1e293b' },
    expandedDocSpec: { fontSize: 12, color: '#64748b', marginTop: 1 },
    physicianBadge: { 
        marginLeft: 'auto', 
        backgroundColor: '#0251fc10', 
        paddingHorizontal: 8, 
        paddingVertical: 4, 
        borderRadius: 8 
    },
    physicianBadgeText: { color: '#0251fc', fontSize: 10, fontWeight: '700' },

    notesGrid: { flexDirection: 'row', gap: 10, marginBottom: 20 },
    adviceCard: { 
        flex: 1, 
        backgroundColor: '#f0fdf4', 
        padding: 12, 
        borderRadius: 16, 
        borderWidth: 1, 
        borderColor: '#dcfce7' 
    },
    restrictionCard: { 
        flex: 1, 
        backgroundColor: '#fef2f2', 
        padding: 12, 
        borderRadius: 16, 
        borderWidth: 1, 
        borderColor: '#fee2e2' 
    },
    noteHeader: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 8 },
    adviceLabel: { fontSize: 9, fontWeight: '900', color: '#15803d' },
    restrictionLabel: { fontSize: 9, fontWeight: '900', color: '#b91c1c' },
    noteText: { fontSize: 12, color: '#475569', lineHeight: 18 },

    sectionHeaderRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 15 },
    sectionLabel: { fontSize: 11, fontWeight: '900', color: '#94a3b8', letterSpacing: 1 },
    medItem: { 
        backgroundColor: '#fff', 
        borderWidth: 1, 
        borderColor: '#f1f5f9', 
        borderRadius: 16, 
        padding: 16, 
        marginBottom: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.02,
        shadowRadius: 5,
        elevation: 1
    },
    medItemHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 12 },
    medNumber: { 
        width: 24, 
        height: 24, 
        borderRadius: 12, 
        backgroundColor: '#0251fc10', 
        justifyContent: 'center', 
        alignItems: 'center' 
    },
    medNumberText: { color: '#0251fc', fontSize: 12, fontWeight: '900' },
    medName: { fontSize: 16, fontWeight: '800', color: '#1e293b' },
    medBadgeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
    medSpecBadge: { 
        backgroundColor: '#eff6ff', 
        paddingHorizontal: 10, 
        paddingVertical: 6, 
        borderRadius: 10,
        borderWidth: 1,
        borderColor: '#dbeafe'
    },
    medSpecText: { fontSize: 12, fontWeight: '700', color: '#0251fc' },
    medSpecBadgeGray: { 
        backgroundColor: '#f8fafc', 
        paddingHorizontal: 10, 
        paddingVertical: 6, 
        borderRadius: 10,
        borderWidth: 1,
        borderColor: '#f1f5f9'
    },
    medSpecTextGray: { fontSize: 12, fontWeight: '700', color: '#64748b' },
    foodInstBox: { 
        marginTop: 12, 
        padding: 10, 
        backgroundColor: '#fffbeb', 
        borderRadius: 10,
        borderWidth: 1,
        borderColor: '#fef3c7'
    },
    foodInstText: { fontSize: 12, color: '#b45309', fontWeight: '600' },

    downloadCardBtn: {
        backgroundColor: '#1e293b',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 10,
        paddingVertical: 16,
        borderRadius: 16,
        marginTop: 10
    },
    downloadCardBtnText: { color: '#fff', fontSize: 15, fontWeight: '700' },

    emptyContainer: { alignItems: 'center', paddingVertical: 60 },
    emptyIconCircle: { 
        width: 80, 
        height: 80, 
        borderRadius: 40, 
        backgroundColor: '#f1f5f9', 
        justifyContent: 'center', 
        alignItems: 'center',
        marginBottom: 20
    },
    emptyTitle: { fontSize: 18, fontWeight: '800', color: '#64748b' },
    emptySubtitle: { fontSize: 14, color: '#94a3b8', textAlign: 'center', paddingHorizontal: 40, marginTop: 8 },
    familyBadge: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        backgroundColor: '#eef2ff',
        paddingHorizontal: 8,
        paddingVertical: 2,
        borderRadius: 6,
        borderWidth: 1,
        borderColor: '#e0e7ff',
    },
    familyBadgeText: {
        fontSize: 10,
        fontWeight: '700',
        color: '#4f46e5',
    },
});

