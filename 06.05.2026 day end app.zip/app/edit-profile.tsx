import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, ActivityIndicator, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { router } from 'expo-router';
import { ChevronLeft, Save } from 'lucide-react-native';
import { UserApi } from '../src/api';

export default function EditProfileScreen() {
    const [profile, setProfile] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [formData, setFormData] = useState<any>({});

    useEffect(() => {
        fetchProfile();
    }, []);

    const fetchProfile = async () => {
        try {
            const response = await UserApi.getProfile();
            if (response.success) {
                setProfile(response.data);
                setFormData(response.data);
            }
        } catch (error) {
            console.error('Error fetching profile:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleSave = async () => {
        try {
            setSaving(true);
            // Remove fields that shouldn't be sent to API
            const { id, userUuid, email, createdAt, updatedAt, role, isActive, ...updateData } = formData;

            const response = await UserApi.updateProfile(updateData);
            if (response.success) {
                Alert.alert('Success', 'Profile updated successfully', [
                    { text: 'OK', onPress: () => router.back() }
                ]);
            } else {
                Alert.alert('Error', response.message || 'Failed to update profile');
            }
        } catch (error) {
            console.error('Error updating profile:', error);
            Alert.alert('Error', 'An unexpected error occurred');
        } finally {
            setSaving(false);
        }
    };

    const updateField = (field: string, value: string) => {
        setFormData((prev: any) => ({ ...prev, [field]: value }));
    };

    if (loading) {
        return (
            <View style={styles.center}>
                <ActivityIndicator size="large" color="#1e3a8a" />
            </View>
        );
    }

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            style={styles.container}
        >
            <View style={styles.header}>
                <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
                    <ChevronLeft size={24} color="#1e3a8a" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Edit Profile</Text>
                <TouchableOpacity
                    onPress={handleSave}
                    disabled={saving}
                    style={[styles.saveButton, saving && styles.saveButtonDisabled]}
                >
                    {saving ? (
                        <ActivityIndicator size="small" color="#fff" />
                    ) : (
                        <Save size={20} color="#fff" />
                    )}
                </TouchableOpacity>
            </View>

            <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Personal Information</Text>
                    <View style={styles.fieldRow}>
                        <InputField
                            label="First Name"
                            value={formData.firstName}
                            onChangeText={(v: string) => updateField('firstName', v)}
                            flex={1}
                        />
                        <View style={{ width: 12 }} />
                        <InputField
                            label="Last Name"
                            value={formData.lastName}
                            onChangeText={(v: string) => updateField('lastName', v)}
                            flex={1}
                        />
                    </View>
                    <InputField
                        label="Phone Number"
                        value={formData.phone}
                        onChangeText={(v: string) => updateField('phone', v)}
                        keyboardType="phone-pad"
                    />
                    <InputField
                        label="Date of Birth (YYYY-MM-DD)"
                        value={formData.dateOfBirth}
                        onChangeText={(v: string) => updateField('dateOfBirth', v)}
                        placeholder="1990-01-01"
                    />
                    <View style={styles.fieldContainer}>
                        <Text style={styles.fieldLabel}>Gender</Text>
                        <View style={styles.genderRow}>
                            {['Male', 'Female', 'Other'].map((g) => (
                                <TouchableOpacity
                                    key={g}
                                    style={[styles.genderButton, formData.gender === g && styles.genderButtonActive]}
                                    onPress={() => updateField('gender', g)}
                                >
                                    <Text style={[styles.genderButtonText, formData.gender === g && styles.genderButtonTextActive]}>{g}</Text>
                                </TouchableOpacity>
                            ))}
                        </View>
                    </View>
                </View>

                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Address Details</Text>
                    <InputField
                        label="Street Address"
                        value={formData.streetAddress}
                        onChangeText={(v: string) => updateField('streetAddress', v)}
                    />
                    <InputField
                        label="City"
                        value={formData.city}
                        onChangeText={(v: string) => updateField('city', v)}
                    />
                    <View style={styles.fieldRow}>
                        <InputField
                            label="State"
                            value={formData.state}
                            onChangeText={(v: string) => updateField('state', v)}
                            flex={1}
                        />
                        <View style={{ width: 12 }} />
                        <InputField
                            label="ZIP Code"
                            value={formData.zipCode}
                            onChangeText={(v: string) => updateField('zipCode', v)}
                            flex={1}
                        />
                    </View>
                    <InputField
                        label="Country"
                        value={formData.country}
                        onChangeText={(v: string) => updateField('country', v)}
                    />
                </View>

                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Emergency Contact</Text>
                    <InputField
                        label="Contact Name"
                        value={formData.emergencyContactName}
                        onChangeText={(v: string) => updateField('emergencyContactName', v)}
                    />
                    <InputField
                        label="Contact Phone"
                        value={formData.emergencyContactPhone}
                        onChangeText={(v: string) => updateField('emergencyContactPhone', v)}
                        keyboardType="phone-pad"
                    />
                    <InputField
                        label="Relationship"
                        value={formData.emergencyContactRelationship}
                        onChangeText={(v: string) => updateField('emergencyContactRelationship', v)}
                    />
                    <InputField
                        label="Blood Type"
                        value={formData.bloodType}
                        onChangeText={(v: string) => updateField('bloodType', v)}
                        placeholder="A+, O-, etc."
                    />
                </View>

                <View style={{ height: 40 }} />
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

function InputField({ label, value, onChangeText, flex, keyboardType, placeholder }: any) {
    return (
        <View style={[styles.fieldContainer, flex ? { flex } : {}]}>
            <Text style={styles.fieldLabel}>{label}</Text>
            <TextInput
                style={styles.input}
                value={value || ''}
                onChangeText={onChangeText}
                keyboardType={keyboardType}
                placeholder={placeholder}
                placeholderTextColor="#94a3b8"
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f8fafc',
    },
    center: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 16,
        paddingTop: 60,
        paddingBottom: 16,
        backgroundColor: '#fff',
        borderBottomWidth: 1,
        borderBottomColor: '#e2e8f0',
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#0f172a',
    },
    backButton: {
        padding: 8,
    },
    saveButton: {
        backgroundColor: '#1e3a8a',
        padding: 10,
        borderRadius: 8,
        width: 44,
        height: 44,
        justifyContent: 'center',
        alignItems: 'center',
    },
    saveButtonDisabled: {
        opacity: 0.7,
    },
    content: {
        flex: 1,
        padding: 20,
    },
    section: {
        marginBottom: 24,
    },
    sectionTitle: {
        fontSize: 16,
        fontWeight: '700',
        color: '#1e3a8a',
        marginBottom: 16,
    },
    fieldContainer: {
        marginBottom: 16,
    },
    fieldLabel: {
        fontSize: 14,
        fontWeight: '600',
        color: '#475569',
        marginBottom: 8,
    },
    input: {
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: '#e2e8f0',
        borderRadius: 10,
        paddingHorizontal: 14,
        paddingVertical: 12,
        fontSize: 15,
        color: '#1e293b',
    },
    fieldRow: {
        flexDirection: 'row',
    },
    genderRow: {
        flexDirection: 'row',
        gap: 10,
        marginTop: 4,
    },
    genderButton: {
        flex: 1,
        paddingVertical: 10,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: '#e2e8f0',
        backgroundColor: '#fff',
        alignItems: 'center',
    },
    genderButtonActive: {
        borderColor: '#1e3a8a',
        backgroundColor: '#eff6ff',
    },
    genderButtonText: {
        fontSize: 14,
        color: '#64748b',
        fontWeight: '500',
    },
    genderButtonTextActive: {
        color: '#1e3a8a',
        fontWeight: '700',
    },
});
