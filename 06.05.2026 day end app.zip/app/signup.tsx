import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Image,
  ScrollView,
  Alert,
  Modal,
  ActivityIndicator,
  Linking,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Lock, Mail, User, ArrowRight, Eye, EyeOff, X, FileText, Shield, ChevronDown, ChevronUp, ChevronRight, Phone, Calendar, MapPin, Activity, Heart, Users } from 'lucide-react-native';
import { AuthApi } from '../src/api/features/auth';
import { ConsentApi } from '../src/api/features/consent';

const TERMS_URL = 'https://travelhealth.navalaglobal.com/terms-of-service';
const PRIVACY_URL = 'https://travelhealth.navalaglobal.com/privacy-policy';

// Category dot colors
const CATEGORY_COLORS: Record<string, string> = {
  'Data Usage': '#2563eb',
  'Telehealth': '#10b981',
  'Data Sharing': '#8b5cf6',
  'Cross-Border Transfer': '#f59e0b',
  'User Rights': '#0d9488',
};

interface ConsentItem {
  id: string;
  category: string;
  title: string;
  content: string;
}

interface ConsentSection {
  category: string;
  items: ConsentItem[];
  expanded: boolean;
}

function groupByCategory(sections: ConsentItem[]): ConsentSection[] {
  const map: Record<string, ConsentItem[]> = {};
  sections.forEach(item => {
    if (!map[item.category]) map[item.category] = [];
    map[item.category].push(item);
  });
  return Object.keys(map).map(cat => ({ category: cat, items: map[cat], expanded: cat === 'Data Usage' }));
}

export default function SignupScreen() {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  // Optional details state (Fixed field names for backend)
  const [showOptional, setShowOptional] = useState(false);
  const [phone, setPhone] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [gender, setGender] = useState('');
  const [streetAddress, setStreetAddress] = useState('');
  const [city, setCity] = useState('');
  const [country, setCountry] = useState('United States');
  const [state, setState] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [emergencyContactName, setEmergencyContactName] = useState('');
  const [emergencyContactPhone, setEmergencyContactPhone] = useState('');
  const [emergencyContactRelationship, setEmergencyContactRelationship] = useState('');
  const [bloodType, setBloodType] = useState('');

  const [agreedLegal, setAgreedLegal] = useState(false);
  const [agreedTelehealth, setAgreedTelehealth] = useState(false);

  // Modal
  const [modalVisible, setModalVisible] = useState(false);
  const [modalTitle, setModalTitle] = useState('');
  const [modalLoading, setModalLoading] = useState(false);
  const [modalTarget, setModalTarget] = useState<'legal' | 'telehealth'>('legal');

  // For legal (plain text from web)
  const [legalContent, setLegalContent] = useState('');

  // For telehealth (structured sections from API)
  const [consentSections, setConsentSections] = useState<ConsentSection[]>([]);

  const isValid =
    firstName.trim().length > 0 &&
    lastName.trim().length > 0 &&
    email.trim().length > 0 &&
    password.trim().length >= 6 &&
    confirmPassword === password &&
    agreedLegal &&
    agreedTelehealth;

  const openLegalModal = async (title: string, url: string) => {
    setModalTitle(title);
    setLegalContent('');
    setModalLoading(true);
    setModalTarget('legal');
    setModalVisible(true);
    try {
      const response = await fetch(url);
      const html = await response.text();
      const plain = html
        .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
        .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s{2,}/g, '\n')
        .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ')
        .trim();
      setLegalContent(plain);
    } catch {
      setLegalContent(`Unable to load content.\n\nPlease visit:\n${url}`);
    } finally {
      setModalLoading(false);
    }
  };

  const openTelehealthModal = async () => {
    setModalTitle('Consent & Data Sharing');
    setConsentSections([]);
    setModalLoading(true);
    setModalTarget('telehealth');
    setModalVisible(true);
    try {
      const res = await ConsentApi.getConsent();
      if (res && res.success && res.data && Array.isArray(res.data.sections)) {
        setConsentSections(groupByCategory(res.data.sections));
      } else {
        setConsentSections([]);
      }
    } catch {
      setConsentSections([]);
    } finally {
      setModalLoading(false);
    }
  };

  const toggleSection = (idx: number) => {
    setConsentSections(prev =>
      prev.map((s, i) => i === idx ? { ...s, expanded: !s.expanded } : s)
    );
  };

  const handleModalAgree = () => {
    if (modalTarget === 'legal') setAgreedLegal(true);
    else setAgreedTelehealth(true);
    setModalVisible(false);
  };

  const handleSignup = async () => {
    if (!agreedLegal || !agreedTelehealth) {
      Alert.alert('Agreement Required', 'Please agree to both consents to continue.');
      return;
    }
    if (!isValid) {
      Alert.alert('Error', 'Please fill all fields correctly and ensure passwords match (min. 6 characters).');
      return;
    }
    try {
      setLoading(true);
      await AuthApi.register({ 
        firstName, 
        lastName, 
        email, 
        password,
        // Optional fields (Updated to match backend)
        phone,
        dateOfBirth,
        gender,
        streetAddress,
        city,
        country,
        state,
        zipCode,
        emergencyContactName,
        emergencyContactPhone,
        emergencyContactRelationship,
        bloodType
      });
      Alert.alert('Success', 'Account created successfully! Please login.', [
        { text: 'OK', onPress: () => router.replace('/login') }
      ]);
    } catch (error: any) {
      Alert.alert('Registration Failed', error.message || 'An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  const Checkbox = ({ checked, onPress }: { checked: boolean; onPress: () => void }) => (
    <TouchableOpacity onPress={onPress} style={[styles.checkbox, checked && styles.checkboxChecked]}>
      {checked && <Text style={styles.checkboxTick}>✓</Text>}
    </TouchableOpacity>
  );

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <LinearGradient colors={['#2563eb', '#1d4ed8']} style={styles.header}>
        <View style={styles.headerRow}>
          <View style={styles.headerLogoWrapper}>
            <Image source={require('../assets/images/icon.png')} style={styles.headerLogo} />
          </View>
          <View style={styles.headerTextWrapper}>
            <Text style={styles.appTitle}>Create your account</Text>
            <Text style={styles.appSubtitle}>Sign up to manage your travel health and appointments.</Text>
          </View>
        </View>
      </LinearGradient>

      <ScrollView style={styles.content} contentContainerStyle={{ paddingBottom: 32 }}>
        <View style={styles.card}>
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>First Name</Text>
            <View style={styles.inputWrapper}>
              <User size={18} color="#6b7280" />
              <TextInput style={styles.input} placeholder="John" placeholderTextColor="#9ca3af" value={firstName} onChangeText={setFirstName} />
            </View>
          </View>
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Last Name</Text>
            <View style={styles.inputWrapper}>
              <User size={18} color="#6b7280" />
              <TextInput style={styles.input} placeholder="Doe" placeholderTextColor="#9ca3af" value={lastName} onChangeText={setLastName} />
            </View>
          </View>
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Email</Text>
            <View style={styles.inputWrapper}>
              <Mail size={18} color="#6b7280" />
              <TextInput style={styles.input} placeholder="you@example.com" placeholderTextColor="#9ca3af" keyboardType="email-address" autoCapitalize="none" value={email} onChangeText={setEmail} />
            </View>
          </View>
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Password</Text>
            <View style={styles.inputWrapper}>
              <Lock size={18} color="#6b7280" />
              <TextInput style={styles.input} placeholder="••••••••" placeholderTextColor="#9ca3af" secureTextEntry={!showPassword} value={password} onChangeText={setPassword} />
              <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={{ padding: 8 }}>
                {showPassword ? <EyeOff size={18} color="#6b7280" /> : <Eye size={18} color="#6b7280" />}
              </TouchableOpacity>
            </View>
          </View>
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Confirm Password</Text>
            <View style={styles.inputWrapper}>
              <Lock size={18} color="#6b7280" />
              <TextInput style={styles.input} placeholder="••••••••" placeholderTextColor="#9ca3af" secureTextEntry={!showConfirmPassword} value={confirmPassword} onChangeText={setConfirmPassword} />
              <TouchableOpacity onPress={() => setShowConfirmPassword(!showConfirmPassword)} style={{ padding: 8 }}>
                {showConfirmPassword ? <EyeOff size={18} color="#6b7280" /> : <Eye size={18} color="#6b7280" />}
              </TouchableOpacity>
            </View>
          </View>

          {/* Optional Details Accordion */}
          <View style={styles.optionalSection}>
            <TouchableOpacity 
              style={styles.optionalHeader} 
              onPress={() => setShowOptional(!showOptional)}
              activeOpacity={0.7}
            >
              <Text style={styles.optionalTitle}>Optional details (phone, address, emergency contact)</Text>
              {showOptional ? <ChevronUp size={20} color="#64748b" /> : <ChevronDown size={20} color="#64748b" />}
            </TouchableOpacity>

            {showOptional && (
              <View style={styles.optionalContent}>
                <Text style={styles.optionalSubtitle}>You can add these now or later in your profile.</Text>
                
                <View style={styles.row}>
                  <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
                    <Text style={styles.inputLabel}>Phone</Text>
                    <View style={styles.inputWrapper}>
                      <TextInput style={styles.input} placeholder="e.g. 5551234567" placeholderTextColor="#9ca3af" keyboardType="phone-pad" value={phone} onChangeText={setPhone} />
                    </View>
                  </View>
                  <View style={[styles.inputGroup, { flex: 1 }]}>
                    <Text style={styles.inputLabel}>Date of Birth</Text>
                    <View style={styles.inputWrapper}>
                      <TextInput style={styles.input} placeholder="mm/dd/yyyy" placeholderTextColor="#9ca3af" value={dateOfBirth} onChangeText={setDateOfBirth} />
                      <Calendar size={18} color="#6b7280" />
                    </View>
                  </View>
                </View>

                {/* Gender Field */}
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Gender</Text>
                  <View style={styles.genderRow}>
                    {['Male', 'Female', 'Other'].map((g) => (
                      <TouchableOpacity 
                        key={g} 
                        style={[styles.genderButton, gender === g && styles.genderButtonActive]}
                        onPress={() => setGender(g)}
                      >
                        <Text style={[styles.genderButtonText, gender === g && styles.genderButtonTextActive]}>{g}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}><MapPin size={14} color="#6b7280" /> Street Address</Text>
                  <View style={styles.inputWrapper}>
                    <TextInput style={styles.input} placeholder="Street address (letters, numbers, , . - # /)" placeholderTextColor="#9ca3af" value={streetAddress} onChangeText={setStreetAddress} />
                  </View>
                </View>

                <View style={styles.row}>
                  <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
                    <Text style={styles.inputLabel}>City</Text>
                    <View style={styles.inputWrapper}>
                      <TextInput style={styles.input} placeholder="City" placeholderTextColor="#9ca3af" value={city} onChangeText={setCity} />
                    </View>
                  </View>
                  <View style={[styles.inputGroup, { flex: 1 }]}>
                    <Text style={styles.inputLabel}>Country</Text>
                    <View style={styles.inputWrapper}>
                      <TextInput style={styles.input} placeholder="United States" placeholderTextColor="#9ca3af" value={country} onChangeText={setCountry} />
                    </View>
                  </View>
                </View>

                <View style={styles.row}>
                  <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
                    <Text style={styles.inputLabel}>State</Text>
                    <View style={styles.inputWrapper}>
                      <TextInput style={styles.input} placeholder="State" placeholderTextColor="#9ca3af" value={state} onChangeText={setState} />
                    </View>
                  </View>
                  <View style={[styles.inputGroup, { flex: 1 }]}>
                    <Text style={styles.inputLabel}>ZIP Code</Text>
                    <View style={styles.inputWrapper}>
                      <TextInput style={styles.input} placeholder="6 digits" placeholderTextColor="#9ca3af" keyboardType="numeric" value={zipCode} onChangeText={setZipCode} />
                    </View>
                  </View>
                </View>

                <View style={styles.divider} />
                <Text style={styles.sectionSubTitle}><Phone size={14} color="#6b7280" /> Emergency Contact</Text>

                <View style={styles.row}>
                  <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
                    <Text style={styles.inputLabel}>Name</Text>
                    <View style={styles.inputWrapper}>
                      <TextInput style={styles.input} placeholder="Contact name" placeholderTextColor="#9ca3af" value={emergencyContactName} onChangeText={setEmergencyContactName} />
                    </View>
                  </View>
                  <View style={[styles.inputGroup, { flex: 1 }]}>
                    <Text style={styles.inputLabel}>Phone</Text>
                    <View style={styles.inputWrapper}>
                      <TextInput style={styles.input} placeholder="e.g. 5551234567" placeholderTextColor="#9ca3af" keyboardType="phone-pad" value={emergencyContactPhone} onChangeText={setEmergencyContactPhone} />
                    </View>
                  </View>
                </View>

                <View style={styles.row}>
                  <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
                    <Text style={styles.inputLabel}>Relationship</Text>
                    <View style={styles.inputWrapper}>
                      <TextInput style={styles.input} placeholder="e.g. Spouse" placeholderTextColor="#9ca3af" value={emergencyContactRelationship} onChangeText={setEmergencyContactRelationship} />
                    </View>
                  </View>
                  <View style={[styles.inputGroup, { flex: 1 }]}>
                    <Text style={styles.inputLabel}>Blood Type</Text>
                    <View style={styles.inputWrapper}>
                      <TextInput style={styles.input} placeholder="e.g. O+" placeholderTextColor="#9ca3af" value={bloodType} onChangeText={setBloodType} />
                    </View>
                  </View>
                </View>
              </View>
            )}
          </View>

          {/* Consent Section */}
          <View style={styles.consentSection}>
            <Text style={styles.consentSectionLabel}>AGREEMENTS & CONSENT</Text>

            {/* Legal */}
            <View style={styles.consentRow}>
              <Checkbox checked={agreedLegal} onPress={() => setAgreedLegal(!agreedLegal)} />
              <View style={styles.consentTextWrapper}>
                <Text style={styles.consentText}>I agree to the </Text>
                <TouchableOpacity onPress={() => Linking.openURL(TERMS_URL)}>
                  <Text style={styles.consentLink}>Terms of Service</Text>
                </TouchableOpacity>
                <Text style={styles.consentText}> & </Text>
                <TouchableOpacity onPress={() => Linking.openURL(PRIVACY_URL)}>
                  <Text style={styles.consentLink}>Privacy Policy</Text>
                </TouchableOpacity>
                <Text style={styles.consentText}> *</Text>
              </View>
            </View>

            {/* Telehealth */}
            <View style={styles.consentRow}>
              <Checkbox checked={agreedTelehealth} onPress={() => setAgreedTelehealth(!agreedTelehealth)} />
              <View style={styles.consentTextWrapper}>
                <Text style={styles.consentText}>I consent to </Text>
                <TouchableOpacity onPress={openTelehealthModal}>
                  <Text style={styles.consentLink}>Telehealth & Data Sharing</Text>
                </TouchableOpacity>
                <Text style={styles.consentText}> *</Text>
              </View>
            </View>
          </View>

          <TouchableOpacity
            style={[styles.primaryButton, (!isValid || loading) && styles.primaryButtonDisabled]}
            disabled={!isValid || loading}
            onPress={handleSignup}>
            <Text style={styles.primaryButtonText}>{loading ? 'Creating account...' : 'Create account'}</Text>
            {!loading && <ArrowRight size={18} color="#ffffff" />}
          </TouchableOpacity>

          <TouchableOpacity style={styles.switchRow} onPress={() => router.replace('/login')}>
            <Text style={styles.switchText}>Already have an account?</Text>
            <Text style={styles.switchLink}>Sign in</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Consent Modal */}
      <Modal visible={modalVisible} animationType="slide" transparent onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            {/* Header */}
            <View style={styles.modalHeader}>
              <View style={styles.modalHeaderLeft}>
                <View style={styles.modalIconWrapper}>
                  {modalTarget === 'telehealth' ? <Shield size={20} color="#1e40af" /> : <FileText size={20} color="#1e40af" />}
                </View>
                <View>
                  <Text style={styles.modalTitle}>{modalTitle}</Text>
                  {modalTarget === 'telehealth' && (
                    <Text style={styles.modalSubtitle}>Please review how Navala Travel Health handles your health data and telehealth services.</Text>
                  )}
                </View>
              </View>
              <TouchableOpacity onPress={() => setModalVisible(false)} style={styles.modalCloseBtn}>
                <X size={20} color="#64748b" />
              </TouchableOpacity>
            </View>

            {/* Body */}
            <ScrollView style={styles.modalBody} contentContainerStyle={{ paddingBottom: 20 }}>
              {modalLoading ? (
                <View style={styles.modalLoading}>
                  <ActivityIndicator size="large" color="#2563eb" />
                  <Text style={styles.modalLoadingText}>Loading document...</Text>
                </View>
              ) : modalTarget === 'legal' ? (
                <Text style={styles.modalBodyText}>{legalContent}</Text>
              ) : (
                <View>
                  {consentSections.length === 0 ? (
                    <Text style={styles.modalBodyText}>No consent content available.</Text>
                  ) : (
                    consentSections.map((section, idx) => {
                      const dotColor = CATEGORY_COLORS[section.category] || '#2563eb';
                      return (
                        <View key={section.category} style={styles.accordionBlock}>
                          {/* Section Header */}
                          <TouchableOpacity style={styles.accordionHeader} onPress={() => toggleSection(idx)}>
                            <View style={styles.accordionHeaderLeft}>
                              <View style={[styles.categoryDot, { backgroundColor: dotColor }]} />
                              <Text style={styles.accordionTitle}>{section.category}</Text>
                            </View>
                            {section.expanded
                              ? <ChevronUp size={18} color="#64748b" />
                              : <ChevronDown size={18} color="#64748b" />}
                          </TouchableOpacity>

                          {/* Section Items */}
                          {section.expanded && (
                            <View style={styles.accordionContent}>
                              {section.items.map(item => (
                                <View key={item.id} style={styles.consentItem}>
                                  <View style={styles.consentItemTitleRow}>
                                    <ChevronRight size={14} color="#2563eb" />
                                    <Text style={styles.consentItemTitle}>{item.title}</Text>
                                  </View>
                                  <Text style={styles.consentItemContent}>{item.content}</Text>
                                </View>
                              ))}
                            </View>
                          )}
                        </View>
                      );
                    })
                  )}
                </View>
              )}
            </ScrollView>

            {/* Footer */}
            <View style={styles.modalFooter}>
              <TouchableOpacity style={styles.acceptBtn} onPress={handleModalAgree}>
                <Text style={styles.acceptBtnText}>I Understand</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f9fafb' },
  header: { paddingTop: 80, paddingBottom: 32, paddingHorizontal: 24 },
  headerRow: { flexDirection: 'row', alignItems: 'center' },
  headerLogoWrapper: { width: 80, height: 80, backgroundColor: '#ffffff', borderRadius: 16, justifyContent: 'center', alignItems: 'center', marginRight: 18 },
  headerLogo: { width: '80%', height: '80%', resizeMode: 'contain' },
  headerTextWrapper: { flex: 1 },
  appTitle: { fontSize: 24, fontWeight: '700', color: '#ffffff', marginBottom: 4 },
  appSubtitle: { fontSize: 13, color: '#e0e7ff' },
  content: { flex: 1, paddingHorizontal: 16, paddingTop: 8 },
  card: { backgroundColor: '#ffffff', borderRadius: 16, padding: 20, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 10, elevation: 3, marginBottom: 20 },
  inputGroup: { marginBottom: 16 },
  inputLabel: { fontSize: 13, fontWeight: '500', color: '#4b5563', marginBottom: 6 },
  inputWrapper: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f9fafb', borderRadius: 12, borderWidth: 1, borderColor: '#e5e7eb', paddingHorizontal: 12 },
  input: { flex: 1, paddingVertical: 12, paddingHorizontal: 8, fontSize: 14, color: '#111827' },
  row: { flexDirection: 'row', marginBottom: 4 },
  // Gender
  genderRow: { flexDirection: 'row', gap: 10, marginTop: 4 },
  genderButton: { flex: 1, paddingVertical: 10, borderRadius: 10, borderWidth: 1, borderColor: '#e2e8f0', backgroundColor: '#f9fafb', alignItems: 'center' },
  genderButtonActive: { borderColor: '#2563eb', backgroundColor: '#eff6ff' },
  genderButtonText: { fontSize: 14, color: '#64748b', fontWeight: '500' },
  genderButtonTextActive: { color: '#2563eb', fontWeight: '700' },
  // Optional section
  optionalSection: { marginBottom: 20, borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 12, overflow: 'hidden' },
  optionalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 14, backgroundColor: '#f8fafc' },
  optionalTitle: { fontSize: 14, fontWeight: '600', color: '#475569', flex: 1 },
  optionalContent: { padding: 14, backgroundColor: '#ffffff' },
  optionalSubtitle: { fontSize: 12, color: '#94a3b8', marginBottom: 16 },
  sectionSubTitle: { fontSize: 13, fontWeight: '700', color: '#64748b', marginBottom: 12, marginTop: 4, flexDirection: 'row', alignItems: 'center', gap: 6 },
  divider: { height: 1, backgroundColor: '#f1f5f9', marginVertical: 12 },
  // Consent section
  consentSection: { backgroundColor: '#f8faff', borderRadius: 12, padding: 14, borderWidth: 1, borderColor: '#dbeafe', marginBottom: 20, gap: 12 },
  consentSectionLabel: { fontSize: 11, fontWeight: '700', color: '#1e40af', letterSpacing: 0.8 },
  consentRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12 },
  checkbox: { width: 22, height: 22, borderRadius: 6, borderWidth: 2, borderColor: '#d1d5db', backgroundColor: '#ffffff', justifyContent: 'center', alignItems: 'center', marginTop: 1, flexShrink: 0 },
  checkboxChecked: { borderColor: '#2563eb', backgroundColor: '#2563eb' },
  checkboxTick: { color: '#ffffff', fontSize: 13, fontWeight: '700', lineHeight: 16 },
  consentTextWrapper: { flex: 1, flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center' },
  consentText: { fontSize: 13, color: '#6b7280', lineHeight: 20 },
  consentLink: { fontSize: 13, color: '#2563eb', fontWeight: '600', textDecorationLine: 'underline', lineHeight: 20 },
  primaryButton: { backgroundColor: '#2563eb', paddingVertical: 14, borderRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
  primaryButtonDisabled: { backgroundColor: '#9ca3af' },
  primaryButtonText: { color: '#ffffff', fontSize: 16, fontWeight: '600' },
  switchRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 16, gap: 4 },
  switchText: { fontSize: 13, color: '#6b7280' },
  switchLink: { fontSize: 13, fontWeight: '600', color: '#2563eb' },
  // Modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContainer: { backgroundColor: '#ffffff', borderTopLeftRadius: 24, borderTopRightRadius: 24, maxHeight: '92%', overflow: 'hidden' },
  modalHeader: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', padding: 20, borderBottomWidth: 1, borderBottomColor: '#f1f5f9' },
  modalHeaderLeft: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, flex: 1 },
  modalIconWrapper: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#eff6ff', justifyContent: 'center', alignItems: 'center', flexShrink: 0, marginTop: 2 },
  modalTitle: { fontSize: 18, fontWeight: '700', color: '#0f172a', flex: 1 },
  modalSubtitle: { fontSize: 12, color: '#64748b', marginTop: 4, lineHeight: 18, flex: 1 },
  modalCloseBtn: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#f1f5f9', justifyContent: 'center', alignItems: 'center', flexShrink: 0 },
  modalBody: { padding: 16, maxHeight: 480 },
  modalLoading: { alignItems: 'center', paddingVertical: 60 },
  modalLoadingText: { marginTop: 16, fontSize: 15, color: '#64748b' },
  modalBodyText: { fontSize: 13, color: '#374151', lineHeight: 22 },
  // Accordion
  accordionBlock: { borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 12, marginBottom: 10, overflow: 'hidden' },
  accordionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 14, backgroundColor: '#f8fafc' },
  accordionHeaderLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  categoryDot: { width: 10, height: 10, borderRadius: 5 },
  accordionTitle: { fontSize: 14, fontWeight: '700', color: '#1e293b' },
  accordionContent: { padding: 14, gap: 14, backgroundColor: '#ffffff' },
  consentItem: { gap: 6 },
  consentItemTitleRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 6 },
  consentItemTitle: { fontSize: 13, fontWeight: '700', color: '#1e293b', flex: 1, lineHeight: 19 },
  consentItemContent: { fontSize: 13, color: '#475569', lineHeight: 20, paddingLeft: 20 },
  // Footer
  modalFooter: { padding: 20, borderTopWidth: 1, borderTopColor: '#f1f5f9' },
  acceptBtn: { backgroundColor: '#1e3a8a', paddingVertical: 15, borderRadius: 12, alignItems: 'center' },
  acceptBtnText: { color: '#ffffff', fontSize: 15, fontWeight: '700' },
});
