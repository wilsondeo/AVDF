import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ActivityIndicator,
    ScrollView,
    TouchableOpacity,
    Platform,
    Image,
    Dimensions
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { UserApi, PlansApi } from '../src/api';
import { printDocument } from '../src/utils/print';
import { Alert } from 'react-native';
import {
    CheckCircle,
    ArrowLeft,
    CreditCard,
    Calendar,
    FileText,
    ShieldCheck,
    Users,
    Download,
    CheckCircle2,
    Video,
    Phone,
    MapPin
} from 'lucide-react-native';
import { format } from 'date-fns';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export default function PlanConfirmationScreen() {
    const [loading, setLoading] = useState(true);
    const [activePlan, setActivePlan] = useState<any>(null);
    const [familyMembers, setFamilyMembers] = useState<any[]>([]);
    const [latestPayment, setLatestPayment] = useState<any>(null);
    const [userData, setUserData] = useState<any>(null);
    const [printing, setPrinting] = useState(false);
    const [verificationCode] = useState(`NTH-V-${Math.random().toString(36).substring(7).toUpperCase()}`);

    const generateHtml = () => {
        const dateIssued = latestPayment?.createdAt ? format(new Date(latestPayment.createdAt), 'MMMM dd, yyyy') : format(new Date(), 'MMMM dd, yyyy');
        const price = latestPayment?.amount ? (latestPayment.amount / 100).toFixed(2) : '0.00';
        const transId = latestPayment?.stripePaymentIntentId || 'NTH-TEST-INTENT';
        const planName = plan?.name || 'Active Healthcare Plan';
        const userName = `${userData?.firstName} ${userData?.lastName}`;
        const userUuidStr = userData?.userUuid || 'N/A';
        const itineraryArray = (() => {
            const raw = latestPayment?.itinerary || activePlan?.itinerary;
            if (!raw) return [];
            try {
                const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
                if (Array.isArray(parsed)) return parsed.map((d: any) => d.cityName || d.locationName || d.name || 'Unknown');
            } catch (e) { }
            return [];
        })();
        const itineraryStr = itineraryArray.length > 0 ? itineraryArray.join(', ') : 'Global Coverage Active';

        return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Plan Confirmation</title>
    <style>
        body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; padding: 40px; background-color: #f8fafc; color: #1e293b; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        .container { max-width: 800px; margin: 0 auto; background-color: #ffffff; padding: 40px; min-height: 1000px; position: relative; border: 1px solid #f1f5f9; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .flex { display: flex; }
        .justify-between { justify-content: space-between; }
        .items-center { align-items: center; }
        .mb-12 { margin-bottom: 3rem; }
        .gap-3 { gap: 0.75rem; }
        .logo-box { width: 48px; height: 48px; background-color: #2563eb; border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 24px; }
        .title { font-size: 24px; font-weight: 900; letter-spacing: -0.05em; margin: 0; }
        .subtitle { font-size: 10px; font-weight: bold; color: #2563eb; letter-spacing: 0.2em; text-transform: uppercase; margin: 0; }
        .status-badge { background-color: #dcfce7; color: #15803d; font-size: 10px; font-weight: 900; padding: 4px 12px; border-radius: 9999px; border: 1px solid #bbf7d0; display: inline-block; }
        .meta-row { border-top: 1px solid #f1f5f9; border-bottom: 1px solid #f1f5f9; padding: 2rem 0; margin-bottom: 3rem; display: flex; justify-content: space-between; align-items: center; }
        .meta-label { font-size: 10px; font-weight: bold; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.1em; margin: 0 0 4px 0; }
        .meta-value { font-size: 14px; font-weight: bold; font-family: monospace; color: #1e293b; margin: 0; }
        h3 { font-size: 20px; font-weight: 800; color: #0f172a; margin: 0 0 1.5rem 0; }
        .summary-box { background-color: #f8fafc; border-radius: 16px; padding: 2rem; border: 1px solid #f1f5f9; margin-bottom: 2rem; }
        .plan-name { font-size: 24px; font-weight: 900; color: #2563eb; margin: 0; }
        .plan-desc { font-size: 14px; color: #64748b; font-weight: 500; margin: 0; }
        .price { font-size: 24px; font-weight: 900; color: #0f172a; margin: 0; }
        .price-label { font-size: 12px; color: #94a3b8; font-weight: bold; text-transform: uppercase; margin: 0; }
        .summary-details { margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid #e2e8f0; }
        .detail-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; }
        .detail-label { font-size: 14px; font-weight: bold; color: #334155; margin: 0; }
        .detail-value { font-size: 14px; font-weight: 500; color: #0f172a; margin: 0; }
        .section-title { font-size: 12px; font-weight: 900; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.1em; margin: 0 0 1rem 0; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
        .family-card { background-color: white; border: 1px solid #f1f5f9; padding: 1rem; border-radius: 12px; }
        .family-name { font-size: 14px; font-weight: bold; color: #1e293b; margin: 0; }
        .family-rel { font-size: 10px; font-weight: bold; color: #94a3b8; text-transform: uppercase; margin: 4px 0 0 0; }
        .itinerary-box { background-color: #eff6ff; border: 1px solid #dbeafe; padding: 1rem; border-radius: 12px; color: #1e40af; font-weight: 600; font-size: 14px; margin-bottom: 2rem; }
        .service-card { display: flex; align-items: center; gap: 0.75rem; background-color: white; border: 1px solid #f1f5f9; padding: 1rem; border-radius: 12px; }
        .dot { width: 8px; height: 8px; background-color: #3b82f6; border-radius: 50%; }
        .service-text { font-size: 12px; font-weight: bold; color: #334155; margin: 0; }
        .footer-box { position: absolute; bottom: 3rem; left: 3rem; right: 3rem; padding: 2rem; border: 2px dashed #f1f5f9; border-radius: 24px; text-align: center; }
        .footer-thx { color: #94a3b8; font-size: 12px; margin: 0 0 8px 0; }
        .footer-active { color: #1e293b; font-weight: 800; font-size: 16px; margin: 0; }
        .footer-code { font-size: 9px; color: #cbd5e1; margin: 1rem 0 0 0; }
    </style>
</head>
<body>
    <div class="container">
        <div class="flex justify-between items-center mb-12">
            <div class="flex items-center gap-3">
                <div class="logo-box">N</div>
                <div>
                    <p class="title">Navala Travel Health</p>
                    <p class="subtitle">Premium Confirmation</p>
                </div>
            </div>
            <div>
                <span class="status-badge">PAYMENT SUCCESSFUL</span>
            </div>
        </div>

        <div class="meta-row">
            <div>
                <p class="meta-label">Transaction ID</p>
                <p class="meta-value">${transId}</p>
            </div>
            <div style="text-align: right;">
                <p class="meta-label">Invoice Date</p>
                <p class="meta-value" style="font-family: 'Helvetica Neue', sans-serif;">${dateIssued}</p>
            </div>
        </div>

        <h3>Plan Summary</h3>
        <div class="summary-box">
            <div class="flex justify-between items-center">
                <div>
                    <p class="plan-name">${planName}</p>
                    <p class="plan-desc">Annual Travel Coverage</p>
                </div>
                <div style="text-align: right;">
                    <p class="price">$${price}</p>
                    <p class="price-label">Total Paid</p>
                </div>
            </div>
            
            <div class="summary-details">
                <div class="detail-row">
                    <p class="detail-label">Base Price</p>
                    <p class="detail-value">$${latestPayment?.amount ? ((Number(latestPayment.amount) - (Number(latestPayment.taxCents) || 0) - (Number(latestPayment.processingFeeCents) || 0)) / 100).toFixed(2) : '0.00'}</p>
                </div>
                ${(latestPayment?.taxCents || 0) > 0 ? `
                <div class="detail-row">
                    <p class="detail-label">Government Taxes</p>
                    <p class="detail-value">+ $${(Number(latestPayment.taxCents) / 100).toFixed(2)}</p>
                </div>
                ` : ''}
                <div class="detail-row">
                    <p class="detail-label">Processing Fee ${latestPayment?.processingFeePercent ? `(${latestPayment.processingFeePercent}%)` : ''}</p>
                    <p class="detail-value">+ $${(Number(latestPayment?.processingFeeCents || 0) / 100).toFixed(2)}</p>
                </div>
                <div class="detail-row" style="margin-top: 0.5rem; padding-top: 0.5rem; border-top: 1px dashed #e2e8f0;">
                    <p class="detail-label">Account Holder</p>
                    <p class="detail-value">${userName}</p>
                </div>
                <div class="detail-row" style="margin-bottom: 0;">
                    <p class="detail-label">Member ID</p>
                    <p class="detail-value" style="font-family: monospace; color: #64748b;">#${userData?.id || 'N/A'}</p>
                </div>
            </div>
        </div>

        ${familyMembers.length > 0 ? `
        <div style="margin-bottom: 2rem;">
            <p class="section-title">Family Beneficiaries</p>
            <div class="grid-2">
                ${familyMembers.map(m => `
                    <div class="family-card">
                        <p class="family-name">${m.firstName} ${m.lastName}</p>
                        <p class="family-rel">${m.relationship || 'Member'}</p>
                    </div>
                `).join('')}
            </div>
        </div>
        ` : ''}

        <div style="margin-bottom: 2rem;">
            <p class="section-title">Travel Itinerary</p>
            <div class="itinerary-box">
                📍 ${itineraryStr}
            </div>
        </div>

        <div>
            <p class="section-title">Included Services</p>
            <div class="grid-2">
                <div class="service-card"><div class="dot"></div><p class="service-text">24/7 Virtual Care</p></div>
                <div class="service-card"><div class="dot"></div><p class="service-text">Global Coverage</p></div>
                <div class="service-card"><div class="dot"></div><p class="service-text">Specialist Referrals</p></div>
                <div class="service-card"><div class="dot"></div><p class="service-text">Prescription Savings</p></div>
            </div>
        </div>

        <div class="footer-box">
            <p class="footer-thx">Thank you for choosing Navala Travel Health</p>
            <p class="footer-active">Your coverage is now active.</p>
            <p class="footer-code">Validation Code: ${verificationCode}</p>
        </div>
    </div>
</body>
</html>
        `;
    };

    const handlePrint = async () => {
        // Use userUuid if available, otherwise try id
        const uuid = userData?.userUuid || userData?.id;

        if (!uuid) {
            Alert.alert('Error', 'User information not available for download.');
            return;
        }

        try {
            setPrinting(true);
            const customHtml = generateHtml();
            const dateSuffix = format(new Date(), 'MMM_dd');
            await printDocument(`/api/shared/confirmation/${uuid}/view`, `Navala_Payment_Receipt_${dateSuffix}.pdf`, customHtml);
        } catch (error) {
            Alert.alert('Download Failed', 'Could not generate PDF. Please try again later.');
        } finally {
            setPrinting(false);
        }
    };

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            setLoading(true);
            const [planRes, familyRes, paymentRes, profileRes] = await Promise.all([
                UserApi.getActivePlan(),
                UserApi.getFamilyMembers(),
                PlansApi.getMyPayments(20, 0),
                UserApi.getProfile()
            ]);

            if (planRes.success) {
                setActivePlan(planRes.data.activePlan || planRes.data);
            }
            if (familyRes.success) {
                setFamilyMembers(familyRes.data.familyMembers || []);
            }
            if (paymentRes.success && paymentRes.data.payments && paymentRes.data.payments.length > 0) {
                // Strictly use only SUCCESS payments — never show PENDING or FAILED data
                const successPayments = paymentRes.data.payments.filter((p: any) => p.status === 'SUCCESS');
                if (successPayments.length > 0) {
                    const sorted = [...successPayments].sort(
                        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
                    );
                    setLatestPayment(sorted[0]); // strictly the last SUCCESS payment
                }
            }
            if (profileRes.success) {
                setUserData(profileRes.data);
            }
        } catch (error) {
            console.error('Failed to load confirmation data:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <View style={styles.center}>
                <ActivityIndicator size="large" color="#0251fc" />
                <Text style={styles.loadingText}>Finalizing activation...</Text>
            </View>
        );
    }

    const plan = activePlan?.plan || activePlan;
    const features = plan?.features ? (typeof plan.features === 'string' ? JSON.parse(plan.features) : plan.features) : [];
    const services = plan?.services ? (typeof plan.services === 'string' ? JSON.parse(plan.services) : plan.services) : [];

    return (
        <View style={styles.container}>
            {/* Action Bar */}
            <LinearGradient colors={['#0251fc', '#072169']} style={styles.actionBar}>
                <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
                    <ArrowLeft color="#ffffff" size={24} />
                    <Text style={[styles.backBtnText, { color: '#ffffff' }]}>Back</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    style={[styles.downloadHeaderBtn, printing && { opacity: 0.7 }]}
                    onPress={handlePrint}
                    disabled={printing}
                >
                    {printing ? (
                        <ActivityIndicator size="small" color="#ffffff" />
                    ) : (
                        <Download size={18} color="#ffffff" />
                    )}
                    <Text style={[styles.downloadHeaderBtnText, { color: '#ffffff' }]}>{printing ? 'Generating...' : 'Download Receipt'}</Text>
                </TouchableOpacity>
            </LinearGradient>

            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
                {/* Simulated Web Document */}
                <View style={styles.docWrapper}>
                    {/* Background Gradients (Simulated) */}
                    <View style={styles.gradientDecor} />

                    {/* Document Header */}
                    <View style={styles.docHeader}>
                        <View style={{ flex: 1 }}>
                            <Image source={require('../assets/images/icon.png')} style={styles.logo} resizeMode="contain" />
                            <View style={styles.statusBadge}>
                                <ShieldCheck size={12} color="#10b981" />
                                <Text style={styles.statusBadgeText}>OFFICIAL CONFIRMATION</Text>
                            </View>
                            <Text style={styles.docTitle}>Plan Activation Details</Text>
                            <Text style={styles.confId}>ID: NTH-CONF-{latestPayment?.id?.toString().padStart(6, '0') || '000000'}</Text>
                        </View>
                        <View style={styles.issueDateContainer}>
                            <Text style={styles.issueLabel}>ISSUE DATE</Text>
                            <Text style={styles.issueValue}>
                                {latestPayment?.createdAt ? format(new Date(latestPayment.createdAt), 'MMM dd, yyyy') : format(new Date(), 'MMM dd, yyyy')}
                            </Text>
                        </View>
                    </View>

                    {/* Top Stats Grid */}
                    <View style={styles.statsGrid}>
                        <View style={styles.statBox}>
                            <Text style={styles.statLabel}>Member</Text>
                            <View style={styles.statContent}>
                                <Text style={styles.memberName} numberOfLines={1}>{userData?.firstName} {userData?.lastName}</Text>
                                <Text style={styles.memberEmail} numberOfLines={1}>{userData?.email}</Text>
                            </View>
                        </View>
                        <View style={[styles.statBox, styles.statBoxSuccess]}>
                            <Text style={[styles.statLabel, { color: '#059669' }]}>Status</Text>
                            <View style={styles.statRow}>
                                <Text style={[styles.statusMain, { color: '#059669' }]}>ACTIVE</Text>
                                <View style={styles.successCircle}>
                                    <CheckCircle2 size={16} color="#059669" />
                                </View>
                            </View>
                        </View>
                    </View>

                    {/* Coverage card (Dark Header) */}
                    <View style={styles.coverageCard}>
                        <LinearGradient colors={['#1e293b', '#0f172a']} style={styles.cardHeader}>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.cardPlanName} numberOfLines={1}>{plan?.name || 'Healthcare Plan'}</Text>
                                <Text style={styles.cardPlanDesc} numberOfLines={1}>{plan?.description || 'Global Medical Concierge'}</Text>
                            </View>
                            <View style={styles.cardDateContainer}>
                                <Text style={styles.cardDateLabel}>PERIOD</Text>
                                <Text style={styles.cardDateValue}>June 9th–July 20th</Text>
                            </View>
                        </LinearGradient>
                        <View style={styles.cardBody}>
                            <View style={styles.cardSection}>
                                <Text style={styles.cardSectionTitle}>BENEFITS</Text>
                                {features.slice(0, 3).map((f: string, i: number) => (
                                    <View key={i} style={styles.benefitItem}>
                                        <CheckCircle2 size={12} color="#0251fc" />
                                        <Text style={styles.benefitText} numberOfLines={1}>{f}</Text>
                                    </View>
                                ))}
                            </View>
                            <View style={styles.cardSection}>
                                <Text style={styles.cardSectionTitle}>SERVICES</Text>
                                <View style={styles.servicesGrid}>
                                    <View style={styles.servicePill}>
                                        <Video size={12} color="#0251fc" />
                                        <Text style={styles.servicePillText}>24/7</Text>
                                    </View>
                                    <View style={styles.servicePill}>
                                        <Phone size={12} color="#0251fc" />
                                        <Text style={styles.servicePillText}>SOS</Text>
                                    </View>
                                </View>
                            </View>
                        </View>
                    </View>

                    {/* Payment Details (Dark Card) */}
                    <View style={styles.paymentCard}>
                        <View style={styles.paymentCardInfo}>
                            <View style={styles.paymentDetailsGrid}>
                                <View style={styles.pDetail}>
                                    <Text style={styles.pDetailLabel}>BASE PRICE</Text>
                                    <Text style={styles.pDetailValue}>
                                        ${latestPayment?.amount ? ((Number(latestPayment.amount) - (Number(latestPayment.taxCents) || 0) - (Number(latestPayment.processingFeeCents) || 0)) / 100).toFixed(2) : '0.00'}
                                    </Text>
                                </View>
                                <View style={styles.pDetail}>
                                    <Text style={styles.pDetailLabel}>TAXES & FEES</Text>
                                    <Text style={styles.pDetailValue}>
                                        + ${((Number(latestPayment?.taxCents || 0) + Number(latestPayment?.processingFeeCents || 0)) / 100).toFixed(2)}
                                    </Text>
                                </View>
                                <View style={[styles.pDetail, { width: '100%' }]}>
                                    <Text style={styles.pDetailStatus}>● Paid via Stripe</Text>
                                </View>
                            </View>
                        </View>
                        <View style={styles.amountBadge}>
                            <Text style={styles.amountLabel}>TOTAL PAID</Text>
                            <Text style={styles.amountValue}>
                                ${latestPayment?.amount ? (latestPayment.amount / 100).toFixed(2) : '0'}
                            </Text>
                        </View>
                    </View>

                    {/* Family Members Section */}
                    {familyMembers.length > 0 && (
                        <View style={styles.docSection}>
                            <Text style={styles.sectionLabel}>FAMILY BENEFICIARIES</Text>
                            <View style={styles.familyGrid}>
                                {familyMembers.map((member: any) => (
                                    <View key={member.id} style={styles.familyItem}>
                                        <Users size={12} color="#475569" />
                                        <Text style={styles.familyMemberName}>{member.firstName} {member.lastName}</Text>
                                        <Text style={styles.familyMemberRel}>{member.relationship || 'Member'}</Text>
                                    </View>
                                ))}
                            </View>
                        </View>
                    )}

                    {/* Itinerary Section */}
                    <View style={styles.docSection}>
                        <Text style={styles.sectionLabel}>TRAVEL ITINERARY</Text>
                        <View style={styles.itineraryBox}>
                            <MapPin size={12} color="#0251fc" />
                            <Text style={styles.itineraryText}>
                                {(() => {
                                    const raw = latestPayment?.itinerary || activePlan?.itinerary;
                                    if (!raw) return 'Coverage active globally for specified travel dates.';
                                    try {
                                        const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
                                        if (Array.isArray(parsed) && parsed.length > 0) {
                                            return parsed.map((dest: any) => dest.cityName || dest.locationName || dest.name || 'Unknown').join(', ');
                                        }
                                    } catch (e) {
                                        return 'Global Coverage Active';
                                    }
                                    return 'Coverage active globally for specified travel dates.';
                                })()}
                            </Text>
                        </View>
                    </View>

                    {/* Footer Verification */}
                    <View style={styles.docFooter}>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.footerBrand}>Navala Travel Health</Text>
                            <Text style={styles.footerNote}>Verified for WC 2026.</Text>
                        </View>
                        <View style={styles.verificationBox}>
                            <Text style={styles.vLabel}>VERIFICATION</Text>
                            <Text style={styles.vValue}>{verificationCode.slice(0, 10)}</Text>
                        </View>
                    </View>
                </View>

                {/* Bottom Actions */}
                <View style={styles.bottomActions}>
                    <TouchableOpacity style={styles.dashboardBtn} onPress={() => router.replace('/(tabs)')}>
                        <Text style={styles.dashboardBtnText}>Go to Dashboard</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.contractBtn} onPress={() => router.push('/contract')}>
                        <FileText size={18} color="#0251fc" />
                        <Text style={styles.contractBtnText}>Service Contract</Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f8fafc' },
    center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
    loadingText: { marginTop: 12, color: '#64748b', fontWeight: '600' },
    actionBar: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 16,
        paddingTop: 50,
        paddingBottom: 12,
    },
    backBtn: { flexDirection: 'row', alignItems: 'center', gap: 6 },
    backBtnText: { color: '#ffffff', fontWeight: '700' },
    downloadHeaderBtn: {
        backgroundColor: 'rgba(255,255,255,0.2)',
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        paddingHorizontal: 16,
        paddingVertical: 10,
        borderRadius: 12
    },
    downloadHeaderBtnText: { color: '#fff', fontWeight: '700', fontSize: 13 },
    scrollContent: { padding: SCREEN_WIDTH > 400 ? 16 : 10, paddingBottom: 40 },

    docWrapper: {
        backgroundColor: '#fff',
        borderRadius: 24,
        padding: SCREEN_WIDTH > 400 ? 24 : 16,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.1,
        shadowRadius: 20,
        elevation: 5,
        borderWidth: 1,
        borderColor: '#f1f5f9',
        overflow: 'hidden',
        position: 'relative'
    },
    gradientDecor: {
        position: 'absolute',
        top: -50,
        right: -50,
        width: 150,
        height: 150,
        backgroundColor: '#eff6ff',
        borderRadius: 75,
        opacity: 0.5
    },
    docHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: 20
    },
    logo: { width: 60, height: 30, marginBottom: 8 },
    statusBadge: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        backgroundColor: '#ecfdf5',
        paddingHorizontal: 8,
        paddingVertical: 3,
        borderRadius: 12,
        marginBottom: 8,
        alignSelf: 'flex-start'
    },
    statusBadgeText: { fontSize: 8, fontWeight: '800', color: '#059669' },
    docTitle: { fontSize: 20, fontWeight: '900', color: '#1e293b' },
    confId: { fontSize: 10, color: '#64748b', marginTop: 2 },
    issueDateContainer: { alignItems: 'flex-end' },
    issueLabel: { fontSize: 8, fontWeight: '800', color: '#94a3b8' },
    issueValue: { fontSize: 12, fontWeight: '700', color: '#1e293b', marginTop: 2 },

    statsGrid: { flexDirection: 'row', gap: 10, marginBottom: 20 },
    statBox: {
        flex: 1,
        backgroundColor: '#f8fafc',
        padding: 12,
        borderRadius: 16,
        borderWidth: 1,
        borderColor: '#f1f5f9'
    },
    statBoxSuccess: { backgroundColor: '#f0fdf4', borderColor: '#dcfce7' },
    statLabel: { fontSize: 8, fontWeight: '900', color: '#94a3b8', textTransform: 'uppercase', marginBottom: 4 },
    statContent: {},
    memberName: { fontSize: 14, fontWeight: '800', color: '#1e293b' },
    memberEmail: { fontSize: 10, color: '#64748b' },
    statRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    statusMain: { fontSize: 14, fontWeight: '900' },
    successCircle: { width: 20, height: 20, borderRadius: 10, backgroundColor: '#dcfce7', justifyContent: 'center', alignItems: 'center' },

    coverageCard: {
        borderRadius: 20,
        overflow: 'hidden',
        borderWidth: 1,
        borderColor: '#f1f5f9',
        marginBottom: 20
    },
    cardHeader: {
        padding: 16,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center'
    },
    cardPlanName: { color: '#fff', fontSize: 16, fontWeight: '900' },
    cardPlanDesc: { color: '#94a3b8', fontSize: 10, marginTop: 1 },
    cardDateContainer: { alignItems: 'flex-end' },
    cardDateLabel: { color: '#64748b', fontSize: 8, fontWeight: '800' },
    cardDateValue: { color: '#fff', fontSize: 12, fontWeight: '900' },
    cardBody: { padding: 16, flexDirection: 'row', gap: 12 },
    cardSection: { flex: 1 },
    cardSectionTitle: { fontSize: 8, fontWeight: '900', color: '#94a3b8', marginBottom: 8 },
    benefitItem: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 },
    benefitText: { fontSize: 11, fontWeight: '600', color: '#475569' },
    servicesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
    servicePill: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        backgroundColor: '#f8fafc',
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: '#f1f5f9'
    },
    servicePillText: { fontSize: 9, fontWeight: '700', color: '#1e293b' },

    paymentCard: {
        backgroundColor: '#0f172a',
        borderRadius: 20,
        padding: 16,
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 20
    },
    paymentCardInfo: { flex: 1 },
    paymentDetailsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
    pDetail: { width: '45%' },
    pDetailLabel: { fontSize: 8, fontWeight: '800', color: '#64748b', marginBottom: 2 },
    pDetailValue: { color: '#fff', fontSize: 10, fontWeight: '700' },
    pDetailStatus: { color: '#10b981', fontSize: 9, fontWeight: '900', marginTop: 4 },
    amountBadge: {
        backgroundColor: 'rgba(255,255,255,0.05)',
        padding: 12,
        borderRadius: 16,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: 'rgba(255,255,255,0.1)'
    },
    amountLabel: { color: '#64748b', fontSize: 8, fontWeight: '800', marginBottom: 2 },
    amountValue: { color: '#fff', fontSize: 22, fontWeight: '900' },

    docSection: { marginBottom: 15 },
    sectionLabel: { fontSize: 8, fontWeight: '900', color: '#94a3b8', textTransform: 'uppercase', marginBottom: 6 },
    familyGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
    familyItem: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        backgroundColor: '#f8fafc',
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: '#f1f5f9'
    },
    familyMemberName: { fontSize: 10, fontWeight: '700', color: '#1e293b' },
    familyMemberRel: { fontSize: 8, color: '#64748b', fontStyle: 'italic' },

    itineraryBox: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        backgroundColor: '#eff6ff',
        padding: 10,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#dbeafe'
    },
    itineraryText: { fontSize: 11, color: '#1e40af', fontWeight: '600', flex: 1 },

    docFooter: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginTop: 5,
        paddingTop: 16,
        borderTopWidth: 1,
        borderTopColor: '#f1f5f9'
    },
    footerBrand: { fontSize: 10, fontWeight: '700', color: '#1e293b' },
    footerNote: { fontSize: 9, color: '#94a3b8' },
    verificationBox: { alignItems: 'flex-end' },
    vLabel: { fontSize: 8, fontWeight: '800', color: '#94a3b8' },
    vValue: { fontSize: 10, fontWeight: '700', color: '#475569', marginTop: 1 },

    bottomActions: { marginTop: 20, gap: 10 },
    dashboardBtn: {
        backgroundColor: '#0251fc',
        paddingVertical: 16,
        borderRadius: 16,
        alignItems: 'center',
        shadowColor: '#0251fc',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 10,
        elevation: 4
    },
    dashboardBtnText: { color: '#fff', fontSize: 15, fontWeight: '800' },
    contractBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        paddingVertical: 16,
        borderRadius: 16,
        backgroundColor: '#eff6ff'
    },
    contractBtnText: { color: '#0251fc', fontSize: 14, fontWeight: '700' }
});
