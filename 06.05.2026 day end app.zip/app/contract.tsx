import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ActivityIndicator,
    ScrollView,
    TouchableOpacity,
    Image,
    Dimensions
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { UserApi } from '../src/api';
import { printDocument } from '../src/utils/print';
import { Alert } from 'react-native';
import { 
    ArrowLeft, 
    FileSignature, 
    Calendar, 
    ShieldCheck, 
    Info,
    AlertCircle,
    User,
    Download,
    CheckCircle2,
    MapPin,
    Users
} from 'lucide-react-native';
import { format } from 'date-fns';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export default function ContractScreen() {
    const [loading, setLoading] = useState(true);
    const [userData, setUserData] = useState<any>(null);
    const [activePlan, setActivePlan] = useState<any>(null);
    const [familyMembers, setFamilyMembers] = useState<any[]>([]);
    const [currentDate, setCurrentDate] = useState('');
    const [printing, setPrinting] = useState(false);
    const [docRef] = useState(`NTH-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`);

    const generateHtml = () => {
        const planName = activePlan?.plan?.name || activePlan?.name || 'Standard Plan';
        const coverageType = familyMembers.length > 0 ? 'Family Coverage' : 'Individual';
        const userName = `${userData?.firstName} ${userData?.lastName}`;
        const userEmail = userData?.email || '';
        
        const itineraryArray = (() => {
            const raw = activePlan?.itinerary;
            if (!raw) return [];
            try {
                const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
                if (Array.isArray(parsed)) return parsed.map((d: any) => d.cityName || d.locationName || d.name || 'Unknown');
            } catch(e) {}
            return [];
        })();
        const itineraryStr = itineraryArray.length > 0 ? itineraryArray.join(', ') : 'Coverage active globally for specified travel dates.';
        return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Service Contract</title>
    <style>
        body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; padding: 40px; background-color: #f8fafc; color: #1e293b; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        .container { max-width: 800px; margin: 0 auto; background-color: #ffffff; padding: 40px; min-height: 1000px; position: relative; border: 1px solid #f1f5f9; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .flex { display: flex; }
        .justify-between { justify-content: space-between; }
        .items-center { align-items: center; }
        .items-end { align-items: flex-end; }
        .border-b-2 { border-bottom: 2px solid #0f172a; padding-bottom: 2rem; margin-bottom: 2rem; }
        h1 { font-size: 28px; font-weight: 900; color: #0f172a; margin: 0; letter-spacing: -0.05em; }
        .subtitle { font-size: 10px; font-weight: bold; color: #64748b; text-transform: uppercase; letter-spacing: 0.1em; margin: 4px 0 0 0; }
        .meta-right { text-align: right; font-size: 10px; color: #64748b; font-weight: 500; }
        .meta-right p { margin: 0 0 4px 0; }
        .meta-right span { color: #0f172a; font-weight: bold; }
        .section-box { background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 1.5rem; margin-bottom: 2rem; }
        .section-title { font-size: 12px; font-weight: bold; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.1em; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; margin: 0 0 1rem 0; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
        .info-label { font-size: 10px; color: #64748b; text-transform: uppercase; font-weight: bold; margin: 0 0 4px 0; }
        .info-value { font-size: 18px; font-weight: bold; color: #0f172a; margin: 0; }
        .info-sub { font-size: 12px; color: #475569; margin: 4px 0 0 0; }
        .info-sub.blue { color: #2563eb; font-weight: bold; }
        .family-item { background-color: white; border: 1px solid #e2e8f0; padding: 1rem; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; }
        .family-name { font-size: 14px; font-weight: bold; color: #1e293b; margin: 0; }
        .family-rel { font-size: 10px; background-color: #f1f5f9; color: #475569; padding: 2px 8px; border-radius: 4px; font-weight: bold; text-transform: uppercase; }
        .itinerary-box { font-size: 14px; font-weight: bold; color: #1e3a8a; background-color: #eff6ff; padding: 12px; border-radius: 6px; border: 1px solid #dbeafe; margin-top: 4px; }
        .period-box { font-size: 14px; font-weight: bold; color: #0f172a; margin-top: 4px; }
        .terms-box { font-size: 12px; color: #334155; line-height: 1.6; text-align: justify; }
        .term-clause { margin-bottom: 1rem; }
        .term-clause strong { color: #0f172a; font-weight: bold; display: block; margin-bottom: 4px; }
        .signatures { margin-top: 4rem; padding-top: 2rem; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: flex-end; }
        .sig-block { width: 250px; text-align: center; }
        .sig-line { border-bottom: 1px solid #1e293b; padding-bottom: 8px; margin-bottom: 8px; height: 64px; display: flex; align-items: flex-end; justify-content: center; }
        .sig-text { font-family: 'Brush Script MT', cursive, serif; font-style: italic; font-size: 24px; color: #2563eb; margin: 0; }
        .sig-text.dark { color: #1e293b; }
        .sig-name { font-weight: bold; font-size: 14px; color: #0f172a; margin: 0; }
        .sig-title { font-size: 10px; text-transform: uppercase; letter-spacing: 0.1em; color: #94a3b8; font-weight: bold; margin: 4px 0 0 0; }
    </style>
</head>
<body>
    <div class="container">
        <div class="flex justify-between items-center border-b-2">
            <div>
                <h1>Navala Travel Health</h1>
                <p class="subtitle">Medical Services Agreement</p>
            </div>
            <div class="meta-right">
                <p>Contract Ref: <span>${docRef}</span></p>
                <p>Date Generated: <span>${currentDate}</span></p>
            </div>
        </div>

        <div class="section-box">
            <h2 class="section-title">Patient Details</h2>
            <div class="grid-2">
                <div>
                    <p class="info-label">Primary Member</p>
                    <p class="info-value">${userName}</p>
                    <p class="info-sub">${userEmail}</p>
                </div>
                <div>
                    <p class="info-label">Plan Configuration</p>
                    <p class="info-value">${planName}</p>
                    <p class="info-sub blue">${coverageType}</p>
                </div>
            </div>
        </div>

        ${familyMembers.length > 0 ? `
        <div style="margin-bottom: 2rem;">
            <h2 class="section-title">Family Coverage Roster</h2>
            <div class="grid-2" style="gap: 1rem;">
                ${familyMembers.map(m => `
                    <div class="family-item">
                        <span class="family-name">${m.firstName} ${m.lastName}</span>
                        <span class="family-rel">${m.relationship || 'Member'}</span>
                    </div>
                `).join('')}
            </div>
        </div>
        ` : ''}

        <div style="margin-bottom: 2.5rem;">
            <h2 class="section-title">Coverage Parameters</h2>
            <div style="margin-bottom: 1rem;">
                <p class="info-label">Travel Itinerary</p>
                <div class="itinerary-box">📍 ${itineraryStr}</div>
            </div>
            <div>
                <p class="info-label">Active Period</p>
                <p class="period-box">Valid strictly between: June to July</p>
            </div>
        </div>

        <div style="margin-bottom: 3rem;">
            <h2 class="section-title">Terms & Conditions</h2>
            <div class="terms-box">
                <div class="term-clause">
                    <strong>1. Nature of the Agreement</strong>
                    This Medical Services Contract ("Agreement") is entered into between Navala Travel Health ("Provider") and the aforementioned individual ("Patient"). This Agreement establishes the terms under which the Provider will deliver healthcare services, including telehealth and facilitated in-person care, during the specified Coverage Period associated with the World Cup 2026 travel timeline.
                </div>
                <div class="term-clause">
                    <strong>2. Scope of Services</strong>
                    During the Coverage Period (9 Jun to 20 July), the Patient is entitled to access the Provider's global network of healthcare professionals. Services include but are not limited to 24/7 on-demand telehealth consultations, emergency medical coordination, and prescription management. All services are subject to the specific tiers and limitations of the Patient's selected Plan Configuration.
                </div>
                <div class="term-clause">
                    <strong>3. Acknowledgment of Limitations</strong>
                    The Patient acknowledges that Navala Travel Health is a facilitator and direct provider of telehealth care, but relies on third-party local healthcare facilities for emergency and intensive physical care. The Provider shall not be held liable for the outcomes of physical interventions performed by third-party facilities not directly employed by the Provider.
                </div>
                <div class="term-clause">
                    <strong>4. Privacy and Data Sharing</strong>
                    The Patient consents to the collection, processing, and sharing of their medical and personal data by Navala Travel Health with partnered local practitioners, hospitals, and pharmacies solely for the purpose of administering necessary medical care.
                </div>
                <div class="term-clause">
                    <strong>5. Exclusions and Out-of-Pocket Expenses</strong>
                    While the plan covers coordination and associated telehealth professional fees, the Patient accepts that certain localized treatments, specialized surgeries, and physical pharmacy prescriptions may incur additional out-of-pocket expenses.
                </div>
                <div class="term-clause">
                    <strong>6. Termination and Liability</strong>
                    This agreement automatically terminates at the end of the Coverage Period. The Provider's total liability under this contract shall not exceed the total fees paid by the Patient for the plan.
                </div>
            </div>
        </div>

        <div class="signatures">
            <div class="sig-block">
                <div class="sig-line">
                    <p class="sig-text">Digital Signature Attached</p>
                </div>
                <p class="sig-name">Navala Travel Health</p>
                <p class="sig-title">Authorized Provider</p>
            </div>
            <div class="sig-block">
                <div class="sig-line">
                    <p class="sig-text dark">${userData?.firstName} ${userData?.lastName}</p>
                </div>
                <p class="sig-name">${userName}</p>
                <p class="sig-title">Patient / Member</p>
            </div>
        </div>
    </div>
</body>
</html>
        `;
    };

    const handlePrint = async () => {
        const uuid = userData?.userUuid || userData?.id;
        
        if (!uuid) {
            Alert.alert('Error', 'User data not found.');
            return;
        }

        try {
            setPrinting(true);
            const userName = userData?.firstName ? `_${userData.firstName}` : '';
            const customHtml = generateHtml();
            await printDocument(`/api/shared/contract/${uuid}/view`, `Navala_Service_Contract${userName}.pdf`, customHtml);
        } catch (error) {
            Alert.alert('Download Failed', 'Could not generate contract PDF. Please try again later.');
        } finally {
            setPrinting(false);
        }
    };

    useEffect(() => {
        loadData();
        setCurrentDate(format(new Date(), 'MMMM dd, yyyy'));
    }, []);

    const loadData = async () => {
        try {
            setLoading(true);
            const [profileRes, planRes, familyRes] = await Promise.all([
                UserApi.getProfile(),
                UserApi.getActivePlan(),
                UserApi.getFamilyMembers()
            ]);

            if (profileRes.success) {
                setUserData(profileRes.data);
            }
            if (planRes.success) {
                setActivePlan(planRes.data.activePlan || planRes.data);
            }
            if (familyRes.success) {
                setFamilyMembers(familyRes.data.familyMembers || []);
            }
        } catch (error) {
            console.error('Failed to load contract data:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <View style={styles.center}>
                <ActivityIndicator size="large" color="#0251fc" />
            </View>
        );
    }

    const planName = activePlan?.plan?.name || activePlan?.name || 'Standard Plan';
    const coverageType = activePlan?.plan?.maxPersons > 1 ? 'Family' : 'Individual';

    return (
        <View style={styles.container}>
            {/* Action Header */}
            <LinearGradient colors={['#0251fc', '#072169']} style={styles.actionHeader}>
                <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
                    <ArrowLeft color="#ffffff" size={24} />
                </TouchableOpacity>
                <View style={{ flex: 1, marginLeft: 12 }}>
                    <Text style={[styles.actionHeaderTitle, { color: '#ffffff' }]}>Service Contract</Text>
                    <Text style={[styles.actionHeaderSubtitle, { color: '#e0e7ff' }]}>Official Agreement</Text>
                </View>
                <TouchableOpacity 
                    style={[styles.downloadIconBtn, printing && { opacity: 0.5 }, { backgroundColor: 'rgba(255,255,255,0.2)' }]} 
                    onPress={handlePrint}
                    disabled={printing}
                >
                    {printing ? (
                        <ActivityIndicator size="small" color="#ffffff" />
                    ) : (
                        <Download color="#ffffff" size={22} />
                    )}
                </TouchableOpacity>
            </LinearGradient>

            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
                {/* Informational Banner */}
                <View style={styles.infoBanner}>
                    <FileSignature size={20} color="#b45309" />
                    <Text style={styles.infoBannerText}>
                        <Text style={styles.bold}>Official Document:</Text> Legally binding agreement with Navala Travel Health.
                    </Text>
                </View>

                {/* Simulated A4 Page 1 */}
                <View style={styles.pageContainer}>
                    <View style={styles.documentHeader}>
                        <Image 
                            source={require('../assets/images/icon.png')} 
                            style={styles.logo}
                            resizeMode="contain"
                        />
                        <View style={styles.headerMetaData}>
                            <Text style={styles.docType}>MEDICAL SERVICES CONTRACT</Text>
                            <Text style={styles.docRef}>Ref: {docRef}</Text>
                        </View>
                    </View>

                    <View style={styles.docDivider} />

                    {/* Patient Section */}
                    <View style={styles.docSection}>
                        <Text style={styles.sectionLabel}>PATIENT INFORMATION</Text>
                        <View style={styles.patientInfoBox}>
                            <View style={styles.infoColumn}>
                                <Text style={styles.infoLabel}>Name</Text>
                                <Text style={styles.infoValue} numberOfLines={1}>{userData?.firstName} {userData?.lastName}</Text>
                            </View>
                            <View style={[styles.infoColumn, { alignItems: 'flex-end' }]}>
                                <Text style={styles.infoLabel}>Email</Text>
                                <Text style={styles.infoValueSmall} numberOfLines={1}>{userData?.email}</Text>
                            </View>
                        </View>
                        
                        <View style={[styles.patientInfoBox, { marginTop: 10 }]}>
                            <View style={styles.infoColumn}>
                                <Text style={styles.infoLabel}>Plan</Text>
                                <Text style={styles.infoValue} numberOfLines={1}>{planName}</Text>
                            </View>
                            <View style={[styles.infoColumn, { alignItems: 'flex-end' }]}>
                                <Text style={styles.infoLabel}>Type</Text>
                                <Text style={styles.infoValue}>{coverageType}</Text>
                            </View>
                        </View>
                    </View>

                    {/* Family Coverage Section */}
                    {familyMembers.length > 0 && (
                        <View style={styles.docSection}>
                            <Text style={styles.sectionLabel}>FAMILY COVERAGE</Text>
                            <View style={styles.familyGrid}>
                                {familyMembers.map((member: any) => (
                                    <View key={member.id} style={styles.familyItem}>
                                        <Users size={12} color="#475569" />
                                        <Text style={styles.familyMemberName}>{member.firstName} {member.lastName}</Text>
                                        <Text style={styles.familyMemberRel}>{member.relationship || 'Member'}</Text>
                                    </View>
                                ))}
                            </View>
                        </View>
                    )}

                    {/* Travel Itinerary Section */}
                    <View style={styles.docSection}>
                        <Text style={styles.sectionLabel}>TRAVEL ITINERARY</Text>
                        <View style={styles.itineraryBox}>
                            <MapPin size={12} color="#0251fc" />
                            <Text style={styles.itineraryText}>
                                {(() => {
                                    const raw = activePlan?.itinerary;
                                    if (!raw) return 'Coverage active globally for specified travel dates.';
                                    try {
                                        const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
                                        if (Array.isArray(parsed) && parsed.length > 0) {
                                            return parsed.map((dest: any) => dest.cityName || dest.locationName || dest.name || 'Unknown').join(', ');
                                        }
                                    } catch (e) {
                                        return 'Global Coverage Active';
                                    }
                                    return 'Coverage active globally for specified travel dates.';
                                })()}
                            </Text>
                        </View>
                    </View>

                    {/* Coverage Period Section */}
                    <View style={styles.docSection}>
                        <Text style={styles.sectionLabel}>COVERAGE PERIOD</Text>
                        <View style={styles.coveragePeriodBox}>
                            <Text style={styles.coverageText}>
                                Valid strictly between: <Text style={styles.coverageDates}>Jun to Jul</Text>
                            </Text>
                        </View>
                    </View>

                    {/* Agreement Clauses */}
                    <View style={styles.docSection}>
                        <View style={styles.clause}>
                            <Text style={styles.clauseHeader}>1. Nature of the Agreement</Text>
                            <Text style={styles.clauseBody}>
                                This Medical Services Contract ("Agreement") is entered into between Navala Travel Health ("Provider") and the aforementioned individual ("Patient"). This Agreement establishes the terms under which the Provider will deliver healthcare services, including telehealth and facilitated in-person care, during the specified Coverage Period associated with the World Cup 2026 travel timeline.
                            </Text>
                        </View>

                        <View style={styles.clause}>
                            <Text style={styles.clauseHeader}>2. Scope of Services</Text>
                            <Text style={styles.clauseBody}>
                                During the Coverage Period (9 Jun to 20 July), the Patient is entitled to access the Provider's global network of healthcare professionals. Services include but are not limited to 24/7 on-demand telehealth consultations, emergency medical coordination, and prescription management.
                            </Text>
                        </View>

                        <View style={styles.clause}>
                            <Text style={styles.clauseHeader}>3. Acknowledgment of Limitations</Text>
                            <Text style={styles.clauseBody}>
                                The Patient acknowledges that Navala Travel Health is a facilitator and direct provider of telehealth care, but relies on third-party local healthcare facilities for emergency and intensive physical care.
                            </Text>
                        </View>
                    </View>

                    <View style={styles.pageFooter}>
                        <Text style={styles.pageNumber}>Page 1 of 2</Text>
                        <Text style={styles.genDate}>{currentDate}</Text>
                    </View>
                </View>

                {/* Simulated A4 Page 2 */}
                <View style={[styles.pageContainer, { marginTop: 20 }]}>
                    <View style={styles.docSection}>
                        <Text style={styles.docType}>TERMS OF COVERAGE & AGREEMENT</Text>
                        <View style={styles.docDivider} />
                        
                        <View style={styles.clause}>
                            <Text style={styles.clauseHeader}>4. Privacy and Data Sharing</Text>
                            <Text style={styles.clauseBody}>
                                The Patient consents to the collection, processing, and sharing of their medical and personal data by Navala Travel Health with partnered local practitioners, hospitals, and pharmacies solely for the purpose of administering necessary medical care.
                            </Text>
                        </View>

                        <View style={styles.clause}>
                            <Text style={styles.clauseHeader}>5. Exclusions and Out-of-Pocket Expenses</Text>
                            <Text style={styles.clauseBody}>
                                While the plan covers coordination and associated telehealth professional fees, the Patient accepts that certain localized treatments, specialized surgeries, and physical pharmacy prescriptions may incur additional out-of-pocket expenses.
                            </Text>
                        </View>

                        <View style={styles.clause}>
                            <Text style={styles.clauseHeader}>6. Termination and Liability</Text>
                            <Text style={styles.clauseBody}>
                                This agreement automatically terminates at the end of the Coverage Period. The Provider's total liability under this contract shall not exceed the total fees paid by the Patient for the plan.
                            </Text>
                        </View>
                    </View>

                    {/* Signatures */}
                    <View style={styles.signaturesArea}>
                        <View style={styles.signatureBlock}>
                            <View style={styles.signatureLine}>
                                <Text style={styles.signatureScript}>Navala Medical Board</Text>
                            </View>
                            <Text style={styles.signatoryLabel}>Authorized Signatory</Text>
                            <Text style={styles.signatoryCompany}>Navala Travel Health</Text>
                        </View>

                        <View style={styles.signatureBlock}>
                            <View style={styles.signatureLine}>
                                <View style={styles.acceptedBadge}>
                                    <CheckCircle2 size={10} color="#059669" />
                                    <Text style={styles.acceptedText}>Accepted</Text>
                                </View>
                            </View>
                            <Text style={styles.signatoryLabel} numberOfLines={1}>{userData?.firstName} {userData?.lastName}</Text>
                            <Text style={styles.signatoryCompany}>Patient / Beneficiary</Text>
                        </View>
                    </View>

                    <View style={styles.pageFooter}>
                        <Text style={styles.pageNumber}>Page 2 of 2</Text>
                        <Text style={styles.genDate}>{currentDate}</Text>
                    </View>
                </View>

                {/* Primary Action */}
                <TouchableOpacity style={styles.primaryDownloadBtn} onPress={handlePrint}>
                    <Download size={20} color="#fff" />
                    <Text style={styles.primaryDownloadBtnText}>Download PDF Document</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.footerBackBtn} onPress={() => router.back()}>
                    <Text style={styles.footerBackBtnText}>Back to Profile</Text>
                </TouchableOpacity>
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f8fafc' },
    center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
    actionHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingTop: 50,
        paddingBottom: 16,
    },
    actionHeaderTitle: { fontSize: 18, fontWeight: '800', color: '#1e293b' },
    actionHeaderSubtitle: { fontSize: 12, color: '#64748b', fontWeight: '500' },
    backButton: { width: 44, height: 44, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.2)', justifyContent: 'center', alignItems: 'center' },
    downloadIconBtn: { width: 44, height: 44, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.2)', justifyContent: 'center', alignItems: 'center' },
    scrollContent: { padding: SCREEN_WIDTH > 400 ? 20 : 12, paddingBottom: 50 },
    infoBanner: {
        flexDirection: 'row',
        backgroundColor: '#fffbeb',
        padding: 16,
        borderRadius: 16,
        borderWidth: 1,
        borderColor: '#fef3c7',
        gap: 12,
        marginBottom: 20
    },
    infoBannerText: { flex: 1, fontSize: 13, color: '#92400e', lineHeight: 18 },
    bold: { fontWeight: '800' },

    pageContainer: {
        backgroundColor: '#fff',
        borderRadius: 12,
        padding: SCREEN_WIDTH > 400 ? 24 : 16,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.1,
        shadowRadius: 20,
        elevation: 5,
        borderWidth: 1,
        borderColor: '#e2e8f0',
        minHeight: 400,
    },
    documentHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: 15
    },
    logo: { width: 60, height: 30 },
    headerMetaData: { alignItems: 'flex-end', flex: 1 },
    docType: { fontSize: 9, fontWeight: '800', color: '#1e293b', textAlign: 'right' },
    docRef: { fontSize: 8, color: '#64748b', marginTop: 2 },
    docDivider: { height: 2, backgroundColor: '#0f172a', marginBottom: 20 },
    
    docSection: { marginBottom: 20 },
    sectionLabel: { fontSize: 9, fontWeight: '900', color: '#94a3b8', letterSpacing: 1, marginBottom: 8 },
    familyGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 5 },
    familyItem: { 
        flexDirection: 'row', 
        alignItems: 'center', 
        gap: 6, 
        backgroundColor: '#f8fafc', 
        paddingHorizontal: 8, 
        paddingVertical: 4, 
        borderRadius: 8,
        borderWidth: 1,
        borderColor: '#f1f5f9'
    },
    familyMemberName: { fontSize: 10, fontWeight: '700', color: '#1e293b' },
    familyMemberRel: { fontSize: 8, color: '#64748b', fontStyle: 'italic' },
    
    itineraryBox: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        backgroundColor: '#eff6ff',
        padding: 10,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#dbeafe'
    },
    itineraryText: { fontSize: 11, color: '#1e40af', fontWeight: '600', flex: 1 },

    patientInfoBox: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: '#f8fafc',
        padding: 10,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: '#f1f5f9'
    },
    infoColumn: { flex: 1 },
    infoLabel: { fontSize: 8, color: '#94a3b8', fontWeight: '700', textTransform: 'uppercase', marginBottom: 2 },
    infoValue: { fontSize: 13, fontWeight: '800', color: '#1e293b' },
    infoValueSmall: { fontSize: 11, fontWeight: '600', color: '#1e293b' },

    coveragePeriodBox: {
        backgroundColor: '#f0f9ff',
        padding: 10,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: '#e0f2fe'
    },
    coverageText: { fontSize: 13, color: '#0369a1', fontWeight: '600' },
    coverageDates: { fontSize: 14, fontWeight: '900' },

    clause: { marginBottom: 12 },
    clauseHeader: { fontSize: 13, fontWeight: '800', color: '#1e293b', marginBottom: 4 },
    clauseBody: { fontSize: 11, color: '#475569', lineHeight: 16, textAlign: 'justify' },

    signaturesArea: {
        marginTop: 20,
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    signatureBlock: { width: '45%' },
    signatureLine: {
        borderBottomWidth: 1,
        borderBottomColor: '#cbd5e1',
        paddingBottom: 4,
        marginBottom: 8,
        height: 24,
        justifyContent: 'flex-end'
    },
    signatureScript: { fontSize: 13, fontStyle: 'italic', color: '#475569' },
    signatoryLabel: { fontSize: 9, fontWeight: '800', color: '#1e293b' },
    signatoryCompany: { fontSize: 8, color: '#64748b' },
    acceptedBadge: { flexDirection: 'row', alignItems: 'center', gap: 4 },
    acceptedText: { fontSize: 10, fontWeight: '700', color: '#059669' },

    pageFooter: {
        marginTop: 30,
        paddingTop: 12,
        borderTopWidth: 1,
        borderTopColor: '#f1f5f9',
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    pageNumber: { fontSize: 9, color: '#94a3b8' },
    genDate: { fontSize: 9, color: '#94a3b8' },

    primaryDownloadBtn: {
        backgroundColor: '#0251fc',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 10,
        paddingVertical: 18,
        borderRadius: 16,
        marginTop: 20,
        shadowColor: '#0251fc',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 10,
        elevation: 4
    },
    primaryDownloadBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
    footerBackBtn: {
        paddingVertical: 18,
        alignItems: 'center',
        marginTop: 10
    },
    footerBackBtnText: { color: '#64748b', fontSize: 15, fontWeight: '600' }
});
