import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import { Platform } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { STRIPE_CONFIG } from '../src/config/stripe';
import { VersionCheck } from '../src/components/VersionCheck';

// Safe Stripe loading for web compatibility
let StripeProvider: any = ({ children }: any) => <>{children}</>;

if (Platform.OS !== 'web') {
  try {
    const Stripe = require('@stripe/stripe-react-native');
    StripeProvider = Stripe.StripeProvider;
  } catch (e) {
    console.warn('Stripe native module not found');
  }
}

export default function RootLayout() {
  useFrameworkReady();

  return (
    <SafeAreaProvider>
      <StripeProvider
        publishableKey={STRIPE_CONFIG.publishableKey}
        merchantIdentifier={STRIPE_CONFIG.merchantIdentifier}
        urlScheme={STRIPE_CONFIG.urlScheme}
      >
        <Stack initialRouteName="index" screenOptions={{ headerShown: false }}>
          <Stack.Screen name="index" />
          <Stack.Screen name="login" />
          <Stack.Screen name="signup" />
          <Stack.Screen name="plans" />
          <Stack.Screen name="(tabs)" />
          <Stack.Screen name="+not-found" />
        </Stack>
        <StatusBar style="auto" />
        <VersionCheck />
      </StripeProvider>
    </SafeAreaProvider>
  );
}
