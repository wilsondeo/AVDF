import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ActivityIndicator,
    FlatList,
    TouchableOpacity,
    Alert,
    Platform,
    RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { PlansApi, UserApi, AppointmentsApi, ItineraryApi, SystemConfigApi } from '../src/api';
import { STRIPE_CONFIG } from '../src/config/stripe';
import { Check, Plus, MapPin, X, Plane, Info, ShieldCheck, Video, PhoneCall, Sparkles, Shield } from 'lucide-react-native';
import { Modal, ScrollView, TextInput } from 'react-native';

// Safe Stripe hook for web compatibility
let useStripeHook: any = () => ({ initPaymentSheet: async () => ({}), presentPaymentSheet: async () => ({}) });

if (Platform.OS !== 'web') {
    try {
        const Stripe = require('@stripe/stripe-react-native');
        useStripeHook = Stripe.useStripe;
    } catch (e) {
        console.warn('Stripe native module not found');
    }
}

interface Plan {
    id: number;
    planId: string;
    name: string;
    price: string | number;
    validityDays: number;
    description: string;
    features: string;
    services?: string[];
    planTabName?: string;
    maxPersons?: number;
}

export default function PlansScreen() {
    const [plans, setPlans] = useState<Plan[]>([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [activePlan, setActivePlan] = useState<any>(null);
    const [purchasing, setPurchasing] = useState<number | null>(null);
    const [activeTab, setActiveTab] = useState<'INDIVIDUAL' | 'FAMILY_2' | 'FAMILY_3_4'>('INDIVIDUAL');
    const stripe = useStripeHook();

    // Destination & Tax State
    const [locations, setLocations] = useState<any[]>([]);
    const [selectedDestinations, setSelectedDestinations] = useState<any[]>([]);
    const [showAddCityModal, setShowAddCityModal] = useState(false);
    const [selectedCountry, setSelectedCountry] = useState('');
    const [selectedCity, setSelectedCity] = useState('');
    const [selectedState, setSelectedState] = useState('');
    const [showCountryDrop, setShowCountryDrop] = useState(false);
    const [showCityDrop, setShowCityDrop] = useState(false);

    // Wizard Flow State
    const [currentStep, setCurrentStep] = useState(1);
    const [processingFeePercent, setProcessingFeePercent] = useState(0);
    const [previousItineraryCountries, setPreviousItineraryCountries] = useState<string[]>([]);
    const [isTaxEnabled, setIsTaxEnabled] = useState<boolean>(true);

    useEffect(() => {
        loadData();
        // Auto-refresh data every 10 seconds in the background
        const interval = setInterval(() => loadData(true), 10000);
        return () => clearInterval(interval);
    }, []);

    const loadData = async (silent = false) => {
        try {
            if (!silent && !refreshing) setLoading(true);
            const [plansRes, activeRes, locationsRes, taxEnabledRes] = await Promise.all([
                PlansApi.getPlans().catch(e => { console.error('Plans error:', e); return { success: false }; }),
                UserApi.getActivePlan().catch(e => { console.error('Active plan error:', e); return { success: false }; }),
                AppointmentsApi.getLocations().catch(e => { console.error('Locations error:', e); return null; }),
                SystemConfigApi.get('is_location_tax_enabled').catch(() => ({ success: false, data: "true" }))
            ]);

            if (taxEnabledRes && taxEnabledRes.success) {
                setIsTaxEnabled(taxEnabledRes.data === 'true');
            }

            // Robust plans parsing
            if (plansRes && plansRes.success && plansRes.data) {
                const planList = plansRes.data.plans || (Array.isArray(plansRes.data) ? plansRes.data : []);
                const sorted = [...planList].sort((a, b) => Number(a.price) - Number(b.price));
                setPlans(sorted);
            } else if (Array.isArray(plansRes)) {
                const sorted = [...plansRes].sort((a, b) => Number(a.price) - Number(b.price));
                setPlans(sorted);
            }

            // Robust active plan parsing
            if (activeRes && activeRes.success && activeRes.data) {
                const actualPlan = activeRes.data.activePlan || activeRes.data;
                if (actualPlan && (actualPlan.plan || actualPlan.planId)) {
                    setActivePlan(actualPlan);
                    // Skip Step 1 if user is in upgrade flow (has an active plan)
                    setCurrentStep(2);
                } else {
                    setActivePlan(null);
                }
            }

            // Locations parsing
            if (locationsRes && locationsRes.success && Array.isArray(locationsRes.data)) {
                const grouped = locationsRes.data.reduce((acc: any[], curr: any) => {
                    let country = acc.find(c => c.country === curr.country);
                    if (!country) {
                        country = { country: curr.country, cities: [] };
                        acc.push(country);
                    }
                    if (!country.cities.find((city: any) => city.name === curr.city)) {
                        country.cities.push({ ...curr, name: curr.city });
                    }
                    return acc;
                }, []);
                setLocations(grouped);
            }

            // Fetch Processing Fee
            const feeRes = await SystemConfigApi.get('processing_fee_percentage');
            if (feeRes.success && feeRes.data) {
                setProcessingFeePercent(parseFloat(feeRes.data) || 0);
            }

            // Fetch Previous Itinerary
            const itinRes = await ItineraryApi.getItinerary();
            if (itinRes.success && Array.isArray(itinRes.data)) {
                const countries = itinRes.data.map((i: any) => String(i.location?.country || '').trim().toLowerCase()).filter(Boolean);
                setPreviousItineraryCountries(countries);

                // Auto-populate current destinations if empty
                if (selectedDestinations.length === 0 && itinRes.data.length > 0) {
                    const loaded = itinRes.data.map((i: any) => ({
                        ...i.location,
                        id: i.locationId,
                        name: i.location?.city
                    }));
                    setSelectedDestinations(loaded);
                }
            }
        } catch (error: any) {
            console.error('Failed to fetch data:', error);
            Alert.alert('Error', 'Could not load plans. Please check your connection.');
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    const onRefresh = () => {
        setRefreshing(true);
        loadData(true);
    };

    const calculateTaxes = (planPrice: number) => {
        if (selectedDestinations.length === 0 || !isTaxEnabled) return 0;

        let totalTax = 0;
        const seenCountries = new Set();
        selectedDestinations.forEach(dest => {
            const countryKey = String(dest.country || '').trim().toLowerCase();
            
            // Smart Tax Logic: Only apply tax if NOT already paid in previous plan
            const alreadyPaid = activePlan && previousItineraryCountries.includes(countryKey);
            
            if (countryKey && !seenCountries.has(countryKey) && !alreadyPaid) {
                seenCountries.add(countryKey);
                const taxVal = Number(dest.taxValue || 0);
                if (dest.taxType === 'PERCENTAGE') {
                    totalTax += (taxVal / 100) * planPrice;
                } else {
                    totalTax += taxVal;
                }
            }
        });
        return totalTax;
    };

    const handleAddDestination = () => {
        const countryObj = locations.find(l => l.country === selectedCountry);
        const cityObj = countryObj?.cities.find((c: any) => c.name === selectedCity);

        if (cityObj) {
            // Check if already added
            if (selectedDestinations.find(d => d.id === cityObj.id)) {
                Alert.alert('Duplicate', 'This city is already in your itinerary.');
                return;
            }
            setSelectedDestinations([...selectedDestinations, cityObj]);
            setSelectedCountry('');
            setSelectedCity('');
            setSelectedState('');
            setShowAddCityModal(false);
        }
    };

    const removeDestination = (id: number) => {
        setSelectedDestinations(selectedDestinations.filter(d => d.id !== id));
    };

    const handleBuy = async (plan: Plan) => {
        if (Platform.OS === 'web') {
            Alert.alert('Not Supported', 'Payments require a physical device.');
            return;
        }

        const currentPlanPrice = Number(activePlan?.plan?.price || activePlan?.price || 0);
        const selectedPlanPrice = Number(plan.price);
        const isUpgrade = activePlan && selectedPlanPrice > currentPlanPrice;
        
        const baseDiff = isUpgrade ? (selectedPlanPrice - currentPlanPrice) : selectedPlanPrice;
        const planTax = calculateTaxes(baseDiff);
        const feeAmount = (baseDiff + planTax) * (processingFeePercent / 100);
        const finalTotal = baseDiff + planTax + feeAmount;

        const subtotal = baseDiff + planTax;
        let breakdownMsg = `Cost of plan: $${baseDiff.toFixed(2)}`;
        if (planTax > 0) breakdownMsg += `\nCountry Health Levy: $${planTax.toFixed(2)}`;
        breakdownMsg += `\nSubtotal: $${subtotal.toFixed(2)}`;
        if (processingFeePercent > 0) breakdownMsg += `\n${processingFeePercent}% Processing Fees: +$${feeAmount.toFixed(2)}`;
        breakdownMsg += `\n\nTotal: $${finalTotal.toFixed(2)}`;

        if (activePlan) {
            if (selectedPlanPrice < currentPlanPrice) {
                Alert.alert(
                    'Plan Downgrade',
                    'You cannot move down to a lower plan.',
                    [{ text: 'OK' }]
                );
                return;
            }

            Alert.alert(
                'Confirm Upgrade',
                `${breakdownMsg}\n\nYou already have an active plan. Would you like to pay the difference and upgrade?`,
                [
                    { text: 'Cancel', style: 'cancel' },
                    { text: 'Proceed to Pay', onPress: () => processPurchase(plan) }
                ]
            );
        } else {
            Alert.alert(
                'Confirm Purchase',
                `${breakdownMsg}\n\nWould you like to proceed to payment?`,
                [
                    { text: 'Cancel', style: 'cancel' },
                    { text: 'Proceed to Pay', onPress: () => processPurchase(plan) }
                ]
            );
        }
    };

    const processPurchase = async (plan: Plan) => {
        setPurchasing(plan.id);
        try {
            // Map destinations to the format backend expects
            const itineraryData = selectedDestinations.map(d => ({
                locationId: d.id,
                arrivalDate: new Date().toISOString(), // Default for now
                departureDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // Default 30 days
            }));

            const taxAmount = calculateTaxes(Number(plan.price));
            const response = await PlansApi.purchasePlan(plan.planId, taxAmount, itineraryData);
            if (response.success && response.data) {
                const { clientSecret } = response.data;
                const { error: initError } = await stripe.initPaymentSheet({
                    merchantDisplayName: 'Navala Travel',
                    paymentIntentClientSecret: clientSecret,
                    returnURL: `${STRIPE_CONFIG.urlScheme}://plans`,
                });

                if (initError) {
                    Alert.alert('Error', initError.message);
                } else {
                    const { error: paymentError } = await stripe.presentPaymentSheet();
                    if (!paymentError) {
                        const amountText = response.data.type === 'UPGRADE'
                            ? `(Paid difference: $${response.data.amountCharged})`
                            : `($${response.data.amountCharged})`;

                        Alert.alert('Success', `Purchased ${plan.name} ${amountText}. Your health plan will be applied from Jun 09 to July 20.`, [
                            { text: 'OK', onPress: () => router.replace('/(tabs)') }
                        ]);
                    }
                }
            }
        } catch (error) {
            Alert.alert('Error', 'Payment failed');
        } finally {
            setPurchasing(null);
        }
    };

    const renderPlan = ({ item }: { item: Plan }) => {
        let featuresList: string[] = [];
        if (Array.isArray(item.features)) {
            featuresList = item.features;
        } else {
            try { featuresList = JSON.parse(item.features); } catch (e) { featuresList = [item.description]; }
        }

        const currentPlanIdStr = activePlan?.plan?.planId || activePlan?.planId;
        const currentPlanInternalId = activePlan?.plan?.id || activePlan?.plan_id;
        const currentPlanPrice = Number(activePlan?.plan?.price || activePlan?.price || 0);

        const isActive = activePlan && (item.planId === currentPlanIdStr || item.id === currentPlanInternalId);
        const isUpgrade = activePlan && !isActive && Number(item.price) > currentPlanPrice;
        const isDowngrade = activePlan && !isActive && Number(item.price) < currentPlanPrice;
        const baseDiff = isUpgrade ? (Number(item.price) - currentPlanPrice) : Number(item.price);
        const planTax = calculateTaxes(baseDiff);
        const feeAmount = (baseDiff + planTax) * (processingFeePercent / 100);
        const finalTotal = baseDiff + planTax + feeAmount;

        // Split price into integer and decimal
        const priceNum = (isActive ? Number(item.price) : finalTotal);
        const priceStr = priceNum.toFixed(2);
        const [intPart, decPart] = priceStr.split('.');

        return (
            <View style={[styles.card, isActive && styles.activeCard]}>
                {/* Header Icon */}
                <View style={styles.cardIconContainer}>
                    {item.name.toLowerCase().includes('basic') ? (
                        <Shield size={32} color="#1e3a8a" />
                    ) : (
                        <Sparkles size={32} color="#0d9488" />
                    )}
                </View>

                {/* Badges */}
                {isActive && (
                    <View style={styles.activeBadgeNew}>
                        <Text style={styles.activeBadgeTextNew}>ACTIVE</Text>
                    </View>
                )}
                {!isActive && item.name.toLowerCase().includes('premium') && (
                    <View style={styles.recommendedBadgeNew}>
                        <Plus size={12} color="#fff" style={{ marginRight: 4 }} />
                        <Text style={styles.recommendedBadgeTextNew}>RECOMMENDED</Text>
                    </View>
                )}

                {/* Plan Info */}
                <View style={styles.cardHeaderNew}>
                    <Text style={styles.planNameNew}>{item.name}</Text>
                    <Text style={styles.planDescriptionNew} numberOfLines={2}>{item.description}</Text>
                    
                    <View style={styles.priceContainerNew}>
                        <Text style={styles.currencySymbolNew}>$</Text>
                        <Text style={styles.priceIntNew}>{intPart}</Text>
                        <Text style={styles.priceDecNew}>.{decPart}</Text>
                        {isUpgrade && (
                            <View style={styles.upgradeBadgeInline}>
                                <Text style={styles.upgradeBadgeTextInline}>UPGRADE</Text>
                            </View>
                        )}
                    </View>

                    <View style={styles.taxBadgeContainer}>
                        <View style={styles.greyBadge}>
                            <Text style={styles.greyBadgeText}>INC. GOVT TAXES</Text>
                        </View>
                        {processingFeePercent > 0 && (
                            <View style={styles.feeBadge}>
                                <Text style={styles.feeBadgeText}>+ {processingFeePercent}% PROCESSING FEE</Text>
                            </View>
                        )}
                    </View>

                    <Text style={styles.validityTextNew}>Validity: June 9th–July 20th</Text>
                </View>

                <View style={styles.sectionDivider}>
                    <View style={styles.dividerLine} />
                    <Text style={styles.sectionTitle}>SERVICES</Text>
                    <View style={styles.dividerLine} />
                </View>

                <View style={styles.servicesRow}>
                    <View style={styles.serviceItem}>
                        <Video size={16} color="#0d9488" />
                        <Text style={styles.serviceText}>Telehealth</Text>
                    </View>
                    <View style={styles.serviceItem}>
                        <PhoneCall size={16} color="#0d9488" />
                        <Text style={styles.serviceText}>Emergency</Text>
                    </View>
                </View>

                <View style={styles.sectionDivider}>
                    <View style={styles.dividerLine} />
                    <Text style={styles.sectionTitle}>PLAN BENEFITS</Text>
                    <View style={styles.dividerLine} />
                </View>

                <View style={styles.benefitsList}>
                    {featuresList.map((f, i) => (
                        <View key={i} style={styles.benefitItem}>
                            <View style={styles.checkCircle}>
                                <Check size={12} color="#1e3a8a" />
                            </View>
                            <Text style={styles.benefitText}>{f}</Text>
                        </View>
                    ))}
                </View>

                <TouchableOpacity
                    style={[
                        styles.actionButton,
                        isActive ? styles.viewButton : styles.upgradeButton,
                        purchasing === item.id && styles.disabledButton,
                        isDowngrade && { opacity: 0.5 }
                    ]}
                    onPress={() => isActive ? router.push('/plan-confirmation') : handleBuy(item)}
                    disabled={purchasing === item.id || isDowngrade}
                >
                    {purchasing === item.id ? (
                        <ActivityIndicator color="#fff" />
                    ) : (
                        <View style={styles.buttonContent}>
                            {isActive ? (
                                <>
                                    <ShieldCheck size={18} color="#64748b" />
                                    <Text style={styles.viewButtonText}>VIEW CONFIRMATION</Text>
                                </>
                            ) : (
                                <>
                                    <Sparkles size={18} color="#fff" />
                                    <Text style={styles.upgradeButtonText}>{isUpgrade ? 'UPGRADE PLAN' : (isDowngrade ? 'LOWER PLAN' : 'SELECT PLAN')}</Text>
                                </>
                            )}
                        </View>
                    )}
                </TouchableOpacity>
            </View>
        );
    };

    if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#2563eb" /></View>;

    return (
        <View style={styles.container}>
            <LinearGradient colors={['#2563eb', '#1d4ed8']} style={styles.header}>
                <View style={styles.headerTopRow}>
                    <Text style={styles.headerTitle}>Available Plans</Text>
                    {activePlan && (
                        <TouchableOpacity
                            style={styles.topConfirmationBtn}
                            onPress={() => router.push('/plan-confirmation')}
                        >
                            <ShieldCheck size={16} color="#fff" />
                            <Text style={styles.topConfirmationBtnText}>View Confirmation</Text>
                        </TouchableOpacity>
                    )}
                </View>

                {currentStep === 2 && (
                    <View style={styles.tabsContainer}>
                        <TouchableOpacity
                            style={[styles.tabButton, activeTab === 'INDIVIDUAL' && styles.activeTabButton]}
                            onPress={() => setActiveTab('INDIVIDUAL')}
                        >
                            <Text style={[styles.tabText, activeTab === 'INDIVIDUAL' && styles.activeTabText]}>Individual</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={[styles.tabButton, activeTab === 'FAMILY_2' && styles.activeTabButton]}
                            onPress={() => setActiveTab('FAMILY_2')}
                        >
                            <Text style={[styles.tabText, activeTab === 'FAMILY_2' && styles.activeTabText]}>Family of 2</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={[styles.tabButton, activeTab === 'FAMILY_3_4' && styles.activeTabButton]}
                            onPress={() => setActiveTab('FAMILY_3_4')}
                        >
                            <Text style={[styles.tabText, activeTab === 'FAMILY_3_4' && styles.activeTabText]}>Family 3-4</Text>
                        </TouchableOpacity>
                    </View>
                )}
            </LinearGradient>
            <FlatList
                data={currentStep === 2 ? plans.filter(p => {
                    const maxP = p.maxPersons || 1;
                    const tabName = (p.planTabName || '').toLowerCase();
                    if (activeTab === 'INDIVIDUAL') return maxP === 1 || tabName.includes('individual');
                    if (activeTab === 'FAMILY_2') return maxP === 2 || tabName.includes('family of 2');
                    if (activeTab === 'FAMILY_3_4') return maxP >= 3 || tabName.includes('family of 3-4');
                    return false;
                }).filter((p, _, filtered) => {
                    if (!activePlan) {
                        // If no active plan, only show the base plan (lowest price in this category)
                        return p.id === filtered[0]?.id;
                    }
                    return true;
                }) : []}
                renderItem={renderPlan}
                keyExtractor={(item) => item.id.toString()}
                contentContainerStyle={{ padding: 16 }}
                refreshControl={
                    <RefreshControl 
                        refreshing={refreshing} 
                        onRefresh={onRefresh} 
                        colors={['#2563eb']} 
                        tintColor="#2563eb"
                    />
                }
                ListHeaderComponent={
                    <View>
                        {/* Step 1: Your Destinations */}
                        {currentStep === 1 ? (
                            <View style={styles.itineraryCard}>
                                <View style={styles.stepHeaderRow}>
                                    <View style={styles.stepBadge}><Text style={styles.stepBadgeText}>1</Text></View>
                                    <View>
                                        <Text style={styles.stepTitle}>Step 1: Your Destinations</Text>
                                        <Text style={styles.stepSubtitle}>Add cities for tax calculation and care coordination</Text>
                                    </View>
                                </View>

                                <View style={styles.itineraryContent}>
                                    <View style={styles.itineraryHeader}>
                                        <View style={styles.itineraryLabelRow}>
                                            <Plane size={20} color="#1e3a8a" />
                                            <Text style={styles.itineraryLabel}>Your Travel Destinations</Text>
                                        </View>
                                        <TouchableOpacity style={styles.addCityBtn} onPress={() => setShowAddCityModal(true)}>
                                            <Plus size={18} color="#1e3a8a" />
                                            <Text style={styles.addCityBtnText}>Add City</Text>
                                        </TouchableOpacity>
                                    </View>

                                    {selectedDestinations.length === 0 ? (
                                        <View style={styles.emptyItinerary}>
                                            <MapPin size={40} color="#e2e8f0" />
                                            <Text style={styles.emptyItineraryText}>No destinations added yet.</Text>
                                            <Text style={styles.emptyItinerarySub}>Add cities to calculate government taxes and plan your trip.</Text>
                                        </View>
                                    ) : (
                                        <View style={styles.destinationList}>
                                            {selectedDestinations.map((dest, index) => {
                                                const isFirstInCountry = selectedDestinations.findIndex(d =>
                                                    String(d.country || '').trim().toLowerCase() === String(dest.country || '').trim().toLowerCase()
                                                ) === index;
                                                return (
                                                    <View key={dest.id} style={styles.destinationItem}>
                                                        <View style={styles.destinationInfo}>
                                                            <MapPin size={16} color="#0d9488" />
                                                            <Text style={styles.destinationName}>{dest.city}, {dest.country}</Text>
                                                            {/* Only show badge if it's the first city for this country and tax is enabled */}
                                                            {isFirstInCountry && isTaxEnabled && (
                                                                <View style={styles.taxBadge}>
                                                                    <Text style={styles.taxBadgeText}>
                                                                        {dest.taxType === 'PERCENTAGE' ? `${dest.taxValue}%` : `$${dest.taxValue}`} Tax
                                                                    </Text>
                                                                </View>
                                                            )}
                                                        </View>
                                                        <TouchableOpacity onPress={() => removeDestination(dest.id)}>
                                                            <X size={18} color="#94a3b8" />
                                                        </TouchableOpacity>
                                                    </View>
                                                );
                                            })}
                                        </View>
                                    )}
                                </View>

                                <TouchableOpacity
                                    style={[styles.mainNextBtn, selectedDestinations.length === 0 && styles.disabledBtn]}
                                    onPress={async () => {
                                        await loadData();
                                        setCurrentStep(2);
                                    }}
                                    disabled={selectedDestinations.length === 0}
                                >
                                    <Text style={styles.mainNextBtnText}>Continue to Plans</Text>
                                </TouchableOpacity>
                            </View>
                        ) : (
                            <View>
                                <View style={styles.summaryCard}>
                                    <View style={styles.summaryHeader}>
                                        <Text style={styles.summaryTitle}>Destinations Set</Text>
                                        <TouchableOpacity onPress={() => setCurrentStep(1)}>
                                            <Text style={styles.editLink}>Edit</Text>
                                        </TouchableOpacity>
                                    </View>
                                    <Text style={styles.summaryText}>
                                        {selectedDestinations.length} location(s) added.{isTaxEnabled ? ' Taxes will be applied automatically.' : ''}
                                    </Text>
                                    {activePlan && selectedDestinations.length === 0 && (
                                        <View style={styles.destinationWarning}>
                                            <Info size={14} color="#f59e0b" />
                                            <Text style={styles.destinationWarningText}>
                                                Please add your travel destinations to calculate correct taxes and processing fees.
                                            </Text>
                                        </View>
                                    )}
                                </View>

                                {/* Step 2 Header */}
                                <View style={styles.stepHeaderRowLarge}>
                                    <View style={styles.stepBadge}><Text style={styles.stepBadgeText}>2</Text></View>
                                    <View>
                                        <Text style={styles.stepTitle}>Step 2: Choose Your Plan</Text>
                                        <Text style={styles.stepSubtitle}>Compare and select the plan that works best for you</Text>
                                    </View>
                                </View>
                            </View>
                        )}

                        {activePlan && currentStep === 2 ? (
                            <View style={styles.activePlanBanner}>
                                <View style={styles.activePlanInfo}>
                                    <ShieldCheck size={20} color="#16a34a" />
                                    <Text style={styles.activePlanText}>
                                        You have an active {activePlan.plan?.name || 'plan'}
                                    </Text>
                                </View>
                                <View style={{ flexDirection: 'row', gap: 10, marginTop: 4 }}>
                                    <TouchableOpacity
                                        style={[styles.dashboardButton, { flex: 1, backgroundColor: '#16a34a' }]}
                                        onPress={() => router.push('/plan-confirmation')}
                                    >
                                        <Text style={[styles.dashboardButtonText, { color: '#ffffff' }]}>View Confirmation</Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity
                                        style={[styles.dashboardButton, { flex: 1 }]}
                                        onPress={() => router.replace('/(tabs)')}
                                    >
                                        <Text style={styles.dashboardButtonText}>Go to Dashboard</Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        ) : null}
                    </View>
                }
                ListEmptyComponent={currentStep === 2 ? (
                    <View style={styles.emptyContainer}>
                        <ActivityIndicator size="small" color="#2563eb" style={{ marginBottom: 10 }} />
                        <Text style={styles.emptyText}>No plans found for this category.</Text>
                        <TouchableOpacity onPress={loadData} style={{ marginTop: 10 }}>
                            <Text style={{ color: '#2563eb', fontWeight: '600' }}>Retry</Text>
                        </TouchableOpacity>
                    </View>
                ) : null}
            />

            {/* Add City Modal */}
            <Modal visible={showAddCityModal} transparent animationType="slide" onRequestClose={() => setShowAddCityModal(false)}>
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContent}>
                        <View style={styles.modalHeader}>
                            <Text style={styles.modalTitle}>Add Travel Destination</Text>
                            <TouchableOpacity onPress={() => setShowAddCityModal(false)}>
                                <X size={24} color="#64748b" />
                            </TouchableOpacity>
                        </View>

                        <View style={styles.modalBody}>
                            <View style={styles.inputGroup}>
                                <Text style={styles.inputLabel}>Country *</Text>
                                <TouchableOpacity style={styles.dropdownTrigger} onPress={() => { setShowCountryDrop(!showCountryDrop); setShowCityDrop(false); }}>
                                    <Text style={[styles.dropdownValue, !selectedCountry && styles.placeholderText]}>{selectedCountry || 'Select Country'}</Text>
                                    <Plus size={20} color="#94a3b8" style={{ transform: [{ rotate: showCountryDrop ? '45deg' : '0deg' }] }} />
                                </TouchableOpacity>
                                {showCountryDrop && (
                                    <ScrollView style={styles.dropdownMenu} nestedScrollEnabled={true}>
                                        {locations.map(c => (
                                            <TouchableOpacity key={c.country} style={styles.dropdownItem} onPress={() => { setSelectedCountry(c.country); setSelectedCity(''); setSelectedState(''); setShowCountryDrop(false); }}>
                                                <Text style={styles.dropdownItemText}>{c.country}</Text>
                                            </TouchableOpacity>
                                        ))}
                                    </ScrollView>
                                )}
                            </View>

                            <View style={styles.inputGroup}>
                                <Text style={styles.inputLabel}>City *</Text>
                                <TouchableOpacity style={[styles.dropdownTrigger, !selectedCountry && styles.disabledInput]} disabled={!selectedCountry} onPress={() => { setShowCityDrop(!showCityDrop); setShowCountryDrop(false); }}>
                                    <Text style={[styles.dropdownValue, !selectedCity && styles.placeholderText]}>{selectedCity || 'Select City'}</Text>
                                    <Plus size={20} color="#94a3b8" style={{ transform: [{ rotate: showCityDrop ? '45deg' : '0deg' }] }} />
                                </TouchableOpacity>
                                {showCityDrop && (
                                    <ScrollView style={styles.dropdownMenu} nestedScrollEnabled={true}>
                                        {(locations.find(l => l.country === selectedCountry)?.cities || []).map((c: any) => (
                                            <TouchableOpacity key={c.name} style={styles.dropdownItem} onPress={() => { setSelectedCity(c.name); setSelectedState(c.state); setShowCityDrop(false); }}>
                                                <Text style={styles.dropdownItemText}>{c.name}</Text>
                                            </TouchableOpacity>
                                        ))}
                                    </ScrollView>
                                )}
                            </View>

                            <View style={styles.inputGroup}>
                                <Text style={styles.inputLabel}>State / Province</Text>
                                <TextInput style={styles.disabledInputText} value={selectedState} editable={false} placeholder="Auto-populated" placeholderTextColor="#cbd5e1" />
                            </View>

                            <View style={styles.modalNotice}>
                                <Info size={16} color="#1e40af" />
                                <Text style={styles.modalNoticeText}>Taxes are calculated based on government regulations for the selected city.</Text>
                            </View>
                        </View>

                        <TouchableOpacity style={[styles.confirmAddBtn, !selectedCity && styles.disabledBtn]} disabled={!selectedCity} onPress={handleAddDestination}>
                            <Text style={styles.confirmAddBtnText}>Add to Itinerary</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f9fafb' },
    center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
    header: { paddingTop: 60, paddingBottom: 24, paddingHorizontal: 20 },
    headerTitle: { fontSize: 24, fontWeight: '700', color: '#ffffff', marginBottom: 16 },
    tabsContainer: { flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 12, padding: 4 },
    tabButton: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 10 },
    activeTabButton: { backgroundColor: '#ffffff' },
    tabText: { color: '#ffffff', fontSize: 13, fontWeight: '600' },
    activeTabText: { color: '#2563eb' },
    card: { backgroundColor: '#ffffff', borderRadius: 16, padding: 20, marginBottom: 16, elevation: 3 },
    cardHeader: { alignItems: 'center', marginBottom: 16 },
    planName: { fontSize: 20, fontWeight: '700', color: '#111827' },
    planPrice: { fontSize: 32, fontWeight: '800', color: '#2563eb' },
    planValidity: { fontSize: 14, color: '#6b7280' },
    divider: { height: 1, backgroundColor: '#f3f4f6', marginVertical: 16 },
    featuresContainer: { marginBottom: 20 },
    featureRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 8, gap: 8 },
    featureText: { fontSize: 14, color: '#4b5563', flex: 1 },
    buyButton: { backgroundColor: '#2563eb', paddingVertical: 14, borderRadius: 12, alignItems: 'center' },
    buyButtonText: { color: '#ffffff', fontSize: 16, fontWeight: '600' },
    activeCard: {
        borderColor: '#16a34a',
        borderWidth: 2,
    },
    activeBuyButtonText: { color: '#16a34a' },
    upgradeBadge: { position: 'absolute', top: -12, left: 20, backgroundColor: '#0d9488', paddingHorizontal: 12, paddingVertical: 4, borderRadius: 20, zIndex: 10 },
    upgradeBadgeSide: { position: 'absolute', top: 35, right: 20, backgroundColor: '#0d9488', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 20, zIndex: 10 },
    upgradeBadgeText: { color: '#ffffff', fontSize: 10, fontWeight: 'bold' },
    activeBadge: {
        position: 'absolute',
        top: -12,
        right: 20,
        backgroundColor: '#16a34a',
        paddingHorizontal: 12,
        paddingVertical: 4,
        borderRadius: 20,
        zIndex: 10,
    },
    activeBadgeText: {
        color: '#ffffff',
        fontSize: 12,
        fontWeight: 'bold',
    },
    recommendedBadge: {
        position: 'absolute',
        top: -12,
        right: 20,
        backgroundColor: '#f59e0b',
        paddingHorizontal: 12,
        paddingVertical: 4,
        borderRadius: 20,
        zIndex: 10,
    },
    recommendedBadgeText: {
        color: '#ffffff',
        fontSize: 12,
        fontWeight: 'bold',
    },
    planDescription: {
        fontSize: 14,
        color: '#6b7280',
        marginBottom: 16,
        lineHeight: 20,
    },
    activeBuyButton: {
        backgroundColor: '#f0fdf4',
        borderWidth: 1,
        borderColor: '#16a34a',
    },
    activeBuyButtonText: {
        color: '#16a34a',
    },
    disabledButton: {
        opacity: 0.5,
    },
    activePlanBanner: {
        backgroundColor: '#f0fdf4',
        borderRadius: 12,
        padding: 16,
        marginBottom: 20,
        borderWidth: 1,
        borderColor: '#dcfce7',
    },
    activePlanInfo: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        marginBottom: 12,
    },
    activePlanText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#16a34a',
    },
    dashboardButton: {
        backgroundColor: '#ffffff',
        paddingVertical: 10,
        borderRadius: 8,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#16a34a',
    },
    dashboardButtonText: {
        color: '#16a34a',
        fontWeight: '700',
        fontSize: 14,
    },
    upgradeDifference: {
        fontSize: 14,
        fontWeight: '700',
        color: '#16a34a',
        marginTop: 4,
        marginBottom: 2,
    },
    // New Styles for Redesigned Plan Card
    cardIconContainer: {
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 10,
    },
    activeBadgeNew: {
        position: 'absolute',
        top: 15,
        right: 15,
        backgroundColor: '#10b981',
        paddingHorizontal: 12,
        paddingVertical: 4,
        borderRadius: 8,
    },
    activeBadgeTextNew: {
        color: '#fff',
        fontSize: 11,
        fontWeight: '800',
    },
    recommendedBadgeNew: {
        position: 'absolute',
        top: 15,
        right: 15,
        backgroundColor: '#0d9488',
        paddingHorizontal: 10,
        paddingVertical: 6,
        borderRadius: 20,
        flexDirection: 'row',
        alignItems: 'center',
    },
    recommendedBadgeTextNew: {
        color: '#fff',
        fontSize: 10,
        fontWeight: '800',
    },
    cardHeaderNew: {
        alignItems: 'center',
        marginBottom: 15,
    },
    planNameNew: {
        fontSize: 22,
        fontWeight: '800',
        color: '#111827',
        marginBottom: 6,
    },
    planDescriptionNew: {
        fontSize: 13,
        color: '#6b7280',
        textAlign: 'center',
        paddingHorizontal: 10,
        marginBottom: 12,
    },
    priceContainerNew: {
        flexDirection: 'row',
        alignItems: 'baseline',
        justifyContent: 'center',
    },
    currencySymbolNew: {
        fontSize: 20,
        fontWeight: '600',
        color: '#111827',
        bottom: 12,
    },
    priceIntNew: {
        fontSize: 48,
        fontWeight: '800',
        color: '#111827',
    },
    priceDecNew: {
        fontSize: 20,
        fontWeight: '700',
        color: '#111827',
    },
    upgradeBadgeInline: {
        backgroundColor: '#f1f5f9',
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 12,
        marginLeft: 8,
        bottom: 8,
    },
    upgradeBadgeTextInline: {
        fontSize: 10,
        fontWeight: '800',
        color: '#1e293b',
    },
    taxBadgeContainer: {
        marginTop: 10,
        gap: 8,
        alignItems: 'center',
    },
    greyBadge: {
        backgroundColor: '#f1f5f9',
        paddingHorizontal: 40,
        paddingVertical: 6,
        borderRadius: 10,
        width: '100%',
        alignItems: 'center',
    },
    greyBadgeText: {
        fontSize: 11,
        fontWeight: '700',
        color: '#475569',
        letterSpacing: 0.5,
    },
    feeBadge: {
        backgroundColor: '#ecfeff',
        paddingHorizontal: 40,
        paddingVertical: 6,
        borderRadius: 10,
        width: '100%',
        alignItems: 'center',
    },
    feeBadgeText: {
        fontSize: 11,
        fontWeight: '700',
        color: '#0d9488',
        letterSpacing: 0.5,
    },
    validityTextNew: {
        fontSize: 14,
        color: '#64748b',
        marginTop: 12,
        fontWeight: '500',
    },
    sectionDivider: {
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: 15,
    },
    dividerLine: {
        flex: 1,
        height: 1,
        backgroundColor: '#f1f5f9',
    },
    sectionTitle: {
        fontSize: 11,
        fontWeight: '800',
        color: '#94a3b8',
        marginHorizontal: 12,
        letterSpacing: 1,
    },
    servicesRow: {
        flexDirection: 'row',
        justifyContent: 'center',
        gap: 20,
        marginBottom: 5,
    },
    serviceItem: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
    },
    serviceText: {
        fontSize: 13,
        fontWeight: '600',
        color: '#334155',
    },
    benefitsList: {
        gap: 10,
        marginBottom: 20,
    },
    benefitItem: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
    },
    checkCircle: {
        width: 20,
        height: 20,
        borderRadius: 10,
        backgroundColor: '#f1f5f9',
        justifyContent: 'center',
        alignItems: 'center',
    },
    benefitText: {
        fontSize: 14,
        color: '#475569',
        fontWeight: '500',
    },
    actionButton: {
        borderRadius: 12,
        paddingVertical: 16,
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
    },
    buttonContent: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
    },
    viewButton: {
        backgroundColor: '#f8fafc',
        borderWidth: 1,
        borderColor: '#e2e8f0',
    },
    viewButtonText: {
        fontSize: 15,
        fontWeight: '800',
        color: '#64748b',
    },
    upgradeButton: {
        backgroundColor: '#0d9488',
    },
    upgradeButtonText: {
        fontSize: 15,
        fontWeight: '800',
        color: '#fff',
    },
    // New Styles for Itinerary and Tax
    itineraryCard: {
        backgroundColor: '#ffffff',
        borderRadius: 20,
        padding: 20,
        marginBottom: 24,
        borderWidth: 1,
        borderColor: '#e2e8f0',
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 8,
    },
    stepHeaderRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        marginBottom: 16,
    },
    stepHeaderRowLarge: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        marginBottom: 20,
        marginTop: 8,
    },
    stepBadge: {
        width: 28,
        height: 28,
        borderRadius: 14,
        backgroundColor: '#1e3a8a',
        justifyContent: 'center',
        alignItems: 'center',
    },
    stepBadgeText: {
        color: '#ffffff',
        fontSize: 14,
        fontWeight: '700',
    },
    stepTitle: {
        fontSize: 18,
        fontWeight: '700',
        color: '#0f172a',
    },
    stepSubtitle: {
        fontSize: 13,
        color: '#64748b',
    },
    itineraryContent: {
        borderWidth: 1,
        borderColor: '#f1f5f9',
        borderRadius: 16,
        padding: 16,
        backgroundColor: '#fcfdfe',
        borderStyle: 'dashed',
    },
    itineraryHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 16,
    },
    itineraryLabelRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
    },
    itineraryLabel: {
        fontSize: 15,
        fontWeight: '600',
        color: '#1e3a8a',
    },
    addCityBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        backgroundColor: '#eff6ff',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: '#dbeafe',
    },
    addCityBtnText: {
        fontSize: 14,
        fontWeight: '600',
        color: '#1e3a8a',
    },
    emptyItinerary: {
        alignItems: 'center',
        paddingVertical: 20,
    },
    emptyItineraryText: {
        fontSize: 15,
        fontWeight: '600',
        color: '#64748b',
        marginTop: 12,
    },
    emptyItinerarySub: {
        fontSize: 12,
        color: '#94a3b8',
        textAlign: 'center',
        marginTop: 4,
    },
    destinationList: {
        gap: 10,
    },
    destinationItem: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: '#ffffff',
        padding: 12,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#e2e8f0',
    },
    destinationInfo: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        flex: 1,
    },
    destinationName: {
        fontSize: 14,
        fontWeight: '600',
        color: '#334155',
    },
    taxBadge: {
        backgroundColor: '#f0fdfa',
        paddingHorizontal: 8,
        paddingVertical: 2,
        borderRadius: 6,
        borderWidth: 1,
        borderColor: '#ccfbf1',
    },
    taxBadgeText: {
        fontSize: 11,
        fontWeight: '700',
        color: '#0d9488',
    },
    priceRow: {
        flexDirection: 'row',
        alignItems: 'baseline',
        gap: 6,
        marginTop: 4,
    },
    basePrice: {
        fontSize: 20,
        fontWeight: '600',
        color: '#64748b',
        textDecorationLine: 'none',
    },
    taxText: {
        fontSize: 14,
        fontWeight: '600',
        color: '#0d9488',
    },
    // Modal Styles
    modalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0,0,0,0.5)',
        justifyContent: 'flex-end',
    },
    modalContent: {
        backgroundColor: '#ffffff',
        borderTopLeftRadius: 24,
        borderTopRightRadius: 24,
        padding: 24,
        maxHeight: '80%',
    },
    modalHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
    },
    modalTitle: {
        fontSize: 20,
        fontWeight: '700',
        color: '#0f172a',
    },
    modalBody: {
        gap: 16,
    },
    inputGroup: {
        gap: 8,
    },
    inputLabel: {
        fontSize: 14,
        fontWeight: '600',
        color: '#475569',
    },
    dropdownTrigger: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: '#f8fafc',
        padding: 16,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#e2e8f0',
    },
    dropdownValue: {
        fontSize: 15,
        color: '#0f172a',
    },
    placeholderText: {
        color: '#94a3b8',
    },
    dropdownMenu: {
        backgroundColor: '#ffffff',
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#e2e8f0',
        marginTop: 4,
        maxHeight: 150,
        elevation: 4,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.1,
        shadowRadius: 10,
    },
    dropdownItem: {
        padding: 16,
        borderBottomWidth: 1,
        borderBottomColor: '#f1f5f9',
    },
    dropdownItemText: {
        fontSize: 15,
        color: '#334155',
    },
    disabledInput: {
        backgroundColor: '#f1f5f9',
        opacity: 0.6,
    },
    disabledInputText: {
        backgroundColor: '#f1f5f9',
        padding: 16,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#e2e8f0',
        color: '#94a3b8',
    },
    modalNotice: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        backgroundColor: '#eff6ff',
        padding: 12,
        borderRadius: 12,
        marginTop: 8,
    },
    modalNoticeText: {
        fontSize: 12,
        color: '#1e40af',
        flex: 1,
        lineHeight: 18,
    },
    confirmAddBtn: {
        backgroundColor: '#1e3a8a',
        paddingVertical: 16,
        borderRadius: 12,
        alignItems: 'center',
        marginTop: 24,
    },
    confirmAddBtnText: {
        color: '#ffffff',
        fontSize: 16,
        fontWeight: '700',
    },
    disabledBtn: {
        backgroundColor: '#cbd5e1',
    },
    emptyContainer: {
        padding: 40,
        alignItems: 'center',
        justifyContent: 'center',
    },
    emptyText: {
        fontSize: 16,
        color: '#64748b',
        textAlign: 'center',
    },
    mainNextBtn: {
        backgroundColor: '#1e3a8a',
        paddingVertical: 16,
        borderRadius: 12,
        alignItems: 'center',
        marginTop: 20,
    },
    mainNextBtnText: {
        color: '#ffffff',
        fontSize: 16,
        fontWeight: '700',
    },
    summaryCard: {
        backgroundColor: '#eff6ff',
        borderRadius: 16,
        padding: 16,
        marginBottom: 20,
        borderWidth: 1,
        borderColor: '#dbeafe',
    },
    summaryHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 4,
    },
    summaryTitle: {
        fontSize: 14,
        fontWeight: '700',
        color: '#1e40af',
    },
    summaryText: {
        fontSize: 13,
        color: '#60a5fa',
    },
    destinationWarning: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        backgroundColor: '#fffbeb',
        padding: 8,
        borderRadius: 8,
        marginTop: 10,
        borderWidth: 1,
        borderColor: '#fef3c7',
    },
    destinationWarningText: {
        fontSize: 12,
        color: '#b45309',
        flex: 1,
        fontWeight: '600',
    },
    editLink: {
        fontSize: 13,
        fontWeight: '700',
        color: '#2563eb',
        textDecorationLine: 'underline',
    },
    headerTopRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 10,
    },
    topConfirmationBtn: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 20,
        gap: 6,
        borderWidth: 1,
        borderColor: 'rgba(255, 255, 255, 0.4)',
    },
    topConfirmationBtnText: {
        color: '#fff',
        fontSize: 12,
        fontWeight: '700',
    },
});
