import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, ActivityIndicator, RefreshControl, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Video, AlertCircle, Calendar, Globe2, ShieldCheck, Activity, Heart, ClipboardCheck, Check, Info, CreditCard, PlusCircle, Stethoscope, Clock, FileText } from 'lucide-react-native';
import { format } from 'date-fns';
import { router } from 'expo-router';
import { UserApi, AppointmentsApi } from '../../src/api';
import { getItem } from '../../src/utils/storage';
import { UI_SETTINGS } from '../../src/config/settings';

export default function HomeScreen() {
  const [userData, setUserData] = useState<any>(null);
  const [activePlan, setActivePlan] = useState<any>(null);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      if (!refreshing) setLoading(true);

      // 1. Get cached user data
      const storedUser = await getItem('userData');
      if (storedUser) setUserData(JSON.parse(storedUser));

      // 2. Fetch fresh data from API
      const [profileRes, planRes, appointmentsRes] = await Promise.all([
        UserApi.getProfile(),
        UserApi.getActivePlan(),
        AppointmentsApi.getMyRequests()
      ]);

      if (profileRes.success) setUserData(profileRes.data);

      // Fix for Active Plan display - mapping data.activePlan correctly
      if (planRes.success && planRes.data) {
        // Handle both direct and nested structure
        const actualPlan = planRes.data.activePlan || planRes.data;
        // Aligned with web app logic: hide if plan.plan is empty
        if (actualPlan && actualPlan.plan) {
          setActivePlan(actualPlan);
        } else {
          setActivePlan(null);
        }
      } else {
        setActivePlan(null);
      }

      if (appointmentsRes.success) setAppointments(appointmentsRes.data);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    fetchDashboardData();
  };

  const handleAddFamily = () => {
    const maxPersons = activePlan?.plan?.maxPersons || activePlan?.maxPersons || 1;
    if (maxPersons <= 1) {
      Alert.alert(
        "Upgrade Required",
        "Your current plan does not support family members. Please upgrade to a family plan.",
        [
          { text: "Cancel", style: "cancel" },
          { text: "View Plans", onPress: () => router.push('/plans') }
        ]
      );
    } else {
      router.push('/family' as any);
    }
  };

  if (loading && !userData) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#2563eb" />
      </View>
    );
  }

  const upcomingAppointments = appointments.filter(
    (apt) => apt.status?.toLowerCase() === 'confirmed' || apt.status?.toLowerCase() === 'pending'
  );

  return (
    <ScrollView
      style={styles.container}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
    >
      <LinearGradient colors={['#0251fc', '#072169']} style={styles.header}>
        <View style={styles.headerRow}>
          <View style={styles.logoWrapper}>
            <Image
              source={require('../../assets/images/icon.png')}
              style={styles.logo}
              resizeMode="contain"
            />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.greeting}>Hello, {userData?.firstName || 'User'}!</Text>
            <Text style={styles.subtitle}>How can we help you today?</Text>
          </View>
        </View>
      </LinearGradient>

      <View style={styles.content}>
        {/* PLAN NOTICE CARD */}
        {UI_SETTINGS.SHOW_PLAN_NOTICE && (
          <View style={styles.noticeCard}>
            <LinearGradient
              colors={['#eff6ff', '#dbeafe']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.noticeCardGradient}
            >
              <View style={styles.noticeCardHeader}>
                <View style={styles.noticeIconContainer}>
                  <Calendar size={20} color="#2563eb" />
                </View>
                <Text style={styles.noticeCardTitle}>Plan Application Period</Text>
              </View>

              <View style={styles.noticeDatesRow}>
                <View style={styles.dateBlock}>
                  <Text style={styles.dateLabel}>Starts</Text>
                  <Text style={styles.dateValue}>{UI_SETTINGS.START_DATE}</Text>
                </View>
                <View style={styles.dateDivider} />
                <View style={styles.dateBlock}>
                  <Text style={styles.dateLabel}>Ends</Text>
                  <Text style={styles.dateValue}>{UI_SETTINGS.END_DATE}</Text>
                </View>
              </View>

              <View style={styles.noticeFooter}>
                <Info size={14} color="#3b82f6" />
                <Text style={styles.noticeFooterText}>Active coverage for this period</Text>
              </View>
            </LinearGradient>
          </View>
        )}

        {/* STATS CARDS SECTION */}
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <View style={[styles.statIconContainer, { backgroundColor: '#9dc9ee' }]}>
              <ClipboardCheck size={20} color="#2563eb" />
            </View>
            <Text style={styles.statValue}>{appointments.length}</Text>
            <Text style={styles.statLabel}>Consultations</Text>
          </View>

          <View style={styles.statCard}>
            <View style={[styles.statIconContainer, { backgroundColor: '#f8e6d0' }]}>
              <Activity size={20} color="#f97316" />
            </View>
            <Text style={styles.statValue}>{upcomingAppointments.length}</Text>
            <Text style={styles.statLabel}>Upcoming</Text>
          </View>

          <View style={styles.statCard}>
            <View style={[styles.statIconContainer, { backgroundColor: '#e3f7e9' }]}>
              <Heart size={20} color="#16a34a" />
            </View>
            <Text style={styles.statValue}>92%</Text>
            <Text style={styles.statLabel}>Health Score</Text>
          </View>
        </View>

        {/* ACTIVE PLAN SECTION */}
        {activePlan ? (
          <View style={styles.planCard}>
            <View style={styles.planHeader}>
              <View style={styles.planStatusInfo}>
                <ShieldCheck size={20} color="#2563eb" />
                <Text style={styles.planLabel}>Your Active Plan</Text>
              </View>
              <View style={styles.planBadge}>
                <Text style={styles.planBadgeText}>
                  {activePlan.plan?.name || activePlan.name || activePlan.plan_name || activePlan.title || 'Active Member'}
                </Text>
              </View>
            </View>

            <View style={styles.planBody}>
              <Text style={styles.planDescriptionText}>
                {activePlan.plan?.description || activePlan.description || activePlan.planDescription || 'Access to premium travel healthcare services.'}
              </Text>
            </View>

            <View style={styles.planFeatures}>
              {(Array.isArray(activePlan.plan?.features) ? activePlan.plan.features : []).slice(0, 4).map((feature: string, idx: number) => (
                <View key={idx} style={styles.featureItemMini}>
                  <Check size={12} color="#10b981" />
                  <Text style={styles.featureTextSmall}>{feature}</Text>
                </View>
              ))}
            </View>

            <View style={styles.planFooter}>
              <View style={styles.expiryContainer}>
                <Calendar size={14} color="#6b7280" />
                <Text style={styles.planExpiry}>
                  Expires: {activePlan.endDate || activePlan.end_date || activePlan.expiryDate ? format(new Date(activePlan.endDate || activePlan.end_date || activePlan.expiryDate), 'MMM dd, yyyy') : 'No expiry'}
                </Text>
              </View>
              <TouchableOpacity style={styles.changeBtn} onPress={() => router.push('/plans')}>
                <Text style={styles.changePlanText}>Manage Plan</Text>
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <TouchableOpacity style={styles.noPlanCard} onPress={() => router.push('/plans')}>
            <View style={styles.noPlanIcon}><AlertCircle size={20} color="#6b7280" /></View>
            <Text style={styles.noPlanText}>No active plan. Get one now to access services.</Text>
            <ChevronRight size={18} color="#9ca3af" style={{ marginLeft: 'auto' }} />
          </TouchableOpacity>
        )}

        <View style={styles.quickActions}>
          <LinearGradient colors={['#eff6ff', '#e0f2fe']} style={styles.quickActionsGradient}>
            <Text style={styles.quickActionsTitle}>Quick Actions</Text>
            <View style={styles.actionsGridWrap}>
              <TouchableOpacity style={styles.actionCardWrap} onPress={() => router.push('/plans')}>
                <View style={[styles.actionIconSmall, { backgroundColor: '#e0e7ff' }]}><CreditCard size={22} color="#3730a3" /></View>
                <Text style={styles.actionTitleSmall}>Buy/Upgrade Plan</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.actionCardWrap} onPress={handleAddFamily}>
                <View style={[styles.actionIconSmall, { backgroundColor: '#ccfbf1' }]}><PlusCircle size={22} color="#0f766e" /></View>
                <Text style={styles.actionTitleSmall}>Add Family</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.actionCardWrap} onPress={() => router.push('/booking')}>
                <View style={[styles.actionIconSmall, { backgroundColor: '#f1f5f9' }]}><Stethoscope size={22} color="#334155" /></View>
                <Text style={styles.actionTitleSmall}>Book Visit</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.actionCardWrap} onPress={() => router.push('/appointments')}>
                <View style={[styles.actionIconSmall, { backgroundColor: '#ffedd5' }]}><Clock size={22} color="#c2410c" /></View>
                <Text style={styles.actionTitleSmall}>Upcoming</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.actionCardWrap} onPress={() => router.push('/prescriptions')}>
                <View style={[styles.actionIconSmall, { backgroundColor: '#dcfce7' }]}><FileText size={22} color="#15803d" /></View>
                <Text style={styles.actionTitleSmall}>Prescriptions</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.actionCardWrap} onPress={() => router.push('/contract')}>
                <View style={[styles.actionIconSmall, { backgroundColor: '#fae8ff' }]}><ShieldCheck size={22} color="#a21caf" /></View>
                <Text style={styles.actionTitleSmall}>Service Contract</Text>
              </TouchableOpacity>
            </View>
          </LinearGradient>
        </View>

        {upcomingAppointments.length > 0 && (
          <View style={styles.appointmentsSection}>
            <Text style={styles.sectionTitle}>Today's Schedule</Text>
            {upcomingAppointments.map((apt) => (
              <View key={apt.id || apt.requestUuid} style={styles.appointmentCard}>
                <View style={styles.appointmentIcon}><Calendar size={20} color="#2563eb" /></View>
                <View style={styles.appointmentDetails}>
                  <Text style={styles.appointmentDoctor}>{apt.serviceType || 'Consultation'}</Text>
                  <Text style={styles.appointmentDate}>
                    {apt.createdAt ? format(new Date(apt.createdAt), 'MMM dd') : 'Recent'} • {apt.city}
                  </Text>
                </View>
                <View style={[styles.appointmentBadge, apt.status?.toLowerCase() === 'pending' && styles.pendingBadge]}>
                  <Text style={[styles.appointmentBadgeText, apt.status?.toLowerCase() === 'pending' && styles.pendingBadgeText]}>
                    {apt.status}
                  </Text>
                </View>
              </View>
            ))}
          </View>
        )}

        <View style={styles.tipsSection}>
          <Text style={styles.sectionTitle}>Health Tips</Text>
          <View style={styles.tipCard}>
            <Text style={styles.tipText}>Stay hydrated! Drink at least 8 glasses of water daily for optimal travel health.</Text>
          </View>

          <View style={styles.tipCardAlt}>
            <View style={styles.tipHeaderAlt}>
              {/* <Clock size={16} color="#ffffff" /> */}
              {/* <Text style={styles.tipTitleAlt}>Sleep Schedule</Text> */}
            </View>
            <Text style={styles.tipTextAlt}>Adjust your sleep schedule 2-3 days before your trip to minimize jet lag symptoms.</Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

// Fixed import of ChevronRight
import { ChevronRight } from 'lucide-react-native';

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f9fafb' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { paddingHorizontal: 20, paddingTop: 50, paddingBottom: 28 },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  logoWrapper: { width: 100, height: 60, backgroundColor: '#ffffff', borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  logo: { width: '80%', height: '80%' },
  greeting: { fontSize: 24, fontWeight: '700', color: '#ffffff' },
  subtitle: { fontSize: 14, color: '#e0e7ff' },
  content: { padding: 16 },

  // STATS GRID STYLES
  statsGrid: { flexDirection: 'row', gap: 12, marginBottom: 24, marginTop: 10 },
  statCard: { flex: 1, backgroundColor: '#ffffff', borderRadius: 16, padding: 12, alignItems: 'center', elevation: 2, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 8 },
  statIconContainer: { width: 40, height: 40, borderRadius: 30, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  statValue: { fontSize: 18, fontWeight: '700', color: '#111827' },
  statLabel: { fontSize: 11, color: '#6b7280', textAlign: 'center' },

  quickActions: { marginBottom: 24, marginTop: 10 },
  quickActionsGradient: { padding: 20, borderRadius: 24, borderWidth: 1, borderColor: '#bae6fd' },
  quickActionsTitle: { fontSize: 18, fontWeight: '700', color: '#1e3a8a', marginBottom: 16, textTransform: 'uppercase', letterSpacing: 0.5 },
  sectionTitle: { fontSize: 20, fontWeight: '600', color: '#111827', marginBottom: 16 },
  actionsGridWrap: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginBottom: 0 },
  actionCardWrap: { width: '31%', backgroundColor: '#ffffff', borderRadius: 16, paddingVertical: 14, paddingHorizontal: 6, alignItems: 'center', elevation: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 6, borderWidth: 1, borderColor: '#e0f2fe', marginBottom: 16 },
  actionIconSmall: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  actionTitleSmall: { fontSize: 12, fontWeight: '600', color: '#111827', textAlign: 'center' },

  planCard: { backgroundColor: '#ffffff', borderRadius: 16, padding: 16, marginBottom: 24, borderLeftWidth: 4, borderLeftColor: '#2563eb', elevation: 2 },
  planHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  planStatusInfo: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  planLabel: { fontSize: 13, color: '#6b7280', fontWeight: '600' },
  planBadge: { backgroundColor: '#2563eb', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  planBadgeText: { color: '#ffffff', fontSize: 11, fontWeight: '700' },
  planFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderTopWidth: 1, borderTopColor: '#f3f4f6', paddingTop: 12 },
  planBody: { marginBottom: 12 },
  planDescriptionText: { fontSize: 13, color: '#4b5563', lineHeight: 18, marginBottom: 8 },
  planFeatures: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 },
  featureItemMini: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#f0fdf4', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  featureTextSmall: { fontSize: 11, color: '#16a34a', fontWeight: '500' },
  expiryContainer: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  planExpiry: { fontSize: 12, color: '#6b7280', fontWeight: '500' },
  changeBtn: { backgroundColor: '#f3f4f6', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
  changePlanText: { color: '#2563eb', fontSize: 12, fontWeight: '600' },

  noPlanCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#ffffff', padding: 16, borderRadius: 16, marginBottom: 24, borderStyle: 'dashed', borderWidth: 1, borderColor: '#d1d5db', gap: 10 },
  noPlanIcon: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#f3f4f6', alignItems: 'center', justifyContent: 'center' },
  noPlanText: { fontSize: 13, color: '#6b7280', flex: 1 },

  appointmentsSection: { marginBottom: 24 },
  appointmentCard: { backgroundColor: '#ffffff', borderRadius: 12, padding: 12, marginBottom: 12, flexDirection: 'row', alignItems: 'center', elevation: 1 },
  appointmentIcon: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#dbeafe', alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  appointmentDetails: { flex: 1 },
  appointmentDoctor: { fontSize: 15, fontWeight: '600', color: '#111827' },
  appointmentDate: { fontSize: 13, color: '#6b7280' },
  appointmentBadge: { backgroundColor: '#dcfce7', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6 },
  appointmentBadgeText: { color: '#16a34a', fontSize: 11, fontWeight: '600' },
  pendingBadge: { backgroundColor: '#fef3c7' },
  pendingBadgeText: { color: '#d97706' },
  tipsSection: { marginBottom: 24 },
  tipCard: { backgroundColor: '#fffbeb', borderRadius: 12, padding: 16, borderLeftWidth: 4, borderLeftColor: '#f59e0b' },
  tipText: { fontSize: 14, color: '#78350f' },
  tipCardAlt: {
    backgroundColor: '#b0c1f8a4',
    borderRadius: 12,
    padding: 16,
    borderRightWidth: 4,
    borderRightColor: '#4a9cffff',
    marginTop: 12
  },
  tipHeaderAlt: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8
  },
  tipTitleAlt: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff'
  },
  tipTextAlt: {
    fontSize: 14,
    color: '#056df5ff',
    lineHeight: 20
  },
  noticeBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#eff6ff',
    padding: 8,
    borderRadius: 8,
    marginTop: 8,
    gap: 8,
    borderWidth: 1,
    borderColor: '#dbeafe',
  },
  noticeText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#1e40af',
    flex: 1,
  },
  noticeCard: {
    marginBottom: 24,
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#2563eb',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
  },
  noticeCardGradient: {
    padding: 20,
  },
  noticeCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 12,
  },
  noticeIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: '#ffffff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  noticeCardTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e40af',
  },
  noticeDatesRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    padding: 16,
    borderRadius: 16,
    marginBottom: 16,
  },
  dateBlock: {
    flex: 1,
    alignItems: 'center',
  },
  dateLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: '#6b7280',
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  dateValue: {
    fontSize: 18,
    fontWeight: '800',
    color: '#2563eb',
  },
  dateDivider: {
    width: 1,
    height: 30,
    backgroundColor: '#dbeafe',
  },
  noticeFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  noticeFooterText: {
    fontSize: 12,
    fontWeight: '500',
    color: '#3b82f6',
  },
});
