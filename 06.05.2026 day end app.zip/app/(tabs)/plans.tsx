import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ActivityIndicator,
    FlatList,
    TouchableOpacity,
    Alert,
    Platform,
    RefreshControl,
    Modal,
    ScrollView,
    TextInput
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { PlansApi, UserApi, AppointmentsApi, ItineraryApi } from '../../src/api';
import { SystemConfigApi } from '../../src/api/features/systemConfig';
import { STRIPE_CONFIG } from '../../src/config/stripe';
import { Check, Plus, MapPin, X, Plane, Info, ShieldCheck, Users, Video, PhoneCall, Sparkles, Shield } from 'lucide-react-native';

// Safe Stripe hook for web compatibility
let useStripeHook: any = () => ({ initPaymentSheet: async () => ({}), presentPaymentSheet: async () => ({}) });

if (Platform.OS !== 'web') {
    try {
        const Stripe = require('@stripe/stripe-react-native');
        useStripeHook = Stripe.useStripe;
    } catch (e) {
        console.warn('Stripe native module not found');
    }
}

interface Plan {
    id: number;
    planId: string;
    name: string;
    price: string | number;
    validityDays: number;
    description: string;
    features: string;
    services?: string[];
    planTabName?: string;
    maxPersons?: number;
}

export default function PlansScreen() {
    const [plans, setPlans] = useState<Plan[]>([]);
    const [loading, setLoading] = useState(true);
    const [activePlan, setActivePlan] = useState<any>(null);
    const [purchasing, setPurchasing] = useState<number | null>(null);
    const [refreshing, setRefreshing] = useState(false);
    const [activeTab, setActiveTab] = useState<'INDIVIDUAL' | 'FAMILY_2' | 'FAMILY_3_4'>('INDIVIDUAL');
    const [familyMembers, setFamilyMembers] = useState<any[]>([]);
    const [userData, setUserData] = useState<any>(null);
    const [maxSlots, setMaxSlots] = useState<number>(0);
    const [processingFeePercent, setProcessingFeePercent] = useState<number>(0);
    const [isTaxEnabled, setIsTaxEnabled] = useState<boolean>(true);
    const stripe = useStripeHook();

    // Destination & Tax State
    const [locations, setLocations] = useState<any[]>([]);
    const [selectedDestinations, setSelectedDestinations] = useState<any[]>([]);
    const [showAddCityModal, setShowAddCityModal] = useState(false);
    const [selectedCountry, setSelectedCountry] = useState('');
    const [selectedCity, setSelectedCity] = useState('');
    const [selectedState, setSelectedState] = useState('');
    const [showCountryDrop, setShowCountryDrop] = useState(false);
    const [showCityDrop, setShowCityDrop] = useState(false);
    const [currentStep, setCurrentStep] = useState(1);

    // Checkout Modal State
    const [checkoutModalVisible, setCheckoutModalVisible] = useState(false);
    const [selectedPlanForCheckout, setSelectedPlanForCheckout] = useState<Plan | null>(null);
    const [checkoutDetails, setCheckoutDetails] = useState<any>(null);

    useEffect(() => {
        loadData();
        // Auto-refresh data every 10 seconds in the background
        const interval = setInterval(() => loadData(true), 10000);
        return () => clearInterval(interval);
    }, []);

    const loadData = async (silent = false) => {
        try {
            if (!refreshing && !silent) setLoading(true);
            const [plansRes, activeRes, familyRes, profileRes, locationsRes, feeRes, taxEnabledRes] = await Promise.all([
                PlansApi.getPlans().catch(() => ({ success: false })),
                UserApi.getActivePlan().catch(() => ({ success: false })),
                UserApi.getFamilyMembers().catch(() => ({ success: false })),
                UserApi.getProfile().catch(() => ({ success: false })),
                AppointmentsApi.getLocations().catch(() => null),
                SystemConfigApi.get('processing_fee_percentage').catch(() => ({ success: false, data: "0" })),
                SystemConfigApi.get('is_location_tax_enabled').catch(() => ({ success: false, data: "true" }))
            ]);

            if (feeRes && feeRes.success && feeRes.data) {
                setProcessingFeePercent(parseFloat(feeRes.data) || 0);
            }

            if (taxEnabledRes && taxEnabledRes.success) {
                setIsTaxEnabled(taxEnabledRes.data === 'true');
            }

            // Plans parsing
            if (plansRes && plansRes.success && plansRes.data) {
                const planList = plansRes.data.plans || (Array.isArray(plansRes.data) ? plansRes.data : []);
                const sorted = [...planList].sort((a, b) => Number(a.price) - Number(b.price));
                setPlans(sorted);
            } else if (Array.isArray(plansRes)) {
                const sorted = [...plansRes].sort((a, b) => Number(a.price) - Number(b.price));
                setPlans(sorted);
            }

            // Active plan & Family info
            if (activeRes && activeRes.success && activeRes.data) {
                const planData = activeRes.data.activePlan || activeRes.data;
                if (planData && (planData.plan || planData.planId)) {
                    setActivePlan(planData);
                    // Skip Step 1 if user is in upgrade flow (has an active plan)
                    setCurrentStep(2);
                    if (familyRes && familyRes.success && familyRes.data) {
                        setFamilyMembers(familyRes.data.familyMembers || []);
                        let slots = familyRes.data.maxSlots;
                        if (!slots || slots <= 1) slots = planData.plan?.maxPersons || planData.maxPersons || 1;
                        setMaxSlots(slots);
                    }
                } else {
                    setActivePlan(null);
                }
            } else {
                setActivePlan(null);
            }

            if (profileRes && profileRes.success && profileRes.data) {
                setUserData(profileRes.data);
            }

            // Locations parsing
            if (locationsRes && locationsRes.success && Array.isArray(locationsRes.data)) {
                const grouped = locationsRes.data.reduce((acc: any[], curr: any) => {
                    let country = acc.find(c => c.country === curr.country);
                    if (!country) {
                        country = { country: curr.country, cities: [] };
                        acc.push(country);
                    }
                    if (!country.cities.find((city: any) => city.name === curr.city)) {
                        country.cities.push({ ...curr, name: curr.city });
                    }
                    return acc;
                }, []);
                setLocations(grouped);
            }
        } catch (error: any) {
            console.error('Failed to fetch data:', error);
            Alert.alert('Error', 'Could not load data.');
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    const calculateTaxes = (planPrice: number) => {
        if (selectedDestinations.length === 0 || !isTaxEnabled) return 0;

        let totalTax = 0;
        const seenCountries = new Set();
        selectedDestinations.forEach(dest => {
            const countryKey = String(dest.country || '').trim().toLowerCase();
            // Only apply tax if this is the first time we see this country
            if (countryKey && !seenCountries.has(countryKey)) {
                seenCountries.add(countryKey);
                const taxVal = Number(dest.taxValue || 0);
                if (dest.taxType === 'PERCENTAGE') {
                    totalTax += (taxVal / 100) * planPrice;
                } else {
                    totalTax += taxVal;
                }
            }
        });
        return totalTax;
    };

    const handleAddDestination = () => {
        const countryObj = locations.find(l => l.country === selectedCountry);
        const cityObj = countryObj?.cities.find((c: any) => c.name === selectedCity);
        if (cityObj) {
            if (selectedDestinations.find(d => d.id === cityObj.id)) {
                Alert.alert('Duplicate', 'This city is already in your itinerary.');
                return;
            }
            setSelectedDestinations([...selectedDestinations, cityObj]);
            setSelectedCountry('');
            setSelectedCity('');
            setSelectedState('');
            setShowAddCityModal(false);
        }
    };

    const removeDestination = (id: number) => {
        setSelectedDestinations(selectedDestinations.filter(d => d.id !== id));
    };

    const onRefresh = () => {
        setRefreshing(true);
        loadData();
    };

    const handleBuy = async (plan: Plan) => {
        if (Platform.OS === 'web') {
            Alert.alert('Not Supported', 'Payments require a physical device.');
            return;
        }

        const currentPlanPrice = Number(activePlan?.plan?.price || activePlan?.price || 0);
        const selectedPlanPrice = Number(plan.price);
        const isUpgrade = activePlan && selectedPlanPrice > currentPlanPrice;
        
        const baseDiff = isUpgrade ? (selectedPlanPrice - currentPlanPrice) : selectedPlanPrice;
        const planTax = calculateTaxes(baseDiff);
        const feeAmount = (baseDiff + planTax) * (processingFeePercent / 100);
        const finalTotal = baseDiff + planTax + feeAmount;

        if (activePlan) {
            if (selectedPlanPrice < currentPlanPrice) {
                Alert.alert('Plan Downgrade', 'You cannot move down to a lower plan.', [{ text: 'OK' }]);
                return;
            }
        }
        
        // Open Custom Modal instead of Alert
        setCheckoutDetails({
            baseDiff,
            planTax,
            feeAmount,
            processingFeePercent,
            finalTotal,
            isUpgrade,
            currentPlanPrice,
            selectedPlanPrice
        });
        setSelectedPlanForCheckout(plan);
        setCheckoutModalVisible(true);
    };

    const processPurchase = async (plan: Plan) => {
        setPurchasing(plan.id);
        try {
            const taxAmount = calculateTaxes(Number(plan.price));
            const itineraryData = selectedDestinations.map(d => ({
                locationId: d.id,
                arrivalDate: new Date().toISOString(),
                departureDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
            }));

            const response = await PlansApi.purchasePlan(plan.planId, taxAmount, itineraryData);
            if (response.success && response.data) {
                const { clientSecret } = response.data;
                const { error: initError } = await stripe.initPaymentSheet({
                    merchantDisplayName: 'Navala Travel',
                    paymentIntentClientSecret: clientSecret,
                    returnURL: `${STRIPE_CONFIG.urlScheme}://plans`,
                });

                if (initError) {
                    Alert.alert('Error', initError.message);
                } else {
                    const { error: paymentError } = await stripe.presentPaymentSheet();
                    if (!paymentError) {
                        const amountText = response.data.type === 'UPGRADE'
                            ? `(Paid difference: $${response.data.amountCharged})`
                            : `($${response.data.amountCharged})`;
                        Alert.alert('Success', `Purchased ${plan.name} ${amountText}.`, [
                            { text: 'OK', onPress: () => router.push('/plan-confirmation') }
                        ]);
                    }
                }
            }
        } catch (error) {
            Alert.alert('Error', 'Payment failed');
        } finally {
            setPurchasing(null);
        }
    };

    const renderPlan = ({ item }: { item: Plan }) => {
        let featuresList: string[] = [];
        if (Array.isArray(item.features)) {
            featuresList = item.features;
        } else {
            try { featuresList = JSON.parse(item.features); } catch (e) { featuresList = [item.description]; }
        }

        const currentPlanIdStr = activePlan?.plan?.planId || activePlan?.planId;
        const currentPlanInternalId = activePlan?.plan?.id || activePlan?.plan_id;
        const currentPlanPrice = Number(activePlan?.plan?.price || activePlan?.price || 0);
        const isActive = activePlan && (item.planId === currentPlanIdStr || item.id === currentPlanInternalId);
        const isUpgrade = activePlan && !isActive && Number(item.price) > currentPlanPrice;
        const isDowngrade = activePlan && !isActive && Number(item.price) < currentPlanPrice;
        
        const baseDiff = isUpgrade ? (Number(item.price) - currentPlanPrice) : Number(item.price);
        const totalTax = calculateTaxes(baseDiff);
        const feeAmount = (baseDiff + totalTax) * (processingFeePercent / 100);
        const finalTotal = baseDiff + totalTax + feeAmount;

        // Split price into integer and decimal
        const priceNum = (isActive ? Number(item.price) : finalTotal);
        const priceStr = priceNum.toFixed(2);
        const [intPart, decPart] = priceStr.split('.');

        return (
            <View style={[styles.card, isActive && styles.activeCard]}>
                {/* Header Icon */}
                <View style={styles.cardIconContainer}>
                    {item.name.toLowerCase().includes('basic') ? (
                        <Shield size={32} color="#1e3a8a" />
                    ) : (
                        <Sparkles size={32} color="#0d9488" />
                    )}
                </View>

                {/* Badges */}
                {isActive && (
                    <View style={styles.activeBadgeNew}>
                        <Text style={styles.activeBadgeTextNew}>ACTIVE</Text>
                    </View>
                )}
                {!isActive && item.name.toLowerCase().includes('premium') && (
                    <View style={styles.recommendedBadgeNew}>
                        <Plus size={12} color="#fff" style={{ marginRight: 4 }} />
                        <Text style={styles.recommendedBadgeTextNew}>RECOMMENDED</Text>
                    </View>
                )}

                {/* Plan Info */}
                <View style={styles.cardHeaderNew}>
                    <Text style={styles.planNameNew}>{item.name}</Text>
                    <Text style={styles.planDescriptionNew} numberOfLines={2}>{item.description}</Text>
                    
                    <View style={styles.priceContainerNew}>
                        <Text style={styles.currencySymbolNew}>$</Text>
                        <Text style={styles.priceIntNew}>{intPart}</Text>
                        <Text style={styles.priceDecNew}>.{decPart}</Text>
                        {isUpgrade && (
                            <View style={styles.upgradeBadgeInline}>
                                <Text style={styles.upgradeBadgeTextInline}>UPGRADE</Text>
                            </View>
                        )}
                    </View>

                    <View style={styles.taxBadgeContainer}>
                        <View style={styles.greyBadge}>
                            <Text style={styles.greyBadgeText}>INC. GOVT TAXES</Text>
                        </View>
                        {processingFeePercent > 0 && (
                            <View style={styles.feeBadge}>
                                <Text style={styles.feeBadgeText}>+ {processingFeePercent}% PROCESSING FEE</Text>
                            </View>
                        )}
                    </View>

                    <Text style={styles.validityTextNew}>Validity: June 9th–July 20th</Text>
                </View>

                <View style={styles.sectionDivider}>
                    <View style={styles.dividerLine} />
                    <Text style={styles.sectionTitle}>SERVICES</Text>
                    <View style={styles.dividerLine} />
                </View>

                <View style={styles.servicesRow}>
                    <View style={styles.serviceItem}>
                        <Video size={16} color="#0d9488" />
                        <Text style={styles.serviceText}>Telehealth</Text>
                    </View>
                    <View style={styles.serviceItem}>
                        <PhoneCall size={16} color="#0d9488" />
                        <Text style={styles.serviceText}>Emergency</Text>
                    </View>
                </View>

                <View style={styles.sectionDivider}>
                    <View style={styles.dividerLine} />
                    <Text style={styles.sectionTitle}>PLAN BENEFITS</Text>
                    <View style={styles.dividerLine} />
                </View>

                <View style={styles.benefitsList}>
                    {featuresList.map((f, i) => (
                        <View key={i} style={styles.benefitItem}>
                            <View style={styles.checkCircle}>
                                <Check size={12} color="#1e3a8a" />
                            </View>
                            <Text style={styles.benefitText}>{f}</Text>
                        </View>
                    ))}
                </View>

                <TouchableOpacity
                    style={[
                        styles.actionButton,
                        isActive ? styles.viewButton : styles.upgradeButton,
                        purchasing === item.id && styles.disabledButton,
                        isDowngrade && { opacity: 0.5 }
                    ]}
                    onPress={() => isActive ? router.push('/plan-confirmation') : handleBuy(item)}
                    disabled={purchasing === item.id || currentStep !== 2 || isDowngrade}
                >
                    {purchasing === item.id ? (
                        <ActivityIndicator color="#fff" />
                    ) : (
                        <View style={styles.buttonContent}>
                            {isActive ? (
                                <>
                                    <ShieldCheck size={18} color="#64748b" />
                                    <Text style={styles.viewButtonText}>VIEW CONFIRMATION</Text>
                                </>
                            ) : (
                                <>
                                    <Sparkles size={18} color="#fff" />
                                    <Text style={styles.upgradeButtonText}>{isUpgrade ? 'UPGRADE PLAN' : (isDowngrade ? 'LOWER PLAN' : 'SELECT PLAN')}</Text>
                                </>
                            )}
                        </View>
                    )}
                </TouchableOpacity>
            </View>
        );
    };

    if (loading && !refreshing) return <View style={styles.center}><ActivityIndicator size="large" color="#2563eb" /></View>;

    return (
        <View style={styles.container}>
            <LinearGradient colors={['#0251fc', '#072169']} style={styles.header}>
                <Text style={styles.headerTitle}>Plans & Pricing</Text>
                {currentStep === 2 && (
                    <View style={styles.tabsContainer}>
                        <TouchableOpacity style={[styles.tabButton, activeTab === 'INDIVIDUAL' && styles.activeTabButton]} onPress={() => setActiveTab('INDIVIDUAL')}>
                            <Text style={[styles.tabText, activeTab === 'INDIVIDUAL' && styles.activeTabText]}>Individual</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={[styles.tabButton, activeTab === 'FAMILY_2' && styles.activeTabButton]} onPress={() => setActiveTab('FAMILY_2')}>
                            <Text style={[styles.tabText, activeTab === 'FAMILY_2' && styles.activeTabText]}>Family of 2</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={[styles.tabButton, activeTab === 'FAMILY_3_4' && styles.activeTabButton]} onPress={() => setActiveTab('FAMILY_3_4')}>
                            <Text style={[styles.tabText, activeTab === 'FAMILY_3_4' && styles.activeTabText]}>Family 3-4</Text>
                        </TouchableOpacity>
                    </View>
                )}
            </LinearGradient>
            <FlatList
                data={currentStep === 2 ? plans.filter(p => {
                    const maxP = p.maxPersons || 1;
                    const tabName = (p.planTabName || '').toLowerCase();
                    if (activeTab === 'INDIVIDUAL') return maxP === 1 || tabName.includes('individual');
                    if (activeTab === 'FAMILY_2') return maxP === 2 || tabName.includes('family of 2');
                    if (activeTab === 'FAMILY_3_4') return maxP >= 3 || tabName.includes('family of 3-4');
                    return false;
                }).filter((p, _, filtered) => {
                    if (!activePlan) {
                        // If no active plan, only show the base plan (lowest price in this category)
                        return p.id === filtered[0]?.id;
                    }
                    return true;
                }) : []}
                renderItem={renderPlan}
                keyExtractor={(item) => item.id.toString()}
                contentContainerStyle={{ padding: 16 }}
                refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
                ListHeaderComponent={
                    <View>
                        {currentStep === 1 ? (
                            <View style={styles.itineraryCard}>
                                <View style={styles.stepHeaderRow}>
                                    <View style={styles.stepBadge}><Text style={styles.stepBadgeText}>1</Text></View>
                                    <View>
                                        <Text style={styles.stepTitle}>Step 1: Your Destinations</Text>
                                        <Text style={styles.stepSubtitle}>Add cities for tax calculation and care coordination</Text>
                                    </View>
                                </View>
                                <View style={styles.itineraryContent}>
                                    <View style={styles.itineraryHeader}>
                                        <View style={styles.itineraryLabelRow}>
                                            <Plane size={20} color="#1e3a8a" />
                                            <Text style={styles.itineraryLabel}>Your Travel Destinations</Text>
                                        </View>
                                        <TouchableOpacity style={styles.addCityBtn} onPress={() => setShowAddCityModal(true)}>
                                            <Plus size={18} color="#1e3a8a" />
                                            <Text style={styles.addCityBtnText}>Add City</Text>
                                        </TouchableOpacity>
                                    </View>
                                    {selectedDestinations.length === 0 ? (
                                        <View style={styles.emptyItinerary}>
                                            <MapPin size={40} color="#e2e8f0" />
                                            <Text style={styles.emptyItineraryText}>No destinations added yet.</Text>
                                            <Text style={styles.emptyItinerarySub}>Add cities to calculate taxes and plan your trip.</Text>
                                        </View>
                                    ) : (
                                        <View style={styles.destinationList}>
                                            {selectedDestinations.map((dest, index) => {
                                                const isFirstInCountry = selectedDestinations.findIndex(d =>
                                                    String(d.country || '').trim().toLowerCase() === String(dest.country || '').trim().toLowerCase()
                                                ) === index;
                                                return (
                                                    <View key={dest.id} style={styles.destinationItem}>
                                                        <View style={styles.destinationInfo}>
                                                            <MapPin size={16} color="#0d9488" />
                                                            <Text style={styles.destinationName}>{dest.city}, {dest.country}</Text>
                                                            {/* Only show badge if it's the first city for this country and tax is enabled */}
                                                            {isFirstInCountry && isTaxEnabled && (
                                                                <View style={styles.taxBadge}>
                                                                    <Text style={styles.taxBadgeText}>
                                                                        {dest.taxType === 'PERCENTAGE' ? `${dest.taxValue}%` : `$${dest.taxValue}`} Tax
                                                                    </Text>
                                                                </View>
                                                            )}
                                                        </View>
                                                        <TouchableOpacity onPress={() => removeDestination(dest.id)}>
                                                            <X size={18} color="#94a3b8" />
                                                        </TouchableOpacity>
                                                    </View>
                                                );
                                            })}
                                        </View>
                                    )}
                                </View>
                                <TouchableOpacity 
                                    style={[styles.mainNextBtn, selectedDestinations.length === 0 && styles.disabledBtn]} 
                                    onPress={async () => {
                                        await loadData();
                                        setCurrentStep(2);
                                    }} 
                                    disabled={selectedDestinations.length === 0}
                                >
                                    <Text style={styles.mainNextBtnText}>Continue to Plans</Text>
                                </TouchableOpacity>
                            </View>
                        ) : (
                            <View>
                                <View style={styles.summaryCard}>
                                    <View style={styles.summaryHeader}>
                                        <Text style={styles.summaryTitle}>Destinations Set</Text>
                                        <TouchableOpacity onPress={() => setCurrentStep(1)}><Text style={styles.editLink}>Edit</Text></TouchableOpacity>
                                    </View>
                                    <Text style={styles.summaryText}>{selectedDestinations.length} location(s) added.{isTaxEnabled ? ' Taxes applied.' : ''}</Text>
                                    {activePlan && selectedDestinations.length === 0 && (
                                        <View style={styles.destinationWarning}>
                                            <Info size={14} color="#f59e0b" />
                                            <Text style={styles.destinationWarningText}>
                                                Please add your travel destinations to calculate correct taxes and processing fees.
                                            </Text>
                                        </View>
                                    )}
                                </View>
                                <View style={styles.stepHeaderRowLarge}>
                                    <View style={styles.stepBadge}><Text style={styles.stepBadgeText}>2</Text></View>
                                    <View>
                                        <Text style={styles.stepTitle}>Step 2: Choose Your Plan</Text>
                                        <Text style={styles.stepSubtitle}>Compare and select the best plan for you</Text>
                                    </View>
                                </View>
                            </View>
                        )}

                        {activePlan && currentStep === 2 ? (
                            <View style={styles.activePlanBanner}>
                                <View style={styles.bannerTopRow}>
                                    <View style={styles.bannerIconWrapper}><ShieldCheck size={28} color="#059669" /></View>
                                    <View style={styles.bannerPlanDetails}>
                                        <View style={styles.bannerPlanTitleRow}>
                                            <Text style={styles.bannerPlanName}>Active: {activePlan.plan?.name || 'Basic'}</Text>
                                            <View style={styles.activePill}><Text style={styles.activePillText}>ACTIVE</Text></View>
                                        </View>
                                        <Text style={styles.bannerPlanDate}>Coverage active</Text>
                                    </View>
                                </View>
                                <View style={styles.bannerDivider} />
                                <View style={styles.coverageSection}>
                                    <View style={styles.coverageHeaderRow}><Users size={16} color="#047857" /><Text style={styles.coverageLabel}>COVERAGE DETAILS</Text></View>
                                    <View style={styles.coverageMembersRow}>
                                        <View style={styles.userPill}>
                                            <View style={styles.userAvatar}><Text style={styles.userAvatarText}>{(userData?.firstName?.[0] || 'Y').toUpperCase()}</Text></View>
                                            <Text style={styles.userPillText}>{userData?.firstName || 'You'}</Text>
                                        </View>
                                        {familyMembers.map((member, idx) => (
                                            <View key={idx} style={styles.userPill}>
                                                <View style={styles.userAvatar}><Text style={styles.userAvatarText}>{member.firstName[0].toUpperCase()}</Text></View>
                                                <Text style={styles.userPillText}>{member.firstName}</Text>
                                            </View>
                                        ))}
                                    </View>
                                </View>
                                <TouchableOpacity
                                    style={[styles.buyButton, { marginTop: 16, backgroundColor: '#059669' }]}
                                    onPress={() => router.push('/plan-confirmation')}
                                >
                                    <Text style={styles.buyButtonText}>View Confirmation</Text>
                                </TouchableOpacity>
                            </View>
                        ) : null}
                    </View>
                }
                ListEmptyComponent={currentStep === 2 ? (
                    <View style={styles.emptyContainer}>
                        <ActivityIndicator size="small" color="#2563eb" style={{ marginBottom: 10 }} />
                        <Text style={styles.emptyText}>No plans found for this category.</Text>
                        <TouchableOpacity onPress={loadData} style={{ marginTop: 10 }}><Text style={{ color: '#2563eb', fontWeight: '600' }}>Retry</Text></TouchableOpacity>
                    </View>
                ) : null}
            />

            <Modal visible={showAddCityModal} transparent animationType="slide" onRequestClose={() => setShowAddCityModal(false)}>
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContent}>
                        <View style={styles.modalHeader}><Text style={styles.modalTitle}>Add Travel Destination</Text><TouchableOpacity onPress={() => setShowAddCityModal(false)}><X size={24} color="#64748b" /></TouchableOpacity></View>
                        <View style={styles.modalBody}>
                            <View style={styles.inputGroup}>
                                <Text style={styles.inputLabel}>Country *</Text>
                                <TouchableOpacity style={styles.dropdownTrigger} onPress={() => { setShowCountryDrop(!showCountryDrop); setShowCityDrop(false); }}>
                                    <Text style={[styles.dropdownValue, !selectedCountry && styles.placeholderText]}>{selectedCountry || 'Select Country'}</Text>
                                    <Plus size={20} color="#94a3b8" style={{ transform: [{ rotate: showCountryDrop ? '45deg' : '0deg' }] }} />
                                </TouchableOpacity>
                                {showCountryDrop && (
                                    <ScrollView style={styles.dropdownMenu} nestedScrollEnabled={true}>
                                        {locations.map(c => (
                                            <TouchableOpacity key={c.country} style={styles.dropdownItem} onPress={() => { setSelectedCountry(c.country); setSelectedCity(''); setSelectedState(''); setShowCountryDrop(false); }}>
                                                <Text style={styles.dropdownItemText}>{c.country}</Text>
                                            </TouchableOpacity>
                                        ))}
                                    </ScrollView>
                                )}
                            </View>
                            <View style={styles.inputGroup}>
                                <Text style={styles.inputLabel}>City *</Text>
                                <TouchableOpacity style={[styles.dropdownTrigger, !selectedCountry && styles.disabledInput]} disabled={!selectedCountry} onPress={() => { setShowCityDrop(!showCityDrop); setShowCountryDrop(false); }}>
                                    <Text style={[styles.dropdownValue, !selectedCity && styles.placeholderText]}>{selectedCity || 'Select City'}</Text>
                                    <Plus size={20} color="#94a3b8" style={{ transform: [{ rotate: showCityDrop ? '45deg' : '0deg' }] }} />
                                </TouchableOpacity>
                                {showCityDrop && (
                                    <ScrollView style={styles.dropdownMenu} nestedScrollEnabled={true}>
                                        {(locations.find(l => l.country === selectedCountry)?.cities || []).map((c: any) => (
                                            <TouchableOpacity key={c.name} style={styles.dropdownItem} onPress={() => { setSelectedCity(c.name); setSelectedState(c.state); setShowCityDrop(false); }}>
                                                <Text style={styles.dropdownItemText}>{c.name}</Text>
                                            </TouchableOpacity>
                                        ))}
                                    </ScrollView>
                                )}
                            </View>
                            <View style={styles.inputGroup}><Text style={styles.inputLabel}>State / Province</Text><TextInput style={styles.disabledInputText} value={selectedState} editable={false} placeholder="Auto-populated" placeholderTextColor="#cbd5e1" /></View>
                            <View style={styles.modalNotice}><Info size={16} color="#1e40af" /><Text style={styles.modalNoticeText}>Taxes are calculated based on government regulations for the selected city.</Text></View>
                        </View>
                        <TouchableOpacity style={[styles.confirmAddBtn, !selectedCity && styles.disabledBtn]} disabled={!selectedCity} onPress={handleAddDestination}><Text style={styles.confirmAddBtnText}>Add to Itinerary</Text></TouchableOpacity>
                    </View>
                </View>
            </Modal>

            {/* Premium Checkout Breakdown Modal */}
            <Modal visible={checkoutModalVisible} transparent animationType="slide" onRequestClose={() => setCheckoutModalVisible(false)}>
                <View style={styles.modalOverlay}>
                    <View style={styles.checkoutModalContent}>
                        <View style={styles.checkoutModalHeader}>
                            <View>
                                <Text style={styles.checkoutModalTitle}>Order Summary</Text>
                                <Text style={styles.checkoutModalSubtitle}>{selectedPlanForCheckout?.name}</Text>
                            </View>
                            <TouchableOpacity onPress={() => setCheckoutModalVisible(false)}>
                                <X size={28} color="#94a3b8" />
                            </TouchableOpacity>
                        </View>

                        {checkoutDetails?.isUpgrade && (
                            <View style={styles.upgradeNoticeBox}>
                                <Info size={20} color="#0d9488" />
                                <Text style={styles.upgradeNoticeText}>
                                    You are upgrading from your current plan. You will only pay the difference.
                                </Text>
                            </View>
                        )}

                        <View style={styles.breakdownContainer}>
                            <View style={styles.breakdownRow}>
                                <Text style={styles.breakdownLabel}>Cost of plan</Text>
                                <Text style={styles.breakdownValue}>${checkoutDetails?.baseDiff?.toFixed(2)}</Text>
                            </View>
                            
                            {checkoutDetails?.planTax > 0 && isTaxEnabled && (
                                <View style={styles.breakdownRow}>
                                    <Text style={styles.breakdownLabel}>Country Health Levy</Text>
                                    <Text style={styles.breakdownValue}>+ ${checkoutDetails?.planTax?.toFixed(2)}</Text>
                                </View>
                            )}

                            <View style={[styles.breakdownRow, { borderTopWidth: 1, borderStyle: 'dashed', borderColor: '#eee', paddingTop: 8, marginTop: 4 }]}>
                                <Text style={[styles.breakdownLabel, { fontWeight: 'bold' }]}>Subtotal</Text>
                                <Text style={[styles.breakdownValue, { fontWeight: 'bold' }]}>${(checkoutDetails?.baseDiff + checkoutDetails?.planTax).toFixed(2)}</Text>
                            </View>
                            
                            {checkoutDetails?.processingFeePercent > 0 && (
                                <View style={styles.breakdownRow}>
                                    <Text style={styles.breakdownLabel}>{checkoutDetails?.processingFeePercent}% Processing Fees</Text>
                                    <Text style={styles.breakdownValue}>+ ${checkoutDetails?.feeAmount?.toFixed(2)}</Text>
                                </View>
                            )}
                            
                            <View style={styles.breakdownDivider} />
                            
                            <View style={styles.breakdownTotalRow}>
                                <Text style={styles.breakdownTotalLabel}>Total</Text>
                                <Text style={styles.breakdownTotalValue}>${checkoutDetails?.finalTotal?.toFixed(2)}</Text>
                            </View>
                        </View>

                        <View style={styles.securePaymentNotice}>
                            <ShieldCheck size={16} color="#64748b" />
                            <Text style={styles.securePaymentText}>Payments are processed securely via Stripe.</Text>
                        </View>

                        <TouchableOpacity 
                            style={styles.payNowBtn} 
                            onPress={() => {
                                setCheckoutModalVisible(false);
                                if (selectedPlanForCheckout) {
                                    processPurchase(selectedPlanForCheckout);
                                }
                            }}
                        >
                            <Text style={styles.payNowBtnText}>Proceed to Payment</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f9fafb' },
    center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
    header: { paddingTop: 50, paddingBottom: 24, paddingHorizontal: 20 },
    headerTitle: { fontSize: 24, fontWeight: '700', color: '#ffffff', marginBottom: 16 },
    tabsContainer: { flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 12, padding: 4 },
    tabButton: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 10 },
    activeTabButton: { backgroundColor: '#ffffff' },
    tabText: { color: '#ffffff', fontSize: 13, fontWeight: '600' },
    activeTabText: { color: '#2563eb' },
    card: { backgroundColor: '#ffffff', borderRadius: 16, padding: 20, marginBottom: 16, elevation: 3 },
    cardHeader: { alignItems: 'center', marginBottom: 16 },
    planName: { fontSize: 20, fontWeight: '700', color: '#111827' },
    planPrice: { fontSize: 32, fontWeight: '800', color: '#2563eb' },
    planValidity: { fontSize: 14, color: '#6b7280' },
    divider: { height: 1, backgroundColor: '#f3f4f6', marginVertical: 16 },
    featuresContainer: { marginBottom: 20 },
    featureRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 8, gap: 8 },
    featureText: { fontSize: 14, color: '#4b5563', flex: 1 },
    buyButton: { backgroundColor: '#2563eb', paddingVertical: 14, borderRadius: 12, alignItems: 'center' },
    buyButtonText: { color: '#ffffff', fontSize: 16, fontWeight: '600' },
    activeCard: { borderColor: '#16a34a', borderWidth: 2 },
    activeBadge: { position: 'absolute', top: -12, right: 20, backgroundColor: '#16a34a', paddingHorizontal: 12, paddingVertical: 4, borderRadius: 20, zIndex: 10 },
    activeBadgeText: { color: '#ffffff', fontSize: 12, fontWeight: 'bold' },
    recommendedBadge: { position: 'absolute', top: -12, right: 20, backgroundColor: '#f59e0b', paddingHorizontal: 12, paddingVertical: 4, borderRadius: 20, zIndex: 10 },
    recommendedBadgeText: { color: '#ffffff', fontSize: 12, fontWeight: 'bold' },
    planDescription: { fontSize: 14, color: '#6b7280', marginBottom: 16, lineHeight: 20, textAlign: 'center' },
    activeBuyButton: { backgroundColor: '#f0fdf4', borderWidth: 1, borderColor: '#16a34a' },
    activeBuyButtonText: { color: '#16a34a' },
    disabledButton: { opacity: 0.5 },
    upgradeBadge: { position: 'absolute', top: -12, left: 20, backgroundColor: '#0d9488', paddingHorizontal: 12, paddingVertical: 4, borderRadius: 20, zIndex: 10 },
    upgradeBadgeSide: { position: 'absolute', top: 35, right: 20, backgroundColor: '#0d9488', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 20, zIndex: 10 },
    upgradeBadgeText: { color: '#ffffff', fontSize: 10, fontWeight: 'bold' },
    activePlanBanner: { backgroundColor: '#ecfdf5', borderRadius: 16, padding: 16, marginBottom: 20, borderWidth: 1, borderColor: '#a7f3d0' },
    bannerTopRow: { flexDirection: 'row', gap: 12, alignItems: 'center' },
    bannerIconWrapper: { width: 48, height: 48, borderRadius: 24, backgroundColor: '#d1fae5', justifyContent: 'center', alignItems: 'center' },
    bannerPlanDetails: { flex: 1 },
    bannerPlanTitleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
    bannerPlanName: { fontSize: 18, fontWeight: '700', color: '#047857' },
    activePill: { backgroundColor: '#10b981', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
    activePillText: { color: '#ffffff', fontSize: 10, fontWeight: '800' },
    bannerPlanDate: { fontSize: 13, color: '#64748b' },
    bannerDivider: { height: 1, backgroundColor: '#a7f3d0', marginVertical: 16 },
    coverageSection: {},
    coverageHeaderRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 12 },
    coverageLabel: { fontSize: 12, fontWeight: '700', color: '#047857', letterSpacing: 0.5 },
    coverageMembersRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, alignItems: 'center' },
    userPill: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#ffffff', borderRadius: 20, paddingRight: 12, paddingLeft: 4, paddingVertical: 4, borderWidth: 1, borderColor: '#d1fae5' },
    userAvatar: { width: 24, height: 24, borderRadius: 12, backgroundColor: '#cbd5e1', justifyContent: 'center', alignItems: 'center', marginRight: 8 },
    userAvatarText: { fontSize: 12, fontWeight: '700', color: '#334155' },
    userPillText: { fontSize: 13, fontWeight: '500', color: '#334155' },
    addFamilyInlineBtn: { paddingHorizontal: 8, paddingVertical: 6 },
    addFamilyInlineText: { color: '#10b981', fontSize: 13, fontWeight: '600' },
    activePlanInfo: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    activePlanText: { fontSize: 15, fontWeight: '600', color: '#16a34a', flex: 1 },
    upgradeDifference: { fontSize: 14, fontWeight: '700', color: '#16a34a', marginTop: 4, marginBottom: 2 },
    // New Styles for Redesigned Plan Card
    cardIconContainer: {
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 10,
    },
    activeBadgeNew: {
        position: 'absolute',
        top: 15,
        right: 15,
        backgroundColor: '#10b981',
        paddingHorizontal: 12,
        paddingVertical: 4,
        borderRadius: 8,
    },
    activeBadgeTextNew: {
        color: '#fff',
        fontSize: 11,
        fontWeight: '800',
    },
    recommendedBadgeNew: {
        position: 'absolute',
        top: 15,
        right: 15,
        backgroundColor: '#0d9488',
        paddingHorizontal: 10,
        paddingVertical: 6,
        borderRadius: 20,
        flexDirection: 'row',
        alignItems: 'center',
    },
    recommendedBadgeTextNew: {
        color: '#fff',
        fontSize: 10,
        fontWeight: '800',
    },
    cardHeaderNew: {
        alignItems: 'center',
        marginBottom: 15,
    },
    planNameNew: {
        fontSize: 22,
        fontWeight: '800',
        color: '#111827',
        marginBottom: 6,
    },
    planDescriptionNew: {
        fontSize: 13,
        color: '#6b7280',
        textAlign: 'center',
        paddingHorizontal: 10,
        marginBottom: 12,
    },
    priceContainerNew: {
        flexDirection: 'row',
        alignItems: 'baseline',
        justifyContent: 'center',
    },
    currencySymbolNew: {
        fontSize: 20,
        fontWeight: '600',
        color: '#111827',
        bottom: 12,
    },
    priceIntNew: {
        fontSize: 48,
        fontWeight: '800',
        color: '#111827',
    },
    priceDecNew: {
        fontSize: 20,
        fontWeight: '700',
        color: '#111827',
    },
    upgradeBadgeInline: {
        backgroundColor: '#f1f5f9',
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 12,
        marginLeft: 8,
        bottom: 8,
    },
    upgradeBadgeTextInline: {
        fontSize: 10,
        fontWeight: '800',
        color: '#1e293b',
    },
    taxBadgeContainer: {
        marginTop: 10,
        gap: 8,
        alignItems: 'center',
    },
    greyBadge: {
        backgroundColor: '#f1f5f9',
        paddingHorizontal: 40,
        paddingVertical: 6,
        borderRadius: 10,
        width: '100%',
        alignItems: 'center',
    },
    greyBadgeText: {
        fontSize: 11,
        fontWeight: '700',
        color: '#475569',
        letterSpacing: 0.5,
    },
    feeBadge: {
        backgroundColor: '#ecfeff',
        paddingHorizontal: 40,
        paddingVertical: 6,
        borderRadius: 10,
        width: '100%',
        alignItems: 'center',
    },
    feeBadgeText: {
        fontSize: 11,
        fontWeight: '700',
        color: '#0d9488',
        letterSpacing: 0.5,
    },
    validityTextNew: {
        fontSize: 14,
        color: '#64748b',
        marginTop: 12,
        fontWeight: '500',
    },
    sectionDivider: {
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: 15,
    },
    dividerLine: {
        flex: 1,
        height: 1,
        backgroundColor: '#f1f5f9',
    },
    sectionTitle: {
        fontSize: 11,
        fontWeight: '800',
        color: '#94a3b8',
        marginHorizontal: 12,
        letterSpacing: 1,
    },
    servicesRow: {
        flexDirection: 'row',
        justifyContent: 'center',
        gap: 20,
        marginBottom: 5,
    },
    serviceItem: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
    },
    serviceText: {
        fontSize: 13,
        fontWeight: '600',
        color: '#334155',
    },
    benefitsList: {
        gap: 10,
        marginBottom: 20,
    },
    benefitItem: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
    },
    checkCircle: {
        width: 20,
        height: 20,
        borderRadius: 10,
        backgroundColor: '#f1f5f9',
        justifyContent: 'center',
        alignItems: 'center',
    },
    benefitText: {
        fontSize: 14,
        color: '#475569',
        fontWeight: '500',
    },
    actionButton: {
        borderRadius: 12,
        paddingVertical: 16,
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        marginTop: 10,
    },
    buttonContent: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
    },
    viewButton: {
        backgroundColor: '#f8fafc',
        borderWidth: 1,
        borderColor: '#e2e8f0',
    },
    viewButtonText: {
        fontSize: 15,
        fontWeight: '800',
        color: '#64748b',
    },
    upgradeButton: {
        backgroundColor: '#0d9488',
    },
    upgradeButtonText: {
        fontSize: 15,
        fontWeight: '800',
        color: '#fff',
    },
    itineraryCard: { backgroundColor: '#ffffff', borderRadius: 20, padding: 20, marginBottom: 24, borderWidth: 1, borderColor: '#e2e8f0', elevation: 2 },
    stepHeaderRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 16 },
    stepHeaderRowLarge: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 20, marginTop: 8 },
    stepBadge: { width: 28, height: 28, borderRadius: 14, backgroundColor: '#1e3a8a', justifyContent: 'center', alignItems: 'center' },
    stepBadgeText: { color: '#ffffff', fontSize: 14, fontWeight: '700' },
    stepTitle: { fontSize: 18, fontWeight: '700', color: '#0f172a' },
    stepSubtitle: { fontSize: 13, color: '#64748b' },
    itineraryContent: { borderWidth: 1, borderColor: '#f1f5f9', borderRadius: 16, padding: 16, backgroundColor: '#fcfdfe', borderStyle: 'dashed' },
    itineraryHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
    itineraryLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    itineraryLabel: { fontSize: 15, fontWeight: '600', color: '#1e3a8a' },
    addCityBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#eff6ff', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, borderWidth: 1, borderColor: '#dbeafe' },
    addCityBtnText: { fontSize: 14, fontWeight: '600', color: '#1e3a8a' },
    emptyItinerary: { alignItems: 'center', paddingVertical: 20 },
    emptyItineraryText: { fontSize: 15, fontWeight: '600', color: '#64748b', marginTop: 12 },
    emptyItinerarySub: { fontSize: 12, color: '#94a3b8', textAlign: 'center', marginTop: 4 },
    destinationList: { gap: 10 },
    destinationItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#ffffff', padding: 12, borderRadius: 12, borderWidth: 1, borderColor: '#e2e8f0' },
    destinationInfo: { flexDirection: 'row', alignItems: 'center', gap: 8, flex: 1 },
    destinationName: { fontSize: 14, fontWeight: '600', color: '#334155' },
    taxBadge: { backgroundColor: '#f0fdfa', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6, borderWidth: 1, borderColor: '#ccfbf1' },
    taxBadgeText: { fontSize: 11, fontWeight: '700', color: '#0d9488' },
    priceRow: { flexDirection: 'row', alignItems: 'baseline', gap: 6, marginTop: 4 },
    basePrice: { fontSize: 20, fontWeight: '600', color: '#64748b' },
    taxText: { fontSize: 14, fontWeight: '600', color: '#0d9488' },
    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
    modalContent: { backgroundColor: '#ffffff', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: '80%' },
    modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
    modalTitle: { fontSize: 20, fontWeight: '700', color: '#0f172a' },
    modalBody: { gap: 16 },
    inputGroup: { gap: 8 },
    inputLabel: { fontSize: 14, fontWeight: '600', color: '#475569' },
    dropdownTrigger: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#f8fafc', padding: 16, borderRadius: 12, borderWidth: 1, borderColor: '#e2e8f0' },
    dropdownValue: { fontSize: 15, color: '#0f172a' },
    placeholderText: { color: '#94a3b8' },
    dropdownMenu: { backgroundColor: '#ffffff', borderRadius: 12, borderWidth: 1, borderColor: '#e2e8f0', marginTop: 4, maxHeight: 150, elevation: 4 },
    dropdownItem: { padding: 16, borderBottomWidth: 1, borderBottomColor: '#f1f5f9' },
    dropdownItemText: { fontSize: 15, color: '#334155' },
    disabledInput: { backgroundColor: '#f1f5f9', opacity: 0.6 },
    disabledInputText: { backgroundColor: '#f1f5f9', padding: 16, borderRadius: 12, borderWidth: 1, borderColor: '#e2e8f0', color: '#94a3b8' },
    modalNotice: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#eff6ff', padding: 12, borderRadius: 12, marginTop: 8 },
    modalNoticeText: { fontSize: 12, color: '#1e40af', flex: 1, lineHeight: 18 },
    confirmAddBtn: { backgroundColor: '#1e3a8a', paddingVertical: 16, borderRadius: 12, alignItems: 'center', marginTop: 24 },
    confirmAddBtnText: { color: '#ffffff', fontSize: 16, fontWeight: '700' },
    disabledBtn: { backgroundColor: '#cbd5e1' },
    emptyContainer: { padding: 40, alignItems: 'center', justifyContent: 'center' },
    emptyText: { fontSize: 16, color: '#64748b', textAlign: 'center' },
    mainNextBtn: { backgroundColor: '#1e3a8a', paddingVertical: 16, borderRadius: 12, alignItems: 'center', marginTop: 20 },
    mainNextBtnText: { color: '#ffffff', fontSize: 16, fontWeight: '700' },
    summaryCard: { backgroundColor: '#eff6ff', borderRadius: 16, padding: 16, marginBottom: 20, borderWidth: 1, borderColor: '#dbeafe' },
    summaryHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
    summaryTitle: { fontSize: 14, fontWeight: '700', color: '#1e40af' },
    summaryText: { fontSize: 13, color: '#1e40af', opacity: 0.8 },
    destinationWarning: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        backgroundColor: '#fffbeb',
        padding: 8,
        borderRadius: 8,
        marginTop: 10,
        borderWidth: 1,
        borderColor: '#fef3c7',
    },
    destinationWarningText: {
        fontSize: 12,
        color: '#b45309',
        flex: 1,
        fontWeight: '600',
    },
    editLink: { fontSize: 13, fontWeight: '700', color: '#2563eb', textDecorationLine: 'underline' },
    checkoutModalContent: { backgroundColor: '#ffffff', borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 24, maxHeight: '90%' },
    checkoutModalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 },
    checkoutModalTitle: { fontSize: 22, fontWeight: '800', color: '#0f172a' },
    checkoutModalSubtitle: { fontSize: 15, color: '#64748b', marginTop: 4, fontWeight: '500' },
    upgradeNoticeBox: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f0fdfa', padding: 14, borderRadius: 12, borderWidth: 1, borderColor: '#ccfbf1', marginBottom: 20, gap: 10 },
    upgradeNoticeText: { flex: 1, fontSize: 13, color: '#0f766e', lineHeight: 18, fontWeight: '500' },
    breakdownContainer: { backgroundColor: '#f8fafc', borderRadius: 16, padding: 20, borderWidth: 1, borderColor: '#e2e8f0', marginBottom: 24 },
    breakdownRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
    breakdownLabel: { fontSize: 15, color: '#475569', fontWeight: '500' },
    breakdownValue: { fontSize: 16, color: '#0f172a', fontWeight: '600' },
    breakdownDivider: { height: 1, backgroundColor: '#e2e8f0', marginVertical: 14 },
    breakdownTotalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    breakdownTotalLabel: { fontSize: 18, color: '#0f172a', fontWeight: '700' },
    breakdownTotalValue: { fontSize: 22, color: '#2563eb', fontWeight: '800' },
    securePaymentNotice: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 6, marginBottom: 24 },
    securePaymentText: { fontSize: 13, color: '#64748b', fontWeight: '500' },
    payNowBtn: { backgroundColor: '#2563eb', paddingVertical: 16, borderRadius: 14, alignItems: 'center', shadowColor: '#2563eb', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 4 },
    payNowBtnText: { color: '#ffffff', fontSize: 18, fontWeight: '700' }
});
