# Authentication – Patient Mobile API

## Overview

Patient endpoints use **JWT Bearer tokens**. After login or register, the client receives an `accessToken` and `refreshToken`. Use the access token in the `Authorization` header for all protected endpoints.

---

## Header Format

```
Authorization: Bearer <accessToken>
```

- **Header name:** `Authorization`
- **Scheme:** `Bearer` (space, then the token)
- **Content-Type:** `application/json` for request bodies

---   Update the custom bottom navigation bar so it is never hidden behind the Android system navigation buttons or gesture bar.

Requirements:
- Use react-native-safe-area-context
- Import and use useSafeAreaInsets()
- Add the bottom inset to the tab bar padding and height
- Keep it working correctly for:
  - Android 3-button navigation
  - Android gesture navigation
  - iPhone safe area
- The bottom bar should stay fixed at the bottom and remain fully clickable

Example behavior:
- paddingBottom should use insets.bottom
- height should be base height + insets.bottom
- For absolutely positioned bars, keep bottom: 0 and add the inset through padding/height

Implement it in the shared/custom bottom navigation component so it applies across all pages automatically.

## Login

**POST** `{BASE_URL}/api/auth/login`

**Request body:**
```json
{
  "email": "patient@example.com",
  "password": "yourPassword"
}
```

**Success (200):**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "id": 1,
      "userUuid": "uuid-string",
      "email": "patient@example.com",
      "firstName": "John",
      "lastName": "Doe",
      "role": "PATIENT",
      "isActive": true
    },
    "accessToken": "eyJhbGc...",
    "refreshToken": "eyJhbGc..."
  }
}
```

**Errors:**
- `400` – Email or password missing
- `401` – Invalid email or password, or account deactivated

---

## Register

**POST** `{BASE_URL}/api/auth/register`

**Request body:**
```json
{
  "email": "newpatient@example.com",
  "password": "securePassword8",
  "firstName": "Jane",
  "lastName": "Smith"
}
```

**Constraints:**
- Password: minimum 8 characters
- Email: valid format, unique

**Success (201):**
```json
{
  "success": true,
  "message": "Registration successful",
  "data": {
    "user": { "id": 2, "userUuid": "...", "email": "...", "firstName": "...", "lastName": "...", "role": "PATIENT", "isActive": true },
    "accessToken": "eyJhbGc...",
    "refreshToken": "eyJhbGc..."
  }
}
```

**Errors:**
- `400` – Validation error or "Email already registered"

---

## Refresh Token

When the access token expires, the API returns `401`. Use the refresh token to get a new access token without asking the user to log in again.

**POST** `{BASE_URL}/api/auth/refresh`

**Request body:**
```json
{
  "refreshToken": "eyJhbGc..."
}
```

**Success (200):**
```json
{
  "success": true,
  "message": "Token refreshed successfully",
  "data": {
    "accessToken": "eyJhbGc..."
  }
}
```

**Notes:**
- Refresh token is long-lived (e.g. 7 days); store it securely.
- Only a new `accessToken` is returned; keep using the same `refreshToken` until it expires.
- On `401` from refresh, redirect the user to login.

---

## Token Expiry

| Token         | Typical expiry | Use |
|---------------|----------------|-----|
| Access token  | 24h (configurable) | Every request to protected endpoints |
| Refresh token | 7d (configurable)  | Only to call `/api/auth/refresh` |

---

## Recommended Flow (Mobile)

1. On app start, read stored `accessToken` (and optionally `refreshToken`).
2. For each API call, send `Authorization: Bearer <accessToken>`.
3. If the API returns **401**:
   - Call `POST /api/auth/refresh` with the stored `refreshToken`.
   - If refresh succeeds, save the new `accessToken` and retry the original request.
   - If refresh fails (401), clear tokens and show login screen.
4. On login/register, store both `accessToken` and `refreshToken` securely (e.g. secure storage / keychain).
