// Stripe Configuration for Mobile App
export const STRIPE_CONFIG = {
    publishableKey: 'pk_live_51QX0cgFDolZMURpEaCg6tKBKxpGgc41LycSaqv1wXEUGrfh7vdLZ1rTX8WSDkf0UZ1RBDuvZBWGuMbpkY7BEe6mY003e2OjWQF',
    merchantIdentifier: 'merchant.com.navala.travelapp', // For Apple Pay
    urlScheme: 'navala-travel-app', // For redirects
};
