import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { Platform } from 'react-native';
import { API_BASE_URL } from '../api/config';
import { getItem } from './storage';

/**
 * Common utility to fetch HTML from the backend and print/share it as a PDF
 */
export const printDocument = async (endpoint: string, filename: string = 'document.pdf', customHtml?: string) => {
  try {
    // 0. Import FileSystem (using require to resolve Metro bundling issues)
    const FileSystem = require('expo-file-system/legacy');
    
    let html = customHtml;

    if (!html) {
        // 1. Fetch the HTML content from the shared endpoint
        const token = await getItem('accessToken');
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });

        if (!response.ok) {
          throw new Error(`Server returned status ${response.status}`);
        }

        html = await response.text();

        // Basic check to see if we got HTML or a JSON error string
        if (!html || html.trim().startsWith('{') || html.length < 50) {
          console.error('Invalid document content received:', html);
          throw new Error('Failed to retrieve document content');
        }
    }

    // 4. Generate the PDF from HTML
    const { uri } = await Print.printToFileAsync({ html: html });

    // 5. Rename the file to the desired filename for professional sharing
    const pdfName = filename.endsWith('.pdf') ? filename : `${filename}.pdf`;
    const newUri = `${FileSystem.cacheDirectory}${pdfName}`;
    
    await FileSystem.moveAsync({
        from: uri,
        to: newUri
    });

    // 6. Share/Download the document
    if (Platform.OS === 'ios') {
        await Sharing.shareAsync(newUri, { UTI: 'com.adobe.pdf' });
    } else {
        await Sharing.shareAsync(newUri, { 
            mimeType: 'application/pdf', 
            dialogTitle: `Download ${pdfName}` 
        });
    }
  } catch (error: any) {
    console.error('Print Error:', error);
    throw error;
  }
};
