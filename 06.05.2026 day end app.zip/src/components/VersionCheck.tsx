import React, { useEffect, useState } from 'react';
import {
    Modal,
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Linking,
    Platform,
    Animated,
    Dimensions,
    Image,
} from 'react-native';
import { FontAwesome5 } from '@expo/vector-icons';
import { SystemConfigApi } from '../api';
import { CURRENT_APP_VERSION } from '../config/version';
import { Smartphone, Star, ArrowRight, X } from 'lucide-react-native';

const { width } = Dimensions.get('window');

const PLAY_STORE_URL = 'https://play.google.com/store/apps/details?id=com.navala.travelapp';
const APP_STORE_URL = 'https://apps.apple.com/us/app/navala-travel-health/id6759361812';

export const VersionCheck = () => {
    const [updateConfig, setUpdateConfig] = useState<{
        latest_version: string;
        show_update: boolean;
        force_update: boolean;
        update_url?: string;
    } | null>(null);
    const [isVisible, setIsVisible] = useState(false);
    const scaleAnim = React.useRef(new Animated.Value(0.85)).current;
    const opacityAnim = React.useRef(new Animated.Value(0)).current;

    useEffect(() => {
        checkVersion();
    }, []);

    useEffect(() => {
        if (isVisible) {
            Animated.parallel([
                Animated.spring(scaleAnim, {
                    toValue: 1,
                    useNativeDriver: true,
                    damping: 14,
                    stiffness: 180,
                }),
                Animated.timing(opacityAnim, {
                    toValue: 1,
                    duration: 250,
                    useNativeDriver: true,
                }),
            ]).start();
        }
    }, [isVisible]);

    const checkVersion = async () => {
        try {
            const response = await SystemConfigApi.get('app_update_config');
            if (response.success && response.data) {
                const config = typeof response.data === 'string' ? JSON.parse(response.data) : response.data;
                setUpdateConfig(config);
                if (config.show_update && config.latest_version !== CURRENT_APP_VERSION) {
                    setIsVisible(true);
                }
            }
        } catch (error) {
            console.error('Version check failed:', error);
        }
    };

    const handlePlayStore = () => Linking.openURL(PLAY_STORE_URL);
    const handleAppStore = () => Linking.openURL(APP_STORE_URL);

    const handleDismiss = () => {
        if (!updateConfig?.force_update) setIsVisible(false);
    };

    if (!isVisible || !updateConfig) return null;

    return (
        <Modal
            transparent={true}
            visible={isVisible}
            animationType="fade"
            onRequestClose={handleDismiss}
        >
            <View style={styles.overlay}>
                <Animated.View style={[styles.card, { opacity: opacityAnim, transform: [{ scale: scaleAnim }] }]}>

                    {/* Dismiss button */}
                    {!updateConfig.force_update && (
                        <TouchableOpacity style={styles.closeBtn} onPress={handleDismiss} activeOpacity={0.7}>
                            <X size={16} color="#94a3b8" />
                        </TouchableOpacity>
                    )}

                    {/* Header gradient stripe */}
                    <View style={styles.headerStripe}>
                        <View style={styles.iconCircle}>
                            <Image
                                source={require('../../assets/images/icon.png')}
                                style={{ width: 50, height: 50, borderRadius: 12 }}
                            />
                        </View>
                    </View>

                    {/* Content */}
                    <View style={styles.content}>
                        <View style={styles.badgeRow}>
                            <View style={styles.newBadge}>
                                <Star size={10} color="#f59e0b" fill="#f59e0b" />
                                <Text style={styles.newBadgeText}>NEW VERSION</Text>
                            </View>
                        </View>

                        <Text style={styles.title}>Update Available</Text>
                        <Text style={styles.subtitle}>
                            A newer version of Navala Travel Health is ready for you.
                        </Text>

                        {/* Version pills */}
                        <View style={styles.versionRow}>
                            <View style={styles.versionPill}>
                                <Text style={styles.versionLabel}>Current</Text>
                                <Text style={styles.versionNum}>{CURRENT_APP_VERSION}</Text>
                            </View>
                            <ArrowRight size={18} color="#94a3b8" />
                            <View style={[styles.versionPill, styles.versionPillNew]}>
                                <Text style={[styles.versionLabel, { color: '#2563eb' }]}>Latest</Text>
                                <Text style={[styles.versionNum, { color: '#1d4ed8' }]}>{updateConfig.latest_version}</Text>
                            </View>
                        </View>

                        {/* Store buttons */}
                        <View style={styles.storeButtons}>
                            <TouchableOpacity style={styles.playBtn} onPress={handlePlayStore} activeOpacity={0.85}>
                                <View style={styles.storeBtnInner}>
                                    <View style={styles.storeIconBox}>
                                        <FontAwesome5 name="google-play" size={24} color="#e2e8f0" />
                                    </View>
                                    <View>
                                        <Text style={styles.storeSmallText}>GET IT ON</Text>
                                        <Text style={styles.storeBigText}>Google Play</Text>
                                    </View>
                                </View>
                            </TouchableOpacity>

                            <TouchableOpacity style={styles.appleBtn} onPress={handleAppStore} activeOpacity={0.85}>
                                <View style={styles.storeBtnInner}>
                                    <View style={styles.storeIconBox}>
                                        <FontAwesome5 name="apple" size={28} color="#fff" />
                                    </View>
                                    <View>
                                        <Text style={[styles.storeSmallText, { color: '#e2e8f0' }]}>DOWNLOAD ON THE</Text>
                                        <Text style={[styles.storeBigText, { color: '#fff' }]}>App Store</Text>
                                    </View>
                                </View>
                            </TouchableOpacity>
                        </View>

                        {!updateConfig.force_update && (
                            <TouchableOpacity onPress={handleDismiss} style={styles.laterBtn}>
                                <Text style={styles.laterText}>Remind me later</Text>
                            </TouchableOpacity>
                        )}

                        {updateConfig.force_update && (
                            <View style={styles.forceBanner}>
                                <Text style={styles.forceText}>
                                    ⚠️ This update is required to continue using the app.
                                </Text>
                            </View>
                        )}
                    </View>
                </Animated.View>
            </View>
        </Modal>
    );
};

const styles = StyleSheet.create({
    overlay: {
        flex: 1,
        backgroundColor: 'rgba(15, 23, 42, 0.72)',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 24,
    },
    card: {
        width: '100%',
        maxWidth: 360,
        backgroundColor: '#ffffff',
        borderRadius: 28,
        overflow: 'hidden',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 20 },
        shadowOpacity: 0.3,
        shadowRadius: 40,
        elevation: 20,
    },
    closeBtn: {
        position: 'absolute',
        top: 14,
        right: 14,
        zIndex: 10,
        width: 28,
        height: 28,
        borderRadius: 14,
        backgroundColor: 'rgba(255,255,255,0.25)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    headerStripe: {
        height: 50,
        backgroundColor: '#1e3a8a',
        justifyContent: 'flex-end',
        alignItems: 'center',
        paddingBottom: 0,
        // Gradient-like layered effect
        borderBottomLeftRadius: 0,
        borderBottomRightRadius: 0,
    },
    iconCircle: {
        width: 72,
        height: 72,
        borderRadius: 36,
        backgroundColor: '#ffffffff',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: -36,
        borderWidth: 4,
        borderColor: '#fff',
        shadowColor: '#2563eb',
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.4,
        shadowRadius: 16,
        elevation: 8,
    },
    content: {
        paddingTop: 52,
        paddingHorizontal: 24,
        paddingBottom: 24,
        alignItems: 'center',
    },
    badgeRow: {
        marginBottom: 12,
    },
    newBadge: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
        backgroundColor: '#fef3c7',
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 20,
        borderWidth: 1,
        borderColor: '#fde68a',
    },
    newBadgeText: {
        fontSize: 10,
        fontWeight: '800',
        color: '#b45309',
        letterSpacing: 1,
    },
    title: {
        fontSize: 24,
        fontWeight: '800',
        color: '#0f172a',
        textAlign: 'center',
        marginBottom: 8,
    },
    subtitle: {
        fontSize: 14,
        color: '#64748b',
        textAlign: 'center',
        lineHeight: 21,
        marginBottom: 20,
    },
    versionRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        marginBottom: 24,
    },
    versionPill: {
        backgroundColor: '#f1f5f9',
        paddingHorizontal: 16,
        paddingVertical: 4,
        borderRadius: 12,
        alignItems: 'center',
    },
    versionPillNew: {
        backgroundColor: '#eff6ff',
        borderWidth: 1.5,
        borderColor: '#bfdbfe',
    },
    versionLabel: {
        fontSize: 10,
        fontWeight: '600',
        color: '#94a3b8',
        textTransform: 'uppercase',
        letterSpacing: 0.5,
    },
    versionNum: {
        fontSize: 8,
        fontWeight: '800',
        color: '#334155',
        fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
    },
    storeButtons: {
        width: '100%',
        gap: 8,
        marginBottom: 8,
    },
    playBtn: {
        backgroundColor: '#1a1a2e',
        borderRadius: 14,
        paddingVertical: 8,
        paddingHorizontal: 20,
    },
    appleBtn: {
        backgroundColor: '#1e3a8a',
        borderRadius: 14,
        paddingVertical: 8,
        paddingHorizontal: 20,
    },
    storeBtnInner: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 14,
    },
    storeIconBox: {
        width: 36,
        height: 36,
        justifyContent: 'center',
        alignItems: 'center',
    },
    storeEmoji: {
        fontSize: 26,
    },
    storeSmallText: {
        fontSize: 10,
        fontWeight: '600',
        color: '#94a3b8',
        letterSpacing: 0.8,
    },
    storeBigText: {
        fontSize: 17,
        fontWeight: '800',
        color: '#fff',
    },
    laterBtn: {
        paddingVertical: 8,
    },
    laterText: {
        fontSize: 13,
        color: '#94a3b8',
        fontWeight: '600',
        textDecorationLine: 'underline',
    },
    forceBanner: {
        backgroundColor: '#fef2f2',
        borderRadius: 10,
        padding: 12,
        borderWidth: 1,
        borderColor: '#fecaca',
        marginTop: 4,
    },
    forceText: {
        fontSize: 12,
        color: '#b91c1c',
        textAlign: 'center',
        fontWeight: '600',
        lineHeight: 18,
    },
});
