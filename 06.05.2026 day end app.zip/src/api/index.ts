// Central API exports for the mobile app
// Import all patient-related APIs from this file

export { AuthApi } from './features/auth';
export { PlansApi } from './features/plans';
export { UserApi } from './features/user';
export { AppointmentsApi } from './features/appointments';
export { ItineraryApi } from './features/itinerary';
export { ConsentApi } from './features/consent';
export { SystemConfigApi } from './features/systemConfig';


export { PrescriptionApi } from './features/prescription';


// Export config for direct access if needed
export { API_BASE_URL, API_PREFIX, apiClient } from './config';
