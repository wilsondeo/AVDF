export const API_BASE_URL = 'https://travelhealth.navalaglobal.com'; // Update this to your local IP for physical device testing
export const API_PREFIX = '/api';

export const ENDPOINTS = {
  HEALTH: '/health',
  PLANS: '/plans', // Public plans at root
  AUTH: {
    LOGIN: `${API_PREFIX}/auth/login`,
    REGISTER: `${API_PREFIX}/auth/register`,
    REFRESH: `${API_PREFIX}/auth/refresh`,
  },
  USER: {
    PLAN: `${API_PREFIX}/user/plan`,
  },
  PAYMENTS: {
    CREATE_INTENT: `${API_PREFIX}/payments/create-intent`,
    MY_PAYMENTS: `${API_PREFIX}/payments/my`,
  },
  APPOINTMENTS: {
    REQUEST: `${API_PREFIX}/appointments/request`,
    MY_REQUESTS: `${API_PREFIX}/appointments/my-requests`,
  },
  LOCATIONS: `${API_PREFIX}/locations`,
};
