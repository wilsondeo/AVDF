import { apiClient, API_PREFIX } from '../config';

export const SystemConfigApi = {
  get: async (key: string) => {
    try {
      const response = await apiClient.get(`${API_PREFIX}/system-configs/${key}`);
      return response;
    } catch (error: any) {
      return { success: false, message: error.message };
    }
  }
};
