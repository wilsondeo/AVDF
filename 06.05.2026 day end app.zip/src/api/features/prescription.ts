import { apiClient, API_PREFIX } from '../config';
import { ApiResponse } from '../../types/api.types';

export interface Medicine {
    medicineName: string;
    dosage: string;
    frequency: string;
    duration?: string;
    foodInstructions?: string;
}

export interface Prescription {
    id: number;
    prescriptionUuid: string;
    doctorName?: string;
    Doctor?: {
        User?: {
            firstName: string;
            lastName: string;
        };
        specialization?: string;
    };
    diagnosis: string;
    generalAdvice?: string;
    restrictions?: string;
    medicines: Medicine[];
    createdAt: string;
    created_at?: string;
    Appointment?: {
        request?: {
            familyMember?: {
                firstName: string;
                lastName: string;
                relationship: string;
            };
        };
    };
}

export const PrescriptionApi = {
    async getForPatient(): Promise<ApiResponse<Prescription[]>> {
        return apiClient.get(`${API_PREFIX}/prescription/patient`) as unknown as Promise<ApiResponse<Prescription[]>>;
    }
};
