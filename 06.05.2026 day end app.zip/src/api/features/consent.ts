import { apiClient, API_PREFIX } from '../config';
import { ApiResponse } from '../../types/api.types';

export const ConsentApi = {
    async getConsent(): Promise<ApiResponse<any>> {
        return apiClient.get(`${API_PREFIX}/consent`) as unknown as Promise<ApiResponse<any>>;
    },
};
