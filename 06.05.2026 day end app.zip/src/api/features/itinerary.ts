import { apiClient, API_PREFIX } from '../config';
import { ApiResponse } from '../../types/api.types';

export interface ItineraryItem {
    locationId: number;
    arrivalDate?: string;
    departureDate?: string;
}

export const ItineraryApi = {
    async save(destinations: ItineraryItem[]): Promise<ApiResponse<any>> {
        return apiClient.post(`${API_PREFIX}/itinerary`, { destinations }) as unknown as Promise<ApiResponse<any>>;
    },

    async getMyItinerary(): Promise<ApiResponse<any[]>> {
        return apiClient.get(`${API_PREFIX}/itinerary/my`) as unknown as Promise<ApiResponse<any[]>>;
    }
};
